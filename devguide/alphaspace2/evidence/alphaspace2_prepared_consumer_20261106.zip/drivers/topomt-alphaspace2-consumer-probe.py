import json,time
from pathlib import Path
import molsysmt as msm
import topomt as tmt
from devtools.provider_handoff import prepare_reference_source
T=Path('/dev/shm/topomt-alphaspace2-consumer-101');source,selection=prepare_reference_source(Path('/dev/shm/topomt-current-installed-101/harness/prepared.h5msm'))
start=time.monotonic();result=tmt.get_provider_output(source,method='alphaspace2',selection=selection,structure_indices=1,chemical_state=0)
result.run.save(T/'probe-original.zip');msm.convert(source,to_form='file:h5msm',output_filename=T/'probe-source.h5msm')
print(json.dumps({'seconds':time.monotonic()-start,'pocket_count':len(result.pockets),'ids':[p.source_id for p in result.pockets],'member_counts':[len(p.atom_indices) for p in result.pockets]}),flush=True)
from pharmacophoremt.modeler import get_features
pocket=result.pockets[0]
features=get_features(source,selection=list(pocket.atom_indices),structure_index=1,chemical_state=0,features=['hydrophobicity'])
print(json.dumps({'explicit_candidate_pocket':pocket.source_id,'hydrophobic_features':len(features['features'])}),flush=True)
