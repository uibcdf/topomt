import json
from pathlib import Path
import molsysmt as msm
import topomt as tmt
from pharmacophoremt.modeler import get_features
T=Path('/dev/shm/topomt-alphaspace2-consumer-101')
source=msm.convert(T/'probe-source.h5msm',to_form='molsysmt.MolSys')
output=tmt.get_provider_output(source,method='alphaspace2',backend='files',bundle_file=T/'probe-original.zip')
pocket=output.pockets[0]
inventory=get_features(source,selection=list(pocket.atom_indices),structure_index=1,chemical_state=0,features=['hb donor','hb acceptor'])
rows=[{'kind':r['kind'],'atom_indices':r['atom_indices'],'center_nm':r['center'].to('nm').magnitude.tolist()} for r in inventory['features']]
result={'pocket_id':pocket.source_id,'features':rows,'selected_atoms':inventory['selected_atom_indices']}
(T/'polar-probe.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
