import json,collections
from pathlib import Path
import molsysmt as msm
import topomt as tmt
T=Path('/dev/shm/topomt-alphaspace2-consumer-101');s=msm.convert(T/'probe-source.h5msm',to_form='molsysmt.MolSys')
r=tmt.get_provider_output(s,method='alphaspace2',backend='files',bundle_file=T/'probe-original.zip')
rows=[{'id':p.source_id,'atom_types':dict(collections.Counter(msm.get(s,element='atom',selection=list(p.atom_indices),atom_type=True)))} for p in r.pockets]
print(json.dumps(rows,indent=2),flush=True);(T/'atom-membership-probe.json').write_text(json.dumps(rows,indent=2)+'\n')
