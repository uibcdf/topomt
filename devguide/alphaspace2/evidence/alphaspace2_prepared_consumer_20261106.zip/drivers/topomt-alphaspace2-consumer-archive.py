"""Retain bounded prepared AlphaSpace2 evidence without installation claims."""
import hashlib
import json
from pathlib import Path
import subprocess
from zipfile import ZipFile, ZIP_DEFLATED

repo=Path('/home/liliana/repos@uibcdf/topomt')
root=Path('/dev/shm/topomt-alphaspace2-consumer-101')
producer=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert producer=='ce4708a2e5338757ce774a6b0750424324704e30'
def sha(data): return hashlib.sha256(data).hexdigest()
def write(path,obj): path.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def events(stem):
    return [json.loads(line) for line in (root/(stem+'-events.jsonl')).read_text().splitlines()]
def finish(stem):
    row=events(stem)[-1]
    assert row['type']=='session_finish' and row['complete'] and not row['artifact_policy']['truncated']
    return {k:row[k] for k in ('counts','duration','exitstatus')}
all_nodes={r['nodeid'] for r in events('regression') if r['type']=='phase'}
passed={r['nodeid'] for stem in ('regression','fpocket-controls','fpocket-state') for r in events(stem) if r['type']=='phase' and r['phase']=='call' and r['outcome']=='passed'}
assert len(all_nodes)==523 and all_nodes==passed
coverage={'unique_selected_cases':len(all_nodes),'unique_passed_cases':len(passed),
    'all_selected_cases_executed_and_passed':True,
    'initial_skips':8,'explicit_fpocket_followup_passes':8,
    'reason':'Initial command used TOPO_EXE_FPOCKET instead of required TOPOMT_FPOCKET_CMD; seven prepared/source cases and one nonzero-state case subsequently passed with the required original executable.',
    'passed_nodeids':sorted(passed)}
write(root/'coverage-receipt.json',coverage)
versions=json.loads((root/'standalone/receipt.json').read_text())
files={}
def add(name,path):
    assert name not in files
    files[name]=Path(path).read_bytes()
for path in sorted(root.iterdir()):
    if path.is_file() and path.suffix in {'.json','.jsonl','.xml','.log','.py','.zip','.h5msm'}:
        add(path.name,path)
for folder in ('standalone','engine-free'):
    for path in sorted((root/folder).rglob('*')):
        if path.is_file():add(str(path.relative_to(root)),path)
for name in ('consumer-probe','consumer-membership','consumer-atom-probe','consumer-polar-probe'):
    path=Path('/tmp/topomt-alphaspace2-'+name+'.py')
    if path.exists():add('drivers/'+path.name,path)
add('drivers/topomt-alphaspace2-consumer-archive.py',__file__)
add('inputs/prepared.h5msm','/dev/shm/topomt-current-installed-101/harness/prepared.h5msm')
for name in ('original-source.json','public-artifacts.json','engine-installation.json'):
    add('original-engine/'+name,Path('/dev/shm/topomt-alphaspace2-101')/name)
paths=['devtools/provider_handoff.py','devtools/qualify_library_handoff.py','devtools/qualify_alphaspace2_handoff.py','devtools/qualify_pocketeer_handoff.py','devtools/qualify_pharmacophore_handoff.py','tests/test_provider_handoff_tools.py','tests/methods/alphaspace2/test_pharmacophore_handoff.py','docs/content/user/third_party_engines.md']
for path in paths:
    data=(repo/path).read_bytes()
    assert data==subprocess.check_output(['git','show',producer+':'+path],cwd=repo)
    files['producer/'+path]=data
runtime=subprocess.check_output(['git','ls-files','-z','topomt','molsysviewer_topomt'],cwd=repo).decode().split('\0')
runtime_manifest={name:sha((repo/name).read_bytes()) for name in runtime if name}
assert subprocess.check_output(['git','diff','--name-only','HEAD','--','topomt','molsysviewer_topomt'],cwd=repo,text=True).strip()=='topomt/_version.py'
assert runtime_manifest['topomt/_version.py']=='91af00335ecf06be1573c95e22dbba13bfaa0a9e472ffa3de802cee87dc38baf'
files['producer/runtime-source-sha256.json']=(json.dumps(runtime_manifest,indent=2,sort_keys=True)+'\n').encode()
refs=['devguide/pocketeer/evidence/pocketeer_installed_handoff_20261106.json','devguide/alphaspace2/evidence/alphaspace2_arguments_20261106.json','devguide/alphaspace2/evidence/alphaspace2_saved_output_20261106.json']
context={'base_prefix':'/dev/shm/topomt-current-installed-101/env','original_engine_overlay':'/dev/shm/topomt-alphaspace2-101/engine-overlay','retained_qualification_references':{name:sha((repo/name).read_bytes()) for name in refs},'reused_prefix_is_not_current_candidate_qualification':True,'molsysmt_commit':'00abb958fb93649131d5ce5fe5e12e90cf4900e9','pharmacophoremt_commit':'b934471ac8ab8bdb1bd7646550ac23baeb07daa7','module_origins':versions['module_origins'],'package_version_labels':versions['package_versions'],'producer':producer,'human_version_file_preserved':True,'source_test_command_environment':'PYTHONDONTWRITEBYTECODE=1; PYTEST_DISABLE_PLUGIN_AUTOLOAD=1; repo source + explicit original overlay; public pytest-receptor 1.2.0; see event session_start argv for selection.'}
files['dependency-context.json']=(json.dumps(context,indent=2,sort_keys=True)+'\n').encode()
manifest={name:{'bytes':len(data),'sha256':sha(data)} for name,data in files.items()}
files['MANIFEST.json']=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
dest=repo/'devguide/alphaspace2/evidence/alphaspace2_prepared_consumer_20261106.zip'
assert not dest.exists()
with ZipFile(dest,'w',compression=ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(files.items()):archive.writestr(name,data)
with ZipFile(dest) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist())==set(files)
    for name,item in manifest.items():assert sha(archive.read(name))==item['sha256']
rows=[{'policy':row['policy'],'pocket_count':row['handoff']['pocket_count'],'selected_pocket':row['consumer']['context']['pocket_id'],'member_atoms':len(row['consumer']['pocket_atom_indices']),'site_count':row['consumer']['site_count'],'site_source_atoms':[s['atom_indices'] for s in row['consumer']['sites']],'run_id':row['handoff']['run_id'],'source_sha256':row['handoff']['source_sha256'],'original_bundle_sha256':row['handoff']['original_bundle_sha256'],'query_sha256':row['consumer']['query_sha256']} for row in versions['rows']]
sidecar={'schema_version':1,'date':'2026-11-06','owner':'uibcdf/topomt#101','producer':producer,'scope':'Prepared-source original AlphaSpace2 execution, engine-free saved recovery and public PharmacophoreMT acceptor-derived donor control; source-only qualification.','archive':{'name':dest.name,'bytes':dest.stat().st_size,'members':len(files),'sha256':sha(dest.read_bytes())},'results':{name:finish(name) for name in ('comparison-red','red','regression','fpocket-controls','fpocket-state','distribution','distribution-final')},'coverage':{k:v for k,v in coverage.items() if k!='passed_nodeids'},'standalone_checks':versions['checks'],'engine_free_checks':json.loads((root/'engine-free-receipt.json').read_text())['checks'],'measured_profiles':rows,'recipe':{'source_frame':1,'chemical_state':0,'receptor_feature':'hb acceptor','target_sites':'hb donor','projection_direction':{'value':[1,0,0],'unit':'dimensionless'},'distance':{'value':0.30,'unit':'nm'},'target_direction':{'value':[-1,0,0],'unit':'dimensionless'},'matching_radius':{'value':0.15,'unit':'nm'},'membership_expanded':False,'chemical_preparation':False},'checks':{'ruff_lint':'passed','ruff_format_files':456,'mypy_source_files':6,'distribution_reporting_cases':20,'docs_build':'passed','docs_known_warnings':12,'source_files_match_producer':True,'runtime_files_unchanged_except_preserved_human_version':True,'public_pytest_receptor':'1.2.0'},'preserved_human_version_sha256':runtime_manifest['topomt/_version.py'],'dependency_context':context,'limits':['One historical prepared ERalpha fragment reference state, unbound original default min_vertices=20, all 4003 protein atoms including H, selected frame 1; no alternative-state or bound-consumer admission.','All 13 actual pockets yield zero hydrophobic features in the retained exploratory public recognition probe; the distinct polar recipe preserves that negative result and exact original lining membership.','Two caller-declared complementary donor placements; no inferred orientations, binding relevance, affinity, fit or exact volumetric region.','Generic undefined-measurement comparison guard uses a synthetic NaN score; it does not claim an actual fpocket undefined score.','Base prefix/original overlay qualification is reused; no updated installed TopoMT candidate or general hosted/component/full-suite/matrix/public-delivery qualification.','Initial documentation build had one new cross-reference warning, corrected before final build; initial administrative run lacked setuptools and passed with the qualified build-tool overlay.']}
write(dest.with_suffix('.json'),sidecar)
print(json.dumps({'archive':sidecar['archive'],'coverage':sidecar['coverage'],'measured_profiles':rows},indent=2))
