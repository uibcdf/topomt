import json
from pathlib import Path
import molsysmt as msm
import numpy as np
import topomt as tmt
from pharmacophoremt.modeler import get_features
T=Path('/dev/shm/topomt-alphaspace2-consumer-101');source=msm.convert(T/'probe-source.h5msm',to_form='molsysmt.MolSys')
output=tmt.get_provider_output(source,method='alphaspace2',backend='files',bundle_file=T/'probe-original.zip')
rows=[]
for p in output.pockets:
 inventory=get_features(source,selection=list(p.atom_indices),structure_index=1,chemical_state=0,features=['hydrophobicity'])
 rows.append({'pocket_id':p.source_id,'member_count':len(p.atom_indices),'hydrophobic_features':len(inventory['features']),'undefined_nonpolar_occupancy':bool(np.isnan(p.measurements['occupancy_nonpolar'].original_value))})
print(json.dumps(rows,indent=2),flush=True);(T/'membership-probe.json').write_text(json.dumps(rows,indent=2)+'\n')
