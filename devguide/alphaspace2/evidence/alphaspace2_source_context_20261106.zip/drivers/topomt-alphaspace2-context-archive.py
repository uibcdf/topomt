import base64,hashlib,importlib,importlib.metadata as metadata,json,shutil,subprocess,sys,zipfile
from pathlib import Path
T=Path('/dev/shm/topomt-alphaspace2-context-101');PREV=Path('/dev/shm/topomt-alphaspace2-101');R=Path('/home/liliana/repos@uibcdf/topomt');D=R/'devguide/alphaspace2/evidence'
producer=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert producer=='4bb881d1d6f0f4e542dd28e0e5947f9bf066127c'
changed=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',producer],cwd=R,text=True).splitlines()
source_hashes={}
for n in changed:
 b=(R/n).read_bytes();assert b==subprocess.check_output(['git','show',producer+':'+n],cwd=R);source_hashes[n]=hashlib.sha256(b).hexdigest()
records={};modules={}
for name in ['alphaspace2','mdtraj','Cython','configargparser']:
 d=metadata.distribution(name);count=0
 for f in d.files:
  if f.hash is None:continue
  p=Path(d.locate_file(f)).resolve();assert p.is_relative_to(PREV/'engine-overlay')
  digest=base64.urlsafe_b64encode(hashlib.new(f.hash.mode,p.read_bytes()).digest()).rstrip(b'=').decode();assert digest==f.hash.value;count+=1
 records[name]={'version':d.version,'record_hashes_checked':count,'metadata_origin':str(d._path)}
for name in ['topomt','topomt.third_party.alphaspace2.library','molsysmt','alphaspace2','mdtraj','argdigest','pyunitwizard','depdigest','smonitor','pytest_receptor']:
 module=importlib.import_module(name);p=Path(module.__file__).resolve();modules[name]={'origin':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
identity={'producer':producer,'committed_files':source_hashes,'python':sys.version,'prefix':sys.prefix,'primary_origins':modules,'overlay_records':records,'preserved_human_version_sha256':hashlib.sha256((R/'topomt/_version.py').read_bytes()).hexdigest(),'scope':'Separate source-profile identity probe; not before/after instrumentation of pytest or an updated installed TopoMT candidate.'}
(T/'runtime-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
(T/'producer.patch').write_bytes(subprocess.check_output(['git','show','--format=fuller',producer],cwd=R))
files={}
def add(p,n):
 assert p.is_file() and not p.is_symlink();assert n not in files;files[n]=p
for p in T.iterdir():
 if p.is_file() and p.suffix in {'.json','.jsonl','.xml','.log','.txt','.patch'}:add(p,p.name)
for n in changed:add(R/n,'producer/'+n)
for p in (T/'standalone').rglob('*'):
 if p.is_file():add(p,str(p.relative_to(T)))
for p in Path('/tmp').glob('topomt-alphaspace2-context-*.py'):add(p,'drivers/'+p.name)
for n in ['public-artifacts.json','original-source.json','engine-installation.json']:add(PREV/n,'original-profile/'+n)
support={n.split('::')[0] for n in json.loads((T/'regression-command.json').read_text()) if n.startswith('tests/')}
support.update(['devtools/provider_handoff.py','devtools/qualify_fpocket_handoff.py','devtools/qualify_pocketeer_handoff.py','devtools/qualify_pharmacophore_handoff.py'])
for n in sorted(support-set(changed)):add(R/n,'support/'+n)
manifest={n:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for n,p in sorted(files.items())}
name='alphaspace2_source_context_20261106';archive=T/(name+'.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,r in manifest.items():
  b=z.read(n);assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
def result(name):
 rows=[json.loads(l) for l in (T/(name+'-events.jsonl')).read_text().splitlines()]
 r=next(r for r in reversed(rows) if r['type']=='session_finish')
 return {'counts':r['counts'],'duration_seconds':r['duration'],'exitstatus':r['exitstatus']}
control=json.loads((T/'standalone/receipt.json').read_text())
summary={'date':'2026-11-06','owner':'uibcdf/topomt#101','fidelity_owner':'uibcdf/topomt#19','producer':producer,'archive':{'name':archive.name,'bytes':archive.stat().st_size,'members':len(manifest)+1,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'tests':{n:result(n) for n in ['red','green','green-final','regression','distribution']},'source_profiles':control['rows'],'independent_control_checks':control['checks'],'checks':{'ruff_lint':'passed','ruff_formatted_files':448,'mypy_source_files':6,'distribution_runtime_resources':628,'docs_build':'passed','docs_known_warnings':12,'public_pytest_receptor':'1.2.0','source_files_match_producer':True,'overlay_record_hashes_checked':sum(r['record_hashes_checked'] for r in records.values())},'tolerances':{'saved_source_coordinates':{'absolute':1e-12,'unit':'nm','relative':0},'submitted_pdb_coordinates':{'absolute':0.00051,'unit':'angstroms','relative':0},'mdtraj_loaded_coordinates':{'absolute':0.000051,'unit':'nm','relative':4*2**-23}},'preserved_human_version_sha256':identity['preserved_human_version_sha256'],'limits':control['limits']+['Ordinary independent-prefix dependencies are reused with four original-engine packages in a separate overlay.','Initial exact JSON-context equality failed on about 1e-16 nm unit-roundtrip differences; corrected tests reuse the existing physical tolerance and preserve each real run/byte identity.','Runtime identity/overlay RECORD evidence is a separate probe, not before/after pytest instrumentation.','Initial mypy optional-context narrowing failure and its correction are retained.','No new installed TopoMT qualification, prepared PharmacophoreMT receiving, native equivalence, hosted/full-suite/matrix or public-delivery admission.']}
(D/(name+'.json')).write_text(json.dumps(summary,indent=2)+'\n');shutil.copy2(archive,D/archive.name);print(json.dumps(summary['archive']),flush=True)
