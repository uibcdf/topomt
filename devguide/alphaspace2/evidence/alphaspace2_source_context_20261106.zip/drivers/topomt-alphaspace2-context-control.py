import hashlib,importlib.metadata as metadata,json,sys,tempfile,zipfile
from pathlib import Path
import molsysmt as msm
import numpy as np
import topomt as tmt
from topomt import pyunitwizard as puw
from topomt.provider_output import ProviderRun
from topomt.third_party.pdb_context import reference_chemical_context,source_input_context,validate_source_input_context
from devtools.provider_handoff import prepare_reference_source
from tests.methods.fpocket4.test_chemical_context import _with_states
T=Path('/dev/shm/topomt-alphaspace2-context-101');ROOT=T/'standalone';ROOT.mkdir(exist_ok=False)
with tempfile.TemporaryDirectory(dir=T/'scratch') as folder:
 p=Path(folder)/'2pk4.pdb'
 with zipfile.ZipFile(Path(tmt.__file__).parent/'data/CASTpFold_server/2pk4.zip') as z:p.write_bytes(z.read('2pk4.pdb'))
 seed_sha=hashlib.sha256(p.read_bytes()).hexdigest();base,selected=prepare_reference_source(p)
receptor=_with_states(base,reference=1);binder=_with_states(base,reference=0)
ligand=msm.select(binder,selection='group_name=="ACA"')
rows=[];outputs=[]
for tag,policy in [('nm_ps',['nm','ps','radians']),('pm_fs',['pm','fs','radians'])]:
 out=ROOT/tag;out.mkdir()
 with puw.context(standard_units=policy):
  active=puw.configure.get_standard_units()
  sources=[]
  for name,original,frame,index in [('receptor',receptor,1,1),('binder',binder,0,0)]:
   path=out/(name+'.h5msm');msm.convert(original,to_form='file:h5msm',output_filename=path)
   restored=msm.convert(path,to_form='molsysmt.MolSys')
   assert reference_chemical_context(restored,index,provider='AlphaSpace2')==reference_chemical_context(original,index,provider='AlphaSpace2')
   validate_source_input_context(restored,source_input_context(original,frame),frame)
   sources.append(restored)
  result=tmt.get_provider_output(sources[0],method='alphaspace2',selection=np.asarray(selected[::-1]),structure_indices=1,chemical_state=1,binder=sources[1],binder_selection=np.asarray(ligand[::-1]),binder_structure_indices=0,binder_chemical_state=0,min_vertices=1)
  result.run.save(out/'original.zip');assert ProviderRun.load(out/'original.zip')==result.run
  assert puw.configure.get_standard_units()==active
  assert result.run.metadata['distribution_version']=='0.1.2'
  records={}
  for name,source,frame in [('receptor',sources[0],1),('binder',sources[1],0)]:
   context=result.run.metadata if name=='receptor' else result.run.metadata['binder']
   captured=json.loads(result.run.get_artifact(context['source_context_artifact']))
   validate_source_input_context(source,captured,frame)
   path=out/(name+'.h5msm')
   records[name]={'path':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'chemical_state_context':context['chemical_state_context'],'frame':frame,'selected_count':len(context['selected_atom_indices']),'full_atom_count':captured['n_atoms']}
   msm.set(source,structure_indices=frame,coordinates=msm.get(source,structure_indices=frame,coordinates=True)+puw.quantity([[[1.,0.,0.]]],'nm'))
   assert json.loads(result.run.get_artifact(context['source_context_artifact']))==captured
  row={'policy':policy,'source_records':records,'run_id':result.run.run_id,'pocket_count':len(result.pockets),'pocket_ids':[p.source_id for p in result.pockets],'membership_counts':[len(p.atom_indices) for p in result.pockets],'checks':{'both_sources_persist_and_restore':True,'reference_fingerprints_preserved':True,'source_maps_and_loaded_rows_validated':True,'bundle_round_trip':True,'application_policy_preserved':True,'result_detached_from_source_changes':True}}
  rows.append(row);outputs.append(result);print(json.dumps(row),flush=True)
a,b=outputs
assert a.run.get_artifact('output/topomt_snapshot.json')==b.run.get_artifact('output/topomt_snapshot.json')
for first,second in zip(a.pockets,b.pockets):
 assert first.source_id==second.source_id and first.atom_indices==second.atom_indices
 for name in first.geometries:
  left,right=first.geometries[name],second.geometries[name]
  np.testing.assert_allclose(left.points_nm,right.points_nm,rtol=0,atol=1e-12)
  if left.radii_nm is not None:np.testing.assert_allclose(left.radii_nm,right.radii_nm,rtol=0,atol=1e-12)
receipt={'profile':'original-alphaspace2-source-context-1','schema_version':1,'python':sys.version,'seed_pdb_sha256':seed_sha,'rows':rows,'checks':{'original_snapshot_bytes_agree':True,'physical_geometries_agree':True},'versions':{n:metadata.version(n) for n in ['topomt','molsysmt','alphaspace2','mdtraj','argdigest','pyunitwizard','depdigest','smonitor','pytest-receptor']},'primary_origins':{'topomt':tmt.__file__,'molsysmt':msm.__file__},'limits':['Structural 2pk4 reference-state bookkeeping with duplicated analytical states; not prepared receptor chemistry or biological/affinity admission.','TopoMT source profile only; a new installed candidate and engine-free AlphaSpace2Output recovery remain pending.','Snapshot scores retain unspecified units; original untyped receptor and existing compatibility adjustments remain.']}
(ROOT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('PASS: both serialized sources, original capture and physical agreement across policies.',flush=True)
