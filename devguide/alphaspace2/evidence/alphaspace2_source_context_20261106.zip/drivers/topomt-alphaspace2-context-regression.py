import json,os,subprocess
from pathlib import Path
T=Path('/dev/shm/topomt-alphaspace2-context-101')
cmd=json.loads(Path('/dev/shm/topomt-alphaspace2-101/regression-command.json').read_text())
cmd=[s.replace('/dev/shm/topomt-alphaspace2-101/regression',str(T/'regression')) for s in cmd]
cmd.append('tests/methods/alphaspace2/test_input_context.py')
(T/'regression-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
env=os.environ.copy();env.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONPATH='/home/liliana/repos@uibcdf/topomt:/dev/shm/topomt-alphaspace2-101/engine-overlay',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(T/'scratch'),TOPOMT_FPOCKET_CMD='/tmp/topomt-pocket-pilot-101.7bZOKK/fpocket/bin/fpocket',TOPOMT_PREPARED_RECEPTOR='/dev/shm/topomt-current-installed-101/harness/prepared.h5msm')
with (T/'regression.log').open('w') as f:p=subprocess.run(cmd,cwd='/home/liliana/repos@uibcdf/topomt',env=env,stdout=f,stderr=subprocess.STDOUT)
print('Regression exit',p.returncode,flush=True);raise SystemExit(p.returncode)
