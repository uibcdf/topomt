import base64,hashlib,importlib.metadata as m,json,sys,tarfile,urllib.request,zipfile
from pathlib import Path
T=Path('/dev/shm/topomt-alphaspace2-101');rows=[]
for name,version in [('alphaspace2','0.1.2'),('mdtraj','1.11.1'),('Cython','3.2.6'),('configargparser','0.0.2')]:
 with urllib.request.urlopen(f'https://pypi.org/pypi/{name}/{version}/json',timeout=25) as response: info=json.load(response)
 for p in sorted((T/'wheels').iterdir()):
  candidates=[r for r in info['urls'] if r['filename']==p.name]
  if not candidates:continue
  r,=candidates;digest=hashlib.sha256(p.read_bytes()).hexdigest();assert digest==r['digests']['sha256']
  rows.append({'name':name,'version':version,'filename':p.name,'size':p.stat().st_size,'sha256':digest,'url':r['url'],'yanked':r['yanked'],'uploaded':r['upload_time_iso_8601']})
(T/'public-artifacts.json').write_text(json.dumps(rows,indent=2)+'\n')
assert len(rows)==4
with tarfile.open(T/'wheels/alphaspace2-0.1.2.tar.gz') as t,zipfile.ZipFile(T/'wheels/alphaspace2-0.1.2-py3-none-any.whl') as z:
 checked={}
 for member in t.getmembers():
  name=member.name.removeprefix('alphaspace2-0.1.2/')
  if member.isfile() and name.startswith('alphaspace2/') and name.endswith('.py'):
   b=t.extractfile(member).read();assert z.read(name)==b
   checked[name]=hashlib.sha256(b).hexdigest()
(T/'original-source.json').write_text(json.dumps({'sdist':'alphaspace2-0.1.2.tar.gz','wheel':'alphaspace2-0.1.2-py3-none-any.whl','wheel_sha256':hashlib.sha256((T/'wheels/alphaspace2-0.1.2-py3-none-any.whl').read_bytes()).hexdigest(),'all_python_files_match_public_sdist':checked},indent=2)+'\n')
modules={}
for name in ['topomt','molsysmt','pharmacophoremt','argdigest','pyunitwizard','depdigest','smonitor','pytest_receptor','alphaspace2','mdtraj']:
 module=__import__(name);p=Path(module.__file__).resolve();modules[name]={'origin':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'metadata_label':m.version(name.replace('_','-'))}
 assert p.is_relative_to(T/'engine-overlay') if name in {'alphaspace2','mdtraj'} else True
records={}
for name in ['alphaspace2','mdtraj','Cython','configargparser']:
 d=m.distribution(name);count=0
 for f in d.files:
  if f.hash is None:continue
  p=Path(d.locate_file(f)).resolve();assert p.is_relative_to(T/'engine-overlay')
  digest=base64.urlsafe_b64encode(hashlib.new(f.hash.mode,p.read_bytes()).digest()).rstrip(b'=').decode();assert digest==f.hash.value;count+=1
 records[name]={'version':d.version,'record_hashes_checked':count,'metadata_origin':str(d._path)}
(T/'runtime-identity.json').write_text(json.dumps({'python':sys.version,'prefix':sys.prefix,'primary_origins':modules,'overlay_records':records,'scope':'Separate source-profile identity probe, not before/after instrumentation of the pytest process or an installed TopoMT claim.'},indent=2)+'\n')
print('Verified four public artifacts,',len(checked),'original Python files and overlay RECORD hashes',flush=True)
