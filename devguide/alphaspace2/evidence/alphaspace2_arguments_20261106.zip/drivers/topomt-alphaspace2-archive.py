import hashlib,json,shutil,subprocess,zipfile
from pathlib import Path
T=Path('/dev/shm/topomt-alphaspace2-101');R=Path('/home/liliana/repos@uibcdf/topomt');D=R/'devguide/alphaspace2/evidence';D.mkdir(exist_ok=True)
producer=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert producer=='3e86d1b2adec16683b5b74bb4666781f276412f2'
changed=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',producer],cwd=R,text=True).splitlines()
files={}
def add(p,n):
 assert p.is_file() and not p.is_symlink();assert n not in files;files[n]=p
for p in T.iterdir():
 if p.is_file() and p.suffix in {'.json','.jsonl','.xml','.log','.txt'}:add(p,p.name)
source_hashes={}
for n in changed:
 p=R/n;assert p.read_bytes()==subprocess.check_output(['git','show',producer+':'+n],cwd=R)
 source_hashes[n]=hashlib.sha256(p.read_bytes()).hexdigest();add(p,'producer/'+n)
support={n.split('::')[0] for n in json.loads((T/'regression-command.json').read_text()) if n.startswith('tests/')}
support.update(['devtools/provider_handoff.py','devtools/qualify_fpocket_handoff.py','devtools/qualify_pocketeer_handoff.py','devtools/qualify_pharmacophore_handoff.py'])
for n in sorted(support-set(changed)):add(R/n,'support/'+n)
(T/'source-identity.json').write_text(json.dumps({'producer':producer,'committed_files':source_hashes,'preserved_human_version_sha256':hashlib.sha256((R/'topomt/_version.py').read_bytes()).hexdigest(),'runtime_profile':'Source TopoMT plus four original-engine packages in an isolated overlay over the retained installed dependency prefix; not a new installed TopoMT candidate.'},indent=2)+'\n');add(T/'source-identity.json','source-identity.json')
(T/'producer.patch').write_bytes(subprocess.check_output(['git','show','--format=fuller',producer],cwd=R));add(T/'producer.patch','producer.patch')
for p in Path('/tmp').glob('topomt-alphaspace2-*.py'):add(p,'drivers/'+p.name)
for p in (T/'wheels').iterdir():
 if p.name.startswith(('alphaspace2-','configargparser-')):add(p,'original-inputs/'+p.name)
for p in (T/'regression').rglob('bound_run.zip'):
 if not any(part.endswith('current') for part in p.relative_to(T).parts):add(p,str(p.relative_to(T)))
manifest={n:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for n,p in sorted(files.items())}
name='alphaspace2_arguments_20261106';archive=T/(name+'.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,r in manifest.items():
  b=z.read(n);assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
def result(name):
 rows=[json.loads(l) for l in (T/(name+'-events.jsonl')).read_text().splitlines()]
 row=next(r for r in reversed(rows) if r['type']=='session_finish')
 return {'counts':row['counts'],'duration_seconds':row['duration'],'exitstatus':row['exitstatus']}
summary={'date':'2026-11-06','owner':'uibcdf/topomt#101','fidelity_owner':'uibcdf/topomt#19','producer':producer,'archive':{'name':archive.name,'bytes':archive.stat().st_size,'members':len(manifest)+1,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'tests':{name:result(name) for name in ['red','green','regression','final-alpha','distribution','distribution-final']},'original_source':json.loads((T/'original-source.json').read_text()),'checks':{'ruff_lint':'passed','ruff_formatted_files':447,'mypy_source_files':7,'distribution_runtime_resources':628,'docs_build':'passed','docs_known_warnings':12,'public_pytest_receptor':'1.2.0','source_files_match_committed_producer':True},'preserved_human_version_sha256':hashlib.sha256((R/'topomt/_version.py').read_bytes()).hexdigest(),'limits':['Source profile only; current installed wheel receipts still refer to their previous producer.','The original reference is PyPI 0.1.2 with the already documented NumPy, MDTraj SASA and unbound-contact compatibility adjustments, not current upstream main.','Initial red includes a missing-MDTraj normalization probe; final optional imports skip only ordinary absent-engine use, while designated real original cases executed.','Four undefined original nonpolar occupancy ratios retain RuntimeWarnings/NaN semantics; zero is not fabricated.','Runtime identity and overlay RECORD checks are a separate probe, not before/after instrumentation of the pytest process.','Receptor/binder reference-state and complete source provenance, engine-free saved reconstruction, prepared PharmacophoreMT receiving and a new installed AlphaSpace2 candidate remain pending.','No new chemical recognition, preparation, pharmacophore or original detector implementation. No hosted/full-suite/matrix/public-release admission.']}
(D/(name+'.json')).write_text(json.dumps(summary,indent=2)+'\n');shutil.copy2(archive,D/archive.name);print(json.dumps(summary['archive']),flush=True)
