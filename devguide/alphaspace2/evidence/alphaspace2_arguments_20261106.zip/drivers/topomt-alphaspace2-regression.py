import json,os,subprocess
from pathlib import Path
T=Path('/dev/shm/topomt-alphaspace2-101')
selectors=json.loads(Path('/dev/shm/topomt-current-installed-101/selectors.json').read_text())
selectors+=['tests/methods/alphaspace2/test_argument_contracts.py','tests/test_provider_output.py']
selectors += ['tests/methods/test_installed_engines.py::'+name for name in ['test_installed_alphaspace2_matches_direct_snapshot','test_installed_alphaspace2_binder_matches_direct_snapshot','test_installed_alphaspace2_rejects_invalid_binder','test_installed_alphaspace2_selects_binder_frame_without_alignment']]
cmd=['/dev/shm/topomt-current-installed-101/env/bin/python','-m','pytest','--noconftest','-p','pytest_receptor.plugin','--receptor=llm','--receptor-events='+str(T/'regression-events.jsonl'),'--junitxml='+str(T/'regression.xml'),'--basetemp='+str(T/'regression'),*selectors]
(T/'regression-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
env=os.environ.copy();env.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONPATH='/home/liliana/repos@uibcdf/topomt:'+str(T/'engine-overlay'),PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(T/'scratch'),TOPOMT_FPOCKET_CMD='/tmp/topomt-pocket-pilot-101.7bZOKK/fpocket/bin/fpocket',TOPOMT_PREPARED_RECEPTOR='/dev/shm/topomt-current-installed-101/harness/prepared.h5msm')
with (T/'regression.log').open('w') as f:p=subprocess.run(cmd,cwd='/home/liliana/repos@uibcdf/topomt',env=env,stdout=f,stderr=subprocess.STDOUT)
print('Regression exit',p.returncode,flush=True);raise SystemExit(p.returncode)
