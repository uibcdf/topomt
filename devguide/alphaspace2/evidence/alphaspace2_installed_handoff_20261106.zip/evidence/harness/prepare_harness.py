"""Stage producer-identical installed tests and separately pinned checker support."""

import ast
import hashlib
import io
import json
import subprocess
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

REPOSITORY = Path('/fast_data/home/liliana/repos@uibcdf/topomt')
PRODUCER = '5ae5c46d94e425eab24b2aeb8420a4f3b697eebe'
CHECKER_REPOSITORY = REPOSITORY.parent / 'molsyssuite'
CHECKER_COMMIT = 'b9852d973e96613a68cab7278491ff647bfd0b7d'
TASK = Path('/tmp/topomt-alphaspace2-installed-y1j8k2e8')
EVIDENCE = Path(__file__).resolve().parent
SEED_ARCHIVE = (
    'devguide/alphaspace2/evidence/'
    'alphaspace2_prepared_consumer_20261106.zip'
)
SEED_MEMBER = 'inputs/prepared.h5msm'
SEED_SHA256 = 'a42ef9868578ba16c62d52a1267d24160b973dca0d50dbc804ca46b6b2fe316a'

SELECTED_MODULES = [
    'tests/methods/alphaspace2/test_argument_contracts.py',
    'tests/methods/alphaspace2/test_input_context.py',
    'tests/methods/alphaspace2/test_saved_output.py',
    'tests/methods/alphaspace2/test_pharmacophore_handoff.py',
    'tests/test_provider_dispatch_arguments.py',
    'tests/test_provider_output.py',
    'tests/test_provider_handoff_tools.py',
]
ORIGINAL_COMPARISONS = [
    'test_installed_alphaspace2_matches_direct_snapshot',
    'test_installed_alphaspace2_binder_matches_direct_snapshot',
    'test_installed_alphaspace2_rejects_invalid_binder',
    'test_installed_alphaspace2_selects_binder_frame_without_alignment',
]
SUPPORT_FILES = [
    'tests/methods/__init__.py',
    'tests/methods/alphaspace2/__init__.py',
    'tests/methods/fpocket4/__init__.py',
    'tests/methods/fpocket4/test_input_preparation.py',
    'tests/methods/fpocket4/test_chemical_context.py',
    'tests/methods/alphaspace2/data/saved_outputs.zip',
    'devtools/provider_handoff.py',
    'devtools/qualify_fpocket_handoff.py',
    'devtools/qualify_library_handoff.py',
    'devtools/qualify_alphaspace2_handoff.py',
    'devtools/qualify_pharmacophore_handoff.py',
]
CHECKER_FILES = [
    'installed_imports.py',
    'noarch_conda.py',
    'conda_release_contract.py',
    'installed_test_dependencies.py',
    'verify_public_conda.py',
]


def git_bytes(repository: Path, revision: str, path: str) -> tuple[bytes, str]:
    """Read exact committed bytes and their Git object identity."""
    identity = f'{revision}:{path}'
    data = subprocess.check_output(['git', 'show', identity], cwd=repository)
    blob = subprocess.check_output(
        ['git', 'rev-parse', identity], cwd=repository, text=True
    ).strip()
    return data, blob


def main() -> None:
    """Create new staging roots and retain their full payload and provenance."""
    for name in ('harness', 'checker-support'):
        if (TASK / name).exists():
            raise FileExistsError(TASK / name)
    for name in ('manifest.json', 'payload.zip'):
        if (EVIDENCE / name).exists():
            raise FileExistsError(EVIDENCE / name)
    files = []

    def write(relative: str, data: bytes, provenance: dict) -> None:
        target = TASK / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as handle:
            handle.write(data)
        if target.read_bytes() != data:
            raise ValueError(f'Staged file differs: {relative}')
        files.append({
            'target': relative,
            'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest(),
            **provenance,
        })

    source_files = [
        *SELECTED_MODULES,
        'tests/methods/test_installed_engines.py',
        *SUPPORT_FILES,
    ]
    for source in source_files:
        data, blob = git_bytes(REPOSITORY, PRODUCER, source)
        write(f'harness/{source}', data, {
            'kind': 'producer-test-or-support',
            'repository': 'uibcdf/topomt',
            'commit': PRODUCER,
            'source': source,
            'git_blob': blob,
        })
    for source in CHECKER_FILES:
        original = f'devtools/scripts/{source}'
        data, blob = git_bytes(CHECKER_REPOSITORY, CHECKER_COMMIT, original)
        write(f'checker-support/{source}', data, {
            'kind': 'unchanged-checker-support',
            'repository': 'uibcdf/molsyssuite',
            'commit': CHECKER_COMMIT,
            'source': original,
            'git_blob': blob,
        })

    selectors = [
        *SELECTED_MODULES,
        *[f'tests/methods/test_installed_engines.py::{name}'
          for name in ORIGINAL_COMPARISONS],
    ]
    generated = {
        'harness/tests/__init__.py': b'',
        'harness/devtools/__init__.py': b'',
        'harness/pytest.ini': b'[pytest]\naddopts = -q\n',
        'harness/selectors.json': (json.dumps(selectors, indent=2) + '\n').encode(),
    }
    for name, data in generated.items():
        write(name, data, {
            'kind': 'generated-harness-control',
            'reason': (
                'Detached namespace anchors and explicit bounded pytest selection; '
                'no runtime implementation or source-root pythonpath.'
            ),
        })

    archive, blob = git_bytes(REPOSITORY, PRODUCER, SEED_ARCHIVE)
    with ZipFile(io.BytesIO(archive)) as saved:
        seed = saved.read(SEED_MEMBER)
    if hashlib.sha256(seed).hexdigest() != SEED_SHA256:
        raise ValueError('Prepared seed differs from the accepted historical input')
    write('harness/inputs/prepared.h5msm', seed, {
        'kind': 'verified-historical-input',
        'repository': 'uibcdf/topomt',
        'commit': PRODUCER,
        'source_archive': SEED_ARCHIVE,
        'archive_git_blob': blob,
        'archive_sha256': hashlib.sha256(archive).hexdigest(),
        'archive_member': SEED_MEMBER,
        'reason': 'Supplied existing chemistry; no preparation or modification.',
    })

    for item in files:
        target = TASK / item['target']
        if target.suffix == '.py':
            ast.parse(target.read_bytes(), filename=str(target))
    if (TASK / 'harness/topomt').exists():
        raise ValueError('A runtime source package entered the detached harness')
    payload = EVIDENCE / 'payload.zip'
    with ZipFile(payload, 'x', compression=ZIP_DEFLATED) as saved:
        for item in files:
            saved.write(TASK / item['target'], item['target'])
    with ZipFile(payload) as saved:
        if saved.testzip() is not None or set(saved.namelist()) != {
            item['target'] for item in files
        }:
            raise ValueError('Durable harness archive inventory differs')
        for item in files:
            if hashlib.sha256(saved.read(item['target'])).hexdigest() != item['sha256']:
                raise ValueError('Durable harness archive bytes differ')
    manifest = {
        'profile': 'alphaspace2-detached-installed-harness-1',
        'producer': PRODUCER,
        'checker_commit': CHECKER_COMMIT,
        'harness_root': str(TASK / 'harness'),
        'checker_support_root': str(TASK / 'checker-support'),
        'preparation_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'payload': {
            'filename': payload.name,
            'bytes': payload.stat().st_size,
            'sha256': hashlib.sha256(payload.read_bytes()).hexdigest(),
        },
        'files': files,
        'selectors': selectors,
        'expected_static_cases': 256,
        'checks': {
            'all_copied_bytes_equal_committed_git_blobs': True,
            'all_staged_python_parses_without_execution': True,
            'durable_payload_crc_inventory_and_sha256_verified': True,
            'no_topomt_runtime_source_package': True,
            'no_scientific_import_or_pytest_execution': True,
        },
        'limits': [
            'Static case count only; actual pytest collection is pending.',
            'Tests/devtools are declared detached support, not installed runtime APIs.',
            'Checker is pinned separately from the administrative SDK.',
            'No installed, scientific, platform or public-package qualification.',
        ],
    }
    with (EVIDENCE / 'manifest.json').open('x') as handle:
        json.dump(manifest, handle, indent=2)
        handle.write('\n')
    print(json.dumps({
        'harness': manifest['harness_root'],
        'checker_support': manifest['checker_support_root'],
        'files': len(files),
        'selectors': len(selectors),
        'manifest': str(EVIDENCE / 'manifest.json'),
        'payload': manifest['payload'],
        'checks': manifest['checks'],
    }, indent=2))


if __name__ == '__main__':
    main()
