"""Independent full prepared AlphaSpace2 receiving controls; source-only #101."""
import hashlib
import importlib.metadata as metadata
import json
from pathlib import Path
import sys

import molsysmt as msm
import numpy as np
from devtools.qualify_alphaspace2_handoff import qualify
from devtools.qualify_pharmacophore_handoff import consume, _same_sites
from topomt import pyunitwizard as puw
from topomt.provider_output import ProviderRun

root=Path('/dev/shm/topomt-alphaspace2-consumer-101/standalone')
assert not root.exists()
root.mkdir()
seed=Path('/dev/shm/topomt-current-installed-101/harness/prepared.h5msm')
assert hashlib.sha256(seed.read_bytes()).hexdigest()=='a42ef9868578ba16c62d52a1267d24160b973dca0d50dbc804ca46b6b2fe316a'
assert metadata.version('alphaspace2')=='0.1.2'
assert 'pharmacophoremt' not in sys.modules
rows=[];models=[];runs=[]
for tag,policy in [('pm_fs',['pm','fs','radians']),('nm_ps',['nm','ps','radians'])]:
    folder=root/tag
    with puw.context(standard_units=policy):
        before=puw.configure.get_standard_units()
        handoff=qualify(seed,folder/'handoff')
        consumer=consume(folder/'handoff',folder/'consumer',pocket_id='alphaspace2:20',
            projection_direction=(1.,0.,0.),distance='0.30 nm',radius='0.15 nm',
            feature='hb acceptor',target_direction=(-1.,0.,0.))
        assert handoff['pocket_count']==13 and consumer['site_count']==2
        try:
            consume(folder/'handoff',folder/'hydrophobic-empty',pocket_id='alphaspace2:20',
                projection_direction=(1.,0.,0.),distance='0.30 nm',radius='0.15 nm')
        except ValueError as error:
            assert 'no hydrophobic features' in str(error)
            negative=str(error)
        else:
            raise AssertionError('Empty hydrophobic recognition became a query')
        assert not (folder/'hydrophobic-empty').exists()
        assert puw.configure.get_standard_units()==before
        from pharmacophoremt.io import load_json
        model=load_json(folder/'consumer/query.json')
        models.append(model)
        runs.append(ProviderRun.load(folder/'handoff/original.zip'))
        rows.append({'policy':policy,'handoff':handoff,'consumer':consumer,
            'active_policy_preserved':True,'empty_hydrophobic_control':negative})
        print(json.dumps({'policy':policy,'pockets':handoff['pocket_count'],
            'sites':consumer['site_count'],'checks':consumer['checks']}),flush=True)
assert _same_sites(models[0],models[1])
for name in ('output/topomt_snapshot.json',):
    assert runs[0].get_artifact(name)==runs[1].get_artifact(name),name
first=msm.convert(root/'pm_fs/handoff/source.h5msm',to_form='molsysmt.MolSys')
second=msm.convert(root/'nm_ps/handoff/source.h5msm',to_form='molsysmt.MolSys')
np.testing.assert_allclose(puw.get_value(msm.get(first,coordinates=True),to_unit='nm'),
    puw.get_value(msm.get(second,coordinates=True),to_unit='nm'),rtol=0,atol=1e-12)
modules=['topomt','molsysmt','pharmacophoremt','argdigest','pyunitwizard','depdigest','smonitor','alphaspace2','mdtraj']
result={'schema_version':1,'profile':'original-alphaspace2-prepared-source-consumer-1',
    'python':sys.version,'seed_sha256':hashlib.sha256(seed.read_bytes()).hexdigest(),
    'package_versions':{name:metadata.version(name) for name in [*modules,'pytest-receptor']},
    'module_origins':{name:str(Path(sys.modules[name].__file__).resolve()) for name in modules},
    'rows':rows,'checks':{'both_full_flows_passed':True,'original_snapshots_equal':True,
        'physical_sites_agree':True,'source_frames_physically_agree':True,'application_policy_preserved':True,
        'empty_hydrophobic_control_preserved':True},
    'limits':['Source control; not new installed candidate qualification.',
        'All 4003 protein atoms including H; unbound original defaults, min_vertices=20.',
        'Two acceptor-derived donor projections, independent caller-declared orientation; no affinity, fit or biological validation.',
        'TopoMT distribution metadata labels do not identify loaded repository source; source origins/hashes are separate evidence.']}
(root/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS: two independent full flows, physical sites, application policy and empty recognition.',flush=True)
