"""Repeat the historical two-policy prepared AlphaSpace2 receiving control."""

import argparse
import hashlib
import importlib.metadata as metadata
import json
import sys
from pathlib import Path
from typing import Any

SOURCE_CHECKOUT = Path('/fast_data/home/liliana/repos@uibcdf/topomt')
SEED_SHA256 = 'a42ef9868578ba16c62d52a1267d24160b973dca0d50dbc804ca46b6b2fe316a'


def run_control(args: argparse.Namespace) -> dict[str, Any]:
    """Execute both complete flows using declared detached support and inputs.

    Parameters
    ----------
    args : argparse.Namespace
        Explicit harness, seed, output, phase and expected_prefix arguments.

    Returns
    -------
    dict
        The persisted receiving receipt. Source and installed phases keep
        separate output directories and profiles.

    Raises
    ------
    FileExistsError
        The output directory already exists.
    ValueError
        A declared path, phase, seed or runtime origin is incompatible.
    AssertionError
        A historical scientific or application-policy control disagrees.

    Notes
    -----
    The enclosing runner owns candidate hashes, full dependency origins and
    before/after integrity. This driver does not preimport PharmacophoreMT.
    """
    harness = args.harness.resolve(strict=True)
    seed = args.seed.resolve(strict=True)
    root = args.output.resolve()
    expected_prefix = args.expected_prefix.resolve(strict=True)
    phase = args.phase
    if phase not in {'source', 'installed'}:
        raise ValueError('Select the source or installed control phase.')
    if not harness.is_dir() or not seed.is_file():
        raise ValueError('The declared harness and seed must exist.')
    if root.exists():
        raise FileExistsError(root)
    if Path(sys.prefix).resolve() != expected_prefix:
        raise ValueError('The interpreter is outside the expected prefix.')
    if hashlib.sha256(seed.read_bytes()).hexdigest() != SEED_SHA256:
        raise ValueError('The prepared seed differs from the historical input.')
    if str(harness) not in sys.path:
        sys.path.insert(0, str(harness))

    import molsysmt as msm
    import numpy as np

    import topomt
    from devtools.qualify_alphaspace2_handoff import qualify
    from devtools.qualify_pharmacophore_handoff import _same_sites, consume
    from topomt import pyunitwizard as puw
    from topomt.provider_output import ProviderRun

    topomt_origin = Path(topomt.__file__).resolve()
    if phase == 'installed':
        if (
            not topomt_origin.is_relative_to(expected_prefix)
            or topomt_origin.is_relative_to(SOURCE_CHECKOUT.resolve())
        ):
            raise ValueError('Installed TopoMT must load from the expected prefix.')
        installed_init = Path(
            metadata.distribution('topomt').locate_file('topomt/__init__.py')
        ).resolve()
        if topomt_origin != installed_init:
            raise ValueError('Another TopoMT source shadows the installed candidate.')
        if topomt.__version__ != metadata.version('topomt'):
            raise ValueError('TopoMT embedded and distribution versions disagree.')

    for function, relative in (
        (qualify, 'devtools/qualify_alphaspace2_handoff.py'),
        (consume, 'devtools/qualify_pharmacophore_handoff.py'),
        (_same_sites, 'devtools/qualify_pharmacophore_handoff.py'),
    ):
        actual = Path(function.__code__.co_filename).resolve()
        if actual != harness / relative:
            raise ValueError('Qualification support did not load from the harness.')
    assert metadata.version('alphaspace2') == '0.1.2'
    assert not any(
        name == 'pharmacophoremt' or name.startswith('pharmacophoremt.')
        for name in sys.modules
    )

    root.mkdir(parents=True)
    rows = []
    models = []
    runs = []
    for tag, policy in (
        ('pm_fs', ['pm', 'fs', 'radians']),
        ('nm_ps', ['nm', 'ps', 'radians']),
    ):
        folder = root / tag
        with puw.context(standard_units=policy):
            before = puw.configure.get_standard_units()
            handoff = qualify(seed, folder / 'handoff')
            consumer = consume(
                folder / 'handoff',
                folder / 'consumer',
                pocket_id='alphaspace2:20',
                projection_direction=(1.0, 0.0, 0.0),
                distance='0.30 nm',
                radius='0.15 nm',
                feature='hb acceptor',
                target_direction=(-1.0, 0.0, 0.0),
            )
            assert handoff['pocket_count'] == 13 and consumer['site_count'] == 2
            # These identities are already reported by the historical recipe;
            # inspect its existing receipt without another recognition operation.
            assert all(len(site['atom_indices']) == 1 for site in consumer['sites'])
            assert sorted(
                site['atom_indices'][0] for site in consumer['sites']
            ) == [1674, 1707]
            assert all(site['features'] == ['hb donor'] for site in consumer['sites'])
            try:
                consume(
                    folder / 'handoff',
                    folder / 'hydrophobic-empty',
                    pocket_id='alphaspace2:20',
                    projection_direction=(1.0, 0.0, 0.0),
                    distance='0.30 nm',
                    radius='0.15 nm',
                )
            except ValueError as error:
                assert 'no hydrophobic features' in str(error)
                negative = str(error)
            else:
                raise AssertionError('Empty hydrophobic recognition became a query')
            assert not (folder / 'hydrophobic-empty').exists()
            assert puw.configure.get_standard_units() == before
            from pharmacophoremt.io import load_json

            model = load_json(folder / 'consumer/query.json')
            models.append(model)
            runs.append(ProviderRun.load(folder / 'handoff/original.zip'))
            rows.append({
                'policy': policy,
                'handoff': handoff,
                'consumer': consumer,
                'active_policy_preserved': True,
                'empty_hydrophobic_control': negative,
            })
            print(json.dumps({
                'policy': policy,
                'pockets': handoff['pocket_count'],
                'sites': consumer['site_count'],
                'checks': consumer['checks'],
            }), flush=True)
    assert _same_sites(models[0], models[1])
    for name in ('output/topomt_snapshot.json',):
        assert runs[0].get_artifact(name) == runs[1].get_artifact(name), name
    first = msm.convert(
        root / 'pm_fs/handoff/source.h5msm', to_form='molsysmt.MolSys'
    )
    second = msm.convert(
        root / 'nm_ps/handoff/source.h5msm', to_form='molsysmt.MolSys'
    )
    np.testing.assert_allclose(
        puw.get_value(msm.get(first, coordinates=True), to_unit='nm'),
        puw.get_value(msm.get(second, coordinates=True), to_unit='nm'),
        rtol=0,
        atol=1e-12,
    )
    modules = [
        'topomt', 'molsysmt', 'pharmacophoremt', 'argdigest',
        'pyunitwizard', 'depdigest', 'smonitor', 'alphaspace2', 'mdtraj',
    ]
    phase_limit = (
        'Source phase permits authorized editable TopoMT; no installed candidate '
        'qualification. Loaded source origins are retained independently of labels.'
        if phase == 'source'
        else 'Installed phase checks the TopoMT origin/version; the enclosing '
        'runner separately verifies the exact candidate and dependency integrity.'
    )
    result = {
        'schema_version': 1,
        'profile': f'original-alphaspace2-prepared-{phase}-consumer-1',
        'phase': phase,
        'python': sys.version,
        'expected_prefix': str(expected_prefix),
        'harness': str(harness),
        'topomt_origin_guard': {
            'origin': str(topomt_origin),
            'installed_prefix_required': phase == 'installed',
            'excluded_source_checkout': str(SOURCE_CHECKOUT),
        },
        'seed_sha256': hashlib.sha256(seed.read_bytes()).hexdigest(),
        'package_versions': {
            name: metadata.version(name) for name in [*modules, 'pytest-receptor']
        },
        'module_origins': {
            name: str(Path(sys.modules[name].__file__).resolve()) for name in modules
        },
        'rows': rows,
        'checks': {
            'both_full_flows_passed': True,
            'original_snapshots_equal': True,
            'physical_sites_agree': True,
            'source_frames_physically_agree': True,
            'application_policy_preserved': True,
            'empty_hydrophobic_control_preserved': True,
            'reported_acceptor_atom_ids_and_donor_family_preserved': True,
        },
        'limits': [
            phase_limit,
            'All 4003 protein atoms including H; unbound original defaults, '
            'min_vertices=20.',
            'Two acceptor-derived donor projections, independent caller-declared '
            'orientation; no affinity, fit or biological validation.',
            'TopoMT distribution metadata labels do not identify loaded repository '
            'source; source origins/hashes are separate evidence.',
        ],
    }
    (root / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
    print(
        'PASS: two independent full flows, physical sites, application policy '
        'and empty recognition.',
        flush=True,
    )
    return result


def main() -> None:
    """Parse explicit control paths and execute the selected receiving phase."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--harness', type=Path, required=True)
    parser.add_argument('--seed', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--phase', choices=['source', 'installed'], required=True)
    parser.add_argument('--expected-prefix', type=Path, required=True)
    run_control(parser.parse_args())


if __name__ == '__main__':
    main()
