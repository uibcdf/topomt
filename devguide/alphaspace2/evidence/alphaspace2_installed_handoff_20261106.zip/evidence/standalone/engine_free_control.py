"""Consume accepted installed AlphaSpace2 runs with both original engines absent."""

import argparse
import hashlib
import importlib.abc
import importlib.metadata as metadata
import json
import sys
from pathlib import Path
from typing import Any


def run_control(args: argparse.Namespace) -> dict[str, Any]:
    """Recover both accepted installed flows through the unchanged public consumer.

    Parameters
    ----------
    args : argparse.Namespace
        Explicit harness, handoff_root, output and expected_prefix paths.

    Returns
    -------
    dict
        Persisted recovery receipt with original run IDs and boolean checks.

    Raises
    ------
    FileExistsError
        The output directory already exists.
    ValueError
        Input evidence, prefix or installed support origins disagree.
    AssertionError
        An engine is present/imported or a historical receiving control fails.
    """
    harness = args.harness.resolve(strict=True)
    handoff_root = args.handoff_root.resolve(strict=True)
    output = args.output.resolve()
    expected_prefix = args.expected_prefix.resolve(strict=True)
    if Path(sys.prefix).resolve() != expected_prefix:
        raise ValueError('The reader interpreter differs from the expected prefix.')
    if output.exists():
        raise FileExistsError(output)
    accepted = json.loads((handoff_root / 'receipt.json').read_text())
    if (
        accepted.get('phase') != 'installed'
        or accepted.get('profile') != 'original-alphaspace2-prepared-installed-consumer-1'
        or not accepted.get('checks')
        or not all(value is True for value in accepted['checks'].values())
    ):
        raise ValueError('The reader requires both completed installed original flows.')
    for name in ('alphaspace2', 'mdtraj'):
        try:
            metadata.distribution(name)
        except metadata.PackageNotFoundError:
            pass
        else:
            raise AssertionError('Engine distribution is installed: ' + name)
    assert not {'alphaspace2', 'mdtraj'}.intersection(sys.modules)
    assert not any(
        name == 'pharmacophoremt' or name.startswith('pharmacophoremt.')
        for name in sys.modules
    )
    attempts = []

    class Block(importlib.abc.MetaPathFinder):
        def find_spec(self, fullname, path=None, target=None):
            if fullname.split('.')[0] in {'alphaspace2', 'mdtraj'}:
                attempts.append(fullname)
                raise AssertionError(
                    'Detector imported during saved consumer receiving: ' + fullname
                )

    blocker = Block()
    sys.meta_path.insert(0, blocker)
    try:
        if str(harness) not in sys.path:
            sys.path.insert(0, str(harness))
        from devtools.qualify_pharmacophore_handoff import consume
        import topomt
        from topomt import pyunitwizard as puw
        from topomt.provider_output import ProviderRun

        if Path(consume.__code__.co_filename).resolve() != (
            harness / 'devtools/qualify_pharmacophore_handoff.py'
        ):
            raise ValueError('Reader support did not load from the detached harness.')
        if not Path(topomt.__file__).resolve().is_relative_to(expected_prefix):
            raise ValueError('Reader TopoMT did not load from the installed prefix.')
        assert not any(
            name == 'pharmacophoremt' or name.startswith('pharmacophoremt.')
            for name in sys.modules
        )
        output.mkdir(parents=True)
        rows = []
        for tag, units in (
            ('pm_fs', ['pm', 'fs', 'radians']),
            ('nm_ps', ['nm', 'ps', 'radians']),
        ):
            handoff = handoff_root / tag / 'handoff'
            source_file = handoff / 'source.h5msm'
            bundle_file = handoff / 'original.zip'
            source_before = hashlib.sha256(source_file.read_bytes()).hexdigest()
            bundle_before = hashlib.sha256(bundle_file.read_bytes()).hexdigest()
            original = ProviderRun.load(bundle_file)
            with puw.context(standard_units=units):
                before = puw.configure.get_standard_units()
                receipt = consume(
                    handoff, output / tag,
                    pocket_id='alphaspace2:20',
                    projection_direction=(1.0, 0.0, 0.0),
                    distance='0.30 nm', radius='0.15 nm',
                    feature='hb acceptor', target_direction=(-1.0, 0.0, 0.0),
                )
                assert receipt['site_count'] == 2 and all(receipt['checks'].values())
                assert receipt['context']['original_run_id'] == original.run_id
                assert puw.configure.get_standard_units() == before
                assert hashlib.sha256(source_file.read_bytes()).hexdigest() == source_before
                assert hashlib.sha256(bundle_file.read_bytes()).hexdigest() == bundle_before
                rows.append({
                    'units': units,
                    'run_id': receipt['context']['original_run_id'],
                    'query_sha256': receipt['query_sha256'],
                    'site_count': 2,
                    'source_sha256': source_before,
                    'original_bundle_sha256': bundle_before,
                    'consumer_checks': receipt['checks'],
                })
        assert attempts == [] and not {'alphaspace2', 'mdtraj'}.intersection(sys.modules)
        result = {
            'schema_version': 1,
            'profile': 'original-alphaspace2-engine-free-installed-consumer-1',
            'expected_prefix': str(expected_prefix),
            'handoff_root': str(handoff_root),
            'accepted_flow_receipt_sha256': hashlib.sha256(
                (handoff_root / 'receipt.json').read_bytes()
            ).hexdigest(),
            'rows': rows,
            'import_attempts': attempts,
            'checks': {
                'engines_absent': True,
                'engine_imports_blocked': True,
                'zero_import_attempts': True,
                'application_policy_preserved': True,
                'both_saved_receivings_have_two_sites': True,
                'original_run_ids_preserved': True,
                'source_and_bundle_bytes_unchanged': True,
                'native_query_roundtrips_and_source_context_checks_passed': True,
                'accepted_installed_original_flows_used': True,
            },
            'limits': [
                'Engine-free receiving of the exact installed candidate; enclosing '
                'runner owns before/after full dependency integrity and origins.',
                'Existing prepared reference and declared polar query; no chemical '
                'preparation, detector execution, affinity or biological validation.',
            ],
        }
        (output / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
        print(
            'PASS: 2 public-consumer receivings with both original engine '
            'distributions absent, imports blocked, zero attempts.',
            flush=True,
        )
        return result
    finally:
        sys.meta_path.remove(blocker)


def main() -> None:
    """Parse explicit installed reader inputs without preimporting science."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--harness', type=Path, required=True)
    parser.add_argument('--handoff-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--expected-prefix', type=Path, required=True)
    run_control(parser.parse_args())


if __name__ == '__main__':
    main()
