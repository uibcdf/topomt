import importlib.abc
import importlib.metadata as metadata
import json
from pathlib import Path
import sys
from devtools.qualify_pharmacophore_handoff import consume
from topomt import pyunitwizard as puw
attempts=[]
class Block(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0] in {'alphaspace2','mdtraj'}:
            attempts.append(fullname)
            raise AssertionError('Detector imported during saved consumer receiving: '+fullname)
for name in ('alphaspace2','mdtraj'):
    try: metadata.distribution(name)
    except metadata.PackageNotFoundError: pass
    else: raise AssertionError('Engine distribution is installed: '+name)
sys.meta_path.insert(0,Block())
root=Path('/dev/shm/topomt-alphaspace2-consumer-101')
rows=[]
for tag,units in [('pm_fs',['pm','fs','radians']),('nm_ps',['nm','ps','radians'])]:
    with puw.context(standard_units=units):
        before=puw.configure.get_standard_units()
        receipt=consume(root/'standalone'/tag/'handoff',root/'engine-free'/tag,
            pocket_id='alphaspace2:20',projection_direction=(1.,0.,0.),
            distance='0.30 nm',radius='0.15 nm',feature='hb acceptor',target_direction=(-1.,0.,0.))
        assert receipt['site_count']==2 and all(receipt['checks'].values())
        assert puw.configure.get_standard_units()==before
        rows.append({'units':units,'run_id':receipt['context']['original_run_id'],'query_sha256':receipt['query_sha256'],'site_count':2})
assert attempts==[] and not {'alphaspace2','mdtraj'}.intersection(sys.modules)
(root/'engine-free-receipt.json').write_text(json.dumps({'rows':rows,'checks':{'engines_absent':True,'engine_imports_blocked':True,'zero_import_attempts':True,'application_policy_preserved':True}},indent=2)+'\n')
print('PASS: 2 public-consumer receivings with both original engine distributions absent, imports blocked, zero attempts.')
