"""Prepare an independent installed reader prefix without original engines."""

import argparse
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

ROOT = Path('/fast_data/home/liliana/repos@uibcdf/topomt')
TASK = ROOT / '.cache/alphaspace2-installed-receiving'
EVIDENCE = TASK / 'evidence/engine-free-environment'
BASE = Path('/fast_data/home/liliana/miniconda3/envs/topomt-dev')
PREFIX = Path('/tmp/topomt-alphaspace2-installed-y1j8k2e8/engine-free-env')
CONDA = Path('/fast_data/home/liliana/miniconda3/bin/conda')


def sha256(path: Path) -> str:
    """Return the exact checksum of a retained file."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def protected_base() -> dict:
    """Snapshot the developer environment declarations and human version bytes."""
    metadata = {
        str(path.relative_to(BASE)): sha256(path)
        for path in sorted((BASE / 'conda-meta').glob('*')) if path.is_file()
    }
    sites = BASE / 'lib/python3.14/site-packages'
    for path in sorted(sites.glob('*.dist-info/METADATA')):
        metadata[str(path.relative_to(BASE))] = sha256(path)
    return {
        'base_prefix': str(BASE),
        'declarations': metadata,
        'human_topomt_version_sha256': sha256(ROOT / 'topomt/_version.py'),
    }


def command(arguments: list[str], label: str) -> None:
    """Retain commands and complete output for every bootstrap phase."""
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    environment = os.environ.copy()
    environment.pop('PYTHONPATH', None)
    environment['PYTHONNOUSERSITE'] = '1'
    log = EVIDENCE / f'{label}-{time.time_ns()}.log'
    started = time.monotonic()
    with log.open('xb') as stream:
        result = subprocess.run(
            arguments, cwd='/tmp', env=environment,
            stdout=stream, stderr=subprocess.STDOUT, check=False,
        )
    row = {
        'command': arguments, 'cwd': '/tmp', 'exit_code': result.returncode,
        'duration_seconds': time.monotonic() - started,
        'log': str(log), 'log_sha256': sha256(log),
    }
    with (EVIDENCE / 'commands.jsonl').open('a') as stream:
        stream.write(json.dumps(row) + '\n')
    print(json.dumps(row), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)


def selected_inputs() -> list[dict]:
    """Resolve accepted runtime wheels and explicit auxiliary support, without engines."""
    topomt = json.loads((TASK / 'evidence/build/wheel-build-receipt.json').read_text())
    msm = json.loads((TASK / 'evidence/controlled-molsysmt-build/wheel-receipt.json').read_text())
    pharma = json.loads((TASK / 'evidence/pharmacophore-wheel-receipt.json').read_text())
    rows = [
        {'name': 'topomt', **topomt['candidate'], 'producer': topomt['source_sha']},
        {'name': 'molsysmt', **msm['wheel'], 'producer': msm['producer']},
        {
            'name': 'pharmacophoremt',
            'path': str(TASK / 'dependency-wheels/pharmacophoremt' / pharma['filename']),
            'filename': pharma['filename'], 'bytes': pharma['bytes'],
            'sha256': pharma['sha256'], 'producer': pharma['source_commit'],
        },
    ]
    originals = json.loads((TASK / 'evidence/original-wheel-identities.json').read_text())
    for item in originals:
        if item['name'] not in {'Cython', 'configargparser'}:
            continue
        rows.append({
            'name': item['name'], 'path': str(TASK / 'inputs' / item['file']),
            'filename': item['file'], 'bytes': item['bytes'],
            'sha256': item['sha256'], 'identity': item['identity'],
            'role': 'Explicit auxiliary origin-checker support; not an original engine.',
        })
    if {row['name'] for row in rows} != {
        'topomt', 'molsysmt', 'pharmacophoremt', 'Cython', 'configargparser'
    }:
        raise ValueError('The exact engine-free wheel input inventory differs.')
    for row in rows:
        path = Path(row['path'])
        if sha256(path) != row['sha256'] or path.stat().st_size != row['bytes']:
            raise ValueError('An accepted reader wheel input changed.')
    if rows[0]['sha256'] != 'de94e54776bd2222ab6444f7a29aab9f43aa05a77755282c1203191873abb277':
        raise ValueError('The accepted exact TopoMT candidate was not selected.')
    return rows


def main() -> None:
    """Clone, replace selected packages, or verify the independent reader prefix."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=[
        'clone', 'remove-conda', 'install', 'conda-closure', 'pip-check', 'profile', 'protect'
    ])
    args = parser.parse_args()
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    if args.phase == 'clone':
        if PREFIX.exists():
            raise FileExistsError(PREFIX)
        (EVIDENCE / 'base-before.json').write_text(
            json.dumps(protected_base(), indent=2) + '\n'
        )
        command([
            str(CONDA), 'create', '--prefix', str(PREFIX), '--clone', str(BASE),
            '--copy', '--offline', '--yes', '--json',
        ], 'native-conda-clone')
    elif args.phase == 'remove-conda':
        command([
            str(CONDA), 'remove', '--prefix', str(PREFIX), '--force-remove',
            '--offline', '--yes', '--json', 'molsysmt',
        ], 'remove-only-conda-molsysmt')
    elif args.phase == 'install':
        rows = selected_inputs()
        (EVIDENCE / 'inputs.json').write_text(json.dumps(rows, indent=2) + '\n')
        requirements = EVIDENCE / 'wheel-inputs.txt'
        requirements.write_text(''.join(
            f"{Path(row['path']).as_uri()} --hash=sha256:{row['sha256']}\n"
            for row in rows
        ))
        command([
            str(PREFIX / 'bin/python'), '-I', '-m', 'pip', 'install',
            '--no-index', '--no-deps', '--require-hashes', '--force-reinstall',
            '--report', str(EVIDENCE / 'pip-wheel-install-report.json'),
            '--requirement', str(requirements),
        ], 'install-accepted-reader-wheels')
    elif args.phase == 'conda-closure':
        def records(prefix: Path) -> dict:
            return {
                item['name']: item
                for path in (prefix / 'conda-meta').glob('*.json')
                if (item := json.loads(path.read_text()))
            }

        main = records(PREFIX.parent / 'env')
        current = records(PREFIX)
        added = []
        for name, item in main.items():
            if name in current:
                if any(current[name].get(key) != item.get(key)
                       for key in ('version', 'build', 'sha256')):
                    raise ValueError('An existing Conda artifact differs from the receptor.')
                continue
            path = Path('/fast_data/home/liliana/miniconda3/pkgs') / item['fn']
            if sha256(path) != item['sha256']:
                raise ValueError('A cached receptor dependency artifact differs.')
            added.append({
                'name': name, 'version': item['version'], 'build': item['build'],
                'path': str(path), 'sha256': item['sha256'],
                'original_receptor_url': item['url'],
            })
        if set(current) - set(main):
            raise ValueError('The reader has unexpected Conda artifacts.')
        (EVIDENCE / 'conda-closure-inputs.json').write_text(
            json.dumps(added, indent=2) + '\n'
        )
        command([
            str(CONDA), 'install', '--prefix', str(PREFIX), '--offline',
            '--no-deps', '--copy', '--yes', '--json',
            *[item['path'] for item in added],
        ], 'install-exact-cached-receptor-closure')
        installed = records(PREFIX)
        if set(installed) != set(main) or any(
            any(installed[name].get(key) != item.get(key)
                for key in ('version', 'build', 'sha256'))
            for name, item in main.items()
        ):
            raise ValueError('The final reader Conda closure differs from the receptor.')
    elif args.phase == 'pip-check':
        command([str(PREFIX / 'bin/python'), '-I', '-m', 'pip', 'check'], 'pip-check')
    elif args.phase == 'profile':
        command([
            str(PREFIX / 'bin/python'), '-I',
            str(TASK / 'evidence/engine_free_environment_profile.py'),
        ], 'static-reader-profile')
    else:
        before = json.loads((EVIDENCE / 'base-before.json').read_text())
        after = protected_base()
        if before != after:
            raise ValueError('The developer environment or human version changed.')
        (EVIDENCE / 'base-after.json').write_text(json.dumps(after, indent=2) + '\n')
        print('Developer environment declarations and human version remain unchanged.')


if __name__ == '__main__':
    main()
