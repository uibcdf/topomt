"""Check explicit derivative classification against authenticated synthetic source."""

import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path

base = Path(__file__).resolve().parent
run = Path(tempfile.mkdtemp(prefix='bytecode-selfcheck-', dir=base))
fixture = run / 'prefix'
fixture.mkdir(exist_ok=False)
site = fixture / 'lib/python3.14/site-packages'
site.mkdir(parents=True)
(fixture / 'conda-meta').mkdir()
(fixture / 'bin').mkdir()
interpreter = Path('/tmp/topomt-alphaspace2-installed-y1j8k2e8/env/bin/python')
(fixture / 'bin/python').symlink_to(interpreter)
source = site / 'generated.py'
source.write_text('VALUE = -0.0\n')
compiler = (
    'import importlib.util,py_compile,sys; '
    'py_compile.compile(sys.argv[1],doraise=True,invalidation_mode=py_compile.PycInvalidationMode.CHECKED_HASH); '
    'print(importlib.util.cache_from_source(sys.argv[1]))'
)
cache = Path(
    subprocess.check_output(
        [str(interpreter), '-I', '-S', '-B', '-c', compiler, str(source)], text=True
    ).strip()
)
original_bytecode = cache.read_bytes()
metadata = {
    'name': 'synthetic-derived',
    'version': '1.0',
    'build': '0',
    'files': [
        'bin/python',
        source.relative_to(fixture).as_posix(),
        cache.relative_to(fixture).as_posix(),
    ],
    'paths_data': {
        'paths_version': 1,
        'paths': [
            {
                '_path': 'bin/python',
                'sha256_in_prefix': hashlib.sha256(
                    interpreter.read_bytes()
                ).hexdigest(),
            },
            {
                '_path': source.relative_to(fixture).as_posix(),
                'sha256_in_prefix': hashlib.sha256(source.read_bytes()).hexdigest(),
            },
            {
                '_path': cache.relative_to(fixture).as_posix(),
                'sha256_in_prefix': hashlib.sha256(b'OLD DERIVATIVE').hexdigest(),
            },
        ],
    },
}
record = fixture / 'conda-meta/synthetic-derived-1.0-0.json'
record.write_text(json.dumps(metadata))
results = []


def check(name: str, expected_code: int) -> None:
    """Require the expected acceptance and retained raw derivative finding."""
    output = run / f'{name}.json'
    command = [
        sys.executable,
        str(base / 'check_prefix_integrity.py'),
        str(fixture),
        str(output),
    ]
    process = subprocess.run(command, capture_output=True, text=True, check=False)
    if process.returncode != expected_code:
        raise AssertionError((name, process.returncode, process.stdout, process.stderr))
    report = json.loads(output.read_text())
    if not report['raw_native_doctor_has_findings']:
        raise AssertionError('The raw Doctor finding was lost')
    results.append(
        {
            'case': name,
            'exit_code': process.returncode,
            'raw_doctor_has_findings': True,
            'verified_derivatives': len(
                report['regenerated_bytecode_interpretation']['verified']
            ),
            'rejected_derivatives': len(
                report['regenerated_bytecode_interpretation']['rejected']
            ),
        }
    )


check('source-matching-derivative', 0)
manipulate = (
    'from pathlib import Path; import marshal,sys; '
    'p=Path(sys.argv[1]); raw=p.read_bytes(); c=marshal.loads(raw[16:]); '
    'changed=c.replace(co_consts=tuple(0.0 if type(value) is float else value for value in c.co_consts)); '
    'p.write_bytes(raw[:16]+marshal.dumps(changed))'
)
subprocess.run(
    [str(interpreter), '-I', '-S', '-B', '-c', manipulate, str(cache)], check=True
)
check('signed-zero-bytecode-manipulation', 1)
cache.write_bytes(original_bytecode[:8] + b'\0' * 8 + original_bytecode[16:])
check('invalid-source-hash-header', 1)
cache.write_bytes(original_bytecode)
source.write_text('VALUE = 2.0\n')
check('source-modified', 1)
source.write_text('VALUE = -0.0\n')
del metadata['paths_data']['paths'][1]['sha256_in_prefix']
record.write_text(json.dumps(metadata))
check('source-without-conda-hash', 1)
(base / 'selfcheck-bytecode-summary.json').write_text(
    json.dumps(results, indent=2) + '\n'
)
print(json.dumps(results, indent=2))
