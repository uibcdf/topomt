"""Verify reported bytecode derivatives without executing their code objects."""

import hashlib
import importlib.util
import io
import json
import marshal
import re
import struct
import sys
from pathlib import Path
from types import CodeType


def _constant_signature(value: object) -> tuple:
    """Compare compiler constants without losing signed floating-point zeros."""
    if isinstance(value, CodeType):
        return _code_signature(value)
    if type(value) is float:
        return ('float', struct.pack('!d', value))
    if type(value) is complex:
        return ('complex', struct.pack('!dd', value.real, value.imag))
    if type(value) is tuple:
        return ('tuple', tuple(_constant_signature(item) for item in value))
    if type(value) is frozenset:
        return ('frozenset', frozenset(_constant_signature(item) for item in value))
    if value is None or value is Ellipsis or type(value) in (bool, int, str, bytes):
        return (type(value).__name__, value)
    raise ValueError(f'Unsupported compiler constant: {type(value).__name__}')


def _code_signature(code: CodeType) -> tuple:
    """Compare code fields because marshal reference encodings can differ."""
    fields = (
        'co_argcount',
        'co_posonlyargcount',
        'co_kwonlyargcount',
        'co_nlocals',
        'co_stacksize',
        'co_flags',
        'co_code',
        'co_names',
        'co_varnames',
        'co_filename',
        'co_name',
        'co_qualname',
        'co_firstlineno',
        'co_linetable',
        'co_exceptiontable',
        'co_freevars',
        'co_cellvars',
    )
    return (
        'code',
        tuple((name, getattr(code, name)) for name in fields),
        tuple(_constant_signature(value) for value in code.co_consts),
    )


def main() -> int:
    """Return detailed acceptance or rejection for each reported derivative."""
    request = json.load(sys.stdin)
    prefix = Path(request['prefix']).resolve(strict=True)
    results = []
    for entry in request['entries']:
        result = {'path': entry['path'], 'package': entry['package'], 'verified': False}
        try:
            if sys.version_info[:2] != (3, 14):
                raise ValueError('This receiving qualification requires Python 3.14')
            path = prefix / entry['path']
            source = Path(importlib.util.source_from_cache(str(path)))
            if not path.resolve().is_relative_to(
                prefix
            ) or not source.resolve().is_relative_to(prefix):
                raise ValueError(
                    'Bytecode or source resolves outside the receiving prefix'
                )
            if source.relative_to(prefix).as_posix() != entry['source_path']:
                raise ValueError(
                    'Bytecode cache does not identify the authenticated source'
                )
            source_bytes = source.read_bytes()
            source_sha256 = hashlib.sha256(source_bytes).hexdigest()
            if source_sha256 != entry['source_sha256_in_prefix']:
                raise ValueError('Source does not match its Conda sha256_in_prefix')
            optimization_match = re.search(r'\.opt-([12])\.pyc$', path.name)
            optimization = int(optimization_match.group(1)) if optimization_match else 0
            optimization_tag = str(optimization) if optimization else ''
            if (
                Path(
                    importlib.util.cache_from_source(
                        str(source), optimization=optimization_tag
                    )
                )
                != path
            ):
                raise ValueError('Unsupported bytecode cache tag or optimization level')
            payload = path.read_bytes()
            if len(payload) < 16 or payload[:4] != importlib.util.MAGIC_NUMBER:
                raise ValueError('Bytecode header has an incompatible magic number')
            flags = struct.unpack('<I', payload[4:8])[0]
            if flags not in (0, 1, 3):
                raise ValueError('Bytecode header has unsupported flags')
            if flags & 1:
                if payload[8:16] != importlib.util.source_hash(source_bytes):
                    raise ValueError(
                        'Bytecode source-hash header does not match the source'
                    )
                header_validation = 'source hash verified'
            else:
                source_mtime, source_size = struct.unpack('<II', payload[8:16])
                if (
                    source_mtime != int(source.stat().st_mtime) & 0xFFFFFFFF
                    or source_size != len(source_bytes) & 0xFFFFFFFF
                ):
                    raise ValueError(
                        'Bytecode timestamp/size header does not match the source'
                    )
                header_validation = 'source timestamp and byte count verified'
            stream = io.BytesIO(payload[16:])
            observed_code = marshal.load(stream)
            if not isinstance(observed_code, CodeType) or stream.read():
                raise ValueError('Invalid bytecode payload or trailing bytes')
            expected_code = compile(
                source_bytes,
                observed_code.co_filename,
                'exec',
                dont_inherit=True,
                optimize=optimization,
            )
            if observed_code != expected_code or _code_signature(
                observed_code
            ) != _code_signature(expected_code):
                raise ValueError(
                    'Bytecode code object differs from compiling authenticated source'
                )
            if hashlib.sha256(source.read_bytes()).hexdigest() != source_sha256:
                raise ValueError('Source changed during verification')
            result.update(
                {
                    'verified': True,
                    'classification': 'regenerated bytecode verified against authenticated source',
                    'source_path': entry['source_path'],
                    'source_sha256_in_prefix': entry['source_sha256_in_prefix'],
                    'header_flags': flags,
                    'header_validation': header_validation,
                    'cache_optimization': optimization,
                    'code_filename': observed_code.co_filename,
                    'code_object_and_fields_equal_to_compilation': True,
                }
            )
        except (OSError, ValueError, TypeError, EOFError, SyntaxError) as error:
            result['error'] = str(error)
        results.append(result)
    print(
        json.dumps(
            {'python': sys.version, 'executable': sys.executable, 'results': results},
            sort_keys=True,
        )
    )
    return 0 if all(row['verified'] for row in results) else 1


if __name__ == '__main__':
    raise SystemExit(main())
