"""Record bounded Conda Doctor, pip RECORD, link and launcher evidence."""

import argparse
import base64
import csv
import hashlib
import importlib.metadata
import importlib.util
import io
import json
import os
import re
import stat
import subprocess
import sys
from collections import Counter
from pathlib import Path, PurePosixPath

import conda
from conda.plugins.subcommands.doctor import health_checks


def _digest(path: Path, algorithm: str = 'sha256') -> str:
    """Hash a file without importing code from the receiving prefix."""
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, algorithm).hexdigest()


def _bytecode(path: str) -> bool:
    """Identify regenerable bytecode excluded from our snapshots."""
    return path.endswith(('.pyc', '.pyo'))


def _safe_relative(path: str) -> bool:
    """Check the relative file names in a Conda package manifest."""
    parts = PurePosixPath(path)
    return (
        bool(path)
        and not parts.is_absolute()
        and '..' not in parts.parts
        and '\\' not in path
    )


def _classify_bytecode(
    prefix: Path, doctor: dict, authenticated_paths: dict[str, dict[str, str]]
) -> dict:
    """Verify derivatives against hashed source while preserving raw findings."""
    altered = doctor['altered_packages']
    reported = [
        {'package': package, 'path': path}
        for package, paths in altered.items()
        for path in paths
        if _bytecode(path)
    ]
    proof = {'verified': [], 'rejected': [], 'worker': None}
    if not reported:
        return proof
    try:
        if doctor['packages_with_missing_files'] or any(
            not _bytecode(path) for paths in altered.values() for path in paths
        ):
            raise ValueError(
                'Non-bytecode Conda findings prevent derivative classification'
            )
        interpreter = prefix / 'bin/python'
        candidates = {'bin/python'}
        if interpreter.resolve().is_relative_to(prefix):
            candidates.add(interpreter.resolve().relative_to(prefix).as_posix())
        interpreter_hashes = {
            value
            for paths in authenticated_paths.values()
            for path, value in paths.items()
            if path in candidates
        }
        if (
            len(interpreter_hashes) != 1
            or _digest(interpreter) not in interpreter_hashes
        ):
            raise ValueError(
                'Receiving interpreter lacks an unambiguous matching Conda hash'
            )
        entries = []
        for row in reported:
            source = Path(importlib.util.source_from_cache(str(prefix / row['path'])))
            source_path = source.relative_to(prefix).as_posix()
            expected = authenticated_paths.get(row['package'], {}).get(source_path)
            if not expected or _digest(source) != expected:
                raise ValueError(
                    f'No matching same-package Conda source hash: {source_path}'
                )
            entries.append(
                {**row, 'source_path': source_path, 'source_sha256_in_prefix': expected}
            )
        worker = Path(__file__).with_name('verify_regenerated_bytecode.py')
        process = subprocess.run(
            [str(interpreter), '-I', '-S', '-B', str(worker)],
            input=json.dumps({'prefix': str(prefix), 'entries': entries}),
            text=True,
            capture_output=True,
            check=False,
        )
        if process.returncode not in (0, 1):
            raise ValueError(f'Bytecode worker failed: {process.stderr.strip()}')
        result = json.loads(process.stdout)
        proof['worker'] = {
            'python': result['python'],
            'executable': result['executable'],
        }
        if len(result['results']) != len(entries):
            raise ValueError('Bytecode worker returned an incomplete result inventory')
        for row in result['results']:
            proof['verified' if row['verified'] else 'rejected'].append(row)
        if process.returncode and not proof['rejected']:
            raise ValueError(
                'Bytecode worker failed without an explicit rejected derivative'
            )
    except (OSError, ValueError, TypeError, KeyError) as error:
        proof['rejected'].append({'reported': reported, 'error': str(error)})
    return proof


def main() -> int:
    """Write an integrity report and reject findings or baseline differences."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('prefix', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--baseline', type=Path)
    args = parser.parse_args()
    prefix = args.prefix.resolve(strict=True)
    output = args.output.resolve()
    if output.is_relative_to(prefix):
        parser.error('The report must be outside the read-only receiving prefix')
    if output.exists():
        parser.error('The output already exists; preserve previous evidence')
    failures = []
    records = []
    authenticated_paths = {}
    conda_dist_owners = {}
    totals = Counter()
    metadata_valid = True
    for record_path in sorted((prefix / 'conda-meta').glob('*.json')):
        try:
            data = json.loads(record_path.read_text())
            files = data.get('files', [])
            paths_data = data.get('paths_data', {})
            paths = paths_data.get('paths', [])
            if not isinstance(files, list) or not isinstance(paths, list):
                raise ValueError('Conda files/paths_data.paths must be lists')
            for name in files + [row.get('_path', '') for row in paths]:
                if not isinstance(name, str) or not _safe_relative(name):
                    raise ValueError(f'Unsafe Conda manifest path: {name!r}')
            counts = Counter()
            counts['files_entries'] = len(files)
            counts['missing_check_excludes_bytecode'] = sum(
                _bytecode(name) for name in files
            )
            counts['paths_entries'] = len(paths)
            counts['paths_version_1'] = int(paths_data.get('paths_version') == 1)
            counts['records_without_paths_data'] = int('paths_data' not in data)
            for row in paths:
                name = row['_path']
                if _bytecode(name):
                    counts['paths_bytecode_not_snapshotted'] += 1
                if row.get('path_type') == 'softlink':
                    counts['paths_softlinks'] += 1
                if row.get('sha256_in_prefix'):
                    counts['paths_with_sha256_in_prefix'] += 1
                    if _bytecode(name):
                        counts['doctor_potential_bytecode_hashes'] += 1
                    elif (
                        paths_data.get('paths_version') == 1
                        and (prefix / name).is_file()
                    ):
                        counts['doctor_existing_nonbytecode_hash_targets'] += 1
                else:
                    counts['paths_without_sha256_in_prefix'] += 1
            if paths_data.get('paths_version') == 1:
                authenticated_paths[record_path.stem] = {
                    row['_path']: row['sha256_in_prefix']
                    for row in paths
                    if row.get('sha256_in_prefix')
                }
            for name in set(files) | {row['_path'] for row in paths}:
                for suffix in ('.dist-info/', '.egg-info/'):
                    if suffix in name:
                        directory = name.split(suffix, 1)[0] + suffix[:-1]
                        conda_dist_owners.setdefault(directory, []).append(
                            record_path.stem
                        )
            totals.update(counts)
            records.append(
                {
                    'record': record_path.name,
                    'record_sha256': _digest(record_path),
                    'name': data.get('name'),
                    'version': data.get('version'),
                    'build': data.get('build'),
                    'coverage': dict(sorted(counts.items())),
                }
            )
        except (OSError, ValueError, TypeError, AttributeError) as error:
            metadata_valid = False
            failures.append(
                {
                    'boundary': 'conda_metadata',
                    'record': record_path.name,
                    'error': str(error),
                }
            )
    if not records:
        metadata_valid = False
        failures.append(
            {'boundary': 'conda_metadata', 'error': 'No readable Conda records'}
        )
    doctor = {'ran': False, 'altered_packages': {}, 'packages_with_missing_files': {}}
    if metadata_valid:
        try:
            doctor['altered_packages'] = health_checks.find_altered_packages(prefix)
            doctor['packages_with_missing_files'] = (
                health_checks.find_packages_with_missing_files(prefix)
            )
            doctor['ran'] = True
        except Exception as error:
            failures.append({'boundary': 'native_conda_doctor', 'error': str(error)})
    nonbytecode_alterations = {
        package: [path for path in paths if not _bytecode(path)]
        for package, paths in doctor['altered_packages'].items()
        if any(not _bytecode(path) for path in paths)
    }
    for kind, packages in (
        ('altered_nonbytecode_packages', nonbytecode_alterations),
        ('packages_with_missing_files', doctor['packages_with_missing_files']),
    ):
        if packages:
            failures.append(
                {'boundary': 'native_conda_doctor', 'kind': kind, 'packages': packages}
            )
    bytecode_proof = _classify_bytecode(prefix, doctor, authenticated_paths)
    if bytecode_proof['rejected']:
        failures.append(
            {'boundary': 'derived_bytecode', 'rejected': bytecode_proof['rejected']}
        )
    conda_distributions = []
    pip_distributions = []
    unidentified_distributions = []
    distribution_names = Counter()
    site_roots = sorted((prefix / 'lib').glob('python*/site-packages'))
    if (prefix / 'Lib/site-packages').exists():
        site_roots.append(prefix / 'Lib/site-packages')
    for site_root in site_roots:
        directories = sorted(
            set(site_root.glob('*.dist-info')) | set(site_root.glob('*.egg-info'))
        )
        for directory in directories:
            dist = importlib.metadata.PathDistribution(directory)
            name = dist.metadata.get('Name', directory.name)
            normalized = re.sub(r'[-_.]+', '-', name).lower()
            distribution_names[normalized] += 1
            relative = directory.relative_to(prefix).as_posix()
            owners = sorted(set(conda_dist_owners.get(relative, [])))
            row = {
                'name': name,
                'version': dist.version,
                'metadata_directory': relative,
            }
            if owners:
                row['conda_owners'] = owners
                row['record_policy'] = (
                    'Conda Doctor authority; Conda-owned RECORD is not accepted as a pip wheel integrity manifest'
                )
                conda_distributions.append(row)
                continue
            installer = (dist.read_text('INSTALLER') or '').strip()
            record = directory / 'RECORD'
            row['installer'] = installer
            if installer != 'pip' or not record.is_file():
                unidentified_distributions.append(row)
                failures.append(
                    {
                        'boundary': 'distribution_ownership',
                        'distribution': name,
                        'error': 'Neither Conda-owned metadata nor a pip-installed standard RECORD',
                    }
                )
                continue
            row['record_sha256'] = _digest(record)
            hashed = 0
            unhashable = []
            skipped_bytecode = 0
            seen = set()
            for target_name, recorded_hash, recorded_size in csv.reader(
                io.StringIO(record.read_text())
            ):
                if target_name in seen:
                    failures.append(
                        {
                            'boundary': 'pip_RECORD',
                            'distribution': name,
                            'path': target_name,
                            'error': 'Duplicate RECORD path',
                        }
                    )
                seen.add(target_name)
                if _bytecode(target_name):
                    skipped_bytecode += 1
                    continue
                target = Path(os.path.normpath(site_root / target_name))
                if not target.is_relative_to(
                    prefix
                ) or not target.resolve().is_relative_to(prefix):
                    failures.append(
                        {
                            'boundary': 'pip_RECORD',
                            'distribution': name,
                            'path': target_name,
                            'error': 'RECORD target escapes receiving prefix',
                        }
                    )
                    continue
                if not target.is_file():
                    failures.append(
                        {
                            'boundary': 'pip_RECORD',
                            'distribution': name,
                            'path': target_name,
                            'error': 'Missing regular file',
                        }
                    )
                    continue
                if recorded_size and target.stat().st_size != int(recorded_size):
                    failures.append(
                        {
                            'boundary': 'pip_RECORD',
                            'distribution': name,
                            'path': target_name,
                            'error': 'Size mismatch',
                        }
                    )
                if recorded_hash:
                    algorithm, expected = recorded_hash.split('=', 1)
                    try:
                        actual = (
                            base64.urlsafe_b64encode(
                                bytes.fromhex(_digest(target, algorithm))
                            )
                            .rstrip(b'=')
                            .decode()
                        )
                    except (ValueError, OSError) as error:
                        failures.append(
                            {
                                'boundary': 'pip_RECORD',
                                'distribution': name,
                                'path': target_name,
                                'error': str(error),
                            }
                        )
                        continue
                    if actual != expected:
                        failures.append(
                            {
                                'boundary': 'pip_RECORD',
                                'distribution': name,
                                'path': target_name,
                                'error': 'Hash mismatch',
                            }
                        )
                    hashed += 1
                else:
                    unhashable.append(target_name)
            row.update(
                {
                    'hashes_checked': hashed,
                    'unhashed_nonbytecode_entries': sorted(unhashable),
                    'bytecode_entries_not_snapshotted': skipped_bytecode,
                }
            )
            pip_distributions.append(row)
    duplicates = sorted(name for name, count in distribution_names.items() if count > 1)
    if duplicates:
        failures.append(
            {'boundary': 'distribution_ownership', 'duplicate_names': duplicates}
        )
    links = []
    for folder, directories, files in os.walk(prefix, followlinks=False):
        for name in sorted(directories + files):
            path = Path(folder) / name
            if _bytecode(name) or not path.is_symlink():
                continue
            target = path.resolve()
            row = {
                'path': path.relative_to(prefix).as_posix(),
                'link_text': os.readlink(path),
                'resolved_target': str(target),
                'target_inside_prefix': target.is_relative_to(prefix),
                'target_exists': path.exists(),
            }
            links.append(row)
            if not row['target_exists']:
                failures.append(
                    {
                        'boundary': 'symlinks',
                        'path': row['path'],
                        'error': 'Broken link',
                    }
                )
    launchers = []
    for folder in (prefix / 'bin', prefix / 'Scripts'):
        if not folder.is_dir():
            continue
        for path in sorted(folder.iterdir()):
            if _bytecode(path.name) or not path.is_file():
                continue
            row = {
                'path': path.relative_to(prefix).as_posix(),
                'mode': stat.S_IMODE(path.lstat().st_mode),
                'target_inside_prefix': path.resolve().is_relative_to(prefix),
            }
            if row['target_inside_prefix']:
                row.update({'bytes': path.stat().st_size, 'sha256': _digest(path)})
            launchers.append(row)
    external_links = [row['path'] for row in links if not row['target_inside_prefix']]
    snapshot = {
        'prefix': str(prefix),
        'checker': {
            'python': sys.version,
            'executable': sys.executable,
            'helper_sha256': _digest(Path(__file__)),
            'conda_version': conda.__version__,
            'conda_origin': conda.__file__,
            'health_checks_origin': health_checks.__file__,
            'health_checks_sha256': _digest(Path(health_checks.__file__)),
            'bytecode_worker_sha256': _digest(
                Path(__file__).with_name('verify_regenerated_bytecode.py')
            ),
        },
        'conda': {
            'native_doctor_nonderived': {
                'ran': doctor['ran'],
                'altered_packages': nonbytecode_alterations,
                'packages_with_missing_files': doctor['packages_with_missing_files'],
            },
            'record_count': len(records),
            'coverage': dict(sorted(totals.items())),
            'records': records,
        },
        'python_distributions': {
            'conda_owned': conda_distributions,
            'pip_RECORD_verified': pip_distributions,
            'unidentified': unidentified_distributions,
        },
        'symlinks': sorted(links, key=lambda row: row['path']),
        'external_link_paths_requiring_independence_review': sorted(external_links),
        'launchers': launchers,
        'limits': [
            'Native Conda Doctor checks only existing files with paths_version=1 and sha256_in_prefix; it does not authenticate the metadata.',
            'Conda missing-file checks exclude pyc/pyo. Regenerable bytecode is not part of our code snapshots.',
            'Raw native Doctor findings are retained outside the stable snapshot. Only derivatives with valid cache headers and code identical to compiling same-package Conda-hashed source can receive the explicit regenerated-bytecode classification.',
            'Conda-owned RECORD manifests are deliberately not reinterpreted as authentic pip wheel RECORDs.',
            'Link targets are inventoried; external target bytes are not authenticated. Launcher hashes are before/after observations, not independent original-file provenance.',
            'This checks declared Conda/pip file integrity and selected supplemental observations; it is not a complete prefix hash inventory or dependency acquisition proof.',
        ],
    }
    comparison = None
    if args.baseline:
        baseline = json.loads(args.baseline.read_text())
        comparison = baseline['snapshot'] == snapshot
        if not comparison:
            failures.append(
                {'boundary': 'before_after', 'error': 'Integrity snapshots differ'}
            )
    report = {
        'snapshot': snapshot,
        'native_conda_doctor_raw': doctor,
        'raw_native_doctor_has_findings': bool(
            doctor['altered_packages'] or doctor['packages_with_missing_files']
        ),
        'regenerated_bytecode_interpretation': bytecode_proof,
        'baseline_equal': comparison,
        'passed': not failures,
        'failures': failures,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x') as stream:
        stream.write(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(
        json.dumps(
            {
                'report': str(output),
                'passed': report['passed'],
                'conda_records': len(records),
                'pip_distributions': len(pip_distributions),
                'symlinks': len(links),
                'external_links': len(external_links),
                'launchers': len(launchers),
                'failures': len(failures),
                'baseline_equal': comparison,
                'verified_regenerated_bytecode': len(bytecode_proof['verified']),
            },
            sort_keys=True,
        )
    )
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
