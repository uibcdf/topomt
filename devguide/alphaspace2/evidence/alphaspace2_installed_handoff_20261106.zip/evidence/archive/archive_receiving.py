"""Retain accepted receiving evidence and exact external inputs without publishing."""

import argparse
import hashlib
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path('/fast_data/home/liliana/repos@uibcdf/topomt')
CACHE = ROOT / '.cache/alphaspace2-installed-receiving'
TASK = Path('/tmp/topomt-alphaspace2-installed-y1j8k2e8')
OUTPUT = CACHE / 'archives'
DURABLE = (
    ROOT.parent / 'topomt-local-backup/qualifications/alphaspace2-installed-20261106'
)
NAME = 'alphaspace2_installed_handoff_20261106'
PRODUCER = '5ae5c46d94e425eab24b2aeb8420a4f3b697eebe'
CANDIDATE = 'de94e54776bd2222ab6444f7a29aab9f43aa05a77755282c1203191873abb277'
SEED = 'a42ef9868578ba16c62d52a1267d24160b973dca0d50dbc804ca46b6b2fe316a'
HISTORICAL_SHA256 = 'e5ed2e08b84d46995fb2159f86e7815676004ac7d7ccaf28cc7a490c6712d790'
HISTORICAL = (
    ROOT / 'devguide/alphaspace2/evidence/'
    'alphaspace2_prepared_consumer_20261106.zip'
)
EXCLUDED_DIRECTORIES = {
    '.git', '__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache',
    'node_modules', 'nodecache', 'env', 'engine-free-env', 'target',
    'dependency-build-tools', 'dependency-cargo-home', 'dependency-cargo-target',
}
EXCLUDED_SUFFIXES = ('.pyc', '.pyo', '.whl', '.conda', '.tar.gz', '.tar.bz2')
ATTEMPT_PREFIXES = (
    'source-standalone', 'installed-suite', 'installed-flow', 'installed-recovery',
)


def digest(path: Path) -> str:
    """Return a streamed exact file digest."""
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def encoded(value: object) -> bytes:
    """Serialize maintained evidence deterministically."""
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def member_name(value: str) -> str:
    """Reject absolute or escaping archive member coordinates."""
    path = PurePosixPath(value)
    if path.is_absolute() or '..' in path.parts or '\\' in value:
        raise ValueError(f'Unsafe archive member: {value}')
    return path.as_posix()


def read_json(path: Path) -> dict:
    """Read one completed receipt without importing scientific packages."""
    value = json.loads(path.read_text())
    if not isinstance(value, dict):
        raise ValueError(f'A receipt mapping is required: {path}')
    return value


def gate(path: Path, mode: str) -> dict:
    """Bind one successful accepted gate to its original candidate and witnesses."""
    if path.is_symlink():
        raise ValueError('A selected gate cannot be a symlink alias.')
    path = path.resolve(strict=True)
    if not path.is_relative_to(TASK):
        raise ValueError('Selected gates must remain inside the task directory.')
    receipt_path = path / 'acceptance-receipt.json'
    receipt = read_json(receipt_path)
    if (
        receipt.get('profile') != 'alphaspace2-installed-acceptance-1'
        or receipt.get('mode') != mode
        or receipt.get('passed') is not True
        or receipt.get('failures') != []
        or receipt.get('science', {}).get('passed') is not True
    ):
        raise ValueError(f'The selected {mode} gate is not accepted: {receipt_path}')
    for name in ('candidate_before', 'candidate_after'):
        if receipt.get(name, {}).get('sha256') != CANDIDATE:
            raise ValueError(f'The candidate changed in {receipt_path}: {name}')
    for name in ('integrity_before', 'integrity_after', 'origins_before', 'origins_after'):
        witness = receipt.get(name, {})
        witness_path = Path(witness.get('path', '')).resolve(strict=True)
        if witness.get('passed') is not True or not witness_path.is_relative_to(path):
            raise ValueError(f'The {name} witness is missing or unaccepted.')
        if witness.get('sha256') and digest(witness_path) != witness['sha256']:
            raise ValueError(f'The retained {name} witness changed.')
    science = receipt['science']
    if mode == 'suite':
        outcomes_path = Path(science['outcomes']).resolve(strict=True)
        if not outcomes_path.is_relative_to(path):
            raise ValueError('The suite outcomes escape the accepted gate.')
        outcomes = read_json(outcomes_path)
        if (
            outcomes.get('passed') is not True
            or science.get('collected', 0) <= 0
            or science.get('fully_executed') != science.get('collected')
        ):
            raise ValueError('The accepted suite lacks complete executed outcomes.')
    else:
        scientific_path = Path(science['receipt']).resolve(strict=True)
        if not scientific_path.is_relative_to(path):
            raise ValueError('The scientific receipt escapes the accepted gate.')
        if digest(scientific_path) != science['receipt_sha256']:
            raise ValueError('The scientific receipt changed after acceptance.')
        scientific = read_json(scientific_path)
        checks = scientific.get('checks', {})
        if not checks or any(value is not True for value in checks.values()):
            raise ValueError('The scientific receipt lacks its passing controls.')
    return {
        'path': str(path), 'receipt': str(receipt_path),
        'archive_member': 'task/' + receipt_path.relative_to(TASK).as_posix(),
        'receipt_sha256': digest(receipt_path),
        'passed': receipt['passed'], 'mode': mode,
        'science': science,
        'integrity_before': receipt['integrity_before'],
        'integrity_after': receipt['integrity_after'],
        'origins_before': receipt['origins_before'],
        'origins_after': receipt['origins_after'],
    }


def external_inputs() -> list[dict]:
    """Bind all seven actual wheels, two source archives and the historical seed."""
    evidence = CACHE / 'evidence'
    build = read_json(evidence / 'build/wheel-build-receipt.json')
    msm = read_json(evidence / 'controlled-molsysmt-build/wheel-receipt.json')
    pharma = read_json(evidence / 'pharmacophore-wheel-receipt.json')
    if build['source_sha'] != PRODUCER or build['candidate']['sha256'] != CANDIDATE:
        raise ValueError('The retained producer/candidate selection changed.')
    rows = []

    def add(path: Path, target: str, expected: str, role: str, **context) -> None:
        if not path.is_file() or path.is_symlink() or digest(path) != expected:
            raise ValueError(f'Exact external input is missing or changed: {path}')
        rows.append({
            'source': str(path.resolve()), 'target': member_name(target),
            'bytes': path.stat().st_size, 'sha256': expected, 'role': role, **context,
        })

    item = build['candidate']
    add(Path(item['path']), 'wheels/' + item['filename'], CANDIDATE,
        'Exact installed TopoMT development candidate', producer=PRODUCER)
    item = msm['wheel']
    add(Path(item['path']), 'wheels/' + item['filename'], item['sha256'],
        'Newly built controlled-source dependency', producer=msm['producer'])
    add(CACHE / 'dependency-wheels/pharmacophoremt' / pharma['filename'],
        'wheels/' + pharma['filename'], pharma['sha256'],
        'Newly built controlled-source dependency', producer=pharma['source_commit'])
    originals = json.loads((evidence / 'original-wheel-identities.json').read_text())
    if {row['name'] for row in originals} != {
        'alphaspace2', 'mdtraj', 'Cython', 'configargparser'
    }:
        raise ValueError('The recorded original/auxiliary wheel set changed.')
    for item in originals:
        add(CACHE / 'inputs' / item['file'], 'wheels/' + item['file'],
            item['sha256'], 'Recorded original or auxiliary wheel input',
            inherited_identity=item['identity'])
    if digest(HISTORICAL) != HISTORICAL_SHA256:
        raise ValueError('The historical public-artifact witness archive changed.')
    with ZipFile(HISTORICAL) as saved:
        public = json.loads(saved.read('original-engine/public-artifacts.json'))
    sources = [item for item in public if item['filename'].endswith('.tar.gz')]
    if len(sources) != 2:
        raise ValueError('The historical public source-archive inventory differs.')
    for item in sources:
        add(CACHE / 'inputs' / item['filename'], 'sdists/' + item['filename'],
            item['sha256'], 'Historical verified public source distribution',
            original_public_url=item['url'])
    add(CACHE / 'inputs/prepared.h5msm', 'inputs/prepared.h5msm', SEED,
        'Existing prepared seed; no new preparation')
    if len(rows) != 10 or len({row['target'] for row in rows}) != 10:
        raise ValueError('Expected seven wheels, two source archives and one seed.')
    return rows


def payload(gates: dict) -> tuple[dict[str, Path], list[dict], list[dict]]:
    """Select evidence roots explicitly while retaining every available attempt."""
    roots = [
        (CACHE / 'evidence', 'evidence'),
        (TASK / 'evidence', 'task/evidence'),
        (TASK / 'logs', 'task/logs'),
        (TASK / 'drivers', 'task/drivers'),
        (TASK / 'harness', 'task/harness'),
        (TASK / 'checker-support', 'task/checker-support'),
        (TASK / 'inputs', 'task/inputs'),
    ]
    attempts = []
    directories = {
        path for path in TASK.iterdir()
        if path.is_dir() and path.name.startswith(ATTEMPT_PREFIXES)
    }
    directories.update(Path(item['path']) for item in gates.values())
    for path in sorted(directories):
        roots.append((path, 'task/' + path.relative_to(TASK).as_posix()))
        receipt = path / 'acceptance-receipt.json'
        row = {'path': str(path), 'acceptance_receipt_present': receipt.is_file()}
        if receipt.is_file():
            value = read_json(receipt)
            row.update(
                mode=value.get('mode'), passed=value.get('passed'),
                failures=value.get('failures'), receipt_sha256=digest(receipt),
            )
        attempts.append(row)
    selected = {}
    excluded = []
    for root, prefix in roots:
        if not root.exists():
            continue
        for directory, child_directories, filenames in os.walk(root, followlinks=False):
            directory = Path(directory)
            kept = []
            for name in sorted(child_directories):
                path = directory / name
                if name in EXCLUDED_DIRECTORIES or path.is_symlink():
                    excluded.append({'path': str(path), 'reason': 'excluded cache/environment/symlink directory'})
                else:
                    kept.append(name)
            child_directories[:] = kept
            for name in sorted(filenames):
                path = directory / name
                if path.is_symlink() or name.endswith(EXCLUDED_SUFFIXES):
                    excluded.append({'path': str(path), 'reason': 'external package input, bytecode or symlink alias'})
                    continue
                if not path.is_file() or not path.resolve().is_relative_to(root.resolve()):
                    raise ValueError(f'Evidence source is not a bounded regular file: {path}')
                member = member_name(prefix + '/' + path.relative_to(root).as_posix())
                if member in selected and selected[member] != path:
                    raise ValueError(f'Evidence archive member collision: {member}')
                selected[member] = path
    # Root logs include failed bootstrap attempts and warning totals. Keep this
    # selection shallow so environment/build trees cannot enter by expansion.
    for path in sorted(CACHE.glob('*.log')):
        if path.is_file() and not path.is_symlink():
            selected[member_name('logs/' + path.name)] = path
    for name in ('run-plan.json', 'accepted-results.json', 'scientific-summary.json'):
        path = CACHE / name
        if path.is_file() and not path.is_symlink():
            # Preserve the root source bytes separately from generated gate data.
            selected[member_name('receiving/' + name)] = path
    selected['inputs/prepared.h5msm'] = CACHE / 'inputs/prepared.h5msm'
    return selected, attempts, excluded


def plan(args: argparse.Namespace) -> dict:
    """Read actual accepted results and select bounded archival inputs."""
    gates = {mode: gate(getattr(args, mode), mode) for mode in ('suite', 'flow', 'recovery')}
    artifacts = external_inputs()
    selected, attempts, excluded = payload(gates)
    return {
        'profile': 'alphaspace2-installed-receiving-retention-plan-1',
        'producer': PRODUCER, 'candidate_sha256': CANDIDATE,
        'accepted_gates': gates, 'attempt_inventory': attempts,
        'scientific_payload_files': {name: str(path) for name, path in selected.items()},
        'excluded_aliases_and_caches': excluded,
        'external_artifacts': artifacts,
        'durable_destination': str(DURABLE),
        'package_bytes_inside_scientific_zip': False,
        'scope': 'Bounded installed receiving; no full-suite/matrix/public delivery claim.',
    }


def create_archive(args: argparse.Namespace) -> dict:
    """Write and independently verify the scientific evidence ZIP and sidecar."""
    retained = plan(args)
    output = args.output_dir.resolve()
    if not output.is_relative_to(CACHE) or output.is_relative_to(CACHE / 'evidence'):
        raise ValueError('Archive output must remain outside all selected evidence roots.')
    output.mkdir(parents=True, exist_ok=True)
    archive = output / (NAME + '.zip')
    sidecar = output / (NAME + '.json')
    sums = output / (NAME + '.zip.sha256')
    if any(path.exists() for path in (archive, sidecar, sums)):
        raise FileExistsError('Never overwrite a retained evidence archive or sidecar.')
    files = {name: Path(path) for name, path in retained['scientific_payload_files'].items()}
    generated = {
        'retention-plan.json': encoded(retained),
        'accepted-results.json': encoded(retained['accepted_gates']),
    }
    manifest = {}
    for name, path in sorted(files.items()):
        manifest[name] = {'bytes': path.stat().st_size, 'sha256': digest(path)}
    for name, data in generated.items():
        manifest[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    manifest_bytes = encoded(manifest)
    with ZipFile(archive, 'x', compression=ZIP_DEFLATED, compresslevel=6) as saved:
        for name, path in sorted(files.items()):
            saved.write(path, name)
        for name, data in generated.items():
            saved.writestr(name, data)
        saved.writestr('MANIFEST.json', manifest_bytes)
    with ZipFile(archive) as saved:
        if saved.testzip() is not None or set(saved.namelist()) != set(manifest) | {'MANIFEST.json'}:
            raise ValueError('The archive CRC or exact member inventory differs.')
        for name, row in manifest.items():
            with saved.open(name) as stream:
                actual = hashlib.file_digest(stream, 'sha256').hexdigest()
            if saved.getinfo(name).file_size != row['bytes'] or actual != row['sha256']:
                raise ValueError(f'Archived evidence differs from its manifest: {name}')
    for name, path in files.items():
        if path.stat().st_size != manifest[name]['bytes'] or digest(path) != manifest[name]['sha256']:
            raise ValueError(f'Evidence changed during archival: {name}')
    for mode, item in retained['accepted_gates'].items():
        if digest(Path(item['receipt'])) != item['receipt_sha256']:
            raise ValueError(f'The selected {mode} receipt changed during archival.')
    receipt = {
        'schema_version': 1,
        'date': '2026-11-06',
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'producer': PRODUCER,
        'candidate_sha256': CANDIDATE,
        'archive': {
            'name': archive.name, 'bytes': archive.stat().st_size,
            'sha256': digest(archive), 'members': len(manifest) + 1,
            'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
        },
        'payload_inventory': manifest,
        'results': retained['accepted_gates'],
        'attempt_inventory': retained['attempt_inventory'],
        'excluded_aliases_and_caches': retained['excluded_aliases_and_caches'],
        'external_artifacts': retained['external_artifacts'],
        'durable_destination': str(DURABLE),
        'durable_verification_receipt': str(DURABLE / 'DURABLE_RECEIPT.json'),
        'archive_checks': {
            'crc_and_manifest_inventory_verified': True,
            'all_manifest_sizes_and_hashes_verified': True,
            'selected_receipts_and_evidence_unchanged_during_archival': True,
        },
        'limits': [
            'Only results read from accepted bounded receipts are reported.',
            'Every failed attempt remains archived; no result or receipt is rewritten.',
            'Seven actual wheel files and two source distributions require separate durable retention.',
            'Full environment prefixes, Cargo/tool caches and Git databases are excluded.',
            'Conda dependencies retain recorded coordinates/hashes; their complete archive bytes are not duplicated here.',
            'Source-pinned dependencies and development candidate do not establish public package availability, a full scientific suite or another platform.',
        ],
    }
    sidecar.write_bytes(encoded(receipt))
    sums.write_text(receipt['archive']['sha256'] + '  ' + archive.name + '\n')
    return {'archive': str(archive), 'sidecar': str(sidecar), **receipt['archive']}


def copy_durable(args: argparse.Namespace) -> dict:
    """Copy exact accepted package inputs and scientific evidence to durable storage.

    The caller must separately authorize the destination outside the workspace.
    Existing identical files are verified; different files are never overwritten.
    """
    output = args.output_dir.resolve()
    if not output.is_relative_to(CACHE) or output.is_relative_to(CACHE / 'evidence'):
        raise ValueError('Read scientific archive metadata only from the task cache output.')
    sidecar = output / (NAME + '.json')
    receipt = read_json(sidecar)
    if receipt.get('candidate_sha256') != CANDIDATE:
        raise ValueError('The archived candidate identity differs.')
    for mode, row in receipt['results'].items():
        current = gate(Path(row['path']), mode)
        if current['receipt_sha256'] != row['receipt_sha256']:
            raise ValueError('An accepted result changed after the scientific archive.')
    archive = output / receipt['archive']['name']
    if digest(archive) != receipt['archive']['sha256']:
        raise ValueError('The scientific evidence archive changed.')
    if external_inputs() != receipt['external_artifacts']:
        raise ValueError('An external package/seed input changed after archival.')
    inventory = {}

    def copy(path: Path, target: str, expected: str) -> None:
        target = member_name(target)
        if digest(path) != expected:
            raise ValueError(f'Input changed before durable copy: {path}')
        destination = DURABLE / target
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.is_symlink():
            raise ValueError('A durable artifact cannot be a symlink alias.')
        if destination.exists():
            if digest(destination) != expected:
                raise FileExistsError(f'Preserve the existing durable artifact: {destination}')
        else:
            with path.open('rb') as source, destination.open('xb') as saved:
                shutil.copyfileobj(source, saved)
        if digest(destination) != expected:
            raise ValueError('Durable artifact copy failed its checksum.')
        inventory[target] = {'bytes': destination.stat().st_size, 'sha256': expected}

    for row in receipt['external_artifacts']:
        copy(Path(row['source']), row['target'], row['sha256'])
    for path in (archive, sidecar, output / (NAME + '.zip.sha256')):
        copy(path, 'evidence/' + path.name, digest(path))
    manifest_bytes = encoded(inventory)
    manifest_path = DURABLE / 'MANIFEST.json'
    sums = ''.join(f"{row['sha256']}  {name}\n" for name, row in sorted(inventory.items()))
    manifest_sha = hashlib.sha256(manifest_bytes).hexdigest()
    sums += manifest_sha + '  MANIFEST.json\n'
    result = {
        'profile': 'alphaspace2-installed-durable-retention-1',
        'producer': PRODUCER, 'candidate_sha256': CANDIDATE,
        'destination': str(DURABLE),
        'scientific_archive_sha256': receipt['archive']['sha256'],
        'manifest_sha256': manifest_sha,
        'retained_files': len(inventory),
        'retained_bytes': sum(row['bytes'] for row in inventory.values()),
        'checks': {'all_files_present_and_sha256_verified': True, 'no_existing_different_file_overwritten': True},
    }
    documents = {
        manifest_path: manifest_bytes,
        DURABLE / 'SHA256SUMS': sums.encode(),
        DURABLE / 'DURABLE_RECEIPT.json': encoded(result),
    }
    for path, data in documents.items():
        if path.exists():
            if path.is_symlink() or path.read_bytes() != data:
                raise FileExistsError(f'Preserve existing durable metadata: {path}')
        else:
            with path.open('xb') as stream:
                stream.write(data)
    (output / 'durable-retention-receipt.json').write_bytes(encoded(result))
    return result


def main() -> None:
    """Plan, archive or explicitly copy accepted evidence without publishing."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['plan', 'archive', 'copy-durable'])
    parser.add_argument('--suite', type=Path)
    parser.add_argument('--flow', type=Path)
    parser.add_argument('--recovery', type=Path)
    parser.add_argument('--output-dir', type=Path, default=OUTPUT)
    args = parser.parse_args()
    if args.operation != 'copy-durable' and any(
        getattr(args, name) is None for name in ('suite', 'flow', 'recovery')
    ):
        parser.error('Select exact --suite, --flow and --recovery accepted directories.')
    operations = {'plan': plan, 'archive': create_archive, 'copy-durable': copy_durable}
    print(json.dumps(operations[args.operation](args), indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
