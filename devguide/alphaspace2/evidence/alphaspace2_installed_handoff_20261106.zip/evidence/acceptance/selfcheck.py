"""Validate acceptance bookkeeping and admission without scientific imports."""

import copy
import json
import runpy
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

base = Path(__file__).resolve().parent
namespace = runpy.run_path(
    str(base / 'acceptance.py'), run_name='acceptance_preparation'
)
results = []
outcomes_type = namespace['Outcomes']


def outcomes(*, omit_call: bool = False, skip: bool = False, xfail: bool = False):
    """Make a single native-style stage sequence for observable acceptance cases."""
    recorder = outcomes_type()
    recorder.pytest_collection_finish(
        SimpleNamespace(items=[SimpleNamespace(nodeid='tests/test_demo.py::test_case')])
    )
    for stage in ('setup', 'call', 'teardown'):
        if stage == 'call' and omit_call:
            continue
        report = SimpleNamespace(
            nodeid='tests/test_demo.py::test_case',
            when=stage,
            outcome='skipped' if skip and stage == 'call' else 'passed',
            duration=0.0,
            failed=False,
        )
        if xfail and stage == 'call':
            report.wasxfail = 'declared expected failure'
        recorder.pytest_runtest_logreport(report)
    return recorder


def require(name: str, actual: bool, expected: bool) -> None:
    """Check the acceptance decision and retain the case outcome."""
    if actual != expected:
        raise AssertionError((name, actual, expected))
    results.append(
        {'case': name, 'expected_acceptance': expected, 'actual_acceptance': actual}
    )


require('complete-passing-stages', outcomes().receipt(0)['passed'], True)
require('zero-executed-cases', outcomes_type().receipt(0)['passed'], False)
require('missing-call-stage', outcomes(omit_call=True).receipt(0)['passed'], False)
require('skipped-case', outcomes(skip=True).receipt(0)['passed'], False)
require('xfail-or-xpass-case', outcomes(xfail=True).receipt(0)['passed'], False)
require('nonzero-pytest-exit', outcomes().receipt(1)['passed'], False)
recorder = outcomes()
recorder.deselected.append('tests/test_demo.py::test_omitted')
require('deselected-case', recorder.receipt(0)['passed'], False)
recorder = outcomes()
recorder.reports.append(copy.deepcopy(recorder.reports[1]))
require('repeated-call-stage', recorder.receipt(0)['passed'], False)

task = Path('/tmp/topomt-alphaspace2-installed-y1j8k2e8')
manifest_path = base.parent / 'harness/manifest.json'
manifest, checker = namespace['_manifest'](manifest_path, task / 'harness', task)
require('producer-hashed-detached-support', bool(manifest['files']), True)
run = Path(tempfile.mkdtemp(prefix='acceptance-selfcheck-', dir=base))
bad_manifest = copy.deepcopy(manifest)
bad_manifest['files'][0]['target'] = 'harness/../source/topomt/__init__.py'
(run / 'unsafe-manifest.json').write_text(json.dumps(bad_manifest))
try:
    namespace['_manifest'](run / 'unsafe-manifest.json', task / 'harness', task)
except ValueError:
    require('manifest-traversal-rejected', False, False)
else:
    raise AssertionError('Manifest traversal was accepted')

candidate = json.loads((base.parent / 'build/wheel-build-receipt.json').read_text())[
    'candidate'
]
fake_dist = SimpleNamespace(
    _path=task / 'env/lib/python3.14/site-packages/topomt.dist-info',
    read_text=lambda name: json.dumps({'dir_info': {'editable': True}}),
)
with patch('importlib.metadata.distribution', return_value=fake_dist):
    try:
        namespace['_candidate'](
            task / 'env', Path(candidate['path']), candidate['sha256']
        )
    except ValueError:
        require('editable-candidate-rejected-before-runtime-import', False, False)
    else:
        raise AssertionError('Editable candidate was accepted')
scientific = [
    name
    for name in sys.modules
    if name.split('.')[0]
    in {'topomt', 'molsysmt', 'pharmacophoremt', 'alphaspace2', 'numpy'}
]
if scientific:
    raise AssertionError(scientific)
summary = {
    'cases': results,
    'scientific_imports': scientific,
    'actual_suite_or_flow_executed': False,
}
(base / 'selfcheck-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
