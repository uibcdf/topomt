"""Inspect reader package metadata and origins without executing scientific code."""

import hashlib
import importlib.metadata as metadata
import importlib.util
import json
import re
import sys
from pathlib import Path

EVIDENCE = Path(__file__).resolve().parent / 'engine-free-environment'
PREFIX = Path('/tmp/topomt-alphaspace2-installed-y1j8k2e8/engine-free-env')
MAIN = PREFIX.parent / 'env'


def distributions(prefix: Path) -> dict[str, str]:
    """Read distribution identities from one prefix without importing packages."""
    return {
        re.sub(r'[-_.]+', '-', item.metadata['Name']).lower(): item.version
        for item in metadata.distributions(
            path=[str(prefix / 'lib/python3.14/site-packages')]
        )
    }


def main() -> None:
    """Verify exact reader inputs, engine absence and the shared dependency closure."""
    assert Path(sys.prefix).resolve() == PREFIX
    assert sys.flags.isolated and sys.flags.no_user_site
    inputs = json.loads((EVIDENCE / 'inputs.json').read_text())
    roots = {'Cython': 'Cython', 'configargparser': 'configargparser'}
    origins = {}
    for row in inputs:
        name = row['name']
        distribution = metadata.distribution(name)
        direct = json.loads(distribution.read_text('direct_url.json'))
        assert direct['archive_info']['hashes']['sha256'] == row['sha256']
        assert not direct.get('dir_info', {}).get('editable', False)
        spec = importlib.util.find_spec(roots.get(name, name))
        assert spec is not None and spec.origin is not None
        origin = Path(spec.origin).resolve()
        assert origin.is_relative_to(PREFIX)
        origins[name] = {
            'version': distribution.version,
            'origin': str(origin),
            'origin_sha256': hashlib.sha256(origin.read_bytes()).hexdigest(),
            'wheel_sha256': row['sha256'],
            'direct_url': direct,
        }
    absent = {}
    for name in ('alphaspace2', 'mdtraj'):
        try:
            metadata.distribution(name)
        except metadata.PackageNotFoundError:
            absent[name] = True
        else:
            raise AssertionError(f'Original engine distribution is present: {name}')
        assert importlib.util.find_spec(name) is None
    assert not list((PREFIX / 'lib/python3.14/site-packages').glob('__editable__*'))
    expected = distributions(MAIN)
    expected.pop('alphaspace2')
    expected.pop('mdtraj')
    actual = distributions(PREFIX)
    assert actual == expected, {
        'unexpected': sorted(set(actual) - set(expected)),
        'missing': sorted(set(expected) - set(actual)),
        'changed': {
            name: [actual[name], expected[name]] for name in actual.keys() & expected.keys()
            if actual[name] != expected[name]
        },
    }
    scientific = {'topomt', 'molsysmt', 'pharmacophoremt', 'numpy', 'alphaspace2', 'mdtraj'}
    assert not scientific.intersection(sys.modules)
    records = [
        {key: item.get(key) for key in ('name', 'version', 'build', 'fn', 'url', 'sha256')}
        for path in sorted((PREFIX / 'conda-meta').glob('*.json'))
        if (item := json.loads(path.read_text()))
    ]
    result = {
        'profile': 'alphaspace2-engine-free-installed-reader-environment-1',
        'prefix': str(PREFIX), 'python': sys.version,
        'bootstrap': 'Official native conda create --clone --copy --offline; exact cached receptor closure added.',
        'engine_distribution_absence': absent,
        'selected_input_origins': origins,
        'distribution_versions': actual,
        'conda_packages': records,
        'checks': {
            'exact_wheel_input_hashes': True,
            'selected_import_specs_inside_reader_prefix': True,
            'no_editable_artifacts': True,
            'original_engine_distributions_and_specs_absent': True,
            'same_distribution_versions_as_receiver_except_two_original_engines': True,
            'no_scientific_package_import_or_calculation': True,
        },
        'scope': 'Static metadata/import-spec readiness; runtime before/after integrity and engine-free receiving remain pending.',
    }
    (EVIDENCE / 'profile.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({
        'prefix': str(PREFIX), 'distributions': len(actual),
        'conda_packages': len(records), 'checks': result['checks'],
    }, indent=2))


if __name__ == '__main__':
    main()
