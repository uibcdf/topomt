"""Build one source-pinned MolSysMT dependency without changing sibling checkouts."""

import argparse
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

ROOT = Path('/fast_data/home/liliana/repos@uibcdf/topomt')
TASK = ROOT / '.cache/alphaspace2-installed-receiving'
EVIDENCE = TASK / 'evidence/controlled-molsysmt-build'
SIBLING = ROOT.parent / 'molsysmt'
SOURCE = TASK / 'dependency-sources/molsysmt'
COMMIT = '00abb958fb93649131d5ce5fe5e12e90cf4900e9'
TOOLS = TASK / 'dependency-build-tools'
PYTHON = TOOLS / 'bin/python'
BASE_PYTHON = Path('/fast_data/home/liliana/miniconda3/envs/topomt-dev/bin/python')
RUST = Path('/fast_data/home/liliana/miniconda3/envs/molsyssuite@uibcdf_3.14/bin')


def digest(path: Path) -> str:
    """Return a file's exact SHA-256 without importing its package."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def record(command: list[str], label: str, *, cwd: Path = ROOT,
           environment: dict[str, str] | None = None) -> None:
    """Run a recorded command and retain successful and failed output unchanged."""
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    log = EVIDENCE / f'{label}-{time.time_ns()}.log'
    start = time.monotonic()
    with log.open('xb') as output:
        result = subprocess.run(
            command, cwd=cwd, env=environment, stdout=output,
            stderr=subprocess.STDOUT, check=False,
        )
    receipt = {
        'command': command,
        'cwd': str(cwd),
        'exit_code': result.returncode,
        'duration_seconds': time.monotonic() - start,
        'log': str(log),
        'log_sha256': digest(log),
    }
    with (EVIDENCE / 'commands.jsonl').open('a') as output:
        output.write(json.dumps(receipt) + '\n')
    print(json.dumps(receipt), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)


def snapshot_sibling() -> dict:
    """Capture the principal sibling state and extension bytes as protected inputs."""
    return {
        'head': subprocess.check_output(
            ['git', 'rev-parse', 'HEAD'], cwd=SIBLING, text=True
        ).strip(),
        'status': subprocess.check_output(
            ['git', 'status', '--porcelain'], cwd=SIBLING, text=True
        ),
        'extension_sha256': digest(SIBLING / 'molsysmt/_rust.abi3.so'),
    }


def main() -> None:
    """Prepare tools/source or build only the isolated dependency candidate."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        'phase', choices=['prepare', 'tools', 'build', 'validate', 'verify-sibling']
    )
    args = parser.parse_args()
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    if args.phase == 'prepare':
        if SOURCE.exists() or TOOLS.exists():
            raise FileExistsError('Use a new isolated dependency source/tool root.')
        (EVIDENCE / 'sibling-before.json').write_text(
            json.dumps(snapshot_sibling(), indent=2) + '\n'
        )
        SOURCE.parent.mkdir(parents=True, exist_ok=True)
        record([
            'git', 'clone', '--no-local', '--no-hardlinks', '--no-checkout',
            str(SIBLING), str(SOURCE),
        ], 'clone')
        record(['git', 'checkout', '--detach', COMMIT], 'checkout', cwd=SOURCE)
        if (SOURCE / '.git/objects/info/alternates').exists():
            raise ValueError('The dependency clone cannot borrow Git objects.')
        record([str(BASE_PYTHON), '-m', 'venv', str(TOOLS)], 'build-venv')
    elif args.phase == 'tools':
        environment = os.environ.copy()
        environment['PIP_CACHE_DIR'] = str(TASK / 'dependency-pip-cache')
        environment['PYTHONNOUSERSITE'] = '1'
        record([
            str(PYTHON), '-m', 'pip', 'install', '--report',
            str(EVIDENCE / 'python-build-tools-report.json'),
            'setuptools>=68.0', 'versioningit>=3.0', 'setuptools-rust>=1.10',
        ], 'python-build-tools', environment=environment)
    elif args.phase == 'build':
        environment = os.environ.copy()
        environment.update({
            'PATH': str(RUST) + os.pathsep + str(TOOLS / 'bin') + os.pathsep
            + environment.get('PATH', ''),
            'CARGO_HOME': str(TASK / 'dependency-cargo-home'),
            'CARGO_TARGET_DIR': str(TASK / 'dependency-cargo-target'),
            'CARGO': str(RUST / 'cargo'),
            'RUSTC': str(RUST / 'rustc'),
            'PYO3_PYTHON': str(PYTHON),
            'PYTHONNOUSERSITE': '1',
            'PIP_CACHE_DIR': str(TASK / 'dependency-pip-cache'),
            'CARGO_BUILD_JOBS': '4',
        })
        environment.pop('PYTHONPATH', None)
        environment.pop('RUSTFLAGS', None)
        environment.pop('CARGO_ENCODED_RUSTFLAGS', None)
        (TASK / 'dependency-wheels').mkdir(exist_ok=True)
        record([
            str(PYTHON), '-m', 'pip', 'wheel', '--no-deps', '--no-build-isolation',
            '--wheel-dir', str(TASK / 'dependency-wheels'), str(SOURCE),
        ], 'molsysmt-wheel', cwd=SOURCE, environment=environment)
    elif args.phase == 'validate':
        wheels = list((TASK / 'dependency-wheels').glob('molsysmt-*.whl'))
        if len(wheels) != 1:
            raise ValueError('Exactly one controlled MolSysMT wheel is required.')
        record([
            str(PYTHON), str(SOURCE / 'devtools/scripts/validate_rust_wheel.py'),
            str(wheels[0]),
        ], 'owner-wheel-validator', cwd=SOURCE)
    else:
        before = json.loads((EVIDENCE / 'sibling-before.json').read_text())
        after = snapshot_sibling()
        if before != after:
            raise ValueError('The protected sibling changed during dependency work.')
        (EVIDENCE / 'sibling-after.json').write_text(
            json.dumps(after, indent=2) + '\n'
        )
        print('Principal MolSysMT checkout and Rust extension remain unchanged.')


if __name__ == '__main__':
    main()
