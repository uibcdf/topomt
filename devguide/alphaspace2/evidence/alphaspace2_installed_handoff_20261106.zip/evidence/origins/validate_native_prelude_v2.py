"""Validate native ownership for the actual acceptance prelude, without science."""

import hashlib
import importlib
import json
import os
import sys
from pathlib import Path


def main() -> int:
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
    os.nice(10)
    task = Path('/tmp/topomt-alphaspace2-installed-y1j8k2e8')
    evidence = Path(sys.argv[1]).resolve()
    config_path = evidence / 'native-attestations-acceptance-v2.json'
    config = json.loads(config_path.read_text())
    sys.path[:0] = [str(task / 'checker-support'), str(task / 'harness')]
    from origin_probe import OriginProbe

    probe = OriginProbe(
        prefix=Path(sys.prefix),
        harness_manifest=evidence.parent / 'harness/manifest.json',
        forbidden_roots=(Path('/fast_data/home/liliana/repos@uibcdf'),),
        driver_files=(Path(__file__),),
        native_generated=config,
    )
    os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
    for name in ('topomt', 'pytest', 'pytest_receptor.plugin'):
        importlib.import_module(name)
    if 'mdtraj.geometry._geometry' in sys.modules:
        raise ValueError('The actual prelude unexpectedly preimported MDTraj geometry')
    before = probe.audit(required_roots=('topomt',))
    probe.write_report(evidence / 'native-acceptance-v2-prelude.json', before)
    if not before['passed'] or before['pharmacophoremt_loaded']:
        raise ValueError(f'Acceptance prelude audit failed: {before["findings"]}')
    for name in ('numpy', 'scipy', 'mdtraj', 'alphaspace2'):
        importlib.import_module(name)
    after = probe.audit(required_roots=('topomt', 'mdtraj', 'alphaspace2'))
    probe.write_report(evidence / 'native-acceptance-v2-full-imports.json', after)
    if not after['passed'] or after['pharmacophoremt_loaded']:
        raise ValueError(f'Full import-only audit failed: {after["findings"]}')
    report = {
        'profile': 'alphaspace2-native-acceptance-prelude-v2',
        'configuration': str(config_path),
        'configuration_sha256': hashlib.sha256(config_path.read_bytes()).hexdigest(),
        'original_configuration_sha256': hashlib.sha256(
            (evidence / 'native-attestations.json').read_bytes()
        ).hexdigest(),
        'helper_sha256': hashlib.sha256(
            (task / 'checker-support/origin_probe.py').read_bytes()
        ).hexdigest(),
        'prelude': {
            'passed': before['passed'],
            'modules': before['module_count'],
            'mdtraj_geometry_forced': False,
            'owner_proof': before['modules']['cython_runtime'],
        },
        'full_imports': {
            'passed': after['passed'],
            'modules': after['module_count'],
            'owner_proof': after['modules']['cython_runtime'],
        },
        'pharmacophoremt_loaded': False,
        'limits': [
            'Imports and origin observation only; no detection, chemistry, recognition or pytest execution.',
            'Shared runtime ownership evidence does not identify which extension created it first or exact dependency compiler inputs.',
        ],
    }
    probe.write_report(evidence / 'native-acceptance-v2-validation.json', report)
    print(
        json.dumps(
            {
                'passed': True,
                'config_sha256': report['configuration_sha256'],
                'prelude_modules': before['module_count'],
                'full_import_modules': after['module_count'],
                'pharmacophoremt_loaded': False,
            }
        )
    )
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
