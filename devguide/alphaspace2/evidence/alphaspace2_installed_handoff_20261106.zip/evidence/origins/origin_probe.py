"""Temporary AlphaSpace2 receiving observer; imports no scientific provider.

Use the unchanged central checker for normal provider roots, then inspect every
loaded module and search path. Unknown fileless modules fail visibly. This is
runtime provenance evidence, complementary to independent prefix integrity.
"""

import ast
import hashlib
import importlib
import importlib.machinery
import importlib.metadata
import importlib.util
import json
import sys
import sysconfig
from pathlib import Path
from types import ModuleType

NORMAL_ROOTS = (
    'topomt',
    'molsysviewer_topomt',
    'molsysmt',
    'molsysviewer_molsysmt',
    'pharmacophoremt',
    'molsysviewer_pharmacophoremt',
    'molsysviewer',
    'smonitor',
    'argdigest',
    'depdigest',
    'pytest_receptor',
    'alphaspace2',
    'mdtraj',
    'numpy',
    'scipy',
    'numba',
    'llvmlite',
)

CYTHON_SHADOW_OBJECTS = {
    'cython.parallel': (
        'CythonDotParallel',
        ('parallel', 'prange', 'threadid'),
        "sys.modules['cython.parallel'] = CythonDotParallel()",
    ),
    'cython.cimports': (
        'CythonCImports',
        ('__init__', '__getattr__'),
        "sys.modules['cython.cimports'] = CythonCImports('cython.cimports', libc=sys.modules['cython.cimports.libc'])",
    ),
    'cython.cimports.libc': (
        'CythonCImports',
        ('__init__', '__getattr__'),
        "sys.modules['cython.cimports.libc'] = CythonCImports('cython.cimports.libc', math=math)",
    ),
    'cython.dataclasses': (
        'CythonDotImportedFromElsewhere',
        ('__init__', '__getattr__'),
        "dataclasses = sys.modules['cython.dataclasses'] = CythonDotImportedFromElsewhere('dataclasses')",
    ),
}


def _sha256(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def _namespace(module) -> dict:
    if not isinstance(module, ModuleType):
        raise ValueError('sys.modules entry is not a module')
    return vars(module)


class OriginProbe:
    """Observe this process without preimporting providers or patching origins.

    ``native_generated`` maps exact module names to explicit native-owner
    attestations. Native kinds are ``native-parent-binding`` and
    ``cython-generated-runtime``. Four exact Cython.Shadow objects additionally
    support ``python-provider-generated-object`` with installed-owner proofs.
    No kind is enabled by an unproved name alone.
    Required roots are assertions about already loaded modules, not imports.
    """

    def __init__(
        self,
        *,
        prefix: Path,
        harness_manifest: Path,
        forbidden_roots: tuple[Path, ...],
        driver_files: tuple[Path, ...] = (),
        native_generated: dict | None = None,
    ) -> None:
        self.prefix = prefix.resolve()
        self.manifest_path = harness_manifest.resolve()
        self.manifest = json.loads(self.manifest_path.read_text())
        self.manifest_sha256 = _sha256(self.manifest_path)
        self.harness = Path(self.manifest['harness_root']).resolve()
        self.checker = Path(self.manifest['checker_support_root']).resolve()
        self.forbidden = tuple(path.resolve() for path in forbidden_roots)
        self.drivers = {path.resolve(): _sha256(path) for path in driver_files}
        self.native_generated = dict(native_generated or {})
        self.helper = Path(__file__).resolve()
        self.helper_sha256 = _sha256(self.helper)
        self.stdlib = Path(sysconfig.get_path('stdlib')).resolve()
        self.expected = {}
        for item in self.manifest['files']:
            target = Path(item['target'])
            if target.parts[0] not in {'harness', 'checker-support'}:
                raise ValueError('unexpected detached-support manifest target')
            path = (self.harness.parent / target).resolve()
            if not path.is_relative_to(self.harness.parent):
                raise ValueError('detached-support manifest target escapes task root')
            self.expected[path] = item['sha256']

    def _location(self, value: str, *, search_path: bool = False) -> dict:
        path = Path(value).resolve()
        if any(path.is_relative_to(root) for root in self.forbidden):
            raise ValueError(f'forbidden source/checkout location: {path}')
        if path.is_relative_to(self.prefix):
            role = 'installed-prefix'
        elif path.is_relative_to(self.stdlib) and not {
            'site-packages',
            'dist-packages',
        }.intersection(path.parts):
            role = 'stdlib'
        elif path in self.drivers:
            role = 'declared-driver'
        elif path == self.helper:
            role = 'temporary-origin-observer'
        else:
            source = path
            if path.suffix == '.pyc':
                try:
                    source = Path(importlib.util.source_from_cache(str(path))).resolve()
                except ValueError:
                    pass
            declared = source in self.expected
            if search_path:
                declared = (
                    declared
                    or any(expected.is_relative_to(path) for expected in self.expected)
                    and path in {self.harness, self.checker}
                )
            elif path.is_dir():
                declared = any(
                    expected.is_relative_to(path) for expected in self.expected
                )
            if not declared:
                raise ValueError(f'undeclared external module/search location: {path}')
            role = 'declared-detached-support'
        return {'path': str(path), 'role': role}

    def _unit_alias(self, name: str, module, modules: dict) -> dict:
        if name != 'pyunitwizard.main':
            raise ValueError(f'unproved fileless module: {name}')
        root = modules.get('pyunitwizard')
        namespace = _namespace(root)
        filename = Path(namespace.get('__file__', '')).resolve()
        if not filename.is_relative_to(self.prefix):
            raise ValueError('PyUnitWizard alias generator is outside prefix')
        alias = _namespace(module)
        functions = {}
        for attr in ('__getattr__', '__dir__'):
            function = alias.get(attr)
            code = getattr(function, '__code__', None)
            if (
                code is None
                or Path(code.co_filename).resolve() != filename
                or function.__globals__ is not namespace
            ):
                raise ValueError(
                    f'PyUnitWizard alias lacks installed generator: {attr}'
                )
            functions[attr] = {'code_file': str(filename), 'code_name': code.co_name}
        generated = namespace.get('_create_main_compat_module')
        if (
            getattr(generated, '__code__', None) is None
            or Path(generated.__code__.co_filename).resolve() != filename
            or tuple(alias.get('__all__', ())) != tuple(namespace.get('__all__', ()))
            or alias.get('__spec__') is not None
        ):
            raise ValueError('PyUnitWizard compatibility generator/exports mismatch')
        return {
            'kind': 'proved-pyunitwizard-main-alias',
            'generator_file': str(filename),
            'generator_sha256': _sha256(filename),
            'functions': functions,
        }

    def _native_owner(self, owner_name: str, modules: dict) -> tuple[object, Path]:
        owner = modules.get(owner_name)
        data = _namespace(owner)
        spec = data.get('__spec__')
        filename = Path(data.get('__file__', '')).resolve()
        if (
            spec is None
            or not isinstance(spec.loader, importlib.machinery.ExtensionFileLoader)
            or not filename.is_relative_to(self.prefix)
            or Path(spec.origin).resolve() != filename
            or not any(
                str(filename).endswith(suffix)
                for suffix in importlib.machinery.EXTENSION_SUFFIXES
            )
        ):
            raise ValueError(f'owner is not a loaded installed extension: {owner_name}')
        return owner, filename

    def _python_generated(self, name: str, value, modules: dict) -> dict:
        if name not in CYTHON_SHADOW_OBJECTS:
            raise ValueError(f'undeclared Cython generated-object name: {name}')
        class_name, methods, registration = CYTHON_SHADOW_OBJECTS[name]
        evidence = self.native_generated[name]
        if evidence.get('owner_module') != 'Cython.Shadow':
            raise ValueError('generated-object owner must be Cython.Shadow')
        owner = modules.get('Cython.Shadow')
        namespace = _namespace(owner)
        filename = Path(namespace.get('__file__', '')).resolve()
        expected = (self.prefix / evidence['owner_relative_path']).resolve()
        spec = namespace.get('__spec__')
        if (
            not filename.is_relative_to(self.prefix)
            or filename != expected
            or spec is None
            or Path(spec.origin).resolve() != filename
            or not isinstance(spec.loader, importlib.machinery.SourceFileLoader)
        ):
            raise ValueError('generated-object owner is outside prefix or declaration')
        if _sha256(filename) != evidence.get('owner_sha256'):
            raise ValueError('generated-object owner source hash differs')
        klass = namespace.get(class_name)
        if evidence.get('owner_class') != class_name or type(value) is not klass:
            raise ValueError('generated-object owner class/type identity differs')
        code_origins = {}
        for method in methods:
            function = vars(klass).get(method)
            code = getattr(function, '__code__', None)
            if (
                code is None
                or Path(code.co_filename).resolve() != filename
                or function.__globals__ is not namespace
            ):
                raise ValueError('generated-object method code is outside owner')
            code_origins[method] = str(filename)
        contents = filename.read_text()
        if (
            evidence.get('factory_registration') != registration
            or registration not in contents
        ):
            raise ValueError('generated-object factory registration literal differs')
        found = False
        for node in ast.parse(contents).body:
            if not isinstance(node, ast.Assign) or not isinstance(node.value, ast.Call):
                continue
            if (
                not isinstance(node.value.func, ast.Name)
                or node.value.func.id != class_name
            ):
                continue
            for target in node.targets:
                if (
                    isinstance(target, ast.Subscript)
                    and isinstance(target.value, ast.Attribute)
                    and isinstance(target.value.value, ast.Name)
                    and target.value.value.id == 'sys'
                    and target.value.attr == 'modules'
                    and isinstance(target.slice, ast.Constant)
                    and target.slice.value == name
                ):
                    found = True
        if not found:
            raise ValueError('generated-object factory registration AST is absent')
        linked = evidence.get('linked_module_files', {})
        if set(linked) != {'Cython', 'cython'}:
            raise ValueError('both linked Cython wrapper declarations are required')
        wrappers = {}
        for linked_name, row in linked.items():
            wrapper = _namespace(modules.get(linked_name))
            path = Path(wrapper.get('__file__', '')).resolve()
            expected = (self.prefix / row['relative_path']).resolve()
            wrapper_spec = wrapper.get('__spec__')
            if (
                not path.is_relative_to(self.prefix)
                or path != expected
                or wrapper_spec is None
                or Path(wrapper_spec.origin).resolve() != path
                or _sha256(path) != row['sha256']
            ):
                raise ValueError('linked Cython wrapper origin/hash differs')
            if wrapper.get(class_name) is not klass:
                raise ValueError('linked Cython class identity differs')
            wrappers[linked_name] = {'path': str(path), 'sha256': row['sha256']}
        data = vars(value)
        state = {}
        if name in {'cython.cimports', 'cython.cimports.libc', 'cython.dataclasses'}:
            expected_name = 'dataclasses' if name == 'cython.dataclasses' else name
            if (
                data.get('__name__') != expected_name
                or data.get('__package__') != expected_name
                or data.get('__file__') is not None
                or data.get('__path__') != []
            ):
                raise ValueError('generated Cython object naming/search state differs')
            state['declared_name'] = expected_name
        if name == 'cython.cimports':
            if data.get('libc') is not modules.get('cython.cimports.libc'):
                raise ValueError('Cython cimports libc object binding differs')
            state['libc_binding'] = 'cython.cimports.libc'
        if name == 'cython.cimports.libc':
            math = modules.get('math')
            if (
                math is None
                or data.get('math') is not math
                or modules.get('cython.cimports.libc.math') is not math
            ):
                raise ValueError('Cython libc math alias binding differs')
            state['math_binding'] = 'math'
        if name == 'cython.dataclasses':
            if namespace.get('dataclasses') is not value:
                raise ValueError('Cython Shadow dataclasses object binding differs')
            state['owner_dataclasses_binding'] = True
        return {
            'kind': 'proved-python-provider-generated-object',
            'owner_module': 'Cython.Shadow',
            'owner_class': class_name,
            'owner_file': str(filename),
            'owner_sha256': evidence['owner_sha256'],
            'method_code_origins': code_origins,
            'factory_registration': registration,
            'factory_registration_ast_verified': True,
            'linked_wrappers': wrappers,
            'linked_state': state,
            'limit': 'Four exact provider-created compatibility objects; no inference that arbitrary non-module sys.modules entries are valid.',
        }

    def _native_generated(self, name: str, module, modules: dict) -> dict:
        evidence = self.native_generated[name]
        owner_name = evidence['owner_module']
        owner, filename = self._native_owner(owner_name, modules)
        if _namespace(module).get('__spec__') is not None:
            raise ValueError(f'generated module has unexpected spec: {name}')
        result = {
            'kind': evidence['kind'],
            'owner_module': owner_name,
            'owner_file': str(filename),
            'owner_sha256': _sha256(filename),
        }
        if evidence['kind'] == 'native-parent-binding':
            if not name.startswith(owner_name + '.'):
                raise ValueError('generated module is outside declared native owner')
            chain = []
            child_name, child = name, module
            while child_name != owner_name:
                parent_name, _, attribute = child_name.rpartition('.')
                parent = modules.get(parent_name)
                if _namespace(parent).get(attribute) is not child:
                    raise ValueError(
                        f'failed native parent object binding: {child_name}'
                    )
                chain.append(
                    {'child': child_name, 'parent': parent_name, 'attribute': attribute}
                )
                child_name, child = parent_name, parent
            if child is not owner:
                raise ValueError('native binding chain reaches another object')
            result['binding_chain'] = chain
        elif evidence['kind'] == 'cython-generated-runtime':
            # A qualification driver must name the inspected owner and installed
            # generator files, exact hashes and literal factory markers. Never
            # accept all names beginning with _cython or cython_runtime blindly.
            if not evidence.get('review_reason') or not evidence.get('generator_files'):
                raise ValueError(
                    'Cython runtime requires explicit reviewed generator evidence'
                )
            if name.encode() not in filename.read_bytes():
                raise ValueError(
                    'loaded native owner lacks declared runtime name marker'
                )
            generators = []
            for row in evidence['generator_files']:
                path = (self.prefix / row['relative_path']).resolve()
                if (
                    not path.is_relative_to(self.prefix)
                    or _sha256(path) != row['sha256']
                ):
                    raise ValueError('Cython generator path/hash differs')
                contents = path.read_text()
                if not row.get('markers') or any(
                    marker not in contents for marker in row['markers']
                ):
                    raise ValueError('Cython generator lacks reviewed factory markers')
                generators.append({**row, 'path': str(path)})
            result.update(
                generator_files=generators,
                review_reason=evidence['review_reason'],
                public_attributes=sorted(
                    key for key in vars(module) if not key.startswith('__')
                ),
                limit='Factory source plus a loaded owner binary marker; not a tamper-proof proof of which extension first created the shared runtime.',
            )
        else:
            raise ValueError('unsupported generated-module attestation kind')
        return result

    def _module(self, name: str, module, modules: dict) -> dict:
        if (
            not isinstance(module, ModuleType)
            and name in self.native_generated
            and self.native_generated[name].get('kind')
            == 'python-provider-generated-object'
        ):
            return self._python_generated(name, module, modules)
        data = _namespace(module)
        locations = [data['__file__']] if data.get('__file__') else []
        package_paths = data.get('__path__', ())
        if isinstance(package_paths, (str, bytes)):
            raise ValueError(f'invalid package search locations: {name}')
        locations.extend(package_paths)
        spec = data.get('__spec__')
        origin = getattr(spec, 'origin', None)
        if origin and origin not in {'built-in', 'frozen'}:
            locations.append(origin)
        if locations:
            return {
                'kind': 'files',
                'locations': [
                    self._location(location) for location in dict.fromkeys(locations)
                ],
            }
        if spec is not None and modules.get(spec.name) is module:
            if (
                origin == 'built-in'
                and spec.loader is importlib.machinery.BuiltinImporter
            ):
                return {'kind': 'builtin', 'spec_name': spec.name}
            if origin == 'frozen' and spec.loader is importlib.machinery.FrozenImporter:
                return {'kind': 'frozen', 'spec_name': spec.name}
        if name == 'pyunitwizard.main':
            return self._unit_alias(name, module, modules)
        if name in self.native_generated:
            return self._native_generated(name, module, modules)
        raise ValueError(f'unproved fileless module: {name}')

    def audit(self, *, required_roots: tuple[str, ...] = ()) -> dict:
        """Return a pass/fail receipt for currently loaded modules; import none."""
        findings = []
        if _sha256(self.manifest_path) != self.manifest_sha256:
            findings.append(
                {
                    'boundary': 'support-manifest',
                    'error': 'manifest changed since observer initialization',
                }
            )
        if Path(sys.prefix).resolve() != self.prefix:
            findings.append(
                {'boundary': 'prefix', 'error': 'wrong receiving interpreter'}
            )
        for path, expected in self.expected.items():
            try:
                if _sha256(path) != expected:
                    raise ValueError('detached-support hash differs')
            except (OSError, ValueError) as error:
                findings.append(
                    {
                        'boundary': 'support-integrity',
                        'path': str(path),
                        'error': str(error),
                    }
                )
        for path, expected in {**self.drivers, self.helper: self.helper_sha256}.items():
            if _sha256(path) != expected:
                findings.append(
                    {
                        'boundary': 'driver-helper-integrity',
                        'path': str(path),
                        'error': 'hash differs since observer initialization',
                    }
                )
        central = None
        try:
            checker = importlib.import_module('installed_imports')
            if (
                Path(checker.__file__).resolve()
                != self.checker / 'installed_imports.py'
            ):
                raise ValueError('wrong central checker import origin')
            central = checker.check_installed_imports(
                NORMAL_ROOTS,
                self.prefix,
                self.forbidden[0]
                if self.forbidden
                else self.harness.parent / 'not-a-source',
            )
        except Exception as error:
            findings.append(
                {
                    'boundary': 'unchanged-central-checker',
                    'error': f'{type(error).__name__}: {error}',
                }
            )
        modules = dict(sys.modules)
        checked, sentinels, unknown = {}, [], {}
        for name, module in sorted(modules.items()):
            if module is None:
                sentinels.append(name)
                continue
            try:
                checked[name] = self._module(name, module, modules)
            except (OSError, TypeError, ValueError, AttributeError) as error:
                data = vars(module) if isinstance(module, ModuleType) else {}
                unknown[name] = {
                    'error': str(error),
                    'file': data.get('__file__'),
                    'spec_origin': getattr(data.get('__spec__'), 'origin', None),
                    'loader_type': type(
                        getattr(data.get('__spec__'), 'loader', None)
                    ).__name__,
                    'attributes': sorted(str(key) for key in data),
                }
                findings.append(
                    {'boundary': 'loaded-module', 'module': name, 'error': str(error)}
                )
        paths = []
        for value in sys.path:
            try:
                paths.append(self._location(value or str(Path.cwd()), search_path=True))
            except (OSError, TypeError, ValueError) as error:
                findings.append(
                    {'boundary': 'sys.path', 'path': str(value), 'error': str(error)}
                )
        editables = [name for name in modules if name.startswith('__editable__')]
        for name in editables:
            findings.append({'boundary': 'editable-import', 'module': name})
        distributions = []
        for dist in importlib.metadata.distributions():
            metadata_path = Path(dist._path).resolve()
            direct = json.loads(dist.read_text('direct_url.json') or '{}')
            editable = direct.get('dir_info', {}).get('editable') is True
            row = {
                'name': dist.metadata.get('Name'),
                'version': dist.version,
                'metadata_path': str(metadata_path),
                'editable': editable,
            }
            distributions.append(row)
            if not metadata_path.is_relative_to(self.prefix) or editable:
                findings.append({'boundary': 'distribution-origin', **row})
        for name in required_roots:
            if name not in modules or modules[name] is None:
                findings.append({'boundary': 'required-loaded-root', 'module': name})
        unchanged = all(
            sys.modules.get(name) is module for name, module in modules.items()
        )
        if not unchanged:
            findings.append(
                {
                    'boundary': 'observer-stability',
                    'error': 'loaded module object changed during observation',
                }
            )
        return {
            'profile': 'alphaspace2-installed-runtime-origins-1',
            'passed': not findings,
            'findings': findings,
            'python': sys.version,
            'prefix': str(self.prefix),
            'checker': {
                'commit': self.manifest.get('checker_commit'),
                'result': central,
            },
            'helper': {'path': str(self.helper), 'sha256': self.helper_sha256},
            'manifest': {
                'path': str(self.manifest_path),
                'sha256': _sha256(self.manifest_path),
            },
            'normal_roots': list(NORMAL_ROOTS),
            'required_loaded_roots': list(required_roots),
            'normal_roots_not_loaded': [
                name for name in NORMAL_ROOTS if name not in modules
            ],
            'modules': checked,
            'unproved_modules': unknown,
            'none_sentinels': sentinels,
            'module_count': len(modules),
            'sys_path': paths,
            'distributions': sorted(
                distributions, key=lambda row: str(row['name']).lower()
            ),
            'snapshot_module_objects_preserved': unchanged,
            'pharmacophoremt_loaded': 'pharmacophoremt' in modules,
            'limits': [
                'Loaded modules only; optional roots are never imported by this observer.',
                'PyUnitWizard main alias uses installed generator code evidence outside the unchanged checker limitation.',
                'Unknown fileless modules are retained as failures; native attestations require explicit owner evidence.',
                'The driver owns application policy selection before PharmacophoreMT import.',
                'Conda/pip file authenticity and before/after integrity are separate checks.',
            ],
        }

    @staticmethod
    def write_report(path: Path, report: dict) -> None:
        """Preserve a new JSON receipt without overwriting earlier observations."""
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('x') as stream:
            json.dump(report, stream, indent=2, sort_keys=True)
            stream.write('\n')
