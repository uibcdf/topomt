"""Synthetic controls for the temporary receiving-origin observer."""

import ast
import hashlib
import importlib.util
import json
import sys
import tempfile
import unittest
from importlib.machinery import ModuleSpec
from pathlib import Path
from types import ModuleType

from origin_probe import OriginProbe


class OriginProbeTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.prefix = self.root / 'env'
        self.prefix.mkdir()
        self.harness = self.root / 'harness'
        self.harness.mkdir()
        self.checker = self.root / 'checker-support'
        self.checker.mkdir()
        self.source = self.root / 'source'
        self.source.mkdir()
        self.manifest = self.root / 'manifest.json'
        self.manifest.write_text(
            json.dumps(
                {
                    'harness_root': str(self.harness),
                    'checker_support_root': str(self.checker),
                    'files': [],
                }
            )
        )
        self.probe = OriginProbe(
            prefix=self.prefix,
            harness_manifest=self.manifest,
            forbidden_roots=(self.source,),
        )

    def test_prefix_file_is_accepted(self):
        module = ModuleType('example')
        module.__file__ = str(self.prefix / 'example.py')
        self.assertEqual(self.probe._module('example', module, {})['kind'], 'files')

    def test_external_file_is_rejected(self):
        module = ModuleType('example')
        module.__file__ = str(self.source / 'example.py')
        with self.assertRaisesRegex(ValueError, 'forbidden'):
            self.probe._module('example', module, {})

    def test_external_namespace_is_rejected(self):
        module = ModuleType('example')
        module.__path__ = [str(self.prefix / 'example'), str(self.source / 'extra')]
        with self.assertRaisesRegex(ValueError, 'forbidden'):
            self.probe._module('example', module, {})

    def test_unknown_fileless_module_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'unproved fileless'):
            self.probe._module('example', ModuleType('example'), {})

    def test_external_spec_origin_is_rejected_even_with_prefix_file(self):
        module = ModuleType('example')
        module.__file__ = str(self.prefix / 'example.py')
        module.__spec__ = ModuleSpec(
            'example', None, origin=str(self.source / 'example.py')
        )
        with self.assertRaisesRegex(ValueError, 'forbidden'):
            self.probe._module('example', module, {})

    def test_string_namespace_path_is_rejected(self):
        module = ModuleType('example')
        module.__path__ = str(self.prefix / 'example')
        with self.assertRaisesRegex(ValueError, 'invalid package'):
            self.probe._module('example', module, {})

    def test_namespace_inside_prefix_is_accepted(self):
        module = ModuleType('example')
        module.__path__ = [str(self.prefix / 'example')]
        self.assertEqual(self.probe._module('example', module, {})['kind'], 'files')

    def test_genuine_builtin_is_accepted(self):
        self.assertEqual(
            self.probe._module('sys', sys, {'sys': sys})['kind'], 'builtin'
        )

    def test_fake_builtin_spec_is_rejected(self):
        module = ModuleType('example')
        module.__spec__ = sys.__spec__
        with self.assertRaisesRegex(ValueError, 'unproved fileless'):
            self.probe._module('example', module, {'example': module})

    def test_prefix_symlink_to_source_is_rejected(self):
        target = self.source / 'example.py'
        target.write_text('')
        link = self.prefix / 'example.py'
        link.symlink_to(target)
        module = ModuleType('example')
        module.__file__ = str(link)
        with self.assertRaisesRegex(ValueError, 'forbidden'):
            self.probe._module('example', module, {})

    def test_lazy_module_attributes_are_not_called(self):
        module = ModuleType('example')
        module.__file__ = str(self.prefix / 'example.py')

        def forbidden(name):
            raise AssertionError(f'observer invoked lazy attribute {name}')

        module.__getattr__ = forbidden
        self.probe._module('example', module, {})

    def _python_generated_fixture(self):
        source = """class CythonDotParallel:
    def parallel(self, num_threads=None):
        return None
    def prange(self, start=0, stop=None, step=1):
        return range(start, stop or 0, step)
    def threadid(self):
        return 0
sys.modules['cython.parallel'] = CythonDotParallel()
"""
        relative = 'lib/python3.14/site-packages/Cython/Shadow.py'
        path = self.prefix / relative
        path.parent.mkdir(parents=True)
        path.write_text(source)
        owner = ModuleType('Cython.Shadow')
        owner.__file__ = str(path)
        owner.__spec__ = importlib.util.spec_from_file_location('Cython.Shadow', path)
        tree = ast.parse(source)
        # Execute only the synthetic class definition, never its registration.
        tree.body = [item for item in tree.body if isinstance(item, ast.ClassDef)]
        exec(compile(tree, str(path), 'exec'), vars(owner))
        klass = vars(owner)['CythonDotParallel']
        value = klass()
        modules = {'Cython.Shadow': owner, 'cython.parallel': value}
        linked = {}
        for name, filename in [
            ('Cython', 'Cython/__init__.py'),
            ('cython', 'cython.py'),
        ]:
            wrapper = self.prefix / 'lib/python3.14/site-packages' / filename
            wrapper.write_text('# Synthetic provider wrapper\n')
            module = ModuleType(name)
            module.__file__ = str(wrapper)
            module.__spec__ = importlib.util.spec_from_file_location(name, wrapper)
            module.CythonDotParallel = klass
            modules[name] = module
            linked[name] = {
                'relative_path': wrapper.relative_to(self.prefix).as_posix(),
                'sha256': hashlib.sha256(wrapper.read_bytes()).hexdigest(),
            }
        evidence = {
            'kind': 'python-provider-generated-object',
            'owner_module': 'Cython.Shadow',
            'owner_relative_path': relative,
            'owner_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'owner_class': 'CythonDotParallel',
            'factory_registration': "sys.modules['cython.parallel'] = CythonDotParallel()",
            'linked_module_files': linked,
        }
        self.probe.native_generated = {'cython.parallel': evidence}
        return value, modules, evidence

    def test_generated_python_object_requires_owner_proof(self):
        value, modules, _ = self._python_generated_fixture()
        self.assertEqual(
            self.probe._module('cython.parallel', value, modules)['kind'],
            'proved-python-provider-generated-object',
        )

    def test_generated_python_object_rejects_wrong_type(self):
        _, modules, _ = self._python_generated_fixture()
        with self.assertRaisesRegex(ValueError, 'type identity'):
            self.probe._module('cython.parallel', object(), modules)

    def test_generated_python_object_rejects_external_owner(self):
        value, modules, _ = self._python_generated_fixture()
        modules['Cython.Shadow'].__file__ = str(self.source / 'Shadow.py')
        with self.assertRaisesRegex(ValueError, 'owner.*prefix'):
            self.probe._module('cython.parallel', value, modules)

    def test_generated_python_object_rejects_owner_hash_mismatch(self):
        value, modules, evidence = self._python_generated_fixture()
        evidence['owner_sha256'] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'owner source hash'):
            self.probe._module('cython.parallel', value, modules)

    def test_generated_python_object_rejects_wrong_registration(self):
        value, modules, evidence = self._python_generated_fixture()
        evidence['factory_registration'] = 'unrelated registration'
        with self.assertRaisesRegex(ValueError, 'factory registration'):
            self.probe._module('cython.parallel', value, modules)

    def test_generated_python_object_rejects_extra_module_name(self):
        value, modules, evidence = self._python_generated_fixture()
        self.probe.native_generated['cython.unauthorized'] = evidence
        with self.assertRaisesRegex(ValueError, 'undeclared Cython generated-object'):
            self.probe._module('cython.unauthorized', value, modules)

    def test_generated_python_object_rejects_linked_class_mismatch(self):
        value, modules, _ = self._python_generated_fixture()
        modules['cython'].CythonDotParallel = object
        with self.assertRaisesRegex(ValueError, 'linked Cython class'):
            self.probe._module('cython.parallel', value, modules)


if __name__ == '__main__':
    unittest.main()
