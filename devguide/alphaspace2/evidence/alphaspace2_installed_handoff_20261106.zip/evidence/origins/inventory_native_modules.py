"""Inventory already imported native runtimes without detecting any pockets."""

import hashlib
import importlib
import importlib.machinery
import json
import os
import sys
from pathlib import Path


def main() -> int:
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
    os.nice(10)
    imports = []
    for name in ('numpy', 'scipy', 'mdtraj', 'alphaspace2'):
        module = importlib.import_module(name)
        imports.append({'name': name, 'file': vars(module).get('__file__')})
    modules = dict(sys.modules)
    owners = []
    fileless = []
    for name, module in sorted(modules.items()):
        if module is None:
            continue
        data = vars(module)
        spec = data.get('__spec__')
        if spec is not None and isinstance(
            spec.loader, importlib.machinery.ExtensionFileLoader
        ):
            path = Path(data['__file__']).resolve()
            raw = path.read_bytes()
            owners.append((name, path, raw))
        if data.get('__file__') or tuple(data.get('__path__', ())):
            continue
        if spec is not None and spec.origin in {'built-in', 'frozen'}:
            continue
        fileless.append(
            {
                'name': name,
                'spec_origin': getattr(spec, 'origin', None),
                'loader': type(getattr(spec, 'loader', None)).__name__,
                'attributes': {
                    key: {
                        'type': type(value).__name__,
                        'type_module': str(type(value).__module__),
                        'object_module': str(getattr(value, '__module__', None)),
                    }
                    for key, value in data.items()
                    if not key.startswith('__')
                },
            }
        )
    for row in fileless:
        marker = row['name'].encode()
        row['loaded_extension_literal_markers'] = [
            {
                'module': name,
                'path': str(path),
                'bytes': len(raw),
                'sha256': hashlib.sha256(raw).hexdigest(),
            }
            for name, path, raw in owners
            if marker in raw
        ]
    report = {
        'profile': 'alphaspace2-native-import-only-inventory-1',
        'python': sys.version,
        'prefix': sys.prefix,
        'imports': imports,
        'fileless': fileless,
        'loaded_extensions': len(owners),
        'pharmacophoremt_loaded': 'pharmacophoremt' in modules,
        'Cython_loaded': 'Cython' in modules,
        'limits': [
            'Explicit imports only; no molecular input, detector, chemistry or recognition executed.',
            'Literal binary markers identify candidate owners; they are not exact compiler/build provenance.',
            'No origin/module object rewritten and no environment files installed or changed.',
        ],
    }
    destination = Path(sys.argv[1])
    with destination.open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(
        json.dumps(
            {
                'report': str(destination),
                'fileless': [row['name'] for row in fileless],
                'pharmacophoremt_loaded': report['pharmacophoremt_loaded'],
            }
        )
    )
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
