"""Validate exact generated-runtime owners with imports only; never run science."""

import hashlib
import importlib
import json
import os
import sys
from pathlib import Path


def main() -> int:
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
    os.nice(10)
    task = Path('/tmp/topomt-alphaspace2-installed-y1j8k2e8')
    evidence = Path(sys.argv[1]).resolve()
    configuration = evidence / 'native-attestations.json'
    config = json.loads(configuration.read_text())
    for name in ('numpy', 'scipy', 'mdtraj', 'alphaspace2'):
        importlib.import_module(name)
    sys.path.insert(0, str(task / 'checker-support'))
    from origin_probe import OriginProbe

    probe = OriginProbe(
        prefix=Path(sys.prefix),
        harness_manifest=evidence.parent / 'harness/manifest.json',
        forbidden_roots=(Path('/fast_data/home/liliana/repos@uibcdf'),),
        driver_files=(Path(__file__),),
        native_generated=config,
    )
    modules = dict(sys.modules)
    rows = {}
    for name, declaration in config.items():
        module = modules[name]
        receipt = probe._module(name, module, modules)
        owner = modules[declaration['owner_module']]
        runtime_type = vars(module).get('cython_function_or_method')
        if runtime_type is not None:
            bound = [
                attribute
                for attribute, value in vars(owner).items()
                if type(value) is runtime_type
            ]
            if not bound:
                raise ValueError(
                    f'No owner function has the shared Cython runtime type: {name}'
                )
            receipt['additional_runtime_type_identity'] = {
                'runtime_type_attribute': 'cython_function_or_method',
                'owner_function_attributes': bound,
                'all_types_are_identical_to_runtime_type': True,
            }
        rows[name] = receipt
    full_audit = probe.audit(required_roots=('numpy', 'scipy', 'mdtraj', 'alphaspace2'))
    report = {
        'profile': 'alphaspace2-exact-native-owner-attestations-1',
        'native_attestations_passed': True,
        'configuration_sha256': hashlib.sha256(configuration.read_bytes()).hexdigest(),
        'prefix': sys.prefix,
        'python': sys.version,
        'validated': rows,
        'full_import_only_audit': full_audit,
        'pharmacophoremt_loaded': 'pharmacophoremt' in modules,
        'known_module_objects_unchanged': all(
            sys.modules.get(name) is module for name, module in modules.items()
        ),
        'limits': [
            'Ten exact generated-object declarations, plus a complete loaded-origin import-only observation; no scientific gate.',
            'Cython factory code is the installed source illustrating the runtime mechanism, not exact dependency build-input provenance.',
            'Literal markers do not prove which loaded extension first created the shared runtime.',
            'Four Cython.Shadow objects require exact installed owner type/code/registration/state proofs; other non-module entries remain failures.',
        ],
    }
    if report['pharmacophoremt_loaded']:
        raise ValueError('Import-only diagnostic unexpectedly loaded PharmacophoreMT')
    destination = evidence / 'native-attestations-validation.json'
    with destination.open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(
        json.dumps(
            {
                'report': str(destination),
                'validated': list(rows),
                'full_import_only_audit_passed': full_audit['passed'],
                'remaining': list(full_audit['unproved_modules']),
                'pharmacophoremt_loaded': False,
            }
        )
    )
    if not full_audit['passed']:
        raise ValueError(f'Import-only origin audit failed: {full_audit["findings"]}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
