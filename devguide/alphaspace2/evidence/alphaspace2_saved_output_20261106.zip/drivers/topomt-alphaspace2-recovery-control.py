import hashlib,importlib.abc,importlib.metadata as metadata,json,sys,zipfile
from pathlib import Path
T=Path('/dev/shm/topomt-alphaspace2-recovery-101');ROOT=T/'standalone';ROOT.mkdir(exist_ok=False)
for name in ['alphaspace2','mdtraj']:
 try:metadata.distribution(name)
 except metadata.PackageNotFoundError:pass
 else:raise AssertionError('Expected original engine absent: '+name)
attempts=[]
class Block(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in {'alphaspace2','mdtraj'}:
   attempts.append(fullname);raise AssertionError('Saved reader attempted original import: '+fullname)
sys.meta_path.insert(0,Block())
import topomt as tmt
from topomt import pyunitwizard as puw
from topomt.provider_output import ProviderRun
from tests.methods.alphaspace2.test_saved_output import _compare
source=Path('/home/liliana/repos@uibcdf/topomt/tests/methods/alphaspace2/data/saved_outputs.zip')
with zipfile.ZipFile(source) as z:
 manifest=json.loads(z.read('manifest.json'))
 for name,row in manifest['members'].items():
  data=z.read(name);assert hashlib.sha256(data).hexdigest()==row['sha256']
  p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
rows=[]
for tag in ['bound','unbound']:
 root=ROOT/tag;witness=json.loads((root/'legacy_fields.json').read_text());original=ProviderRun.load(root/'original.zip')
 source_paths=[root/'receptor.h5msm']+([root/'binder.h5msm'] if tag=='bound' else [])
 hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths}
 for unit_policy in [['pm','fs','radians'],['nm','ps','radians']]:
  with puw.context(standard_units=unit_policy):
   active=puw.configure.get_standard_units()
   result=tmt.get_provider_output(root/'receptor.h5msm',method='alphaspace2',backend='files',binder=root/'binder.h5msm' if tag=='bound' else None,bundle_file=root/'original.zip')
   assert result.run==original and len(result.records)==len(witness['records'])==61
   _compare(result.input_points_nm,witness['input_points_nm'])
   for actual,expected in zip(result.records,witness['records']):
    _compare({n:getattr(actual,n) for n in ['source_id','atom_indices','atom_labels','atom_role','parent_source_ids','fields','geometries']},expected)
   assert puw.configure.get_standard_units()==active
  assert hashes=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths}
  rows.append({'tag':tag,'policy':unit_policy,'run_id':result.run.run_id,'pocket_count':len(result.pockets),'source_sha256':hashes,'all_legacy_observable_fields_agree':True,'original_run_and_artifacts_preserved':True,'source_bytes_unchanged':True,'application_policy_preserved':True})
  print(json.dumps(rows[-1]),flush=True)
 assert not attempts
assert not {'alphaspace2','mdtraj'}.intersection(sys.modules)
(ROOT/'receipt.json').write_text(json.dumps({'profile':'original-alphaspace2-engine-free-recovery-1','python':sys.version,'prefix':sys.prefix,'fixture_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'rows':rows,'checks':{'both_engines_absent':True,'both_engine_imports_blocked':True,'zero_engine_import_attempts':True,'four_full_receivings_passed':True},'primary_topomt_origin':tmt.__file__,'limits':['Source TopoMT over the retained independent package prefix; not a newly installed producer.','Bound/unbound structural 2pk4 controls with analytical duplicated states, not prepared PharmacophoreMT receiving or biological/affinity admission.']},indent=2)+'\n')
print('PASS: four full recoveries, all legacy fields, original identities and zero engine imports.',flush=True)
