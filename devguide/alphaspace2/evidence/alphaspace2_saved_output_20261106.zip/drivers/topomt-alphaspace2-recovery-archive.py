import hashlib,importlib,importlib.metadata as metadata,json,shutil,subprocess,sys,zipfile
from pathlib import Path
T=Path('/dev/shm/topomt-alphaspace2-recovery-101');R=Path('/home/liliana/repos@uibcdf/topomt');D=R/'devguide/alphaspace2/evidence'
producer=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert producer=='dbbc15677660d2ab3559060a4aafd7458441be73'
core='10d3b33101abaff52654c48d6f13286e0bad3c66'
names=set()
for commit in [core,producer]:names.update(subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',commit],cwd=R,text=True).splitlines())
source_hashes={}
for n in sorted(names):
 b=(R/n).read_bytes();assert b==subprocess.check_output(['git','show',producer+':'+n],cwd=R);source_hashes[n]=hashlib.sha256(b).hexdigest()
origins={}
for n in ['topomt','topomt.third_party.alphaspace2.files','topomt.third_party.alphaspace2.parser','topomt.third_party.alphaspace2.records','molsysmt','argdigest','pyunitwizard','depdigest','smonitor','pytest_receptor']:
 module=importlib.import_module(n);p=Path(module.__file__).resolve();origins[n]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
versions={}
for n in ['topomt','molsysmt','argdigest','pyunitwizard','depdigest','smonitor','pytest-receptor','alphaspace2','mdtraj']:
 try:versions[n]=metadata.version(n)
 except metadata.PackageNotFoundError:versions[n]=None
assert versions['alphaspace2'] is versions['mdtraj'] is None
identity={'producer':producer,'runtime_producer':core,'committed_files':source_hashes,'python':sys.version,'prefix':sys.prefix,'versions':versions,'primary_origins':origins,'preserved_human_version_sha256':hashlib.sha256((R/'topomt/_version.py').read_bytes()).hexdigest(),'scope':'Source identity probe in the independent engine-free prefix; not an updated installed TopoMT candidate or before/after pytest instrumentation.'}
(T/'runtime-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
(T/'producer.patch').write_bytes(subprocess.check_output(['git','show','--format=fuller',core],cwd=R)+subprocess.check_output(['git','show','--format=fuller',producer],cwd=R))
files={}
def add(p,n):
 assert p.is_file() and not p.is_symlink();assert n not in files;files[n]=p
for p in T.iterdir():
 if p.is_file() and p.suffix in {'.json','.jsonl','.xml','.log','.txt','.patch'}:add(p,p.name)
for n in sorted(names):add(R/n,'producer/'+n)
for p in (T/'standalone').rglob('*'):
 if p.is_file():add(p,str(p.relative_to(T)))
for p in Path('/tmp').glob('topomt-alphaspace2-*recovery*.py'):add(p,'drivers/'+p.name)
add(Path('/tmp/topomt-alphaspace2-extract-records.py'),'drivers/topomt-alphaspace2-extract-records.py')
support={n.split('::')[0] for n in json.loads((T/'regression-command.json').read_text()) if n.startswith('tests/')}
support.update(['devtools/provider_handoff.py','devtools/qualify_fpocket_handoff.py','devtools/qualify_pocketeer_handoff.py','devtools/qualify_pharmacophore_handoff.py'])
for n in sorted(support-names):add(R/n,'support/'+n)
manifest={n:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for n,p in sorted(files.items())}
name='alphaspace2_saved_output_20261106';archive=T/(name+'.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,row in manifest.items():
  b=z.read(n);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
def result(n):
 rows=[json.loads(l) for l in (T/(n+'-events.jsonl')).read_text().splitlines()]
 r=next(r for r in reversed(rows) if r['type']=='session_finish')
 return {'counts':r['counts'],'duration_seconds':r['duration'],'exitstatus':r['exitstatus']}
control=json.loads((T/'standalone/receipt.json').read_text())
summary={'date':'2026-11-06','owner':'uibcdf/topomt#101','fidelity_owner':'uibcdf/topomt#19','producer':producer,'runtime_producer':core,'archive':{'name':archive.name,'bytes':archive.stat().st_size,'members':len(manifest)+1,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'tests':{n:result(n) for n in ['red','shared-red','green','regression','engine-free','detachment','final-fields','distribution']},'legacy_fixture':{'path':'tests/methods/alphaspace2/data/saved_outputs.zip','sha256':source_hashes['tests/methods/alphaspace2/data/saved_outputs.zip'],'original_mapping_producer':'4bb881d1d6f0f4e542dd28e0e5947f9bf066127c','scope':'All retained legacy field values, units, geometry and attribution; JSON numeric arrays do not promise binary dtype/runtime object identity.'},'receiving_rows':control['rows'],'independent_control_checks':control['checks'],'checks':{'ruff_lint':'passed','ruff_formatted_files':453,'mypy_source_files':14,'distribution_runtime_resources':632,'docs_build':'passed','docs_known_warnings':12,'public_pytest_receptor':'1.2.0','source_files_match_producer':True,'both_original_engines_absent_in_files_prefix':True},'preserved_human_version_sha256':identity['preserved_human_version_sha256'],'limits':control['limits']+['The first reader red selection includes negatives rejected at the absent route; their malformed-data guards become informative after the positive recovery cases pass.','Current original and saved output share the extracted converter, with independently captured pre-refactor field witnesses and direct-original guards preventing self-comparison.','Original undefined occupancy values are retained; JSON arrays preserve numeric values without a frozen binary dtype promise.','The 504-case source regression has ten original divide warnings; the saved-only route emits none of those original runtime warnings.','No new installed wheel, prepared PharmacophoreMT, hosted/full-suite/matrix, native-equivalence or public-release qualification.']}
(D/(name+'.json')).write_text(json.dumps(summary,indent=2)+'\n');shutil.copy2(archive,D/archive.name);print(json.dumps(summary['archive']),flush=True)
