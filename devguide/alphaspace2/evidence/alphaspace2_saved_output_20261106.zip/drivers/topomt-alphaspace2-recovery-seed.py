import dataclasses,hashlib,json,math,sys,zipfile
from pathlib import Path
import molsysmt as msm
import numpy as np
import topomt as tmt
from topomt import pyunitwizard as puw
from topomt.provider_output import ProviderRun
T=Path('/dev/shm/topomt-alphaspace2-recovery-101');BASE=Path('/dev/shm/topomt-alphaspace2-context-101/standalone/nm_ps')
def encode(value):
 if not isinstance(value,(str,bytes)) and puw.is_quantity(value):
  return {'_quantity':encode(puw.get_value(value)),'unit':str(puw.get_unit(value))}
 if dataclasses.is_dataclass(value):return {f.name:encode(getattr(value,f.name)) for f in dataclasses.fields(value)}
 if isinstance(value,np.ndarray):return encode(value.tolist())
 if isinstance(value,np.generic):return encode(value.item())
 if isinstance(value,float) and not math.isfinite(value):return {'_nonfinite':str(value)}
 if isinstance(value,dict):return {k:encode(v) for k,v in value.items()}
 if isinstance(value,(set,frozenset)):return {'_set':sorted([encode(v) for v in value],key=repr)}
 if isinstance(value,(tuple,list)):return [encode(v) for v in value]
 return value
metadata=ProviderRun.load(BASE/'original.zip').metadata
members={}
for tag in ('bound','unbound'):
 receptor=msm.convert(BASE/'receptor.h5msm',to_form='molsysmt.MolSys')
 options={'selection':metadata['selection'],'structure_indices':metadata['structure_indices'],'chemical_state':1,'min_vertices':1}
 if tag=='bound':options.update(binder=msm.convert(BASE/'binder.h5msm',to_form='molsysmt.MolSys'),binder_selection=metadata['binder']['selection'],binder_structure_indices=0,binder_chemical_state=0)
 result=tmt.get_provider_output(receptor,method='alphaspace2',**options)
 path=T/(tag+'.zip');result.run.save(path)
 members[tag+'/original.zip']=path.read_bytes();members[tag+'/receptor.h5msm']=(BASE/'receptor.h5msm').read_bytes()
 if tag=='bound':members[tag+'/binder.h5msm']=(BASE/'binder.h5msm').read_bytes()
 witness={'input_points_nm':encode(result.input_points_nm),'records':[{'source_id':r.source_id,'atom_indices':encode(r.atom_indices),'atom_labels':encode(r.atom_labels),'atom_role':r.atom_role,'parent_source_ids':encode(r.parent_source_ids),'fields':encode(r.fields),'geometries':encode(r.geometries)} for r in result.records]}
 members[tag+'/legacy_fields.json']=(json.dumps(witness,sort_keys=True,allow_nan=False)+'\n').encode()
 print(tag,'original pockets',len(result.pockets),flush=True)
manifest={'producer':'4bb881d1d6f0f4e542dd28e0e5947f9bf066127c','purpose':'Captured original bound/unbound results and legacy observable fields before saved-reader/converter changes; structural 2pk4 controls, not prepared chemistry.','members':{n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in sorted(members.items())}}
path=Path('/home/liliana/repos@uibcdf/topomt/tests/methods/alphaspace2/data/saved_outputs.zip')
with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in members.items():z.writestr(n,b)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
(T/'seed.json').write_text(json.dumps({'archive':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size,**manifest},indent=2)+'\n')
print('Saved legacy witness',path.stat().st_size,flush=True)
