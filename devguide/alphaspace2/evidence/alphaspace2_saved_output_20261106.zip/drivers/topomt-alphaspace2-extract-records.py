from pathlib import Path
from textwrap import dedent
p=Path('topomt/third_party/alphaspace2/library.py');s=p.read_text();start=s.index('        topography = Topography(');end=s.index('\n\n\nget_topography_with_alphaspace2',start)
body=dedent(s[start:end]);body=body.replace('for pocket_index, pocket in enumerate(snapshot.pockets):','for pocket_index, reported_pocket in enumerate(state[\'pocket_properties\']):')
body=body.replace('pocket.alpha_index',"reported_pocket['alpha_indices']")
body=body.replace("    reported_pocket = state['pocket_properties'][pocket_index]\n",'')
for key in ('_alpha_lining','_alpha_space','_alpha_space_nonpolar_ratio','_beta_scores','_alpha_xyz','_alpha_radii','_beta_xyz','_alpha_contact','_beta_space','_beta_contact'):
 body=body.replace('snapshot.'+key,"arrays['"+key+"']")
for key in ('_pocket_beta_index_list','_beta_alpha_index_list'):
 body=body.replace('snapshot.'+key,"state['"+key+"']")
body=body.replace('float(getattr(pocket, source_property))',"_scalar(reported_pocket[name])")
for prop,key in [('space','space'),('nonpolar_space','nonpolar_space'),('score','score'),('occupiedSpace','occupied_space'),('occupiedNonpolarSpace','occupied_nonpolar_space'),('occupancy_nonpolar','occupancy_nonpolar'),('occupancy','occupancy'),('isContact','is_contact')]:
 body=body.replace('pocket.'+prop,"reported_pocket['"+key+"']")
body=body.replace('pocket.centroid',"state['_pocket_xyz'][pocket_index]")
body=body.replace("float(reported_pocket['occupancy'])","_scalar(reported_pocket['occupancy'])").replace("float(reported_pocket['occupancy_nonpolar'])","_scalar(reported_pocket['occupancy_nonpolar'])")
# Replace the old manual angstrom-to-nm factors with the owning quantity tool.
a=body.index('    alpha_centers_nm = (');b=body.index('\n    topography.add_feature(',a)
body=body[:a]+"""    alpha_centers_nm = _length(arrays['_alpha_xyz'][alpha_indices])
    alpha_radii_nm = _length(arrays['_alpha_radii'][alpha_indices])
    beta_centers_nm = _length(arrays['_beta_xyz'][beta_indices])
"""+body[b:]
body=body.replace("center=puw.quantity(\n                np.asarray(state['_pocket_xyz'][pocket_index], dtype=float) / 10.0, 'nm'\n            )", "center=_length(state['_pocket_xyz'][pocket_index])")
body=body.replace("volume=puw.quantity(float(reported_pocket['space']) / 1000.0, 'nm**3')", "volume=_volume(reported_pocket['space'])")
body=body.replace("alpha_sphere_centers=puw.quantity(alpha_centers_nm, 'nm')",'alpha_sphere_centers=alpha_centers_nm').replace("alpha_sphere_radii=puw.quantity(alpha_radii_nm, 'nm')",'alpha_sphere_radii=alpha_radii_nm').replace("beta_centers=puw.quantity(beta_centers_nm, 'nm')",'beta_centers=beta_centers_nm')
body=body.replace("nonpolar_volume=puw.quantity(\n                float(reported_pocket['nonpolar_space']) / 1000.0, 'nm**3'\n            )", "nonpolar_volume=_volume(reported_pocket['nonpolar_space'])")
header='''"""Map original AlphaSpace2 snapshot fields through one TopoMT converter."""\n\nfrom typing import Any\n\nimport numpy as np\n\nfrom topomt import Topography\nfrom topomt import pyunitwizard as puw\nfrom topomt.features import Pocket\nfrom topomt.provider_output import ExternalMeasurement, ProviderRun\n\n\ndef _scalar(value: Any) -> float:\n    if isinstance(value, dict):\n        return float(value['nonfinite'])\n    return float(value)\n\n\ndef _length(value: Any) -> Any:\n    return puw.convert(puw.quantity(np.asarray(value, dtype=float), 'angstroms'), to_unit='nm')\n\n\ndef _volume(value: Any) -> Any:\n    return puw.convert(puw.quantity(float(value), 'angstroms**3'), to_unit='nm**3')\n\n\ndef snapshot_to_topography(\n    molecular_system: Any, state: dict[str, Any], selected_atom_indices: np.ndarray, run: ProviderRun,\n    *, selection: Any, structure_indices: Any, min_vertices: int,\n) -> Topography:\n    """Map captured fields without rerunning AlphaSpace2 clustering or scoring.\n\n    Parameters\n    ----------\n    molecular_system : MolSysMT-compatible input\n        Full receptor source whose ordinal map has been validated.\n    state : dict\n        Original captured snapshot or a strictly validated saved snapshot.\n    selected_atom_indices : numpy.ndarray\n        Submitted receptor row to source index map.\n    run : ProviderRun\n        Original evidence, retained unchanged on every record.\n    selection : str or sequence of int\n        Recorded receptor selection.\n    structure_indices : int or sequence of int\n        Recorded single receptor frame.\n    min_vertices : int\n        Recorded positive adapter filter, not an original clustering option.\n\n    Returns\n    -------\n    Topography\n        Original fields and units in the existing pocket representation.\n\n    Raises\n    ------\n    ValueError\n        If an already admitted mapping or geometry violates its contract.\n    """\n    arrays = {name: np.asarray(state[name]) for name in (\n        '_alpha_lining', '_alpha_space', '_alpha_space_nonpolar_ratio', '_beta_scores',\n        '_alpha_xyz', '_alpha_radii', '_beta_xyz', '_alpha_contact', '_beta_space', '_beta_contact',\n    )}\n'''
Path('topomt/third_party/alphaspace2/records.py').write_text(header+''.join('    '+l if l.strip() else l for l in body.splitlines(keepends=True)))
s=s[:start]+'''        return snapshot_to_topography(\n            molecular_system, state, selected_atom_indices, run,\n            selection=selection, structure_indices=structure_indices, min_vertices=min_vertices,\n        )'''+s[end:]
s=s.replace('from topomt.features import Pocket\n','').replace('from topomt.provider_output import ExternalMeasurement, ProviderRun','from topomt.provider_output import ProviderRun').replace('from .output import _output_protocol','from .output import _output_protocol\nfrom .records import snapshot_to_topography')
p.write_text(s)
