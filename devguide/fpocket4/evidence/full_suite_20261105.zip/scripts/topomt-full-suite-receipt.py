import hashlib
import importlib.metadata as metadata
import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

from pytest_receptor.artifact import read_artifact

TASK = Path('/dev/shm/topomt-installed-101.bch3yxd8/full-suite')
REPO = Path('/home/liliana/repos@uibcdf/topomt')


def save(name, value):
    (TASK / name).write_text(json.dumps(value, indent=2) + '\n')


full = read_artifact(TASK / 'resumed-events.jsonl')
baseline = read_artifact(TASK / 'baseline-all-events.jsonl')
tools = read_artifact(TASK / 'tools-control-events.jsonl')
for artifact in (full, baseline, tools):
    assert artifact.complete and artifact.integrity_valid

phases = [r.data for r in full.events if r.type == 'phase']
failures = {
    (r['nodeid'], r['phase']): r
    for r in phases if r['outcome'] == 'failed'
}
old_failures = {
    (r.data['nodeid'], r.data['phase']): r.data
    for r in baseline.events
    if r.type == 'phase' and r.data['outcome'] == 'failed'
}
assert set(failures) == set(old_failures) and len(failures) == 8
comparison = []
for key, report in sorted(failures.items()):
    old = old_failures[key]
    assert report['exception']['message'] == old['exception']['message']
    if 'test_dfnd_raw_characterization.py' in key[0]:
        category = 'preexisting_dfnd_hash'
    elif 'test_molsysviewer_topomt_addon.py' in key[0]:
        category = 'preexisting_viewer_selection'
    else:
        assert 'test_tools_' in key[0]
        category = 'missing_optional_tools'
    comparison.append({
        'nodeid': key[0], 'phase': key[1], 'category': category,
        'same_baseline_message': True,
        'message': report['exception']['message'],
    })

counts = dict(full.final.data['counts'])
assert counts['collected'] == counts['executed'] == 2245
assert counts['deselected'] == counts['not_executed'] == counts['errors'] == 0
assert counts['passed'] == 2156 and counts['failed'] == 8
assert counts['skipped'] == 76 and counts['xfailed'] == 5
assert len({r['nodeid'] for r in phases if r['phase'] == 'teardown'}) == 2245
xml = ET.parse(TASK / 'resumed-results.xml').getroot().find('testsuite')
assert int(xml.attrib['tests']) == 2245
assert int(xml.attrib['failures']) == 8 and int(xml.attrib['errors']) == 0
assert int(xml.attrib['skipped']) == 81  # JUnit includes the five expected failures.

contract_paths = {
    'tests/test_provider_dispatch_arguments.py',
    *('tests/methods/fpocket4/' + name + '.py' for name in (
        'test_argument_contracts', 'test_chemical_context', 'test_handoff_pilot',
        'test_input_preparation', 'test_pharmacophore_handoff',
        'test_public_gateways', 'test_submission_mapping',
    )),
}
contract_calls = [r for r in phases if r['phase'] == 'call' and r['test_path'] in contract_paths]
assert len(contract_calls) == 144 and all(r['outcome'] == 'passed' for r in contract_calls)
castp_calls = [r for r in phases if r['phase'] == 'call' and r['test_path'] == 'tests/methods/castp/test_castp_modern_void_measurements.py']
assert len(castp_calls) == 952 and all(r['outcome'] == 'passed' for r in castp_calls)
assert tools.final.data['counts']['passed'] == 20
assert tools.final.data['counts']['failed'] == tools.final.data['counts']['skipped'] == 0

before = json.loads((TASK / 'qualified-environment.json').read_text())
old_dists = {d['name']: d['version'] for d in before['distributions'] if d['metadata_path'].startswith(sys.prefix + '/')}
new_dists = {d.metadata['Name']: d.version for d in metadata.distributions() if str(d._path).startswith(sys.prefix + '/')}
assert len(old_dists) == 141 and len(new_dists) == 150
assert all(new_dists[name] == version for name, version in old_dists.items())
added = {name: version for name, version in new_dists.items() if name not in old_dists}
save('tools-environment.json', {'prefix': sys.prefix, 'distributions': new_dists, 'added': added, 'removed': [], 'changed': []})

version_digest = hashlib.sha256((REPO / 'topomt/_version.py').read_bytes()).hexdigest()
assert version_digest == '91af00335ecf06be1573c95e22dbba13bfaa0a9e472ffa3de802cee87dc38baf'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
assert head == 'ca8ad21f726b19cb32644fbc611ff5f48c043f8f'
save('test-files.json', {
    path: hashlib.sha256((REPO / path).read_bytes()).hexdigest()
    for path in sorted({r['test_path'] for r in phases})
})
skips = {r['nodeid']: r['reason'] for r in phases if r['outcome'] == 'skipped'}
xfails = {r['nodeid']: r['reason'] for r in phases if r['outcome'] == 'xfailed'}
assert len(skips) == 76 and len(xfails) == 5
save('skips.json', {'skipped': skips, 'xfailed': xfails})
summary = {
    'source_head': head, 'user_version_sha256': version_digest,
    'python': '3.14.7', 'platform': 'Linux x86_64',
    'scope': 'Source TopoMT, all tests/, normal conftest, no exclusions; installed independent dependencies',
    'full_suite': {'counts': counts, 'seconds': full.final.data['duration'], 'exit_code': full.final.data['exitstatus'], 'junit': xml.attrib},
    'integrity': {'full': full.integrity_valid, 'baseline': baseline.integrity_valid, 'tools_control': tools.integrity_valid, 'dropped_records': full.final.data['artifact_policy']['dropped_records']},
    'execution': {'requested': 'xdist, four workers, loadscope', 'observed_workers': sorted({r['worker_id'] for r in phases}), 'original_header_mode': full.records[0].data['mode'], 'header_caveat': 'The explicit -p xdist.plugin route is recorded as serial in the original session header; argv and gw0-gw3 phase identities retain actual distributed execution. Original artifact bytes are unchanged.'},
    'argdigest_and_original_handoff': {'passed': 144, 'failed': 0, 'skipped': 0},
    'castp_modern_measurements': {'passed': 952, 'failed': 0},
    'baseline': {'source': 'edb43579b2a937e1ac5faa7f89876c7ff3c81e5c', 'failed': 8, 'seconds': baseline.final.data['duration'], 'all_messages_equal': True, 'comparisons': comparison},
    'optional_tools_control': {'passed': 20, 'failed': 0, 'skipped': 0, 'seconds': tools.final.data['duration'], 'installed_added': added, 'full_suite_rerun_in_this_expanded_profile': False},
    'limitations': ['Full source suite failed; six reproduced baseline scientific/viewer failures remain.', 'The two missing-tool failures pass in a separate 20-case control after optional dependencies are added; that does not rewrite the original full run.', 'No new installed-TopoMT, hosted, other-platform/minor or publication qualification.', 'Earlier immutable installed-wheel evidence remains separate.'],
}
save('summary.json', summary)
print(json.dumps({'counts': counts, 'tools_control': 20, 'baseline_messages_equal': True, 'installed_before': 141, 'installed_after': 150}))
