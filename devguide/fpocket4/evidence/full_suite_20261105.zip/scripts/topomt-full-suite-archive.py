import hashlib
import json
from pathlib import Path
import shutil
import zipfile

TASK = Path('/dev/shm/topomt-installed-101.bch3yxd8/full-suite')
REPO = Path('/home/liliana/repos@uibcdf/topomt')
OUTPUT = REPO / 'devguide/fpocket4/evidence'
NAME = 'full_suite_20261105'

summary = json.loads((TASK / 'summary.json').read_text())
assert summary['full_suite']['counts']['executed'] == 2245
assert summary['integrity']['full'] and summary['baseline']['all_messages_equal']
assert '20 passed' in (TASK / 'tools-control.log').read_text()
assert 'PASS exit=0' in (TASK / 'governance.log').read_text()
assert 'No broken requirements found' in (TASK / 'tools-pip-check.log').read_text()
inputs = {}
for name, path in {
    'fpocket': Path('/tmp/topomt-pocket-pilot-101.7bZOKK/fpocket/bin/fpocket'),
    'prepared_receptor': TASK.parent / 'clean/harness/prepared.h5msm',
}.items():
    inputs[name] = {'path': str(path), 'size': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
(TASK / 'scientific-inputs.json').write_text(json.dumps(inputs, indent=2) + '\n')

members = {}
for path in sorted(TASK.iterdir()):
    if path.is_file() and path.suffix in {'.log', '.xml', '.json', '.jsonl'}:
        members['control/' + path.name] = path.read_bytes()
for path in (Path('/tmp/topomt-full-suite-receipt.py'), Path(__file__)):
    members['scripts/' + path.name] = path.read_bytes()
for name in ('wheel.json', 'effective-wheels.json', 'source.json'):
    members['installed-producer/' + name] = (TASK.parent / 'gateways' / name).read_bytes()
for name in ('full_suite_checkpoint.md', 'viewer_selection_issue_draft.md'):
    members['devguide/fpocket4/' + name] = (REPO / 'devguide/fpocket4' / name).read_bytes()
manifest = {name: {'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in members.items()}
archive = TASK / (NAME + '.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, data in members.items():
        bundle.writestr(name, data)
    bundle.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as bundle:
    assert set(bundle.namelist()) == set(manifest) | {'manifest.json'}
    for name, facts in manifest.items():
        data = bundle.read(name)
        assert len(data) == facts['size']
        assert hashlib.sha256(data).hexdigest() == facts['sha256']

sidecar = {
    'schema': 'topomt.full-source-suite-evidence@1',
    'archive': archive.name, 'size': archive.stat().st_size,
    'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'members': len(manifest) + 1,
    'source_head': summary['source_head'],
    'user_version_sha256': summary['user_version_sha256'],
    'scope': summary['scope'],
    'full_suite': summary['full_suite'],
    'argdigest_and_original_handoff': summary['argdigest_and_original_handoff'],
    'castp_modern_measurements': summary['castp_modern_measurements'],
    'baseline': {key: summary['baseline'][key] for key in ('source', 'failed', 'seconds', 'all_messages_equal')},
    'optional_tools_control': summary['optional_tools_control'],
    'integrity': summary['integrity'],
    'execution': summary['execution'],
    'limitations': summary['limitations'],
    'retention': 'Original package/engine files and temporary environments remain task-owned local artifacts; the archive retains results, identities and digests, not those package bytes.',
}
sidecar_path = TASK / (NAME + '.json')
sidecar_path.write_text(json.dumps(sidecar, indent=2) + '\n')
for path in (archive, sidecar_path):
    assert not (OUTPUT / path.name).exists()
    shutil.copyfile(path, OUTPUT / path.name)
print(json.dumps({'archive': archive.name, 'size': sidecar['size'], 'sha256': sidecar['sha256'], 'members': sidecar['members']}))
