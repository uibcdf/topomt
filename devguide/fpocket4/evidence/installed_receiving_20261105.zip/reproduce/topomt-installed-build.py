import hashlib, json, os, subprocess, sys
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8')
for name in ['wheels','scratch','pip-cache','cargo']:
 (base/name).mkdir(exist_ok=True)
env=os.environ.copy()
env.update(TMPDIR=str(base/'scratch'), PIP_CACHE_DIR=str(base/'pip-cache'), PIP_CONFIG_FILE='/dev/null', PIP_INDEX_URL='https://pypi.org/simple', PYTHONDONTWRITEBYTECODE='1', CARGO_HOME=str(base/'cargo'), CARGO_TARGET_DIR=str(base/'cargo-target'))
env.pop('PYTHONPATH',None)
env.pop('PIP_EXTRA_INDEX_URL',None)
receipts=[]
for name in ['smonitor','depdigest','argdigest','pyunitwizard','molsysviewer','pytest-receptor','topomt','pharmacophoremt','molsysmt']:
 print('building',name,flush=True)
 log_path=base/'logs'/f'build-{name}.log'
 with log_path.open('w') as log:
  result=subprocess.run([sys.executable,'-m','pip','wheel','--no-deps','--index-url','https://pypi.org/simple','--wheel-dir',str(base/'wheels'),str(base/'sources'/name)],env=env,stdout=log,stderr=log)
 if result.returncode:
  print('\n'.join(log_path.read_text().splitlines()[-35:]),flush=True)
  raise SystemExit(result.returncode)
 filename=next((base/'wheels').glob(name.replace('-','_')+'-*.whl'))
 receipt={'name':name,'filename':filename.name,'size':filename.stat().st_size,'sha256':hashlib.sha256(filename.read_bytes()).hexdigest(),'build_log_sha256':hashlib.sha256(log_path.read_bytes()).hexdigest()}
 receipts.append(receipt)
 (base/'wheels.json').write_text(json.dumps(receipts,indent=2)+'\n')
 print('built',name,filename.name,receipt['size'],flush=True)
