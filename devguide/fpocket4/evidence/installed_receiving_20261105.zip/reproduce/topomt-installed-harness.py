import json, shutil
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8')
source=base/'sources/topomt'; harness=base/'harness'
for path in ['tests/methods/fpocket4','devtools','topomt']:
 (harness/path).mkdir(parents=True,exist_ok=True)
files=['tests/methods/fpocket4/'+name+'.py' for name in ['test_input_preparation','test_submission_mapping','test_chemical_context','test_handoff_pilot','test_pharmacophore_handoff']]
files += ['devtools/qualify_fpocket_handoff.py','devtools/qualify_pharmacophore_handoff.py']
for name in files:
 shutil.copyfile(source/name,harness/name)
for name in ['tests/__init__.py','tests/methods/__init__.py','tests/methods/fpocket4/__init__.py','devtools/__init__.py']:
 (harness/name).touch()
(harness/'topomt/data').symlink_to(base/'env/lib/python3.14/site-packages/topomt/data',target_is_directory=True)
(harness/'pytest.ini').write_text('[pytest]\naddopts = -q\n')
shutil.copyfile('/tmp/topomt-pocket-pilot-101.7bZOKK/prepared-eralpha.h5msm',harness/'prepared.h5msm')
(base/'test-support.json').write_text(json.dumps({'copied_from':json.loads((base/'sources.json').read_text())['topomt']['commit'],'files':files,'data_link':'installed topomt/data; no Python module link'},indent=2)+'\n')
