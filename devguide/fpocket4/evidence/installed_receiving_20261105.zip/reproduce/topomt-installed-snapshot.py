import json, subprocess
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8')
refs={
 'topomt':'HEAD',
 'molsysmt':'00abb958fb93649131d5ce5fe5e12e90cf4900e9',
 'pharmacophoremt':'b934471ac8ab8bdb1bd7646550ac23baeb07daa7',
 'pyunitwizard':'9d74f0e1e911d78c1906948e74ce8da93935557d',
 'molsysviewer':'73a6f388e09146650349dfe83564ae318ba20298',
 'smonitor':'ccdcace55ba5caf431b4a6a6904d8d18173114a3',
 'argdigest':'cd9c4f3',
 'depdigest':'0884f0cc1dd60b79ed01930e68d80c87e51744c9',
 'pytest-receptor':'b9676f87d317e52ae9121f2e95c2b2c325ad2044',
 'molsyssuite':'8f00e6d9de943b6e4710ea62936e2ebea00fad24',
}
(base/'sources').mkdir()
(base/'logs').mkdir()
receipts={}
for name,ref in refs.items():
 original=Path('/home/liliana/repos@uibcdf')/name
 sha=subprocess.check_output(['git','rev-parse',ref],cwd=original,text=True).strip()
 target=base/'sources'/name
 with (base/'logs'/f'snapshot-{name}.log').open('w') as log:
  subprocess.run(['git','clone','--shared','--no-checkout',str(original),str(target)],stdout=log,stderr=log,check=True)
  subprocess.run(['git','checkout','--detach',sha],cwd=target,stdout=log,stderr=log,check=True)
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=target,text=True).strip()
 receipts[name]={'commit':sha,'checkout':str(target),'source':str(original)}
 print(name,sha,flush=True)
(base/'sources.json').write_text(json.dumps(receipts,indent=2)+'\n')
