import hashlib, importlib.metadata as md, json, os, shutil, subprocess, sys, zipfile
from pathlib import Path
from packaging.requirements import Requirement
base=Path('/dev/shm/topomt-installed-101.bch3yxd8')
# Source snapshots were clean at checkout. Only the generated TopoMT version
# file changed during its normal build hooks; never replace the tested wheel.
postbuild={}
for name in json.loads((base/'sources.json').read_text()):
 target=base/'sources'/name
 postbuild[name]=subprocess.check_output(['git','status','--porcelain'],cwd=target,text=True).splitlines()
(base/'postbuild-status.json').write_text(json.dumps(postbuild,indent=2)+'\n')
required=[]
for wheel in json.loads((base/'wheels.json').read_text()):
 dist=md.distribution(wheel['name'])
 for text in dist.requires or []:
  req=Requirement(text)
  if req.marker is not None and not req.marker.evaluate({'extra':''}): continue
  try: version=md.version(req.name)
  except md.PackageNotFoundError: version=None
  required.append({'consumer':wheel['name'],'requirement':text,'actual_version':version,'satisfied':version is not None and req.specifier.contains(version,prereleases=True)})
(base/'direct-runtime-requirements.json').write_text(json.dumps(required,indent=2)+'\n')
print('direct_runtime_requirements',len(required),'unsatisfied',[r for r in required if not r['satisfied']])
# Preserve downloaded build-tool identities from the fresh task-local cache;
# this is cached-input evidence, not a per-hook environment capture.
tools=[]
for path in (base/'pip-cache').rglob('*.body'):
 if not zipfile.is_zipfile(path): continue
 with zipfile.ZipFile(path) as archive:
  names=[n for n in archive.namelist() if n.endswith('.dist-info/METADATA')]
  if len(names)!=1: continue
  import email
  m=email.message_from_bytes(archive.read(names[0]))
  tools.append({'name':m['Name'],'version':m['Version'],'size':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(base/'build-input-cache.json').write_text(json.dumps(tools,indent=2)+'\n')
print('cached_build_wheels',[(r['name'],r['version']) for r in tools])
summary={'date':'2026-11-05','platform':sys.platform,'machine':os.uname().machine,'python':sys.version,
 'producer':json.loads((base/'sources.json').read_text())['topomt']['commit'],
 'pip_check_exit':1,'pip_check_lines':(base/'logs/pip-check.log').read_text().splitlines(),
 'native':{'path':'env/lib/python3.14/site-packages/molsysmt/_rust.abi3.so','size':(base/'env/lib/python3.14/site-packages/molsysmt/_rust.abi3.so').stat().st_size,'sha256':hashlib.sha256((base/'env/lib/python3.14/site-packages/molsysmt/_rust.abi3.so').read_bytes()).hexdigest()},
 'fpocket':{'path':'/tmp/topomt-pocket-pilot-101.7bZOKK/fpocket/bin/fpocket','sha256':hashlib.sha256(Path('/tmp/topomt-pocket-pilot-101.7bZOKK/fpocket/bin/fpocket').read_bytes()).hexdigest()},
 'compilers':{c:subprocess.check_output([c,'--version'],text=True).splitlines()[0] for c in ['rustc','cargo','gcc']},
 'artifact_retention':{'root':str(base/'wheels'),'status':'Original wheel bytes retained locally in task storage; not committed or publicly hosted.'}}
(base/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
# Keep the actual scientific outputs from this installed execution; exclude
# extracted duplicates and intentionally malformed negative-control candidates.
entries={}
for name in ['sources.json','wheels.json','initial-origins.json','installed-receipt.json','wheel-resources.json','test-support.json','postbuild-status.json','direct-runtime-requirements.json','build-input-cache.json','summary.json']:
 entries['control/'+name]=base/name
for p in (base/'logs').glob('*'):
 if p.name.startswith(('build-','installed-tests','dependency-preflight','pip-check','install.log')):
  entries['logs/'+p.name]=p
for name in ['snapshot','build','setup','harness','run','evidence']:
 p=Path('/tmp')/f'topomt-installed-{name}.py'
 entries['reproduce/'+p.name]=p
for name in json.loads((base/'test-support.json').read_text())['files']:
 entries['support/'+name]=base/'harness'/name
outputs=base/'test-output'
for sub in ['test_real_fpocket_handoff_pres0/handoff','prepared_handoff0/original','test_original_pocket_builds_pe0/consumer','test_original_pocket_builds_pe1/consumer']:
 for p in (outputs/sub).glob('*'):
  if p.is_file(): entries['scientific/'+sub+'/'+p.name]=p
for name in ['original.zip','source.h5msm']:
 entries['scientific/reference-index-1/'+name]=outputs/'test_real_engine_run_retains_n0'/name
archive=base/'installed_receiving_20261105.zip'
manifest={name:{'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for name,p in entries.items()}
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as out:
 for name,p in sorted(entries.items()): out.write(p,name)
 out.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as check:
 for name,row in manifest.items(): assert hashlib.sha256(check.read(name)).hexdigest()==row['sha256']
receipt={'schema':'topomt.installed-receiving-evidence@1','archive':archive.name,'size':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(entries)+1,'producer':summary['producer'],'scope':'Bounded installed Linux x86_64/Python 3.14 fpocket receiving; shared external dependencies; not full/release/public qualification.','tests':{'passed':32,'skipped':0,'failed':0},'wheel_artifacts':json.loads((base/'wheels.json').read_text()),'native':summary['native'],'retention':summary['artifact_retention']}
(base/'installed_receiving_20261105.json').write_text(json.dumps(receipt,indent=2)+'\n')
repo=Path('/home/liliana/repos@uibcdf/topomt/devguide/fpocket4/evidence')
for name in ['installed_receiving_20261105.zip','installed_receiving_20261105.json']:
 shutil.copyfile(base/name,repo/name)
print('archive',receipt['size'],receipt['sha256'],receipt['members'])
