import hashlib,json,os,subprocess,sys,sysconfig,venv,zipfile,tomllib
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8')
# Install suite wheels into a separate prefix. A plain .pth exposes only ordinary
# external site-packages, without executing their editable-install .pth hooks.
venv.EnvBuilder(with_pip=False,symlinks=True).create(base/'env')
site=base/'env/lib/python3.14/site-packages'
(site/'external-packages.pth').write_text(sysconfig.get_path('purelib')+'\n')
env=os.environ.copy(); env.pop('PYTHONPATH',None)
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONSAFEPATH='1',TMPDIR=str(base/'scratch'))
with (base/'logs/install.log').open('w') as log:
 subprocess.run([sys.executable,'-m','pip','--python',str(base/'env/bin/python'),'install','--no-deps','--ignore-installed','--no-compile','--no-index',*[str(p) for p in sorted((base/'wheels').glob('*.whl'))]],env=env,stdout=log,stderr=log,check=True)
# Inspect wheel payload against the maintained resource inventory, independently
# of imports. No release or Conda candidate identity is substituted.
inventory=tomllib.loads((base/'sources/topomt/devtools/conda-build/resources.toml').read_text())
wheel=next((base/'wheels').glob('topomt-*.whl'))
with zipfile.ZipFile(wheel) as archive:
 names=set(archive.namelist()); paths=[p.removeprefix('site-packages/') for p in inventory['required_paths']]
 missing=[p for p in paths if p not in names]
 assert not missing,missing
 extra_roots=sorted({p.split('/')[0] for p in names if '/' in p and not p.split('/')[0].endswith('.dist-info')} - {'topomt','molsysviewer_topomt'})
 assert not extra_roots,extra_roots
 (base/'wheel-resources.json').write_text(json.dumps({'required_count':len(paths),'missing':missing,'unexpected_package_roots':extra_roots},indent=2)+'\n')
print('installed_prefix',base/'env')
print('topomt_resource_count',len(paths))
# Reuse the owning current generic import-origin checker at an exact source pin.
sdk=base/'sources/installed-sdk'
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/home/liliana/repos@uibcdf/molsyssuite',text=True).strip()
with (base/'logs/snapshot-installed-sdk.log').open('w') as log:
 subprocess.run(['git','clone','--shared','--no-checkout','/home/liliana/repos@uibcdf/molsyssuite',str(sdk)],stdout=log,stderr=log,check=True)
 subprocess.run(['git','checkout','--detach',sha],cwd=sdk,stdout=log,stderr=log,check=True)
print('installed_sdk',sha)
sources=json.loads((base/'sources.json').read_text()); sources['installed-sdk']={'commit':sha,'checkout':str(sdk),'source':'/home/liliana/repos@uibcdf/molsyssuite'}; (base/'sources.json').write_text(json.dumps(sources,indent=2)+'\n')
for name in ['topomt','molsysmt','pharmacophoremt']:
 print(name,'postbuild_git_status',repr(subprocess.check_output(['git','status','--porcelain'],cwd=base/'sources'/name,text=True)))
