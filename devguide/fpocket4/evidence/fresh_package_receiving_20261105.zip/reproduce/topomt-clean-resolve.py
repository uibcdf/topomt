import json,os,subprocess,sys
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8'); clean=base/'clean'
env=os.environ.copy()
for name in ['PYTHONPATH','PYTHONHOME','PIP_EXTRA_INDEX_URL','LD_LIBRARY_PATH']: env.pop(name,None)
env.update(PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONSAFEPATH='1',PIP_CONFIG_FILE='/dev/null',PIP_INDEX_URL='https://pypi.org/simple',PIP_CACHE_DIR=str(clean/'pip-cache'),TMPDIR=str(clean/'scratch'))
command=json.loads((clean/'resolution-command.json').read_text())
command[command.index('--report')+1]=str(clean/'resolution-sdist.json')
command.insert(command.index('--only-binary=:all:')+1,'--no-binary=nglview,mmcif')
(clean/'resolution-sdist-command.json').write_text(json.dumps(command,indent=2)+'\n')
with (clean/'logs/resolve-sdist.log').open('w') as log:
 result=subprocess.run(command,env=env,stdout=log,stderr=log)
print('resolver_exit',result.returncode)
print('\n'.join((clean/'logs/resolve-sdist.log').read_text().splitlines()[-18:]))
raise SystemExit(result.returncode)
