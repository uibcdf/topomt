"""Execute the bounded installed fpocket receiving control outside all checkouts."""
import base64
import hashlib
import importlib
import importlib.metadata as metadata
import json
import os
import sys
from pathlib import Path

import pytest

BASE = Path('/dev/shm/topomt-installed-101.bch3yxd8')
PREFIX = BASE / 'env'
ROOTS = ('topomt', 'molsysviewer_topomt', 'molsysmt', 'molsysviewer_molsysmt',
         'pharmacophoremt', 'molsysviewer_pharmacophoremt', 'pyunitwizard',
         'molsysviewer', 'smonitor', 'argdigest', 'depdigest', 'pytest_receptor')
sys.path.insert(0, str(BASE / 'harness'))
sys.path.insert(0, str(BASE / 'sources/installed-sdk/devtools/scripts'))
from installed_imports import check_installed_imports

os.chdir(BASE / 'harness')
for name in ('topomt', 'molsysmt', 'molsysmt._rust', 'pharmacophoremt',
             'pyunitwizard', 'molsysviewer', 'smonitor', 'argdigest', 'depdigest'):
    importlib.import_module(name)


def check_origins():
    receipt = check_installed_imports(tuple(r for r in ROOTS if r != 'pyunitwizard'), PREFIX, BASE / 'sources')
    # The unchanged shared checker requires files even for generated aliases.
    # Keep its strict check for every other suite root; inspect this one known
    # provider alias without deleting or rewriting any imported module.
    unit_origins = {}
    for name, module in tuple(sys.modules.items()):
        if name != 'pyunitwizard' and not name.startswith('pyunitwizard.'):
            continue
        locations = ([module.__file__] if getattr(module, '__file__', None) else [])
        locations += list(getattr(module, '__path__', ()))
        if not locations:
            assert name == 'pyunitwizard.main', name
            assert set(k for k, v in vars(module).items() if hasattr(v, '__code__')) == {'__getattr__', '__dir__'}
            locations = [vars(module)[k].__code__.co_filename for k in ('__getattr__', '__dir__')]
            assert all(Path(p).resolve() == PREFIX / 'lib/python3.14/site-packages/pyunitwizard/__init__.py' for p in locations)
        assert all(Path(p).resolve().is_relative_to(PREFIX) for p in locations), (name, locations)
        unit_origins[name] = locations
    receipt['pyunitwizard_origins'] = unit_origins
    receipt['shared_checker_limit'] = 'The fileless pyunitwizard.main compatibility alias is checked by its two installed generator code origins, separately from the unchanged shared checker.'
    assert not any(name.startswith('__editable__') for name in sys.modules)
    assert not any(Path(p).resolve().is_relative_to(BASE / 'sources')
                   for p in sys.path if p and 'installed-sdk/devtools/scripts' not in p)
    return receipt


def check_files():
    receipts = []
    for wheel in json.loads((BASE / 'wheels.json').read_text()):
        dist = metadata.distribution(wheel['name'])
        assert Path(dist._path).resolve().is_relative_to(PREFIX)
        assert json.loads(dist.read_text('direct_url.json'))['archive_info']['hashes']['sha256'] == wheel['sha256']
        checked = 0
        for file in dist.files:
            if file.hash is None:
                continue
            path = Path(dist.locate_file(file)).resolve()
            assert path.is_relative_to(PREFIX), (wheel['name'], path)
            actual = base64.urlsafe_b64encode(hashlib.new(file.hash.mode, path.read_bytes()).digest()).rstrip(b'=').decode()
            assert actual == file.hash.value, (wheel['name'], str(file))
            checked += 1
        receipts.append({'name': wheel['name'], 'version': dist.version,
                         'requires_python': dist.metadata['Requires-Python'],
                         'record_hashes_checked': checked})
    return receipts


class Outcomes:
    def __init__(self):
        self.reports = []

    def pytest_runtest_logreport(self, report):
        if report.when == 'call' or report.failed or report.skipped:
            self.reports.append({'nodeid': report.nodeid, 'when': report.when,
                                 'outcome': report.outcome})


receipt = {'profile': 'bounded-installed-fpocket-receiving-1',
           'origins_before': check_origins(), 'files_before': check_files(),
           'python': sys.version, 'prefix': sys.prefix}
outcomes = Outcomes()
code = pytest.main(['--noconftest', '-p', 'pytest_receptor.plugin', '--receptor=llm',
                    '--basetemp', str(BASE / 'test-output'),
                    'tests/methods/fpocket4/test_input_preparation.py',
                    'tests/methods/fpocket4/test_submission_mapping.py',
                    'tests/methods/fpocket4/test_chemical_context.py',
                    'tests/methods/fpocket4/test_handoff_pilot.py',
                    'tests/methods/fpocket4/test_pharmacophore_handoff.py'], plugins=[outcomes])
receipt.update(pytest_exit_code=int(code), tests=outcomes.reports,
               origins_after=check_origins(), files_after=check_files())
receipt['passed'] = sum(row['outcome'] == 'passed' for row in outcomes.reports)
receipt['skipped'] = sum(row['outcome'] == 'skipped' for row in outcomes.reports)
receipt['failed'] = sum(row['outcome'] == 'failed' for row in outcomes.reports)
receipt['limits'] = ['External non-suite dependencies reuse the existing Conda site-packages without editable hooks.',
                     'Linux x86_64 / Python 3.14 only; bounded control, not the complete suite or a release/publication gate.',
                     'Local development wheels remain at the recorded task artifact paths; no public package availability inferred.']
(BASE / 'installed-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
assert code == 0 and receipt['passed'] == 32 and not receipt['skipped'] and not receipt['failed'], receipt['tests']
print('INSTALLED_RECEIVING_PASS', receipt['passed'], 'zero skips; before/after files and loaded origins verified')
