import json,os,subprocess
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8'); clean=base/'clean'
env=os.environ.copy()
for name in ['PYTHONPATH','PYTHONHOME','PIP_EXTRA_INDEX_URL','LD_LIBRARY_PATH']: env.pop(name,None)
env.update(PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONSAFEPATH='1',PIP_CONFIG_FILE='/dev/null',PIP_INDEX_URL='https://pypi.org/simple',PIP_CACHE_DIR=str(clean/'pip-cache'),TMPDIR=str(clean/'scratch'))
env['PATH']=os.pathsep.join([str(clean/'build-tools/cmake/data/bin'),str(clean/'native-tools/bin'),env['PATH']])
command=json.loads((clean/'install-command.json').read_text())
with (clean/'logs/install-native.log').open('w') as log:
 result=subprocess.run(command,env=env,stdout=log,stderr=log)
print('install_exit',result.returncode)
print('\n'.join((clean/'logs/install-native.log').read_text().splitlines()[-18:]))
raise SystemExit(result.returncode)
