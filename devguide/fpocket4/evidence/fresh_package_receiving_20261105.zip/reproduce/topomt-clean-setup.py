"""Resolve a fresh package closure around the retained original local wheels."""
import hashlib,json,os,subprocess,sys,venv
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8')
clean=base/'clean'
clean.mkdir()
for name in ['logs','scratch','pip-cache']:
 (clean/name).mkdir()
venv.EnvBuilder(with_pip=False,symlinks=True,system_site_packages=False).create(base/'clean-env')
env=os.environ.copy()
for name in ['PYTHONPATH','PYTHONHOME','PIP_EXTRA_INDEX_URL','LD_LIBRARY_PATH']:
 env.pop(name,None)
env.update(PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONSAFEPATH='1',PIP_CONFIG_FILE='/dev/null',PIP_INDEX_URL='https://pypi.org/simple',PIP_CACHE_DIR=str(clean/'pip-cache'),TMPDIR=str(clean/'scratch'))
rows=json.loads((base/'wheels.json').read_text())
wheels=[]
for row in rows:
 path=base/'wheels'/row['filename']
 assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']
 wheels.append(str(path))
command=[sys.executable,'-m','pip','--python',str(base/'clean-env/bin/python'),'install','--dry-run','--report',str(clean/'resolution.json'),'--index-url','https://pypi.org/simple','--only-binary=:all:',*wheels]
(clean/'resolution-command.json').write_text(json.dumps(command,indent=2)+'\n')
with (clean/'logs/resolve.log').open('w') as log:
 result=subprocess.run(command,env=env,stdout=log,stderr=log)
print('resolver_exit',result.returncode)
print('\n'.join((clean/'logs/resolve.log').read_text().splitlines()[-15:]))
raise SystemExit(result.returncode)
