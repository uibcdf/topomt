"""Install the exact resolved inputs, without a second dependency resolution."""
import json,os,subprocess,sys
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8'); clean=base/'clean'
report=json.loads((clean/'resolution-sdist.json').read_text())
lines=[]
for item in report['install']:
 info=item['download_info']; digest=info['archive_info']['hashes']['sha256']
 lines.append(item['metadata']['name']+' @ '+info['url']+' --hash=sha256:'+digest)
(clean/'resolved-inputs.txt').write_text('\n'.join(sorted(lines,key=str.lower))+'\n')
env=os.environ.copy()
for name in ['PYTHONPATH','PYTHONHOME','PIP_EXTRA_INDEX_URL','LD_LIBRARY_PATH']: env.pop(name,None)
env.update(PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONSAFEPATH='1',PIP_CONFIG_FILE='/dev/null',PIP_INDEX_URL='https://pypi.org/simple',PIP_CACHE_DIR=str(clean/'pip-cache'),TMPDIR=str(clean/'scratch'))
command=[sys.executable,'-m','pip','--python',str(base/'clean-env/bin/python'),'install','--no-compile','--no-deps','--require-hashes','--report',str(clean/'installation.json'),'--index-url','https://pypi.org/simple','-r',str(clean/'resolved-inputs.txt')]
(clean/'install-command.json').write_text(json.dumps(command,indent=2)+'\n')
with (clean/'logs/install.log').open('w') as log:
 result=subprocess.run(command,env=env,stdout=log,stderr=log)
print('install_exit',result.returncode)
print('\n'.join((clean/'logs/install.log').read_text().splitlines()[-15:]))
raise SystemExit(result.returncode)
