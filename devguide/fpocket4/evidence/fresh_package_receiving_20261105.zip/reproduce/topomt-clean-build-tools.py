import json,os,subprocess,sys
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8'); clean=base/'clean'
env=os.environ.copy()
for name in ['PYTHONPATH','PYTHONHOME','PIP_EXTRA_INDEX_URL','LD_LIBRARY_PATH']: env.pop(name,None)
env.update(PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONSAFEPATH='1',PIP_CONFIG_FILE='/dev/null',PIP_INDEX_URL='https://pypi.org/simple',PIP_CACHE_DIR=str(clean/'pip-cache'),TMPDIR=str(clean/'scratch'))
with (clean/'logs/cmake-install.log').open('w') as log:
 result=subprocess.run([sys.executable,'-m','pip','install','--no-deps','--only-binary=:all:','--no-compile','--index-url','https://pypi.org/simple','--target',str(clean/'build-tools'),'--report',str(clean/'build-tool-installation.json'),'cmake==3.31.6'],env=env,stdout=log,stderr=log)
 if result.returncode: print(log.name); raise SystemExit(result.returncode)
env['PATH']=str(clean/'build-tools/cmake/data/bin')+os.pathsep+env['PATH']
print(subprocess.check_output(['cmake','--version'],env=env,text=True).splitlines()[0],flush=True)
command=json.loads((clean/'install-command.json').read_text())
with (clean/'logs/install-with-cmake.log').open('w') as log:
 result=subprocess.run(command,env=env,stdout=log,stderr=log)
print('install_exit',result.returncode)
print('\n'.join((clean/'logs/install-with-cmake.log').read_text().splitlines()[-16:]))
raise SystemExit(result.returncode)
