import json,os,subprocess
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8'); clean=base/'clean'
env=os.environ.copy()
env.update(MAMBA_ROOT_PREFIX=str(clean/'mamba-root'),CONDA_PKGS_DIRS=str(clean/'native-cache'),CONDA_ENVS_PATH=str(clean/'native-envs'))
command=['mamba','--no-rc','--root-prefix',str(clean/'mamba-root'),'create','--prefix',str(clean/'native-tools'),'--override-channels','--channel','https://conda.anaconda.org/conda-forge','--yes','flex=2.6.4','bison=3.8.2']
(clean/'native-tools-command.json').write_text(json.dumps(command,indent=2)+'\n')
with (clean/'logs/native-tools.log').open('w') as log:
 result=subprocess.run(command,env=env,stdout=log,stderr=log)
print('native_tools_exit',result.returncode)
print('\n'.join((clean/'logs/native-tools.log').read_text().splitlines()[-18:]))
raise SystemExit(result.returncode)
