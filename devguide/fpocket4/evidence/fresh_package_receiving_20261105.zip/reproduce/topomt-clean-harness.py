import json,shutil
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8'); clean=base/'clean'; harness=clean/'harness'
for path in ['tests/methods/fpocket4','devtools','topomt']:
 (harness/path).mkdir(parents=True,exist_ok=True)
for name in json.loads((base/'test-support.json').read_text())['files']:
 shutil.copyfile(base/'harness'/name,harness/name)
for name in ['tests/__init__.py','tests/methods/__init__.py','tests/methods/fpocket4/__init__.py','devtools/__init__.py']:
 (harness/name).touch()
(harness/'topomt/data').symlink_to(base/'clean-env/lib/python3.14/site-packages/topomt/data',target_is_directory=True)
(harness/'pytest.ini').write_text('[pytest]\naddopts = -q\n')
shutil.copyfile(base/'harness/prepared.h5msm',harness/'prepared.h5msm')
# Adapt only task-local paths and provenance checks, retaining all scientific
# tests and both unchanged public-operation qualification helpers.
source=Path('/tmp/topomt-installed-run.py').read_text()
source=source.replace("PREFIX = BASE / 'env'", "PREFIX = BASE / 'clean-env'")
source=source.replace("BASE / 'harness'", "BASE / 'clean/harness'")
source=source.replace("BASE / 'test-output'", "BASE / 'clean/test-output'")
source=source.replace("BASE / 'installed-receipt.json'", "BASE / 'clean/installed-receipt.json'")
source=source.replace("'bounded-installed-fpocket-receiving-1'", "'fresh-package-closure-fpocket-receiving-1'")
source=source.replace("receipt['pyunitwizard_origins'] = unit_origins", "receipt['pyunitwizard_origins'] = unit_origins\n    receipt['all_runtime_origins'] = check_all_runtime_origins()")
source=source.replace("receipt = {'profile':", """def check_all_runtime_origins():
    stdlib = Path(sys.base_prefix) / 'lib/python3.14'
    allowed_support = (BASE / 'clean/harness', BASE / 'sources/installed-sdk/devtools/scripts')
    checked = {}
    for name, module in tuple(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        locations = ([filename] if filename else []) + list(getattr(module, '__path__', ()))
        for text in locations:
            path = Path(text).resolve()
            allowed = (path.is_relative_to(PREFIX) or
                       (path.is_relative_to(stdlib) and 'site-packages' not in path.parts) or
                       any(path.is_relative_to(root) for root in allowed_support) or
                       path == Path(__file__).resolve())
            assert allowed, (name, text)
        if locations:
            checked[name] = locations
    assert not any('site-packages' in p and not Path(p).resolve().is_relative_to(PREFIX) for p in sys.path)
    return checked


def check_all_distribution_files():
    checked = []
    for dist in sorted(metadata.distributions(), key=lambda d: d.metadata['Name'].lower()):
        assert Path(dist._path).resolve().is_relative_to(PREFIX)
        count = 0
        for file in dist.files or ():
            if file.hash is None:
                continue
            path = Path(dist.locate_file(file)).resolve()
            assert path.is_relative_to(PREFIX), (dist.metadata['Name'], str(file))
            actual = base64.urlsafe_b64encode(hashlib.new(file.hash.mode, path.read_bytes()).digest()).rstrip(b'=').decode()
            assert actual == file.hash.value, (dist.metadata['Name'], str(file))
            count += 1
        checked.append({'name': dist.metadata['Name'], 'version': dist.version,
                        'record_hashes_checked': count})
    assert len(checked) == 137
    return checked


receipt = {'profile':""")
source=source.replace("'python': sys.version, 'prefix': sys.prefix}", "'python': sys.version, 'prefix': sys.prefix, 'all_files_before': check_all_distribution_files()}")
source=source.replace("\nreceipt['passed'] =", "\nreceipt['all_files_after'] = check_all_distribution_files()\nassert receipt['all_files_before'] == receipt['all_files_after']\nreceipt['passed'] =")
start=source.index("receipt['limits'] = [")
end=source.index("(BASE / 'clean/installed-receipt.json')",start)
source=source[:start]+"""receipt['limits'] = ['Fresh virtual environment with independent packages; the existing Python interpreter and standard library are reused.',
                     'Suite wheels are the original local source-built artifacts; this does not establish a public source-free acquisition route.',
                     'Linux x86_64 / Python 3.14 only, bounded science; not the complete suite, Conda artifact, release or hosted matrix.',
                     'Optional beartype is absent in the metadata-only closure; runtime type checks are disabled and emit provider diagnostics.']
"""+source[end:]
Path('/tmp/topomt-clean-run.py').write_text(source)
