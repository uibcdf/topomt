"""Retain bounded fresh-package receiving evidence without replacing artifacts."""
import hashlib,json,shutil,zipfile
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8'); clean=base/'clean'
profiles={}
for label,name,expected in [('metadata-only','receipt-metadata-only.json',137),('types-enabled','receipt-types-enabled.json',138)]:
 d=json.loads((clean/name).read_text())
 assert d['passed']==32 and d['failed']==d['skipped']==d['pytest_exit_code']==0
 assert d['all_files_before']==d['all_files_after'] and len(d['all_files_after'])==expected
 profiles[label]={'receipt':name,'tests':32,'skipped':0,'failed':0,'distributions':expected,'record_hashes':sum(r['record_hashes_checked'] for r in d['all_files_after']),'test_support':'Unchanged five test files and two qualification helpers from the original producer.'}
# Preserve built external wheels as well as the original suite wheels. These
# two artifacts were built from exactly hashed public source distributions.
external=clean/'external-wheels'; external.mkdir(exist_ok=True)
external_rows=[]
for name in ['mmcif','nglview']:
 matches=list((clean/'pip-cache/wheels').rglob(name+'-*.whl'))
 assert len(matches)==1,(name,matches)
 wheel=matches[0]; target=external/wheel.name; shutil.copyfile(wheel,target)
 external_rows.append({'filename':target.name,'size':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'retained':str(target)})
(clean/'external-built-wheels.json').write_text(json.dumps(external_rows,indent=2)+'\n')
# Bind acquisition hashes to installed metadata and require exact wheel pins.
installation=json.loads((clean/'installation.json').read_text())
assert len(installation['install'])==137
sources=json.loads((base/'sources.json').read_text()); suite=json.loads((base/'wheels.json').read_text())
for row in suite:
 artifact=base/'wheels'/row['filename']; assert hashlib.sha256(artifact.read_bytes()).hexdigest()==row['sha256']
 found=[i for i in installation['install'] if i['metadata']['name'].lower().replace('_','-')==row['name'].lower().replace('_','-')]
 assert len(found)==1 and found[0]['download_info']['archive_info']['hashes']['sha256']==row['sha256']
assert (clean/'logs/pip-check-before.log').read_text().strip()=='No broken requirements found.'
assert (clean/'logs/pip-check-after.log').read_text().strip()=='No broken requirements found.'
# Retain native build-tool identities separately from runtime dependencies.
native=[]
for p in sorted((clean/'native-tools/conda-meta').glob('*.json')):
 d=json.loads(p.read_text()); native.append({k:d[k] for k in ['name','version','build','url','sha256'] if k in d})
(clean/'native-build-tools.json').write_text(json.dumps(native,indent=2)+'\n')
entries={}
for p in clean.glob('*.json'):
 if p.name=='installed-receipt.json': continue # same bytes as retained metadata-only receipt
 entries['control/'+p.name]=p
entries['control/resolved-inputs.txt']=clean/'resolved-inputs.txt'
for p in (clean/'logs').glob('*.log'): entries['logs/'+p.name]=p
for name in ['setup','resolve','install','build-tools','native-tools','retry-native','harness','run','enable-types','run-types','evidence']:
 p=Path('/tmp')/('topomt-clean-'+name+'.py'); entries['reproduce/'+p.name]=p
entries['reproduce/topomt-installed-run.py']=Path('/tmp/topomt-installed-run.py')
for name in json.loads((base/'test-support.json').read_text())['files']:
 entries['support/'+name]=clean/'harness'/name
entries['support/prepared.h5msm']=clean/'harness/prepared.h5msm'
for profile,dirname in [('metadata-only','test-output'),('types-enabled','test-output-types')]:
 outputs=clean/dirname
 for sub in ['test_real_fpocket_handoff_pres0/handoff','prepared_handoff0/original','test_original_pocket_builds_pe0/consumer','test_original_pocket_builds_pe1/consumer']:
  for p in (outputs/sub).glob('*'):
   if p.is_file(): entries['scientific/'+profile+'/'+sub+'/'+p.name]=p
 for name in ['original.zip','source.h5msm']:
  entries['scientific/'+profile+'/reference-index-1/'+name]=outputs/'test_real_engine_run_retains_n0'/name
manifest={name:{'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for name,p in entries.items()}
archive=clean/'fresh_package_receiving_20261105.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(entries.items()): z.write(p,name)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(manifest)|{'manifest.json'}
 for name,row in manifest.items(): assert hashlib.sha256(z.read(name)).hexdigest()==row['sha256']
receipt={'schema':'topomt.fresh-package-receiving-evidence@1','archive':archive.name,'size':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(entries)+1,'producer':sources['topomt']['commit'],'original_wheels_manifest':'installed_receiving_20261105.json','original_wheels_manifest_sha256':hashlib.sha256(Path('/home/liliana/repos@uibcdf/topomt/devguide/fpocket4/evidence/installed_receiving_20261105.json').read_bytes()).hexdigest(),'profiles':profiles,'scope':'Fresh isolated Python-package closure on Linux x86_64/Python 3.14; original local suite wheels; existing interpreter and OS libraries reused. Not full/public/Conda/matrix qualification.','pip_check':{'before':'No broken requirements found.','after':'No broken requirements found.'},'original_wheel_retention':str(base/'wheels'),'external_built_wheels':external_rows,'argdigest_audit':'control/argdigest-boundary-review.json; four undecorated entry points and two invalid-dispatch AttributeErrors. Audit does not change or qualify those boundaries.'}
(clean/'fresh_package_receiving_20261105.json').write_text(json.dumps(receipt,indent=2)+'\n')
repo=Path('/home/liliana/repos@uibcdf/topomt/devguide/fpocket4/evidence')
for name in ['fresh_package_receiving_20261105.zip','fresh_package_receiving_20261105.json']: shutil.copyfile(clean/name,repo/name)
print('archive',receipt['size'],receipt['sha256'],'members',receipt['members'])
print('profiles',profiles)
