import importlib.metadata,json,os,shutil,subprocess,sys
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8'); clean=base/'clean'
shutil.copyfile(clean/'installed-receipt.json',clean/'receipt-metadata-only.json')
version=importlib.metadata.version('beartype')
env=os.environ.copy()
for name in ['PYTHONPATH','PYTHONHOME','PIP_EXTRA_INDEX_URL','LD_LIBRARY_PATH']: env.pop(name,None)
env.update(PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONSAFEPATH='1',PIP_CONFIG_FILE='/dev/null',PIP_INDEX_URL='https://pypi.org/simple',PIP_CACHE_DIR=str(clean/'pip-cache'),TMPDIR=str(clean/'scratch'))
command=[sys.executable,'-m','pip','--python',str(base/'clean-env/bin/python'),'install','--no-compile','--no-deps','--only-binary=:all:','--index-url','https://pypi.org/simple','--report',str(clean/'beartype-installation.json'),'beartype=='+version]
(clean/'beartype-command.json').write_text(json.dumps(command,indent=2)+'\n')
with (clean/'logs/beartype-install.log').open('w') as log:
 result=subprocess.run(command,env=env,stdout=log,stderr=log)
print('beartype_install_exit',result.returncode,'version',version)
if result.returncode: print('\n'.join((clean/'logs/beartype-install.log').read_text().splitlines()[-10:])); raise SystemExit(result.returncode)
source=Path('/tmp/topomt-clean-run.py').read_text()
source=source.replace("BASE / 'clean/test-output'", "BASE / 'clean/test-output-types'").replace("BASE / 'clean/installed-receipt.json'", "BASE / 'clean/receipt-types-enabled.json'").replace("len(checked) == 137", "len(checked) == 138").replace("'fresh-package-closure-fpocket-receiving-1'", "'fresh-package-closure-fpocket-types-enabled-1'")
source=source.replace("Optional beartype is absent in the metadata-only closure; runtime type checks are disabled and emit provider diagnostics.", "Optional beartype "+version+" is installed for this second sequential environment profile; the metadata-only profile remains separately recorded.")
compile(source,'/tmp/topomt-clean-run-types.py','exec')
Path('/tmp/topomt-clean-run-types.py').write_text(source)
