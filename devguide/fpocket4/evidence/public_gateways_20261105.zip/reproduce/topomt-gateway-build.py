"""Build the exact fpocket-argument producer without touching the live version file."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8'); task=base/'gateways'; repo=Path('/home/liliana/repos@uibcdf/topomt')
source=task/'source'; wheels=task/'wheels'; wheels.mkdir()
sha=subprocess.check_output(['git','rev-parse','4a55982'],cwd=repo,text=True).strip()
with (task/'snapshot.log').open('w') as log:
 subprocess.run(['git','clone','--shared','--no-checkout',str(repo),str(source)],stdout=log,stderr=log,check=True)
 subprocess.run(['git','checkout','--detach',sha],cwd=source,stdout=log,stderr=log,check=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
(task/'source.json').write_text(json.dumps({'producer':sha,'checkout':str(source),'runtime_tree':subprocess.check_output(['git','rev-parse',sha+':topomt'],cwd=repo,text=True).strip()},indent=2)+'\n')
env=os.environ.copy()
for name in ['PYTHONPATH','PIP_EXTRA_INDEX_URL','LD_LIBRARY_PATH']: env.pop(name,None)
env.update(TMPDIR=str(base/'clean/scratch'),PIP_CACHE_DIR=str(base/'pip-cache'),PIP_CONFIG_FILE='/dev/null',PIP_INDEX_URL='https://pypi.org/simple',PYTHONDONTWRITEBYTECODE='1')
with (task/'build.log').open('w') as log:
 result=subprocess.run([sys.executable,'-m','pip','wheel','--no-deps','--index-url','https://pypi.org/simple','--wheel-dir',str(wheels),str(source)],env=env,stdout=log,stderr=log)
if result.returncode: print('\n'.join((task/'build.log').read_text().splitlines()[-15:])); raise SystemExit(result.returncode)
p=next(wheels.glob('topomt-*.whl')); row={'name':'topomt','filename':p.name,'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'producer':sha}
(task/'wheel.json').write_text(json.dumps(row,indent=2)+'\n')
with (task/'install.log').open('w') as log:
 subprocess.run([sys.executable,'-m','pip','--python',str(base/'clean-env/bin/python'),'install','--no-deps','--no-compile','--force-reinstall','--no-index',str(p)],env=env,stdout=log,stderr=log,check=True)
print('installed new task-only candidate',json.dumps(row))
