"""Execute the bounded installed fpocket receiving control outside all checkouts."""
import base64
import hashlib
import importlib
import importlib.metadata as metadata
import json
import os
import sys
from pathlib import Path

import pytest

BASE = Path('/dev/shm/topomt-installed-101.bch3yxd8')
PREFIX = BASE / 'clean-env'
ROOTS = ('topomt', 'molsysviewer_topomt', 'molsysmt', 'molsysviewer_molsysmt',
         'pharmacophoremt', 'molsysviewer_pharmacophoremt', 'pyunitwizard',
         'molsysviewer', 'smonitor', 'argdigest', 'depdigest', 'pytest_receptor')
sys.path.insert(0, str(BASE / 'dispatch/harness'))
sys.path.insert(0, str(BASE / 'sources/installed-sdk/devtools/scripts'))
from installed_imports import check_installed_imports

os.chdir(BASE / 'dispatch/harness')
for name in ('topomt', 'molsysmt', 'molsysmt._rust', 'pharmacophoremt',
             'pyunitwizard', 'molsysviewer', 'smonitor', 'argdigest', 'depdigest'):
    importlib.import_module(name)


def check_origins():
    receipt = check_installed_imports(tuple(r for r in ROOTS if r != 'pyunitwizard'), PREFIX, BASE / 'sources')
    # The unchanged shared checker requires files even for generated aliases.
    # Keep its strict check for every other suite root; inspect this one known
    # provider alias without deleting or rewriting any imported module.
    unit_origins = {}
    for name, module in tuple(sys.modules.items()):
        if name != 'pyunitwizard' and not name.startswith('pyunitwizard.'):
            continue
        locations = ([module.__file__] if getattr(module, '__file__', None) else [])
        locations += list(getattr(module, '__path__', ()))
        if not locations:
            assert name == 'pyunitwizard.main', name
            assert set(k for k, v in vars(module).items() if hasattr(v, '__code__')) == {'__getattr__', '__dir__'}
            locations = [vars(module)[k].__code__.co_filename for k in ('__getattr__', '__dir__')]
            assert all(Path(p).resolve() == PREFIX / 'lib/python3.14/site-packages/pyunitwizard/__init__.py' for p in locations)
        assert all(Path(p).resolve().is_relative_to(PREFIX) for p in locations), (name, locations)
        unit_origins[name] = locations
    receipt['pyunitwizard_origins'] = unit_origins
    receipt['all_runtime_origins'] = check_all_runtime_origins()
    receipt['shared_checker_limit'] = 'The fileless pyunitwizard.main compatibility alias is checked by its two installed generator code origins, separately from the unchanged shared checker.'
    assert not any(name.startswith('__editable__') for name in sys.modules)
    assert not any(Path(p).resolve().is_relative_to(BASE / 'sources')
                   for p in sys.path if p and 'installed-sdk/devtools/scripts' not in p)
    return receipt


def check_files():
    receipts = []
    for wheel in json.loads((BASE / 'dispatch/effective-wheels.json').read_text()):
        dist = metadata.distribution(wheel['name'])
        assert Path(dist._path).resolve().is_relative_to(PREFIX)
        assert json.loads(dist.read_text('direct_url.json'))['archive_info']['hashes']['sha256'] == wheel['sha256']
        checked = 0
        for file in dist.files:
            if file.hash is None:
                continue
            path = Path(dist.locate_file(file)).resolve()
            assert path.is_relative_to(PREFIX), (wheel['name'], path)
            actual = base64.urlsafe_b64encode(hashlib.new(file.hash.mode, path.read_bytes()).digest()).rstrip(b'=').decode()
            assert actual == file.hash.value, (wheel['name'], str(file))
            checked += 1
        receipts.append({'name': wheel['name'], 'version': dist.version,
                         'requires_python': dist.metadata['Requires-Python'],
                         'record_hashes_checked': checked})
    return receipts


class Outcomes:
    def __init__(self):
        self.reports = []

    def pytest_runtest_logreport(self, report):
        if report.when == 'call' or report.failed or report.skipped:
            self.reports.append({'nodeid': report.nodeid, 'when': report.when,
                                 'outcome': report.outcome})


def check_all_runtime_origins():
    stdlib = Path(sys.base_prefix) / 'lib/python3.14'
    allowed_support = (BASE / 'dispatch/harness', BASE / 'sources/installed-sdk/devtools/scripts')
    checked = {}
    for name, module in tuple(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        locations = ([filename] if filename else []) + list(getattr(module, '__path__', ()))
        for text in locations:
            path = Path(text).resolve()
            allowed = (path.is_relative_to(PREFIX) or
                       (path.is_relative_to(stdlib) and 'site-packages' not in path.parts) or
                       any(path.is_relative_to(root) for root in allowed_support) or
                       path == Path(__file__).resolve())
            assert allowed, (name, text)
        if locations:
            checked[name] = locations
    assert not any('site-packages' in p and not Path(p).resolve().is_relative_to(PREFIX) for p in sys.path)
    return checked


def check_all_distribution_files():
    checked = []
    for dist in sorted(metadata.distributions(), key=lambda d: d.metadata['Name'].lower()):
        assert Path(dist._path).resolve().is_relative_to(PREFIX)
        count = 0
        for file in dist.files or ():
            if file.hash is None:
                continue
            path = Path(dist.locate_file(file)).resolve()
            assert path.is_relative_to(PREFIX), (dist.metadata['Name'], str(file))
            actual = base64.urlsafe_b64encode(hashlib.new(file.hash.mode, path.read_bytes()).digest()).rstrip(b'=').decode()
            assert actual == file.hash.value, (dist.metadata['Name'], str(file))
            count += 1
        checked.append({'name': dist.metadata['Name'], 'version': dist.version,
                        'record_hashes_checked': count})
    assert len(checked) == 138
    return checked


receipt = {'profile': 'argdigest-original-provider-dispatch-installed-1',
           'origins_before': check_origins(), 'files_before': check_files(),
           'python': sys.version, 'prefix': sys.prefix, 'all_files_before': check_all_distribution_files()}
outcomes = Outcomes()
code = pytest.main(['--noconftest', '--junitxml', str(BASE / 'dispatch/installed-tests.xml'), '-p', 'pytest_receptor.plugin', '--receptor=llm',
                    '--basetemp', str(BASE / 'dispatch/installed-tests'),
                    'tests/test_provider_dispatch_arguments.py',
                    'tests/methods/fpocket4/test_input_preparation.py',
                    'tests/methods/fpocket4/test_submission_mapping.py',
                    'tests/methods/fpocket4/test_chemical_context.py',
                    'tests/methods/fpocket4/test_handoff_pilot.py',
                    'tests/methods/fpocket4/test_pharmacophore_handoff.py'], plugins=[outcomes])
receipt.update(pytest_exit_code=int(code), tests=outcomes.reports,
               origins_after=check_origins(), files_after=check_files())
receipt['all_files_after'] = check_all_distribution_files()
assert receipt['all_files_before'] == receipt['all_files_after']
receipt['passed'] = sum(row['outcome'] == 'passed' for row in outcomes.reports)
receipt['skipped'] = sum(row['outcome'] == 'skipped' for row in outcomes.reports)
receipt['failed'] = sum(row['outcome'] == 'failed' for row in outcomes.reports)
receipt['limits'] = ['New TopoMT candidate f7f4947 and exact ArgDigest 0.17.0 wheel; original earlier artifacts remain separately identified.',
                     'Method/backend use ArgDigest; other provider keywords and source-dependent checks remain delegated, not fully qualified here.',
                     'Independent runtime packages reuse the Python interpreter and OS libraries; Linux x86_64/Python 3.14 only.',
                     'Bounded science and contracts, not a full suite, hosted/Conda/public qualification.']
(BASE / 'dispatch/installed-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
assert code == 0 and receipt['passed'] == 65 and not receipt['skipped'] and not receipt['failed'], receipt['tests']
print('INSTALLED_RECEIVING_PASS', receipt['passed'], 'zero skips; before/after files and loaded origins verified')
