import hashlib,json,shutil,tomllib,zipfile
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8'); task=base/'dispatch'; source=task/'sources/topomt'; harness=task/'harness'
for path in ['tests/methods/fpocket4','devtools','topomt']: (harness/path).mkdir(parents=True,exist_ok=True)
files=json.loads((base/'test-support.json').read_text())['files']+['tests/test_provider_dispatch_arguments.py']
for name in files: shutil.copyfile(source/name,harness/name)
for name in ['tests/__init__.py','tests/methods/__init__.py','tests/methods/fpocket4/__init__.py','devtools/__init__.py']: (harness/name).touch()
(harness/'topomt/data').symlink_to(base/'clean-env/lib/python3.14/site-packages/topomt/data',target_is_directory=True)
(harness/'pytest.ini').write_text('[pytest]\naddopts = -q\n')
shutil.copyfile(base/'clean/harness/prepared.h5msm',harness/'prepared.h5msm')
old={r['name']:r for r in json.loads((base/'wheels.json').read_text())}; old.update({r['name']:r for r in json.loads((task/'wheels.json').read_text())})
(task/'effective-wheels.json').write_text(json.dumps(list(old.values()),indent=2)+'\n')
resources=tomllib.loads((source/'devtools/conda-build/resources.toml').read_text())
wheel=next((task/'wheels').glob('topomt-*.whl'))
with zipfile.ZipFile(wheel) as z:
 paths=[p.removeprefix('site-packages/') for p in resources['required_paths']]
 assert len(paths)==613 and set(paths).issubset(z.namelist())
 assert {n.split('/')[0] for n in z.namelist() if '/' in n and not n.split('/')[0].endswith('.dist-info')}=={'topomt','molsysviewer_topomt'}
(task/'resources.json').write_text(json.dumps({'required_count':613,'missing':[],'unexpected_roots':[]},indent=2)+'\n')
script=Path('/tmp/topomt-clean-run-types.py').read_text()
script=script.replace("BASE / 'clean/harness'","BASE / 'dispatch/harness'").replace("BASE / 'clean/test-output-types'","BASE / 'dispatch/installed-tests'").replace("BASE / 'clean/receipt-types-enabled.json'","BASE / 'dispatch/installed-receipt.json'").replace("BASE / 'wheels.json'","BASE / 'dispatch/effective-wheels.json'")
script=script.replace("'fresh-package-closure-fpocket-types-enabled-1'","'argdigest-original-provider-dispatch-installed-1'")
script=script.replace("'tests/methods/fpocket4/test_input_preparation.py',","'tests/test_provider_dispatch_arguments.py',\n                    'tests/methods/fpocket4/test_input_preparation.py',")
script=script.replace("'--noconftest', '-p'","'--noconftest', '--junitxml', str(BASE / 'dispatch/installed-tests.xml'), '-p'").replace("receipt['passed'] == 32","receipt['passed'] == 65")
start=script.index("receipt['limits'] = ["); end=script.index("(BASE / 'dispatch/installed-receipt.json')",start)
script=script[:start]+"""receipt['limits'] = ['New TopoMT candidate f7f4947 and exact ArgDigest 0.17.0 wheel; original earlier artifacts remain separately identified.',
                     'Method/backend use ArgDigest; other provider keywords and source-dependent checks remain delegated, not fully qualified here.',
                     'Independent runtime packages reuse the Python interpreter and OS libraries; Linux x86_64/Python 3.14 only.',
                     'Bounded science and contracts, not a full suite, hosted/Conda/public qualification.']
"""+script[end:]
compile(script,'/tmp/topomt-dispatch-run.py','exec'); Path('/tmp/topomt-dispatch-run.py').write_text(script)
(task/'test-support.json').write_text(json.dumps({'producer':json.loads((task/'sources.json').read_text())['topomt']['commit'],'files':files,'data_link':'new installed topomt/data'},indent=2)+'\n')
