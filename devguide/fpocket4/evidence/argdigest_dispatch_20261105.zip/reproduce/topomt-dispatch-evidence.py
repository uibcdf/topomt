"""Archive the exact new dispatch candidate's bounded receiving evidence."""
import hashlib,json,shutil,subprocess,zipfile
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8'); task=base/'dispatch'; repo=Path('/home/liliana/repos@uibcdf/topomt')
receipt=json.loads((task/'installed-receipt.json').read_text())
assert receipt['passed']==len(receipt['tests'])==65 and receipt['failed']==receipt['skipped']==receipt['pytest_exit_code']==0
assert receipt['all_files_before']==receipt['all_files_after']
assert len(receipt['all_files_after'])==138
assert (task/'pip-check.log').read_text().strip()=='No broken requirements found.'
for row in json.loads((task/'wheels.json').read_text()):
 p=task/'wheels'/row['filename']; assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
for row in json.loads((base/'wheels.json').read_text()):
 p=base/'wheels'/row['filename']; assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
assert hashlib.sha256((repo/'topomt/_version.py').read_bytes()).hexdigest()=='91af00335ecf06be1573c95e22dbba13bfaa0a9e472ffa3de802cee87dc38baf'
summary={'date':'2026-11-05','producer':json.loads((task/'sources.json').read_text())['topomt']['commit'],'argdigest_source':json.loads((task/'sources.json').read_text())['argdigest'],
 'source_tests':{'passed':185,'deselected':5,'harness_failure':'One reporting check was incompatible with PYTHONSAFEPATH; the two reporting checks passed separately in the ordinary command environment. This is not one completely green 186-case invocation.','final_boundary_and_reporting':{'passed':35}},
 'governance':{'passed':26,'sdk':'8f00e6d9de943b6e4710ea62936e2ebea00fad24','routes':19,'source_records':12,'contexts':7},
 'typing':{'tool':'mypy 2.3.1','checked_files':5,'imported_bodies':'skipped','result':'success'},
 'ruff':{'lint':'passed','format':'passed','files':421},
 'docs':{'full_build':'success with 12 existing warnings','incremental_after_minimum_update':'success with 8 warnings','edited_user_page_diagnostic':False},
 'installed':{'passed':65,'skipped':0,'failed':0,'elapsed_seconds':39.96,'runtime_distributions':138,'record_hashes_before_and_after':26213,'suite_record_hashes_before_and_after':5120},
 'resources':{'required':613,'added':'Three new dispatch runtime modules and the previously omitted fpocket/input_context.py.'},
 'artifact_retention':str(task/'wheels'),'original_artifacts_preserved':True,'user_version_preserved':True,
 'scope':'ArgDigest admission of method/backend at get_provider_output only; provider keyword/value and direct-adapter coverage remain separate.'}
(task/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
entries={}
for name in ['sources.json','wheels.json','effective-wheels.json','resources.json','test-support.json','installed-receipt.json','dependency-preflight.json','summary.json']:
 entries['control/'+name]=task/name
for name in ['source-tests.log','source-tests.xml','governance-tests.log','distribution-tests.log','mypy-final.log','docs.log','docs-final.log','topomt-build.log','argdigest-build.log','candidate-install.log','installed-tests.log','installed-tests.xml','pip-check.log']:
 entries['logs/'+name]=task/name
for name in ['build','harness','run','typecheck','evidence']:
 entries['reproduce/topomt-dispatch-'+name+'.py']=Path('/tmp')/('topomt-dispatch-'+name+'.py')
entries['reproduce/topomt-clean-run-types.py']=Path('/tmp/topomt-clean-run-types.py')
for name in json.loads((task/'test-support.json').read_text())['files']:
 entries['support/'+name]=task/'harness'/name
for name in ['pyproject.toml','devtools/conda-build/resources.toml','devtools/conda-build/meta.yaml','devtools/dependency_routes.toml','devtools/requirements/controlled_suite_dependencies.txt','devtools/requirements/controlled_suite_dependencies_py314.txt']:
 entries['declarations/'+name]=task/'sources/topomt'/name
outputs=task/'installed-tests'
for sub in ['test_real_fpocket_handoff_pres0/handoff','prepared_handoff0/original','test_original_pocket_builds_pe0/consumer','test_original_pocket_builds_pe1/consumer']:
 for p in (outputs/sub).glob('*'):
  if p.is_file(): entries['scientific/'+sub+'/'+p.name]=p
for name in ['original.zip','source.h5msm']:
 entries['scientific/reference-index-1/'+name]=outputs/'test_real_engine_run_retains_n0'/name
manifest={name:{'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for name,p in entries.items()}
archive=task/'argdigest_dispatch_20261105.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(entries.items()): z.write(p,name)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(manifest)|{'manifest.json'}
 for name,row in manifest.items(): assert hashlib.sha256(z.read(name)).hexdigest()==row['sha256']
side={'schema':'topomt.argdigest-dispatch-evidence@1','archive':archive.name,'size':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(entries)+1,'producer':summary['producer'],'wheels':json.loads((task/'wheels.json').read_text()),'installed':summary['installed'],'scope':summary['scope'],'artifact_retention':summary['artifact_retention'],'limits':'Independent installed packages on Linux x86_64/Python 3.14; existing interpreter/OS and pinned local suite inputs. No full hosted/Conda/public qualification.'}
(task/'argdigest_dispatch_20261105.json').write_text(json.dumps(side,indent=2)+'\n')
for name in ['argdigest_dispatch_20261105.zip','argdigest_dispatch_20261105.json']: shutil.copyfile(task/name,repo/'devguide/fpocket4/evidence'/name)
print('retained',side['size'],side['sha256'],side['members'])
