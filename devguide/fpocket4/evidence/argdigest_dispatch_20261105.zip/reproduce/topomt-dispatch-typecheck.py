import os,subprocess,sys
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8/dispatch')
env=os.environ.copy()
for name in ['PYTHONPATH','PIP_EXTRA_INDEX_URL']: env.pop(name,None)
env.update(TMPDIR='/dev/shm/topomt-installed-101.bch3yxd8/clean/scratch',PIP_NO_CACHE_DIR='1',PIP_CONFIG_FILE='/dev/null',PIP_INDEX_URL='https://pypi.org/simple',PYTHONDONTWRITEBYTECODE='1')
with (base/'type-tool-retry.log').open('w') as log:
 result=subprocess.run([sys.executable,'-m','pip','install','--index-url','https://pypi.org/simple','--only-binary=:all:','--no-compile','--target',str(base/'type-tools-ready'),'mypy==2.3.1'],env=env,stdout=log,stderr=log)
 if result.returncode:
  print('\n'.join(line for line in (base/'type-tool-retry.log').read_text().splitlines() if line.startswith('ERROR:'))); raise SystemExit(result.returncode)
env['PYTHONPATH']=str(base/'type-tools-ready')
command=[sys.executable,'-m','mypy','--follow-imports=skip','--ignore-missing-imports','--check-untyped-defs','--cache-dir',str(base/'mypy-cache'),'topomt/get_provider_output.py','topomt/_private/arg_digestion/provider_dispatch.py','topomt/_private/arg_digestion/function/provider_output.py','topomt/_private/arg_digestion/argument/method.py','topomt/_private/arg_digestion/argument/backend.py']
with (base/'mypy.log').open('w') as log: result=subprocess.run(command,env=env,stdout=log,stderr=log)
print((base/'mypy.log').read_text())
raise SystemExit(result.returncode)
