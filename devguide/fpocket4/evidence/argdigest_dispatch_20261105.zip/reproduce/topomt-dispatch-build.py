"""Build a new, separately identified dispatch candidate and its qualified provider."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8'); task=base/'dispatch'
(task/'sources').mkdir(); (task/'wheels').mkdir()
sources={}
for name,ref in [('topomt','f7f4947'),('argdigest','c7128f09b2fe064b6c5603d1077dbd2cec52223d')]:
 original=Path('/home/liliana/repos@uibcdf')/name; target=task/'sources'/name
 sha=subprocess.check_output(['git','rev-parse',ref],cwd=original,text=True).strip()
 with (task/(name+'-snapshot.log')).open('w') as log:
  subprocess.run(['git','clone','--shared','--no-checkout',str(original),str(target)],stdout=log,stderr=log,check=True)
  subprocess.run(['git','checkout','--detach',sha],cwd=target,stdout=log,stderr=log,check=True)
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=target,text=True).strip()
 sources[name]={'commit':sha,'checkout':str(target),'runtime_tree':subprocess.check_output(['git','rev-parse',sha+':'+name],cwd=original,text=True).strip()}
(task/'sources.json').write_text(json.dumps(sources,indent=2)+'\n')
env=os.environ.copy()
for name in ['PYTHONPATH','PIP_EXTRA_INDEX_URL','LD_LIBRARY_PATH']: env.pop(name,None)
env.update(TMPDIR=str(base/'clean/scratch'),PIP_CACHE_DIR=str(base/'pip-cache'),PIP_CONFIG_FILE='/dev/null',PIP_INDEX_URL='https://pypi.org/simple',PYTHONDONTWRITEBYTECODE='1')
receipts=[]
for name in ['argdigest','topomt']:
 print('building',name,flush=True)
 with (task/(name+'-build.log')).open('w') as log:
  result=subprocess.run([sys.executable,'-m','pip','wheel','--no-deps','--index-url','https://pypi.org/simple','--wheel-dir',str(task/'wheels'),str(task/'sources'/name)],env=env,stdout=log,stderr=log)
 if result.returncode:
  print('\n'.join((task/(name+'-build.log')).read_text().splitlines()[-15:])); raise SystemExit(result.returncode)
 p=next((task/'wheels').glob(name+'-*.whl'))
 receipts.append({'name':name,'filename':p.name,'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'producer':sources[name]['commit']})
 (task/'wheels.json').write_text(json.dumps(receipts,indent=2)+'\n')
 print('built',p.name,receipts[-1]['sha256'],flush=True)
# Replace only the task environment's two installations. Original artifact bytes
# and all prior receipts remain untouched, with different producer identities.
with (task/'candidate-install.log').open('w') as log:
 subprocess.run([sys.executable,'-m','pip','--python',str(base/'clean-env/bin/python'),'install','--no-deps','--no-compile','--force-reinstall','--no-index',*[str(p) for p in sorted((task/'wheels').glob('*.whl'))]],env=env,stdout=log,stderr=log,check=True)
print('new candidate installed only in the task environment',flush=True)
