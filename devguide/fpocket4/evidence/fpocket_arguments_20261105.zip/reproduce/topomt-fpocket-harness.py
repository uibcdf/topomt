import json,shutil,tomllib,zipfile
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8'); task=base/'fpocket-arguments'; source=task/'source'; harness=task/'harness'
for path in ['tests/methods/fpocket4','devtools','topomt']: (harness/path).mkdir(parents=True,exist_ok=True)
files=json.loads((base/'dispatch/test-support.json').read_text())['files']+['tests/methods/fpocket4/test_argument_contracts.py']
for name in files: shutil.copyfile(source/name,harness/name)
for name in ['tests/__init__.py','tests/methods/__init__.py','tests/methods/fpocket4/__init__.py','devtools/__init__.py']: (harness/name).touch()
(harness/'topomt/data').symlink_to(base/'clean-env/lib/python3.14/site-packages/topomt/data',target_is_directory=True)
(harness/'pytest.ini').write_text('[pytest]\naddopts = -q\n')
shutil.copyfile(base/'clean/harness/prepared.h5msm',harness/'prepared.h5msm')
rows={r['name']:r for r in json.loads((base/'dispatch/effective-wheels.json').read_text())}; row=json.loads((task/'wheel.json').read_text()); rows['topomt']=row
(task/'effective-wheels.json').write_text(json.dumps(list(rows.values()),indent=2)+'\n')
resources=tomllib.loads((source/'devtools/conda-build/resources.toml').read_text())
with zipfile.ZipFile(task/'wheels'/row['filename']) as z:
 paths=[p.removeprefix('site-packages/') for p in resources['required_paths']]
 assert len(paths)==617 and set(paths).issubset(z.namelist())
 assert {n.split('/')[0] for n in z.namelist() if '/' in n and not n.split('/')[0].endswith('.dist-info')}=={'topomt','molsysviewer_topomt'}
(task/'resources.json').write_text(json.dumps({'required_count':617,'missing':[],'unexpected_roots':[]},indent=2)+'\n')
s=Path('/tmp/topomt-dispatch-run.py').read_text()
for name in ['harness','installed-tests','installed-tests.xml','installed-receipt.json','effective-wheels.json']:
 s=s.replace("BASE / 'dispatch/"+name+"'","BASE / 'fpocket-arguments/"+name+"'")
s=s.replace("'argdigest-original-provider-dispatch-installed-1'","'argdigest-fpocket-arguments-installed-1'")
s=s.replace("'tests/test_provider_dispatch_arguments.py',","'tests/methods/fpocket4/test_argument_contracts.py',\n                    'tests/test_provider_dispatch_arguments.py',")
s=s.replace("receipt['passed'] == 65","receipt['passed'] == 115")
start=s.index("receipt['limits'] = ["); end=s.index("(BASE / 'fpocket-arguments/installed-receipt.json')",start)
s=s[:start]+"""receipt['limits'] = ['Exact new TopoMT producer 75eb36b; original earlier wheels remain separately retained.',
                     'Original fpocket get_output/CLI/files argument boundaries are qualified here; native gateways and parsed-result assembly are separate.',
                     'Source-dependent frame/index/chemical agreement remains with the existing molecular/provider checks.',
                     'Independent packages reuse the interpreter and OS; Linux x86_64/Python 3.14 only, bounded science rather than full hosted/public qualification.']
"""+s[end:]
compile(s,'/tmp/topomt-fpocket-run.py','exec'); Path('/tmp/topomt-fpocket-run.py').write_text(s)
(task/'test-support.json').write_text(json.dumps({'producer':json.loads((task/'source.json').read_text())['producer'],'files':files,'data_link':'new installed topomt/data'},indent=2)+'\n')
