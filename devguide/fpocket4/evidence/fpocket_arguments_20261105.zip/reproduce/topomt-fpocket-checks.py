"""Run the final bounded fpocket contract gates without modifying shared installs."""
import json,os,subprocess,sys
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8'); task=base/'fpocket-arguments'; root=Path('/home/liliana/repos@uibcdf/topomt')
mode=sys.argv[1]
env=os.environ.copy()
for name in ['PYTHONPATH','PYTHONHOME','PYTHONSAFEPATH','LD_LIBRARY_PATH']: env.pop(name,None)
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',TMPDIR=str(base/'clean/scratch'),XDG_CACHE_HOME=str(task/'cache'),TOPOMT_SUITE_ROOT=str(base/'sources/molsyssuite'))
if mode=='source-final':
 env.update(PYTHONPATH=str(root),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',TOPOMT_FPOCKET_CMD='/tmp/topomt-pocket-pilot-101.7bZOKK/fpocket/bin/fpocket',TOPOMT_PREPARED_RECEPTOR=str(base/'clean/harness/prepared.h5msm'))
 env['PATH']='/tmp/topomt-pocket-pilot-101.7bZOKK/fpocket/bin'+os.pathsep+env['PATH']
 tests=['tests/methods/fpocket4/test_argument_contracts.py','tests/test_provider_dispatch_arguments.py','tests/test_topography_input_context.py','tests/test_topography_input_binding.py','tests/test_dfnd_input_context.py','tests/test_topography_registry.py','tests/test_provider_pocket_outputs.py','tests/methods/fpocket4/test_provider_fpocket.py','tests/methods/fpocket4/test_input_preparation.py','tests/methods/fpocket4/test_submission_mapping.py','tests/methods/fpocket4/test_chemical_context.py','tests/methods/fpocket4/test_handoff_pilot.py','tests/methods/fpocket4/test_pharmacophore_handoff.py','tests/test_third_party_dependencies.py','tests/test_dependency_contract.py','tests/test_reporting_protocol.py','tests/test_devguide_contract_terms.py']
 command=[str(base/'clean-env/bin/python'),'-m','pytest','--noconftest','-p','pytest_receptor.plugin','--receptor=llm','--basetemp='+str(task/'source-final-tests'),'--junitxml='+str(task/'source-final.xml'),*tests,'-k','not installed_engine and not provider_tests_do_not_require_optional_engines']
elif mode=='types':
 env['PYTHONPATH']=str(base/'dispatch/type-tools-ready')
 command=[sys.executable,'-m','mypy','--follow-imports=skip','--ignore-missing-imports','--check-untyped-defs','--cache-dir='+str(base/'dispatch/mypy-cache'),'topomt/_private/arg_digestion/fpocket_arguments.py','topomt/_private/arg_digestion/domain/fpocket.py','topomt/_private/arg_digestion/function/fpocket.py','topomt/third_party/fpocket/api.py','topomt/third_party/fpocket/cli.py','topomt/third_party/fpocket/files.py']
elif mode=='distribution':
 command=[sys.executable,'-m','pytest','--noconftest','--receptor=llm','devtools/tests/test_distribution_contract.py','tests/test_reporting_protocol.py']
elif mode=='docs':
 env['PYTHONPATH']='/tmp/topomt-pocket-pilot-101.7bZOKK/docs-tooling'
 command=['make','-C','docs','html','BUILDDIR='+str(base/'dispatch/docs-build')]
else: raise SystemExit('Unknown task gate')
(task/(mode+'-command.json')).write_text(json.dumps(command,indent=2)+'\n')
with (task/(mode+'.log')).open('w') as log: result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=log)
print(mode,'exit',result.returncode)
print('\n'.join((task/(mode+'.log')).read_text().splitlines()[-12:]))
raise SystemExit(result.returncode)
