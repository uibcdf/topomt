"""Retain exact original-fpocket argument-contract receiving evidence."""
import hashlib,json,shutil,zipfile
from pathlib import Path
base=Path('/dev/shm/topomt-installed-101.bch3yxd8'); task=base/'fpocket-arguments'; repo=Path('/home/liliana/repos@uibcdf/topomt')
d=json.loads((task/'installed-receipt.json').read_text()); wheel=json.loads((task/'wheel.json').read_text()); source=json.loads((task/'source.json').read_text())
assert d['passed']==len(d['tests'])==115 and d['skipped']==d['failed']==d['pytest_exit_code']==0
assert d['all_files_before']==d['all_files_after'] and len(d['all_files_after'])==138
assert (task/'pip-check.log').read_text().strip()=='No broken requirements found.'
assert hashlib.sha256((task/'wheels'/wheel['filename']).read_bytes()).hexdigest()==wheel['sha256']
assert hashlib.sha256((repo/'topomt/_version.py').read_bytes()).hexdigest()=='91af00335ecf06be1573c95e22dbba13bfaa0a9e472ffa3de802cee87dc38baf'
summary={'producer':source['producer'],'source_tests':{'passed':242,'deselected':5,'skipped':0,'seconds':95.97},'argument_cases':50,'earlier_dispatch_cases':33,'science_cases':32,'distribution_and_reporting':{'passed':20},'mypy':{'version':'2.3.1','files':6,'imported_bodies':'skipped','result':'success'},'ruff':{'files':426,'lint':'success','format':'success'},'docs':{'result':'success','warnings':8,'edited_user_page_diagnostic':False},'installed':{'passed':115,'failed':0,'skipped':0,'seconds':38.14,'distributions':138,'record_hashes_before_and_after':sum(r['record_hashes_checked'] for r in d['all_files_after'])},'pip_check':'No broken requirements found.','required_resources':617,'artifact_retention':str(task/'wheels'),'scope':'Original fpocket get_output, CLI and files-loader argument boundaries. Molecular/source-dependent agreement remains with its owner; native gateways and parsed-result assembly are separate.'}
(task/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
entries={}
for name in ['source.json','wheel.json','effective-wheels.json','resources.json','test-support.json','installed-receipt.json','summary.json','source-final-command.json','types-command.json','distribution-command.json','docs-command.json']:
 entries['control/'+name]=task/name
for name in ['source-tests.log','source-final.log','source-final.xml','types.log','distribution.log','docs.log','build.log','install.log','installed-tests.log','installed-tests.xml','pip-check.log']:
 entries['logs/'+name]=task/name
for name in ['checks','build','harness','run','evidence']:
 entries['reproduce/topomt-fpocket-'+name+'.py']=Path('/tmp')/('topomt-fpocket-'+name+'.py')
entries['reproduce/topomt-dispatch-run.py']=Path('/tmp/topomt-dispatch-run.py')
for name in json.loads((task/'test-support.json').read_text())['files']:
 entries['support/'+name]=task/'harness'/name
for name in ['pyproject.toml','devtools/conda-build/resources.toml','docs/content/user/third_party_engines.md']:
 entries['declarations/'+name]=task/'source'/name
outputs=task/'installed-tests'
for sub in ['test_real_fpocket_handoff_pres0/handoff','prepared_handoff0/original','test_original_pocket_builds_pe0/consumer','test_original_pocket_builds_pe1/consumer']:
 for p in (outputs/sub).glob('*'):
  if p.is_file(): entries['scientific/'+sub+'/'+p.name]=p
for name in ['original.zip','source.h5msm']: entries['scientific/reference-index-1/'+name]=outputs/'test_real_engine_run_retains_n0'/name
manifest={name:{'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for name,p in entries.items()}
archive=task/'fpocket_arguments_20261105.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(entries.items()): z.write(p,name)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(manifest)|{'manifest.json'}
 for name,row in manifest.items(): assert hashlib.sha256(z.read(name)).hexdigest()==row['sha256']
side={'schema':'topomt.fpocket-argument-evidence@1','archive':archive.name,'size':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(entries)+1,'producer':source['producer'],'wheel':wheel,'validation':summary,'scope_limits':'Bounded Linux x86_64/Python 3.14 installed receiving with existing interpreter/OS; not full hosted/Conda/public qualification.'}
(task/'fpocket_arguments_20261105.json').write_text(json.dumps(side,indent=2)+'\n')
for name in ['fpocket_arguments_20261105.zip','fpocket_arguments_20261105.json']: shutil.copyfile(task/name,repo/'devguide/fpocket4/evidence'/name)
print('retained',side['size'],side['sha256'],side['members'])
