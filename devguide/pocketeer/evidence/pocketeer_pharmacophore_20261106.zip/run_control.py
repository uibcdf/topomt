import hashlib
import importlib.metadata as metadata
import json
from pathlib import Path
import sys

import molsysmt as msm
import numpy as np
from devtools.qualify_pocketeer_handoff import qualify
from devtools.qualify_pharmacophore_handoff import consume, _same_sites
from topomt import pyunitwizard as puw
from topomt.provider_output import ProviderRun

root=Path('/dev/shm/topomt-pocketeer-consumer-101/standalone')
assert not root.exists()
root.mkdir()
seed=Path('/dev/shm/topomt-installed-101.bch3yxd8/clean/harness/prepared.h5msm')
assert hashlib.sha256(seed.read_bytes()).hexdigest()=='a42ef9868578ba16c62d52a1267d24160b973dca0d50dbc804ca46b6b2fe316a'
assert metadata.version('pocketeer')=='0.4.0'
assert 'pharmacophoremt' not in sys.modules
rows=[]
models=[]
runs=[]
for tag,policy in [('pm_fs',['pm','fs','radians']),('nm_ps',['nm','ps','radians'])]:
    folder=root/tag
    with puw.context(standard_units=policy):
        before=puw.configure.get_standard_units()
        handoff=qualify(seed,folder/'handoff')
        consumer=consume(folder/'handoff',folder/'consumer',pocket_id='pocketeer:0',
            projection_direction=(1.,0.,0.),distance='0.30 nm',radius='0.15 nm')
        assert puw.configure.get_standard_units()==before
        from pharmacophoremt.io import load_json
        model=load_json(folder/'consumer/query.json')
        models.append(model)
        runs.append(ProviderRun.load(folder/'handoff/original.zip'))
        rows.append({'policy':policy,'handoff':handoff,'consumer':consumer,
            'active_policy_preserved':True})
        print(json.dumps({'policy':policy,'pockets':handoff['pocket_count'],
            'sites':consumer['site_count'],'checks':consumer['checks']}),flush=True)
assert _same_sites(models[0],models[1])
for name in ('output/pocketeer_pockets.json','output/topomt_masks.json'):
    assert runs[0].get_artifact(name)==runs[1].get_artifact(name),name
first=msm.convert(root/'pm_fs/handoff/source.h5msm',to_form='molsysmt.MolSys')
second=msm.convert(root/'nm_ps/handoff/source.h5msm',to_form='molsysmt.MolSys')
np.testing.assert_allclose(
    puw.get_value(msm.get(first,coordinates=True),to_unit='nm'),
    puw.get_value(msm.get(second,coordinates=True),to_unit='nm'),rtol=0,atol=1e-12)
result={'schema_version':1,'profile':'original-pocketeer-prepared-source-consumer-1',
    'python':sys.version,'seed_sha256':hashlib.sha256(seed.read_bytes()).hexdigest(),
    'package_versions':{name:metadata.version(name) for name in ('topomt','molsysmt','pharmacophoremt','argdigest','pyunitwizard','depdigest','smonitor','pocketeer','biotite','pytest-receptor')},
    'rows':rows,'checks':{'both_full_flows_passed':True,'original_json_and_masks_equal':True,
        'physical_sites_agree':True,'source_frames_physically_agree':True,'application_policy_preserved':True},
    'limits':['Source control; not new installed candidate qualification.',
        'Declared hydrophobic projection, not a binding-site or affinity validation.']}
(root/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS: independent full flows, preserved application policy and physical sites.',flush=True)
