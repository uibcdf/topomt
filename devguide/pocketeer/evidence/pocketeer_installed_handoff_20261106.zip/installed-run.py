"""Execute the bounded installed fpocket receiving control outside all checkouts."""
import base64
import hashlib
import importlib
import importlib.metadata as metadata
import json
import os
import sys
from pathlib import Path

import pytest

BASE = Path('/dev/shm/topomt-installed-101.bch3yxd8')
PREFIX = Path('/dev/shm/topomt-current-installed-101/env')
TASK = Path('/dev/shm/topomt-current-installed-101')
ROOTS = ('topomt', 'molsysviewer_topomt', 'molsysmt', 'molsysviewer_molsysmt',
         'pharmacophoremt', 'molsysviewer_pharmacophoremt', 'pyunitwizard',
         'molsysviewer', 'smonitor', 'argdigest', 'depdigest', 'pytest_receptor', 'pocketeer', 'biotite', 'atomview', 'biotraj')
sys.path.insert(0, str(TASK / 'harness'))
sys.path.insert(0, str(BASE / 'sources/installed-sdk/devtools/scripts'))
from installed_imports import check_installed_imports

os.chdir(TASK / 'harness')
for name in ('topomt', 'molsysmt', 'molsysmt._rust', 'pharmacophoremt',
             'pyunitwizard', 'molsysviewer', 'smonitor', 'argdigest', 'depdigest', 'pocketeer'):
    importlib.import_module(name)


def check_biotite_origins():
    from importlib.machinery import ExtensionFileLoader
    allowed = {
        'biotite.rust.sequence', 'biotite.rust.sequence.align',
        'biotite.rust.sequence.phylo', 'biotite.rust.structure',
        'biotite.rust.structure.io', 'biotite.rust.structure.io.pdb',
        'biotite.rust.structure.io.pdbx',
    }
    root = sys.modules['biotite']
    native = sys.modules['biotite.rust']
    assert isinstance(native.__spec__.loader, ExtensionFileLoader)
    for module in (root, native):
        origin = Path(module.__file__).resolve()
        assert origin.is_relative_to(PREFIX)
        assert Path(module.__spec__.origin).resolve() == origin
    subroots = tuple(sorted({'.'.join(name.split('.')[:2]) for name in sys.modules
                             if name.startswith('biotite.') and not name.startswith('biotite.rust')}))
    regular = check_installed_imports(subroots, PREFIX, BASE / 'sources')
    found = {}
    for name, module in tuple(sys.modules.items()):
        if not name.startswith('biotite.rust.') or getattr(module, '__file__', None):
            continue
        assert name in allowed, name
        assert getattr(module, '__spec__', None) is None
        parent_name, _, attribute = name.rpartition('.')
        assert getattr(sys.modules[parent_name], attribute) is module
        found[name] = {'parent': parent_name, 'attribute': attribute,
                       'parent_binding_verified': True, 'extension': native.__file__}
    assert set(found) == allowed
    return {'regular_subtrees': regular, 'root': root.__file__,
            'native_extension': native.__file__, 'generated_modules': found,
            'scope': 'Seven enumerated Biotite 2.0 PyO3 modules; parent object bindings to the installed ExtensionFileLoader module; extension bytes remain covered by before/after RECORD checks.'}


def check_origins():
    receipt = check_installed_imports(tuple(r for r in ROOTS if r not in {'pyunitwizard', 'biotite'}), PREFIX, BASE / 'sources')
    # The unchanged shared checker requires files even for generated aliases.
    # Keep its strict check for every other suite root; inspect this one known
    # provider alias without deleting or rewriting any imported module.
    unit_origins = {}
    for name, module in tuple(sys.modules.items()):
        if name != 'pyunitwizard' and not name.startswith('pyunitwizard.'):
            continue
        locations = ([module.__file__] if getattr(module, '__file__', None) else [])
        locations += list(getattr(module, '__path__', ()))
        if not locations:
            assert name == 'pyunitwizard.main', name
            assert set(k for k, v in vars(module).items() if hasattr(v, '__code__')) == {'__getattr__', '__dir__'}
            locations = [vars(module)[k].__code__.co_filename for k in ('__getattr__', '__dir__')]
            assert all(Path(p).resolve() == PREFIX / 'lib/python3.14/site-packages/pyunitwizard/__init__.py' for p in locations)
        assert all(Path(p).resolve().is_relative_to(PREFIX) for p in locations), (name, locations)
        unit_origins[name] = locations
    receipt['pyunitwizard_origins'] = unit_origins
    receipt['biotite_origins'] = check_biotite_origins()
    assert not any(Path(p).resolve().is_relative_to(TASK / 'source') for p in sys.path if p)
    receipt['all_runtime_origins'] = check_all_runtime_origins()
    receipt['shared_checker_limit'] = 'The fileless pyunitwizard.main compatibility alias is checked by its two installed generator code origins, separately from the unchanged shared checker.'
    assert not any(name.startswith('__editable__') for name in sys.modules)
    assert not any(Path(p).resolve().is_relative_to(BASE / 'sources')
                   for p in sys.path if p and 'installed-sdk/devtools/scripts' not in p)
    return receipt


def check_files():
    receipts = []
    for wheel in json.loads((TASK / 'effective-wheels.json').read_text()):
        dist = metadata.distribution(wheel['name'])
        assert Path(dist._path).resolve().is_relative_to(PREFIX)
        assert json.loads(dist.read_text('direct_url.json'))['archive_info']['hashes']['sha256'] == wheel['sha256']
        checked = 0
        for file in dist.files:
            if file.hash is None:
                continue
            path = Path(dist.locate_file(file)).resolve()
            assert path.is_relative_to(PREFIX), (wheel['name'], path)
            actual = base64.urlsafe_b64encode(hashlib.new(file.hash.mode, path.read_bytes()).digest()).rstrip(b'=').decode()
            assert actual == file.hash.value, (wheel['name'], str(file))
            checked += 1
        receipts.append({'name': wheel['name'], 'version': dist.version,
                         'requires_python': dist.metadata['Requires-Python'],
                         'record_hashes_checked': checked})
    return receipts


class Outcomes:
    def __init__(self):
        self.reports = []

    def pytest_runtest_logreport(self, report):
        if report.when == 'call' or report.failed or report.skipped:
            self.reports.append({'nodeid': report.nodeid, 'when': report.when,
                                 'outcome': report.outcome})


def check_all_runtime_origins():
    stdlib = Path(sys.base_prefix) / 'lib/python3.14'
    allowed_support = (TASK / 'harness', BASE / 'sources/installed-sdk/devtools/scripts')
    checked = {}
    for name, module in tuple(sys.modules.items()):
        filename = getattr(module, '__file__', None)
        locations = ([filename] if filename else []) + list(getattr(module, '__path__', ()))
        for text in locations:
            path = Path(text).resolve()
            allowed = (path.is_relative_to(PREFIX) or
                       (path.is_relative_to(stdlib) and 'site-packages' not in path.parts) or
                       any(path.is_relative_to(root) for root in allowed_support) or
                       path == Path(__file__).resolve())
            assert allowed, (name, text)
        if locations:
            checked[name] = locations
    assert not any('site-packages' in p and not Path(p).resolve().is_relative_to(PREFIX) for p in sys.path)
    return checked


def check_all_distribution_files():
    checked = []
    for dist in sorted(metadata.distributions(), key=lambda d: d.metadata['Name'].lower()):
        assert Path(dist._path).resolve().is_relative_to(PREFIX)
        count = 0
        for file in dist.files or ():
            if file.hash is None:
                continue
            path = Path(dist.locate_file(file)).resolve()
            assert path.is_relative_to(PREFIX), (dist.metadata['Name'], str(file))
            actual = base64.urlsafe_b64encode(hashlib.new(file.hash.mode, path.read_bytes()).digest()).rstrip(b'=').decode()
            assert actual == file.hash.value, (dist.metadata['Name'], str(file))
            count += 1
        checked.append({'name': dist.metadata['Name'], 'version': dist.version,
                        'record_hashes_checked': count})
    expected = {row['name']: row for row in json.loads((TASK / 'inputs.json').read_text())}
    import re
    actual = {re.sub(r'[-_.]+', '-', row['name']).lower(): row for row in checked}
    assert set(actual) == set(expected) and len(checked) == 161
    for name, row in expected.items():
        assert actual[name]['version'] == row['version'], name
        dist = metadata.distribution(name)
        direct = json.loads(dist.read_text('direct_url.json'))
        assert direct['archive_info']['hashes']['sha256'] == row['sha256'], name
        assert direct['url'] == row['url'], (name, direct['url'], row['url'])
    return checked



receipt = {'profile': 'prepared-fpocket-pocketeer-installed-handoff-1',
           'producer': json.loads((TASK/'build.json').read_text())['producer'],
           'wheel': json.loads((TASK/'build.json').read_text())['wheel'],
           'origins_before': check_origins(), 'files_before': check_files(),
           'python': sys.version, 'prefix': sys.prefix,
           'all_files_before': check_all_distribution_files()}
assert sys.prefix == str(PREFIX)
assert metadata.version('pytest-receptor')=='1.2.0'
assert metadata.version('pocketeer')=='0.4.0'
assert sys.flags.no_user_site
assert 'include-system-site-packages = false' in (PREFIX/'pyvenv.cfg').read_text()
expected = json.loads((TASK/'collected.json').read_text())
outcomes=Outcomes()
code=pytest.main(['--noconftest','-p','pytest_receptor.plugin','--receptor=llm',
 '--receptor-events',str(TASK/'installed-events.jsonl'),'--junitxml',str(TASK/'installed-tests.xml'),
 '--basetemp',str(TASK/'installed-tests'),*json.loads((TASK/'selectors.json').read_text())],plugins=[outcomes])
receipt.update(pytest_exit_code=int(code),tests=outcomes.reports,
 origins_after=check_origins(),files_after=check_files(),
 all_files_after=check_all_distribution_files())
assert receipt['files_before']==receipt['files_after']
assert receipt['all_files_before']==receipt['all_files_after']
for outcome in ('passed','skipped','failed'):
 receipt[outcome]=sum(row['outcome']==outcome for row in outcomes.reports)
receipt['expected_test_count']=len(expected)
receipt['limits']=[
 'Independent packages reuse interpreter/OS; Linux x86_64/Python 3.14 only; hosted/public and full-suite/matrix qualification remain separate.',
 'Prepared ERalpha fragment, structural 2pk4 and raw 3PTB controls; hydrophobic consumer recipe only, no biological/affinity or full recognition admission.',
 'The unchanged SDK checker does not accept known fileless generated modules; explicit installed generator origins verify PyUnitWizard alias and seven Biotite PyO3 parent bindings. No module was rewritten or deleted.',
 'Initial incompatible host build and failed clean metadata attempts remain retained; accepted wheel uses declared-compatible versioningit 2.3.0 and generated-version-only dirty state under #78.'
]
(TASK/'installed-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert code==0 and receipt['passed']==len(expected) and not receipt['skipped'] and not receipt['failed']
assert sorted(row['nodeid'] for row in outcomes.reports)==sorted(expected)
print('INSTALLED_RECEIVING_PASS',receipt['passed'],'zero skips; all wheel inputs/RECORD/origins verified before/after')
