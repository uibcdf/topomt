import hashlib,importlib.metadata as m,json,re,subprocess
from pathlib import Path
from urllib.parse import unquote,urlparse
T=Path('/dev/shm/topomt-current-installed-101'); B=Path('/dev/shm/topomt-installed-101.bch3yxd8'); P=Path('/dev/shm/topomt-pocketeer-101')
def norm(n):return re.sub(r'[-_.]+','-',n).lower()
reports={}
for root in (B,P):
 for f in root.rglob('*.json'):
  if not any(k in f.name for k in ('install','resolution','plan','beartype')) or 'site-packages' in f.parts or '.git' in f.parts:continue
  try:data=json.loads(f.read_text())
  except (ValueError,UnicodeError,OSError):continue
  if not isinstance(data,dict):continue
  for row in data.get('install',[]):
   if 'download_info' in row and 'metadata' in row:
    key=(norm(row['metadata']['name']),row['metadata']['version'])
    if key not in reports or urlparse(row['download_info']['url']).path.endswith('.whl'):
     reports[key]=(row['download_info'],str(f))
rows=[]
for d in m.distributions(path=[str(B/'clean-env/lib/python3.14/site-packages')]):
 name=norm(d.metadata['Name']);v=d.version;direct=d.read_text('direct_url.json')
 if direct: info=json.loads(direct);origin=str(d._path/'direct_url.json')
 else: info,origin=reports[(name,v)]
 digest=info['archive_info']['hashes']['sha256'];url=info['url']
 if not urlparse(url).path.endswith('.whl'):
  source_input={'url':url,'sha256':digest}
  native={r['filename'].split('-')[0]:r for r in json.loads((B/'clean/external-built-wheels.json').read_text())}
  native['biotraj']={'retained':'/home/liliana/.cache/pip/wheels/6c/0d/61/9f76c77cfe77e4c65671c9373739bace0ca3daed6000a808ab/biotraj-1.2.2-cp314-cp314-linux_x86_64.whl','sha256':'4d200a6afb0bb2208b8a07f4830f6b06e245d2c28c61d3e5cb44165b802a4b1e'}
  assert name in native,(name,url)
  wheel=Path(native[name]['retained']);digest=hashlib.sha256(wheel.read_bytes()).hexdigest()
  assert digest==native[name]['sha256']
  url=wheel.as_uri()
  (T/(name+'-input.json')).write_text(json.dumps({'source':source_input,'wheel':url,'sha256':digest},indent=2)+'\n')
 if url.startswith('file:'):
  p=Path(unquote(urlparse(url).path));assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,(name,p)
 rows.append({'name':name,'version':v,'url':url,'sha256':digest,'input_evidence':origin})
assert len(rows)==161
(T/'previous-inputs.json').write_text(json.dumps(sorted(rows,key=lambda r:r['name']),indent=2)+'\n')
print('Recovered all',len(rows),'exact wheel inputs; build completion still required before replacing TopoMT and reporter')
