import hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/home/liliana/repos@uibcdf/topomt')
TASK=Path('/dev/shm/topomt-current-installed-101')
HOST=Path('/home/liliana/Myopt/miniconda3/envs/molsyssuite@uibcdf_3.14/bin/python')
SDK=Path('/dev/shm/topomt-installed-101.bch3yxd8/sources/molsyssuite')
TASK.mkdir(exist_ok=False)
for d in ('scratch','wheels','harness','cache'): (TASK/d).mkdir()
def run(cmd,name,cwd=None,env=None):
 (TASK/(name+'-command.json')).write_text(json.dumps([str(x) for x in cmd],indent=2)+'\n')
 with (TASK/(name+'.log')).open('w') as out:
  p=subprocess.run(cmd,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT)
 print(name,p.returncode,flush=True)
 return p.returncode
producer=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
version_sha=hashlib.sha256((ROOT/'topomt/_version.py').read_bytes()).hexdigest()
assert version_sha=='91af00335ecf06be1573c95e22dbba13bfaa0a9e472ffa3de802cee87dc38baf'
assert run(['git','clone','--no-hardlinks',str(ROOT),str(TASK/'source')],'clone')==0
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=TASK/'source',text=True).strip()==producer
env=os.environ.copy();env.update(TMPDIR=str(TASK/'scratch'),PYTHONDONTWRITEBYTECODE='1',TOPOMT_SUITE_ROOT=str(SDK),PIP_CACHE_DIR=str(TASK/'cache'))
env.pop('PYTHONPATH',None)
assert run([HOST,'devtools/check_dependency_routes.py','--declared-only'],'preflight',TASK/'source',env)==0
states=[]
for attempt in (1,2):
 before=subprocess.check_output(['git','status','--porcelain'],cwd=TASK/'source',text=True).splitlines()
 code=run([HOST,'-m','pip','wheel','--no-deps','--no-build-isolation','--wheel-dir',TASK/'wheels',TASK/'source'],f'build-{attempt}',TASK,env)
 after=subprocess.check_output(['git','status','--porcelain'],cwd=TASK/'source',text=True).splitlines()
 states.append({'attempt':attempt,'before':before,'after':after,'exit_code':code})
 if code==0:break
 assert attempt==1 and after==[' M topomt/_version.py'],after
assert code==0
wheels=list((TASK/'wheels').glob('topomt-*.whl'));assert len(wheels)==1
w=wheels[0]
receipt={'producer':producer,'runtime_tree':subprocess.check_output(['git','rev-parse','HEAD:topomt'],cwd=TASK/'source',text=True).strip(),'attempts':states,'human_version_sha256':version_sha,'wheel':{'name':'topomt','filename':w.name,'size':w.stat().st_size,'sha256':hashlib.sha256(w.read_bytes()).hexdigest(),'producer':producer}}
(TASK/'build.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert hashlib.sha256((ROOT/'topomt/_version.py').read_bytes()).hexdigest()==version_sha
print(json.dumps(receipt),flush=True)
