from pathlib import Path
import json
T=Path('/dev/shm/topomt-current-installed-101')
script=Path('/dev/shm/topomt-pocketeer-101/installed-run.py').read_text()
script=script.replace("PREFIX = BASE / 'clean-env'","PREFIX = Path('/dev/shm/topomt-current-installed-101/env')")
script=script.replace("TASK = Path('/dev/shm/topomt-pocketeer-101')","TASK = Path('/dev/shm/topomt-current-installed-101')")
script=script.replace("'atomview')","'atomview', 'biotraj')")
start=script.index("receipt = {'profile':")
functions=script[:start]
selectors=[n for n in json.loads((T/'test-support.json').read_text())['files'] if n.startswith('tests/') and Path(n).name.startswith('test_')]
(T/'selectors.json').write_text(json.dumps(selectors,indent=2)+'\n')
collection="""\nclass Collected:
    def pytest_collection_finish(self, session):
        (TASK / 'collected.json').write_text(json.dumps([item.nodeid for item in session.items],indent=2)+'\\n')
code=pytest.main(['--noconftest','-p','pytest_receptor.plugin','--receptor=llm','--collect-only',*json.loads((TASK/'selectors.json').read_text())],plugins=[Collected()])
assert code==0
print('COLLECTED',len(json.loads((TASK/'collected.json').read_text())))
"""
(T/'collect.py').write_text(functions+collection)
old="""    assert len(checked) == 161
    return checked
"""
new="""    expected = {row['name']: row for row in json.loads((TASK / 'inputs.json').read_text())}
    import re
    actual = {re.sub(r'[-_.]+', '-', row['name']).lower(): row for row in checked}
    assert set(actual) == set(expected) and len(checked) == 161
    for name, row in expected.items():
        assert actual[name]['version'] == row['version'], name
        dist = metadata.distribution(name)
        direct = json.loads(dist.read_text('direct_url.json'))
        assert direct['archive_info']['hashes']['sha256'] == row['sha256'], name
        assert direct['url'] == row['url'], (name, direct['url'], row['url'])
    return checked
"""
assert old in functions;functions=functions.replace(old,new)
body="""
receipt = {'profile': 'prepared-fpocket-pocketeer-installed-handoff-1',
           'producer': json.loads((TASK/'build.json').read_text())['producer'],
           'wheel': json.loads((TASK/'build.json').read_text())['wheel'],
           'origins_before': check_origins(), 'files_before': check_files(),
           'python': sys.version, 'prefix': sys.prefix,
           'all_files_before': check_all_distribution_files()}
assert sys.prefix == str(PREFIX)
assert metadata.version('pytest-receptor')=='1.2.0'
assert metadata.version('pocketeer')=='0.4.0'
assert sys.flags.no_user_site
assert 'include-system-site-packages = false' in (PREFIX/'pyvenv.cfg').read_text()
expected = json.loads((TASK/'collected.json').read_text())
outcomes=Outcomes()
code=pytest.main(['--noconftest','-p','pytest_receptor.plugin','--receptor=llm',
 '--receptor-events',str(TASK/'installed-events.jsonl'),'--junitxml',str(TASK/'installed-tests.xml'),
 '--basetemp',str(TASK/'installed-tests'),*json.loads((TASK/'selectors.json').read_text())],plugins=[outcomes])
receipt.update(pytest_exit_code=int(code),tests=outcomes.reports,
 origins_after=check_origins(),files_after=check_files(),
 all_files_after=check_all_distribution_files())
assert receipt['files_before']==receipt['files_after']
assert receipt['all_files_before']==receipt['all_files_after']
for outcome in ('passed','skipped','failed'):
 receipt[outcome]=sum(row['outcome']==outcome for row in outcomes.reports)
receipt['expected_test_count']=len(expected)
receipt['limits']=[
 'Independent packages reuse interpreter/OS; Linux x86_64/Python 3.14 only; hosted/public and full-suite/matrix qualification remain separate.',
 'Prepared ERalpha fragment, structural 2pk4 and raw 3PTB controls; hydrophobic consumer recipe only, no biological/affinity or full recognition admission.',
 'The unchanged SDK checker does not accept known fileless generated modules; explicit installed generator origins verify PyUnitWizard alias and seven Biotite PyO3 parent bindings. No module was rewritten or deleted.',
 'Initial incompatible host build and failed clean metadata attempts remain retained; accepted wheel uses declared-compatible versioningit 2.3.0 and generated-version-only dirty state under #78.'
]
(TASK/'installed-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n')
assert code==0 and receipt['passed']==len(expected) and not receipt['skipped'] and not receipt['failed']
assert sorted(row['nodeid'] for row in outcomes.reports)==sorted(expected)
print('INSTALLED_RECEIVING_PASS',receipt['passed'],'zero skips; all wheel inputs/RECORD/origins verified before/after')
"""
(T/'installed-run.py').write_text(functions+body)
print('Prepared',len(selectors),'selected test modules and unchanged SDK origin checker')
