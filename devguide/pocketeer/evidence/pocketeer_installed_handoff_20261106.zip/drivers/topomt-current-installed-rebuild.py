import hashlib,importlib.metadata as m,json,os,subprocess
from pathlib import Path
T=Path('/dev/shm/topomt-current-installed-101');H='/home/liliana/Myopt/miniconda3/envs/molsyssuite@uibcdf_3.14/bin/python'
env=os.environ.copy();env.update(PYTHONPATH=str(T/'build-tools'),TMPDIR=str(T/'scratch'),PIP_CACHE_DIR=str(T/'cache'),PYTHONDONTWRITEBYTECODE='1')
p=subprocess.run([H,'-c','import importlib.metadata as m; print([(n,m.version(n)) for n in ("versioningit","setuptools","wheel","packaging")])'],env=env,text=True,capture_output=True,check=True)
(T/'build-tool-versions.txt').write_text(p.stdout); print(p.stdout,flush=True)
(T/'preliminary-wheels').mkdir()
for w in (T/'wheels').glob('*.whl'):w.rename(T/'preliminary-wheels'/w.name)
subprocess.run(['git','restore','--','topomt/_version.py'],cwd=T/'source',check=True)
old=json.loads((T/'build.json').read_text());old['qualification']='Preliminary build used host versioningit 3.3.0 outside declared ~=2.0; retained but not the accepted candidate.'
(T/'preliminary-build.json').write_text(json.dumps(old,indent=2)+'\n')
states=[]
for i in (3,4):
 before=subprocess.check_output(['git','status','--porcelain'],cwd=T/'source',text=True).splitlines()
 cmd=[H,'-m','pip','wheel','--no-deps','--no-build-isolation','--wheel-dir',str(T/'wheels'),str(T/'source')]
 (T/f'build-{i}-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
 with (T/f'build-{i}.log').open('w') as f:p=subprocess.run(cmd,env=env,cwd=T,stdout=f,stderr=subprocess.STDOUT)
 after=subprocess.check_output(['git','status','--porcelain'],cwd=T/'source',text=True).splitlines()
 states.append({'attempt':i,'before':before,'after':after,'exit_code':p.returncode}); print(states[-1],flush=True)
 if p.returncode==0:break
 assert i==3 and after==[' M topomt/_version.py']
assert p.returncode==0
w,=list((T/'wheels').glob('topomt-*.whl'))
old.update(attempts=states,qualification='Accepted development candidate built using declared-compatible versioningit 2.3.0; known #78 requires the retained second generated-version-only dirty attempt.',wheel={'name':'topomt','filename':w.name,'size':w.stat().st_size,'sha256':hashlib.sha256(w.read_bytes()).hexdigest(),'producer':old['producer']})
(T/'build.json').write_text(json.dumps(old,indent=2)+'\n');print(json.dumps(old['wheel']),flush=True)
