import hashlib,json,os,subprocess
from pathlib import Path
T=Path('/dev/shm/topomt-current-installed-101');HOST='/home/liliana/Myopt/miniconda3/envs/molsyssuite@uibcdf_3.14/bin/python';PREFIX=T/'env'
rows=json.loads((T/'previous-inputs.json').read_text());build=json.loads((T/'build.json').read_text())
w=T/'wheels'/build['wheel']['filename'];receptor=Path('/dev/shm/topomt-pocketeer-recovery-101/receptor-wheels/pytest_receptor-1.2.0-py3-none-any.whl')
assert hashlib.sha256(receptor.read_bytes()).hexdigest()=='4e339abd53d85406c3acc0c643b895154b133c0a6f9d5f7a2350703f514a9971'
for row in rows:
 if row['name']=='topomt':row.update(url=w.as_uri(),sha256=build['wheel']['sha256'],version='0.5.0+355.gbb34e67.dirty',input_evidence=str(T/'build.json'))
 if row['name']=='pytest-receptor':row.update(url=receptor.as_uri(),sha256=hashlib.sha256(receptor.read_bytes()).hexdigest(),version='1.2.0',input_evidence='/dev/shm/topomt-pocketeer-recovery-101/receptor-public.json')
(T/'inputs.json').write_text(json.dumps(rows,indent=2)+'\n')
(T/'inputs.txt').write_text(''.join(f"{r['name']} @ {r['url']} --hash=sha256:{r['sha256']}\n" for r in rows))
effective=json.loads(Path('/dev/shm/topomt-pocketeer-101/effective-wheels.json').read_text())
for i,row in enumerate(effective):
 if row['name']=='topomt':effective[i]=build['wheel']
 if row['name']=='pytest-receptor':effective[i]={'name':'pytest-receptor','filename':receptor.name,'size':receptor.stat().st_size,'sha256':hashlib.sha256(receptor.read_bytes()).hexdigest(),'public_version':'1.2.0'}
(T/'effective-wheels.json').write_text(json.dumps(effective,indent=2)+'\n')
subprocess.run([HOST,'-m','venv','--without-pip',str(PREFIX)],check=True)
cmd=[HOST,'-m','pip','--python',str(PREFIX/'bin/python'),'install','--no-compile','--no-deps','--require-hashes','--report',str(T/'installation.json'),'-r',str(T/'inputs.txt')]
(T/'install-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
env=os.environ.copy();env.pop('PYTHONPATH',None);env.update(TMPDIR=str(T/'scratch'),PYTHONDONTWRITEBYTECODE='1',PIP_CACHE_DIR='/dev/shm/topomt-installed-101.bch3yxd8/clean/pip-cache')
with (T/'install.log').open('w') as f:p=subprocess.run(cmd,cwd=T,env=env,stdout=f,stderr=subprocess.STDOUT)
print('install',p.returncode,flush=True)
assert p.returncode==0
with (T/'pip-check-before.log').open('w') as f:p=subprocess.run([HOST,'-m','pip','--python',str(PREFIX/'bin/python'),'check'],cwd=T,env=env,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0
print('Fresh 161-distribution prefix installed; pip check passed',flush=True)
