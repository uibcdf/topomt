import hashlib,json,shutil,subprocess,zipfile,ast
from pathlib import Path
T=Path('/dev/shm/topomt-current-installed-101');S=T/'source';H=T/'harness';B=Path('/dev/shm/topomt-installed-101.bch3yxd8')
old=json.loads(Path('/dev/shm/topomt-pocketeer-101/test-support.json').read_text())
files=list(old['files'])+['tests/methods/pocketeer/test_chemical_context.py','tests/methods/pocketeer/test_saved_output.py','tests/methods/pocketeer/test_pharmacophore_handoff.py','tests/test_provider_handoff_tools.py','devtools/provider_handoff.py','devtools/qualify_pocketeer_handoff.py']
manifest={}
for name in files:
 src=S/name;dest=H/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest);manifest[name]=hashlib.sha256(src.read_bytes()).hexdigest()
 for p in dest.parents:
  if p==H:break
  init=p/'__init__.py'
  if not init.exists():
   original=S/p.relative_to(H)/'__init__.py'
   if original.exists():shutil.copy2(original,init);manifest[str(init.relative_to(H))]=hashlib.sha256(init.read_bytes()).hexdigest()
   else:init.write_text('');manifest[str(init.relative_to(H))]=hashlib.sha256(b'').hexdigest()
(H/'pytest.ini').write_text('[pytest]\naddopts = -q\n')
(H/'topomt').mkdir();(H/'topomt/data').symlink_to(T/'env/lib/python3.14/site-packages/topomt/data',target_is_directory=True)
seed=B/'clean/harness/prepared.h5msm';shutil.copy2(seed,H/'prepared.h5msm')
seed_sha=hashlib.sha256(seed.read_bytes()).hexdigest();assert seed_sha=='a42ef9868578ba16c62d52a1267d24160b973dca0d50dbc804ca46b6b2fe316a'
build=json.loads((T/'build.json').read_text())
(T/'test-support.json').write_text(json.dumps({'producer':build['producer'],'files':manifest,'data_link':'installed topomt/data; no source package root','prepared_seed_sha256':seed_sha},indent=2)+'\n')
w=T/'wheels'/build['wheel']['filename']
tracked=subprocess.check_output(['git','ls-files','topomt','molsysviewer_topomt'],cwd=S,text=True).splitlines()
with zipfile.ZipFile(w) as z:
 payload={n for n in z.namelist() if n.startswith(('topomt/','molsysviewer_topomt/')) and not n.endswith('/')}
 assert payload==set(tracked),(payload-set(tracked),set(tracked)-payload)
 matched=[]
 for n in tracked:
  if n!='topomt/_version.py':assert z.read(n)==(S/n).read_bytes(),n
  matched.append({'path':n,'sha256':hashlib.sha256(z.read(n)).hexdigest()})
 metadata=z.read(next(n for n in z.namelist() if n.endswith('.dist-info/METADATA'))).decode()
 v=next(l.removeprefix('Version: ') for l in metadata.splitlines() if l.startswith('Version: '))
 tree=ast.parse(z.read('topomt/_version.py'))
 embedded=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='__version__' for x in n.targets))
 assert v==embedded and w.name=='topomt-'+v+'-py3-none-any.whl'
(T/'resources.json').write_text(json.dumps({'required_count':len(tracked),'version':v,'wheel_sha256':build['wheel']['sha256'],'all_source_bytes_match_except_generated_version':True,'paths':matched},indent=2)+'\n')
print('Approved harness',len(manifest),'files;',len(tracked),'exact wheel resources; coherent version',v)
