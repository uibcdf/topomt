import hashlib,json,shutil,subprocess,zipfile
from pathlib import Path
T=Path('/dev/shm/topomt-current-installed-101');R=Path('/home/liliana/repos@uibcdf/topomt')
D=R/'devguide/pocketeer/evidence';name='pocketeer_installed_handoff_20261106'
(T/'drivers').mkdir(exist_ok=True)
for p in Path('/tmp').glob('topomt-current-installed-*.py'):shutil.copy2(p,T/'drivers'/p.name)
(T/'prefix-configuration.txt').write_text((T/'env/pyvenv.cfg').read_text())
(T/'fpocket-executable.json').write_text(json.dumps({'path':'/tmp/topomt-pocket-pilot-101.7bZOKK/fpocket/bin/fpocket','sha256':hashlib.sha256(Path('/tmp/topomt-pocket-pilot-101.7bZOKK/fpocket/bin/fpocket').read_bytes()).hexdigest(),'package_version':'4.2.3','help_label':'4.0'},indent=2)+'\n')
files={}
def add(p,n=None):
 assert p.is_file() and not p.is_symlink(),p
 name=n or str(p.relative_to(T));assert name not in files,name;files[name]=p
for p in T.iterdir():
 if p.is_file() and p.suffix in {'.json','.jsonl','.xml','.log','.txt','.py'}:add(p)
for folder in ('drivers','harness','standalone'):
 for p in (T/folder).rglob('*'):
  if p.is_file() and not p.is_symlink():add(p)
for folder in ('prepared_handoff0/original','test_original_pocket_builds_pe0/consumer','test_original_pocket_builds_pe1/consumer'):
 for p in (T/'installed-tests'/folder).rglob('*'):
  if p.is_file() and not p.is_symlink():add(p)
for p in [Path('/dev/shm/topomt-pocketeer-recovery-101/receptor-wheels/pytest_receptor-1.2.0-py3-none-any.whl'),Path('/dev/shm/topomt-pocketeer-101/wheels/pocketeer-0.4.0-py3-none-any.whl'),Path('/home/liliana/.cache/pip/wheels/6c/0d/61/9f76c77cfe77e4c65671c9373739bace0ca3daed6000a808ab/biotraj-1.2.2-cp314-cp314-linux_x86_64.whl')]:add(p,'dependency-wheels/'+p.name)
manifest={n:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for n,p in sorted(files.items())}
archive=T/(name+'.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(manifest)+1
 for n,row in manifest.items():
  b=z.read(n);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],n
build=json.loads((T/'build.json').read_text());tests=json.loads((T/'installed-receipt.json').read_text());standalone=json.loads((T/'standalone/receipt.json').read_text())
summary={'date':'2026-11-06','owner':'uibcdf/topomt#101','producer':build['producer'],'wheel':build['wheel'],'archive':{'name':archive.name,'bytes':archive.stat().st_size,'members':len(manifest)+1,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'tests':{'passed':tests['passed'],'skipped':tests['skipped'],'failed':tests['failed'],'duration_seconds':101.57408150099218,'public_pytest_receptor':'1.2.0'},'integrity':{'distributions':len(tests['all_files_before']),'record_hashes_before_and_after':sum(r['record_hashes_checked'] for r in tests['all_files_before']),'loaded_file_backed_modules_before':len(tests['origins_before']['all_runtime_origins']),'loaded_file_backed_modules_after':len(tests['origins_after']['all_runtime_origins']),'runtime_resources':625,'pip_check_before':'passed','pip_check_after':'passed','all_inputs_frozen_with_hashes':True,'system_user_site_packages_disabled':True,'unchanged_sdk_origin_checker':'b9852d973e96613a68cab7278491ff647bfd0b7d','dependency_sdk':'8f00e6d9de943b6e4710ea62936e2ebea00fad24'},'preserved_human_version_sha256':build['human_version_sha256'],'prepared_profiles':[{'policy':r['policy'],'pocket_count':r['handoff']['pocket_count'],'pocket_ids':r['handoff']['pocket_ids'],'selected_pocket':r['consumer']['context']['pocket_id'],'site_count':r['consumer']['site_count'],'member_atoms':len(r['consumer']['pocket_atom_indices']),'run_id':r['handoff']['run_id'],'source_sha256':r['handoff']['source_sha256'],'checks':r['consumer']['checks']} for r in standalone['rows']],'independent_control_checks':standalone['checks'],'build':{'versioningit':'2.3.0','setuptools':'84.0.0','wheel':'0.48.0','clean_metadata_failure_retained':True,'preliminary_host_tool_mismatch_retained':True,'accepted_state':'Only the generated version file differs from exact producer; known #78 development build, no release claim.'},'limits':tests['limits']+['Retained dependency/source snapshot, not current sibling mains or minimum-version certification.','Actual TopoMT and other suite wheels remain in temporary task storage; candidate identity and all input hashes/URLs are archived, with small public/native dependency wheels; no durable wheel-hosting or public source-free acquisition claim.','AlphaSpace2, pyCASTA and CASTp/CASTpFold handoff qualification remains outstanding.']}
(D/(name+'.json')).write_text(json.dumps(summary,indent=2)+'\n');shutil.copy2(archive,D/archive.name)
print(json.dumps(summary['archive']),flush=True)
