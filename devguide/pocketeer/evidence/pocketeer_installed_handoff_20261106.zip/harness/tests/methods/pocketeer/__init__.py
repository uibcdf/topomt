"""Pocketeer method tests."""
