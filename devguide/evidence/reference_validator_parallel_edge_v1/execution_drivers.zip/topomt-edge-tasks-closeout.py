import hashlib
import json
import re
import subprocess
import zipfile
from pathlib import Path
from urllib.parse import unquote

base = Path('devguide/evidence/reference_validator_parallel_edge_v1')


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, value):
    (base / name).write_text(json.dumps(value, indent=2) + '\n')


source = read(base / 'source.json')
assert len(source) == 51 and all(sha(p) == h for p, h in source.items())
frozen = read('docs/content/benchlab/synthetic/artifacts/six_case_review_v1/protocol.json')['frozen_files']
assert len(frozen) == 355 and all(sha(p) == h for p, h in frozen.items())
human_sha = 'd76f39e77bb54929c2d4a02f55ec04d61534ec09df776d2fe89ef731626a88b5'
assert sha('topomt/_version.py') == human_sha
execution_names = ['primary_tests', 'integration_tests', 'docs', 'package', 'controls']
executions = {n: read(base / (n + '_execution.json')) for n in execution_names}
assert all(e['exit_code'] == 0 and e['stop_reason'] is None for e in executions.values())
assert all(s['host']['safe'] for e in executions.values() for s in e['samples'])
assert '149 passed' in (base / 'primary_tests_execution.log').read_text()
assert '75 passed' in (base / 'integration_tests_execution.log').read_text()
index = read(base / 'receiving_index.json')
assert len(index['originals']) == 6 and len(index['controls']) == 50
assert all(r['all_mathematical_fields_equal_original_and_serial'] for r in index['originals'] + index['controls'])
manifest = read(base / 'capsule_manifest.json')
assert sha(base / 'receiving.zip') == manifest['archive_sha256']
with zipfile.ZipFile(base / 'receiving.zip') as saved:
    assert set(saved.namelist()) == set(manifest['members'])
    assert all(hashlib.sha256(saved.read(n)).hexdigest() == h for n, h in manifest['members'].items())
    assert saved.read('EXECUTION_CONTRACT.md') == Path('devguide/DFND/reference_validator_parallel_edge.md').read_bytes()
    assert all(hashlib.sha256(saved.read(n)).hexdigest() == h for n, h in source.items())
with zipfile.ZipFile(base / 'source.zip') as saved:
    assert set(saved.namelist()) == set(source)
    assert all(hashlib.sha256(saved.read(n)).hexdigest() == h for n, h in source.items())
html = Path('/tmp/topomt-edge-tasks-docs-html/content')
assert 'id="reference-validator-parallel-analytic"' in (html / 'benchlab/synthetic/reference_validator_report.html').read_text()
assert 'reference_validator_report.html#reference-validator-parallel-analytic' in (html / 'dfnd/validation_and_scope.html').read_text()
changed = subprocess.check_output(['git', 'diff', '--name-only'], text=True).splitlines()
markdown = [Path(p) for p in changed if p.endswith('.md')]
markdown += [Path('devguide/DFND/reference_validator_parallel_edge.md'), base / 'README.md']
local_links = 0
for path in markdown:
    for target in re.findall(r'\]\(([^)\s]+)\)', path.read_text()):
        if target.startswith(('#', 'http:', 'https:', 'mailto:', 'plugin:', 'app:')):
            continue
        target = unquote(target.split('#', 1)[0].strip('<>'))
        if target:
            assert (path.parent / target).exists(), (path, target)
            local_links += 1
drivers = sorted(Path('/tmp').glob('topomt-edge-tasks-*.py'))
assert len(drivers) == 8
with zipfile.ZipFile(base / 'execution_drivers.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as saved:
    for path in drivers:
        saved.writestr(path.name, path.read_bytes())
with zipfile.ZipFile(base / 'execution_drivers.zip') as saved:
    assert all(saved.read(p.name) == p.read_bytes() for p in drivers)
implementation = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert implementation == '799fc5e9b223768cf5d1137f8ceb6a35c433eadb'
save('source_qualification.json', {
    'schema': 'topomt.reference-validator.parallel-edge-qualification/1',
    'owner': 'uibcdf/topomt#76',
    'date': '2026-11-15',
    'base_revision': '2833f166cbcb3c54bc1402ce2760063955b27fe1',
    'implementation_revision': implementation,
    'source_files': source,
    'selected_tests': {'total': 224, 'disjoint_groups': {'primary': 149, 'integration': 75}},
    'execution_receipts': {n: {'path': n + '_execution.json', 'sha256': sha(base / (n + '_execution.json'))} for n in executions},
    'checks': {
        'ruff_check_and_format_selected_files': 738,
        'mypy_local_modules': 51,
        'report_index': 'pass',
        'comparative_findings_offline': 'pass',
        'strict_sphinx': 'pass; one CPU; notebooks not executed; local rendering only',
        'rendered_report_anchor_and_book_link': True,
        'checked_local_markdown_links': local_links,
        'fresh_extracted_parallel_checker_and_serial_reader': 'pass under python -S with producers and scientific packages blocked',
    },
    'actual_receiving': {
        'original_models': 3,
        'original_serial_two_worker_configurations': 6,
        'analytic_controls': 25,
        'control_serial_two_worker_configurations': 50,
        'all_mathematical_fields_equal_original_and_fresh_serial': True,
        'original_absolute_and_relative_total_and_region_requests_met': True,
        'fixed_bits_geometry_domain_units_and_contact_policy_unchanged': True,
        'one_observation_per_configuration_not_general_scaling': True,
        'default_serial': True,
    },
    'trust_boundary': 'Workers execute independent checker arithmetic under trusted local runtime/IPC; complete geometry/frontier first. Saved bounds are fully recomputed on recovery. No cryptographic remote proof or hardware-fault tolerance claim.',
    'partial_scope': 'No whole-domain enclosure or precision completion from partial arithmetic. Selected S7 fixed-frontier receiving, not full-plan completion.',
    'legacy_progress_size_follow_up': {'owner': 'uibcdf/topomt#76 S2/S6', 'pending': 'Older custom power writers permit 128 MiB while common reader permits 16 MiB. Selected original records fit reader bound. New S7 paired generic writer/reader both use 16 MiB; legacy mismatch not repaired.'},
    'preserved': {'original_frozen_files': frozen, 'human_version_file_sha256': human_sha},
    'deferred': {
        'uibcdf/topomt#76': 'Full parallel nineteen-profile/four-worker panel; remaining S1/S3/S5; broader S8/P6/P7; production diagnostics/units/attribution/public API. No new native promotion or operator.',
        'uibcdf/topomt#60': 'Canonical native/public receiving with #76.',
        'uibcdf/topomt#16': 'Full suite, remote CI, installed/public delivery, Python 3.11-3.13 and platform matrix; exact-candidate recovery still required. Authorized direct commits carry [skip ci].',
        'unchanged_native_issues': ['#181', '#180', '#184', '#188'],
    },
    'not_selected': 'No original external engine, new geometry or protein run, new attribution boundary, dependency, Slurm, GPU, distributed-machine execution or hosted deployment.',
    'execution_drivers': {p.name: sha(p) for p in drivers},
})
save('MANIFEST.json', {
    'schema': 'topomt.reference-validator.parallel-edge-evidence/1',
    'manifest_excludes_itself': True,
    'files': {str(p.relative_to(base)): sha(p) for p in sorted(base.rglob('*')) if p.is_file() and p.name != 'MANIFEST.json'},
})
print(json.dumps({'source_modules': len(source), 'original_files_unchanged': len(frozen), 'selected_tests': 224, 'local_links': local_links, 'driver_files': len(drivers), 'evidence_payloads': len(read(base / 'MANIFEST.json')['files'])}))
