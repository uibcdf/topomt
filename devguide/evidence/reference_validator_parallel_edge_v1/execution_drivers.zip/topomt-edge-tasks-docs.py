from pathlib import Path

def before(path,marker,body):
 p=Path(path);s=p.read_text();assert marker in s,(path,marker);p.write_text(s.replace(marker,body+'\n'+marker,1))
def replace(path,old,new):
 p=Path(path);s=p.read_text();assert old in s,(path,old);p.write_text(s.replace(old,new,1))

before('devguide/DFND/reference_validator_performance_plan.md','### Resumable source-cell receiving', '''### Certified analytic task execution — 2026-11-15

The [S7 checker route](reference_validator_parallel_edge.md) distributes the
same canonical signed face pieces to bounded exact arithmetic workers. Complete
topology/assignment precedes scheduling. Direct serial remains the default;
partial work supplies no whole-domain enclosure. Source-bound snapshots are
reconstructed geometrically and numerically on loading. The ordinary symbolic
certificate and independent serial reader remain unchanged in mathematical
meaning, with actual checker provenance retained.

The [versioned receiving](../evidence/reference_validator_parallel_edge_v1/README.md)
qualifies serial/two-worker execution of sixteen boundary and nine region
controls, plus paused/fresh-process recovered original tetrahedron, closed-shell
and dumbbell 1.4 Å profiles. Mathematical output equals the original fixed-bit
receipts and a further new serial read. Unit controls cover signed cancellation,
tiny/asymmetric regions, changed bits/requests/units, forged saved arithmetic,
missing/duplicate tasks, failure and cancellation. S7 is delivered at this fixed-
frontier scope; full parallel nineteen-profile/four-worker and broader S8 remain
open. This route does not replace remaining S1/S3/S5 work or qualify native DFND.
''')
replace('devguide/DFND/reference_validator_performance_plan.md','Earlier range prototype only; analytic-route parallel/failure/resume qualification open','Delivered: canonical analytic frontier, failure/resume controls, 25 analytic controls and three original serial/two-worker profiles; broader panel separate')
replace('devguide/DFND/reference_validator_performance_plan.md','| S7 | `region_volume.py` and saved region bundles | `test_reference_validator_region_volume.py`, `test_reference_validator_region_receiving.py`; add partition/process tests |','| S7 | `edge_tasks.py`, `verify/edge_progress.py`, `verify/edge_volume.py`, bounded pool and generic progress storage | `test_reference_validator_edge_tasks.py`, `test_reference_validator_edge_task_receiving.py`; preserve serial edge/corner and S6 controls |')
before('devguide/DFND/reference_validator_checkpoint.md','## Resumable local source work', '''## Canonical analytic checker tasks — 2026-11-15

The [S7 construction](reference_validator_parallel_edge.md) freezes the exact
signed frontier after complete independent topology/region assignment, then
executes the same certified triangle arithmetic serially or with two explicit
local workers. Every piece contributes once to the total and its checked region;
all original errors/requests remain. Saved arithmetic is untrusted and fully
recomputed on loading; incomplete work has no global volume enclosure.

The [new receiving](../evidence/reference_validator_parallel_edge_v1/README.md)
qualifies 25 analytic controls in both modes and three original 1.4 Å profiles
with pause, fresh-process recovery and a further independent serial read.
Mathematical fields equal the original serial receipts. Sources, requests,
resource/failure scopes and timing phases are retained. This is scoped S7
qualification, not the full parallel panel, four workers, broader S8/P6/P7 or a
native #181/#180/#184/#188 fix. S1/S3/S5 and canonical native #76/#60 remain open;
earlier source-bound checkpoints retain their recorded source/runtime.
''')
before('devguide/pending_proposals/dfnd_reference_validation_panel.md','## Current continuation: resumable local source work', '''## Current continuation: canonical analytic checker tasks — 2026-11-15

The [S7 route](../DFND/reference_validator_parallel_edge.md) and
[receiving](../evidence/reference_validator_parallel_edge_v1/README.md) distribute
certified arithmetic over the same complete signed frontier, after independent
geometry/region assignment. Twenty-five analytic controls and three original
1.4 Å Models pass in direct serial/two-worker modes; original mathematical
outputs and further independent serial reads agree exactly. Recovery recomputes
saved bounds, and partial arithmetic never acquires a whole-domain volume claim.

S7 is delivered at this selected fixed-frontier scope. #76 remains partial/open
for the full parallel panel/four workers, remaining performance work, canonical
native receiving #60 and broader S8/P6/P7/installed #16. Native #181/#180/#184/#188
and all frozen original scientific evidence are unchanged.
''')
before('devguide/DFND/notebook_laboratory_checkpoint.md','## Resumable reference construction', '''## Analytic integration with bounded workers — 2026-11-15 UTC

The [S7 receiving](../evidence/reference_validator_parallel_edge_v1/README.md)
compares direct serial/two-worker canonical analytic verification on 25 controls
and the original tetrahedron, closed shell and dumbbell at 1.4 Å. Paused work is
reconstructed in a fresh process; final results equal the original mathematical
receipts and a further serial read. The domain, atoms/probe, source inputs,
region assignment and requested precision are unchanged. Partial arithmetic has
no global enclosure. Full parallel-panel/four-worker and broader admission remain
open under #76; native/public #60/#181/#180/#184/#188 and installed #16 keep their
separate scopes. No new geometry/protein/provider phase is selected.
''')
before('devtools/reference_validator/README.md','The [resumable process route]', '''The [analytic task route](../../devguide/DFND/reference_validator_parallel_edge.md)
adds `edge_tasks.EdgeVerificationSession`. It admits complete geometry/regions,
freezes the original signed frontier and executes the same interval arithmetic.
Direct serial is the default; an explicit `LocalPolicy` opts into bounded local
processes. Missing/duplicate work cannot produce a total. Manifest-last snapshots
bind source/Model/request/frontier and every saved bound is recomputed on loading.
Completed mathematical output equals the ordinary serial reader; the original
symbolic certificate remains portable. This is a developer verification route,
with source/resource qualification separate from production API admission.
''')
replace('devguide/DFND/reference_validator_improvement_workplan.md','The analytic edge route has no qualified parallel backend yet.','The analytic edge checker now has selected fixed-frontier serial/two-worker qualification; the full parallel panel remains open.')
