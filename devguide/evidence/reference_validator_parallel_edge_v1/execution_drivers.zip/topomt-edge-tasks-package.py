import hashlib,json,shutil,zipfile
from pathlib import Path
from devtools.reference_validator.model import decode_scalar
from devtools.reference_validator.volume_request import VolumeRequest
base=Path('devguide/evidence/reference_validator_parallel_edge_v1')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def scientific(v):return {k:x for k,x in v.items() if k not in ['verifier_files_sha256','python_version']}
source=read(base/'source.json');assert len(source)==51 and all(sha(p)==h for p,h in source.items())
plan=read(base/'plan.json');rows=[];control_rows=[];table=[]
for job in plan['originals']+plan['controls']:
 protocol=Path(job['protocol']);spec=read(protocol);assert sha(protocol)==job['sha256']
 receiving=protocol.parent/'receiving';result=read(receiving/'session_verification.json');fresh=read(receiving/'serial_verification.json');ref=read(spec['inputs']['reference']['path']);cert=read(spec['inputs']['certificate']['path'])
 assert scientific(result)==scientific(fresh)==scientific(ref)
 request=VolumeRequest.from_record(cert['request'])
 assert request.satisfied(decode_scalar(result['volume_lower']),decode_scalar(result['volume_upper']))
 assert all(request.satisfied(decode_scalar(r['lower']),decode_scalar(r['upper'])) for r in result['regions'])
 row={'name':spec['name'],'configuration':spec['mode'],'protocol':str(protocol),'protocol_sha256':sha(protocol),'receiving_prefix':str(receiving.relative_to(base)),'model_sha256':spec['model_sha256'],'precision_status':result['precision_status'],'regions':len(result['regions']),'face_piece_count':result['face_piece_count'],'all_mathematical_fields_equal_original_and_serial':True}
 if spec['name'].startswith('original/'):
  receipts={m:read(receiving/(m+'_receipt.json')) for m in ['partial','resume','read']}
  executions={m:read(protocol.parent/(m+'_execution.json')) for m in receipts}
  assert all(e['exit_code']==0 and e['stop_reason'] is None for e in executions.values())
  assert all(s['host']['safe'] for e in executions.values() for s in e['samples'])
  phases=receipts['resume']['measurements']['phases']
  row.update(worker_wall_seconds=sum(r['wall_seconds'] for r in receipts.values()),bounded_wall_seconds=sum(r['wall_seconds'] for r in executions.values()),numerical_task_wall_seconds=sum(v['wall_seconds'] for n,v in phases.items() if n.startswith('integrate_after_')),recover_geometry_and_two_bounds_seconds=phases['load_and_reconstruct_frontier_and_saved_bounds']['wall_seconds'],fresh_serial_read_seconds=receipts['read']['wall_seconds'],sampled_group_rss_peak_kib=max(e['sampled_group_rss_peak_kib'] for e in executions.values()),peak_individual_rss_kib=max(e['peak_child_rss_kib'] for e in executions.values()),parent_cpu_seconds=sum(v['cpu_seconds'] for r in receipts.values() for v in r['measurements']['phases'].values()),waited_child_cpu_seconds=sum(v['waited_children_cpu_seconds'] for r in receipts.values() for v in r['measurements']['phases'].values()))
  rows.append(row)
  table.append(f"| `{spec['name'].removeprefix('original/')}` | {spec['mode']} | {row['numerical_task_wall_seconds']:.3f} | {row['recover_geometry_and_two_bounds_seconds']:.3f} | {row['fresh_serial_read_seconds']:.3f} | {row['bounded_wall_seconds']:.3f} | {row['sampled_group_rss_peak_kib']/1024:.2f} |")
 else:control_rows.append(row)
assert len(rows)==6 and len(control_rows)==50
members={n:Path(n).read_bytes() for n in source};members['devtools/__init__.py']=b''
working=[]
for p in sorted(base.rglob('*')):
 if p.is_file() and ('receiving' in p.relative_to(base).parts or p.relative_to(base).parts[0]=='inputs'):
  name=str(p.relative_to(base));assert p.suffix=='.json';members[name]=p.read_bytes();working.append((p,name))
members['DERIVATION.md']=Path('devguide/DFND/reference_validator_edge_integration.md').read_bytes()
members['EXECUTION_CONTRACT.md']=Path('devguide/DFND/reference_validator_parallel_edge.md').read_bytes()
inside={'schema':'topomt.reference-validator.parallel-edge-capsule/1','manifest_excludes_itself':True,'members':{n:hashlib.sha256(d).hexdigest() for n,d in members.items()}}
members['MANIFEST.json']=(json.dumps(inside,indent=2)+'\n').encode()
archive=base/'receiving.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(members.items()):z.writestr(name,data)
manifest={'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':{n:hashlib.sha256(d).hexdigest() for n,d in members.items()}}
(base/'capsule_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 for p,n in working:assert hashlib.sha256(z.read(n)).hexdigest()==sha(p)
index={'owner':'uibcdf/topomt#76','archive':'receiving.zip','archive_sha256':sha(archive),'source_files':source,'originals':rows,'controls':control_rows,'retention':'All exact input and working receiving JSON bytes retained in receiving.zip at their original evidence-relative paths; working receiving trees removed only after byte verification. Input records stay in the evidence tree for protocol inspection.'}
(base/'receiving_index.json').write_text(json.dumps(index,indent=2)+'\n')
(base/'table.md').write_text('| Original 1.4 A Model | Mode | Remaining numerical tasks s | Recover geometry + two bounds s | Further serial read s | Full bounded elapsed s | Sampled group MiB |\n| --- | --- | ---: | ---: | ---: | ---: | ---: |\n'+'\n'.join(table)+'\n\nThe full workflow includes first admission/two pieces/checkpoint, fresh-process recovery, completion/storage/reduction, and a further independent serial read. Each configuration is one observation. The remaining numerical-task phase includes pool/startup/scheduling when selected. Do not infer a universal or causal scaling factor from these shared-host observations. Tetrahedron phases are shorter than the five-second memory sampling period, so displayed sampled RSS does not resolve pool memory; all group values can miss peaks or double-count shared pages.\n')
comparisons=[]
for name in sorted({r['name'] for r in rows}):
 a=next(r for r in rows if r['name']==name and r['configuration']=='serial');b=next(r for r in rows if r['name']==name and r['configuration']=='parallel2')
 comparisons.append({'name':name,'full_elapsed_ratio':a['bounded_wall_seconds']/b['bounded_wall_seconds'],'numerical_phase_ratio':a['numerical_task_wall_seconds']/b['numerical_task_wall_seconds'],'scope':'Matched fixed mathematical frontier and precision; direct serial default vs two checker workers. One observation per configuration, independent serial recheck included, no general scaling/novelty claim.'})
(base/'comparisons.json').write_text(json.dumps(comparisons,indent=2)+'\n')
for job in plan['originals']+plan['controls']:
 rec=Path(job['protocol']).parent/'receiving';assert rec.is_dir() and rec.name=='receiving';shutil.rmtree(rec)
print(json.dumps({'original_configurations':6,'control_configurations':50,'retained_files':len(working),'archive_bytes':manifest['archive_bytes'],'comparisons':comparisons}))
