import hashlib,json,os,subprocess,sys
from pathlib import Path
p=Path(sys.argv[1]);spec=json.loads(p.read_text())
assert hashlib.sha256(Path('/tmp/topomt-edge-tasks-worker.py').read_bytes()).hexdigest()==spec['worker_script_sha256']
for mode in ['partial','resume','read']:
 print('START',spec['name'],spec['mode'],mode,flush=True)
 command=[sys.executable,'/tmp/topomt-edge-tasks-case-safe.py','--cpus',str(spec['cpus']),'--record',str(p.parent/(mode+'_execution.json')),'--log',str(p.parent/(mode+'_execution.log')),'--',sys.executable,'/tmp/topomt-edge-tasks-worker.py',mode,str(p),str(p.parent/'receiving')]
 result=subprocess.run(command,env={**os.environ,'PYTHONPATH':str(Path.cwd())},timeout=450)
 if result.returncode:raise SystemExit(result.returncode)
 observed=json.loads((p.parent/(mode+'_execution.json')).read_text());assert observed['stop_reason'] is None
 print('PASS',spec['name'],spec['mode'],mode,flush=True)
