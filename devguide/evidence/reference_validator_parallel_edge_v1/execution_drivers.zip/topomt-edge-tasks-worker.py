import hashlib,json,os,sys,time
from pathlib import Path
mode,protocol_path,output=sys.argv[1],Path(sys.argv[2]),Path(sys.argv[3])
if mode=='read':
 import importlib.abc
 class Block(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   names=('topomt','numpy','scipy','molsysmt','devtools.reference_validator.parallel','devtools.reference_validator.parallel_runs','devtools.reference_validator.edge_tasks','devtools.reference_validator.edge_volume','devtools.reference_validator.power_cells')
   if any(fullname==n or fullname.startswith(n+'.') for n in names):raise ImportError('Producer/pool/scientific import: '+fullname)
 sys.meta_path.insert(0,Block())
from devtools.reference_validator.model import Model
from devtools.reference_validator.performance import Measurements
from devtools.reference_validator.verify import verify

def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
 with Path(p).open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def scientific(v):return {k:x for k,x in v.items() if k not in ['verifier_files_sha256','python_version']}
if __name__=='__main__':
 spec=read(protocol_path)
 for p,h in spec['source_files'].items():assert sha(p)==h,p
 assert sha(__file__)==spec['worker_script_sha256']
 for row in spec['inputs'].values():assert sha(row['path'])==row['sha256']
 assert len(os.sched_getaffinity(0))==spec['cpus']
 if mode=='partial':output.mkdir(parents=True,exist_ok=False)
 else:assert output.is_dir()
 m=Measurements();started=time.monotonic()
 model=m.run('read_exact_model',lambda:Model.from_record(read(spec['inputs']['model']['path'])))
 cert=read(spec['inputs']['certificate']['path']);reference=read(spec['inputs']['reference']['path'])
 assert model.digest==spec['model_sha256']
 if mode=='read':
  result=m.run('independent_serial_saved_read',lambda:verify(model,cert))
  assert scientific(result)==scientific(read(output/'session_verification.json'))==scientific(reference)
  write(output/'serial_verification.json',result)
 else:
  from devtools.reference_validator.edge_tasks import EdgeVerificationSession
  from devtools.reference_validator.parallel import LocalPolicy
  policy=None if spec['mode']=='serial' else LocalPolicy(workers=2,worker_cpu_seconds=120)
  if mode=='partial':
   s=m.run('admit_topology_and_frontier',lambda:EdgeVerificationSession(model,cert))
   m.run('first_two_pieces',lambda:s.advance(piece_budget=2,policy=policy))
   m.run('save_partial_work',lambda:s.save(output/'partial'))
   assert len(s.snapshot['items'])==2
  elif mode=='resume':
   s=m.run('load_and_reconstruct_frontier_and_saved_bounds',lambda:EdgeVerificationSession.from_bundle(model,output/'partial'))
   pools=[]
   while s.snapshot['stop_reason']!='pieces_complete':
    n=len(s.snapshot['items'])
    try:m.run(f'integrate_after_{n:04d}',lambda:s.advance(piece_budget=512,policy=policy))
    except Exception:
     s.save(output/f'failed_after_{len(s.snapshot["items"]):04d}');raise
    pools.append(s.execution)
    m.run(f'save_after_{n:04d}',lambda:s.save(output/'checkpoints'/f'pieces_{len(s.snapshot["items"]):04d}'))
   result=m.run('reduce_complete_signed_frontier_and_requests',s.finish)
   assert scientific(result)==scientific(reference)
   assert result['precision_status']=='resolved'
   write(output/'session_verification.json',result);write(output/'pools.json',pools)
  else:raise ValueError('Unknown phase')
 receipt={'owner':'uibcdf/topomt#76','mode':mode,'configuration':spec['mode'],'protocol_sha256':sha(protocol_path),'model_sha256':model.digest,'source_files':spec['source_files'],'wall_seconds':time.monotonic()-started,'measurements':m.to_record(),'scope':'Same exact symbolic certificate and canonical signed frontier; partial has no whole volume, completed session/fresh serial read match original mathematical fields.'}
 write(output/(mode+'_receipt.json'),receipt)
 print(json.dumps({k:receipt[k] for k in ['mode','configuration','wall_seconds']}),flush=True)
