import hashlib,json,time
from pathlib import Path
from devtools.reference_validator.model import Model
from devtools.reference_validator.edge_tasks import EdgeVerificationSession
from devtools.reference_validator.parallel import LocalPolicy
from devtools.reference_validator.verify import verify
from devtools.reference_validator.verify.edge_volume import _atan_endpoint
from devtools.reference_validator.verify.edge_math import _pi_cached
from devtools.reference_validator.performance import Measurements

def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
 with Path(p).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def scientific(v):return {k:x for k,x in v.items() if k not in ['verifier_files_sha256','python_version']}
if __name__=='__main__':
 base=Path('devguide/evidence/reference_validator_parallel_edge_v1');plan=read(base/'plan.json');rows=[]
 for job in plan['controls']:
  p=Path(job['protocol']);assert sha(p)==job['sha256'];spec=read(p)
  for name,h in spec['source_files'].items():assert sha(name)==h
  for obj in spec['inputs'].values():assert sha(obj['path'])==obj['sha256']
  output=p.parent/'receiving';output.mkdir(exist_ok=False)
  _atan_endpoint.cache_clear();_pi_cached.cache_clear()
  m=Measurements();start=time.monotonic()
  model=m.run('read_model',lambda:Model.from_record(read(spec['inputs']['model']['path'])))
  cert=read(spec['inputs']['certificate']['path']);ref=read(spec['inputs']['reference']['path'])
  session=m.run('admit_topology_frontier',lambda:EdgeVerificationSession(model,cert))
  policy=None if spec['mode']=='serial' else LocalPolicy(workers=2,worker_cpu_seconds=120)
  m.run('integrate_complete_frontier',lambda:session.advance(piece_budget=4096,policy=policy))
  result=m.run('reduce_and_request_check',session.finish)
  checked=m.run('independent_serial_recompute',lambda:verify(model,cert))
  assert scientific(result)==scientific(checked)==scientific(ref)
  assert result['precision_status']=='resolved'
  m.run('save_complete_work',lambda:session.save(output/'complete_work'))
  write(output/'session_verification.json',result);write(output/'serial_verification.json',checked)
  row={'name':spec['name'],'configuration':spec['mode'],'protocol_sha256':sha(p),'n_regions':len(result['regions']),'precision_status':result['precision_status'],'wall_seconds':time.monotonic()-start,'measurements':m.to_record(),'execution':session.execution};write(output/'receipt.json',row);rows.append(row)
 write(base/'controls_receipt.json',rows)
 print(json.dumps({'configurations':len(rows),'all_resolved':all(r['precision_status']=='resolved' for r in rows)}),flush=True)
