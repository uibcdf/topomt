import json, os, subprocess, sys, tempfile, zipfile
from pathlib import Path
base=Path('devguide/evidence/reference_validator_performance_v1').resolve()
with tempfile.TemporaryDirectory(prefix='topomt-performance-fresh-') as directory:
 with zipfile.ZipFile(base/'checker_capsule.zip') as archive:archive.extractall(directory)
 script="""
import json,sys
from pathlib import Path
for name in ['topomt','numpy','scipy','pyunitwizard','ackredit','devtools.reference_validator.power_cells','devtools.reference_validator.boundary_volume','devtools.reference_validator.region_volume','devtools.reference_validator.parallel']:
 sys.modules[name]=None
from devtools.reference_validator.model import Model
from devtools.reference_validator.verify import verify
model=Model.from_record(json.loads(Path('model.json').read_text()))
result=verify(model,json.loads(Path('certificate_4096.json').read_text()))
previous=json.loads(Path('verification_4096.json').read_text())
for key in ['volume_lower','volume_upper','regions','precision_status','n_components']:
 assert result[key]==previous[key],key
assert result['precision_status']=='unresolved'
print(json.dumps(result))
"""
 run=subprocess.run([sys.executable,'-c',script],cwd=directory,env=dict(os.environ,PYTHONPATH=directory),capture_output=True,text=True,check=True,timeout=40)
 (base/'fresh_check.json').write_text(json.dumps(json.loads(run.stdout),indent=2)+'\n')
 print('Fresh independent capsule checking: accepted; precision remains unresolved.')
