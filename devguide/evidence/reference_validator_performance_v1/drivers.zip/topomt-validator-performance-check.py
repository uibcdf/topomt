import os, resource, subprocess, sys, time
os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
resource.setrlimit(resource.RLIMIT_AS, (2*1024**3, 2*1024**3))
resource.setrlimit(resource.RLIMIT_CPU, (100, 110))
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key] = '1'
t = time.monotonic()
result = subprocess.run([sys.executable, *sys.argv[1:]], timeout=115)
print('elapsed_seconds:', round(time.monotonic()-t,3), 'child_peak_rss_kib:', resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
raise SystemExit(result.returncode)
