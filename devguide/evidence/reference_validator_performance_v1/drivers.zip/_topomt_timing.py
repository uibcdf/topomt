def pytest_runtest_logreport(report):
    if report.when == 'call' and report.duration > 2:
        print(f'bounded timing: {report.nodeid}: {report.duration:.3f}s', flush=True)
