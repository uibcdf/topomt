import json, time
from pathlib import Path
from fractions import Fraction
from devtools.reference_validator.model import Model
from devtools.reference_validator.power_cells import topology_certificate
from devtools.reference_validator.boundary_volume import boundary_volume_certificate
from devtools.reference_validator.parallel import parallel_power_topology, parallel_boundary_volume, LocalPolicy
from devtools.reference_validator.verify.geometry import volume
from devtools.reference_validator.verify import verify
from devtools.reference_validator.volume_request import VolumeRequest

def main():
 spec=json.loads(Path('devguide/evidence/reference_validator_region_volume_v1/original/regular_tetrahedron/profile_1/protocol.json').read_text())
 m=Model.from_record(spec['model']);proof=json.loads(Path(spec['topology_path']).read_text())
 req=VolumeRequest(volume(m.domain)/2**24,Fraction(1,2**24))
 result=[]
 for repeat in range(3):
  for workers in [1,2]:
   start,cpu=time.monotonic(),time.process_time()
   if workers==1:p=topology_certificate(m);receipt={}
   else:p,receipt=parallel_power_topology(m,policy=LocalPolicy(workers=2))
   assert p==proof;verify(m,p)
   result.append({'repeat':repeat,'workers':workers,'operation':'topology','wall_seconds':time.monotonic()-start,'parent_cpu_seconds':time.process_time()-cpu,'resources':receipt,'same_proof':True})
   start,cpu=time.monotonic(),time.process_time()
   if workers==1:v=boundary_volume_certificate(m,p,req,max_leaves=512);reference=v;receipt={}
   else:v,receipt=parallel_boundary_volume(m,p,req,max_leaves=512,policy=LocalPolicy(workers=2));assert v==reference
   checked=verify(m,v)
   result.append({'repeat':repeat,'workers':workers,'operation':'boundary','wall_seconds':time.monotonic()-start,'parent_cpu_seconds':time.process_time()-cpu,'resources':receipt,'same_proof':True,'precision_status':checked['precision_status']})
 Path('devguide/evidence/reference_validator_performance_v1/parallel_pilot.json').write_text(json.dumps({'model_sha256':m.digest,'request':req.to_record(),'runs':result},indent=2)+'\n')
if __name__=='__main__':main()
