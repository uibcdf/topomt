import hashlib, json, resource, time
from pathlib import Path
from fractions import Fraction
from devtools.reference_validator.model import Model
from devtools.reference_validator.verify import verify
from devtools.reference_validator.verify.geometry import volume
from devtools.reference_validator.boundary_volume import boundary_volume_certificate
from devtools.reference_validator.volume_request import VolumeRequest
root=Path.cwd()
spec_path=Path('devguide/evidence/reference_validator_region_volume_v1/original/regular_tetrahedron/profile_1/protocol.json')
spec=json.loads(spec_path.read_text())
model=Model.from_record(spec['model'])
topology=json.loads(Path(spec['topology_path']).read_text())
request=VolumeRequest(volume(model.domain)/2**24,Fraction(1,2**24))
out=Path('devguide/evidence/reference_validator_performance_v1/boundary_rounded_pilot')
out.mkdir(exist_ok=False)
(out/'model.json').write_text(json.dumps(model.to_record(),indent=2)+'\n')
rows=[]
for ceiling in [64,512,4096]:
 start,cpu=time.monotonic(),time.process_time()
 proof=boundary_volume_certificate(model,topology,request,max_leaves=ceiling)
 result=verify(model,proof)
 (out/f'certificate_{ceiling}.json').write_text(json.dumps(proof,indent=2)+'\n')
 (out/f'verification_{ceiling}.json').write_text(json.dumps(result,indent=2)+'\n')
 row={'ceiling':ceiling,'leaves':len(proof['leaves']),'wall_seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'precision_status':result['precision_status'],'volume_lower':result['volume_lower'],'volume_upper':result['volume_upper']}
 rows.append(row)
 print(ceiling, row['wall_seconds'], row['precision_status'], flush=True)
(out/'receipt.json').write_text(json.dumps({'original_protocol':str(spec_path),'original_protocol_sha256':hashlib.sha256(spec_path.read_bytes()).hexdigest(),'request':request.to_record(),'runs':rows,'address_space_limit_bytes':resource.getrlimit(resource.RLIMIT_AS)[0],'cpu_affinity':list(__import__('os').sched_getaffinity(0))},indent=2)+'\n')
