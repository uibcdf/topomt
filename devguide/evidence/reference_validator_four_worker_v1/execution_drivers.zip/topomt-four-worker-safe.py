import argparse, json, os, resource, signal, subprocess, time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--record',type=Path,required=True);p.add_argument('--log',type=Path,required=True);p.add_argument('--cpus',type=int,default=1);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args()
assert a.cpus in [1,2,4]
cpus=sorted(os.sched_getaffinity(0))[:a.cpus]
os.sched_setaffinity(0,set(cpus));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));resource.setrlimit(resource.RLIMIT_CPU,(300,330))
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[key]='1'
def host():
 m={r.split(':')[0]:int(r.split()[1])*1024 for r in Path('/proc/meminfo').read_text().splitlines()}
 pressure=Path('/proc/pressure/memory').read_text()
 return {'available_bytes':m['MemAvailable'],'physical_bytes':m['MemTotal'],'pressure':pressure,'loadavg':Path('/proc/loadavg').read_text().strip(),'safe':m['MemAvailable']>max(m['MemTotal']//5,4*1024**3) and all(float(r.split()[1].split('=')[1])<0.1 for r in pressure.splitlines())}
samples=[{'seconds':0,'host':host()}];assert samples[0]['host']['safe']
cmd=a.command[1:] if a.command[0]=='--' else a.command
start=time.monotonic();stop=None
child=None
requested_signals=[]
def forward_stop(signum,frame):
 requested_signals.append(signum)
 if child is not None:
  try:os.killpg(child.pid,signal.SIGTERM)
  except ProcessLookupError:pass
signal.signal(signal.SIGTERM,forward_stop)
signal.signal(signal.SIGINT,forward_stop)
with a.log.open('x') as output:
 child=subprocess.Popen(cmd,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
 while child.poll() is None:
  if requested_signals:
   stop='caller_signal_'+str(requested_signals[-1])
   try:os.killpg(child.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   break
  elapsed=time.monotonic()-start;sample={'seconds':elapsed,'host':host(),'group_rss_kib':0,'group_pids':[],'process_niceness':{}}
  for entry in Path('/proc').iterdir():
   if not entry.name.isdigit():continue
   try:
    stat=(entry/'stat').read_text().rsplit(')',1)[1].split()
    if int(stat[2])!=child.pid:continue
    sample['group_pids'].append(int(entry.name));sample['process_niceness'][entry.name]=int(stat[16])
    for row in (entry/'status').read_text().splitlines():
     if row.startswith('VmRSS:'):sample['group_rss_kib']+=int(row.split()[1])
   except (FileNotFoundError,ProcessLookupError,PermissionError):pass
  samples.append(sample)
  if not sample['host']['safe'] or elapsed>420:
   stop='host_pressure' if not sample['host']['safe'] else 'wall_budget';os.killpg(child.pid,signal.SIGTERM);break
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:pass
 try:code=child.wait(timeout=5)
 except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
if requested_signals:stop='caller_signal_'+str(requested_signals[-1])
usage=resource.getrusage(resource.RUSAGE_CHILDREN)
r={'command':cmd,'exit_code':code,'stop_reason':stop,'cpu_affinity':cpus,'address_space_bytes':2*1024**3,'cpu_soft_seconds':300,'cpu_hard_seconds':330,'wall_seconds':time.monotonic()-start,'waited_cpu_seconds':usage.ru_utime+usage.ru_stime,'peak_child_rss_kib':usage.ru_maxrss,'sampled_group_rss_peak_kib':max(s.get('group_rss_kib',0) for s in samples),'rss_sampling_scope':'5-second process-group samples; summed RSS can double-count shared pages and miss short peaks','samples':samples}
a.record.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ['exit_code','wall_seconds','waited_cpu_seconds','peak_child_rss_kib','stop_reason']}));raise SystemExit(128+requested_signals[-1] if requested_signals else code)
