import hashlib,importlib.abc,json,os,sys,time
from pathlib import Path

class IndependentOnly(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        names=('topomt','numpy','scipy','molsysmt','pyunitwizard','ackredit',
            'devtools.reference_validator.producer','devtools.reference_validator.power_cells',
            'devtools.reference_validator.power_runs','devtools.reference_validator.parallel_runs',
            'devtools.reference_validator.edge_volume','devtools.reference_validator.boundary_volume',
            'devtools.reference_validator.region_volume')
        if any(fullname==n or fullname.startswith(n+'.') for n in names):
            raise ImportError('Producer/scientific import: '+fullname)

if __name__ in ['__main__','__mp_main__']:
    sys.meta_path.insert(0,IndependentOnly())

def read(p):
    from devtools.reference_validator.storage import read_record
    return read_record(Path(p))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,value):
    from devtools.reference_validator.storage import _encode_record
    with Path(p).open('xb') as f:
        f.write(_encode_record(value));f.flush();os.fsync(f.fileno())
def scientific(value):
    return {k:v for k,v in value.items() if k not in ['verifier_files_sha256','python_version']}

def main():
    os.nice(max(0,10-os.getpriority(os.PRIO_PROCESS,0)))
    from devtools.reference_validator.model import Model
    from devtools.reference_validator.performance import Measurements
    from devtools.reference_validator.verify import verify
    stage,protocol,output=sys.argv[1],Path(sys.argv[2]),Path(sys.argv[3])
    spec=read(protocol)
    assert stage in ['solve','read']
    assert sha(__file__)==spec['worker_sha256']
    assert len(os.sched_getaffinity(0))==spec['cpus']
    for p,h in spec['source_files'].items():assert sha(p)==h,p
    for row in spec['inputs'].values():assert sha(row['path'])==row['sha256']
    output.mkdir(parents=True,exist_ok=False)
    m=Measurements();started=time.monotonic()
    try:
        model=m.run('read_exact_model',lambda:Model.from_record(read(spec['inputs']['model']['path'])))
        cert=m.run('read_exact_certificate',lambda:read(spec['inputs']['certificate']['path']))
        reference=read(spec['inputs']['reference']['path'])
        assert model.digest==spec['model_sha256']
        if stage=='solve':
            from devtools.reference_validator.edge_tasks import EdgeVerificationSession
            from devtools.reference_validator.parallel import LocalPolicy
            policy=None if spec['mode']=='serial' else LocalPolicy(workers={'parallel2':2,'parallel4':4}[spec['mode']],worker_cpu_seconds=120)
            session=m.run('admit_complete_topology_and_frontier',lambda:EdgeVerificationSession(model,cert))
            pools=[]
            while session.snapshot['stop_reason']!='pieces_complete':
                n=len(session.snapshot['items'])
                try:m.run(f'integrate_after_{n:04d}',lambda:session.advance(piece_budget=512,policy=policy))
                except Exception:
                    session.save(output/'failed_work');raise
                pools.append(session.execution)
                print(json.dumps({'name':spec['name'],'mode':spec['mode'],'completed_pieces':len(session.snapshot['items'])}),flush=True)
            result=m.run('reduce_complete_frontier_and_requests',session.finish)
            assert scientific(result)==scientific(reference)
            m.run('persist_complete_work',lambda:session.save(output/'complete_work'))
            m.run('publish_saved_scientific_records',lambda:[write(output/n,v) for n,v in [('model.json',model.to_record()),('certificate.json',cert),('verification.json',result)]])
            write(output/'pools.json',pools)
        else:
            # This entire phase is a fresh process with both task/pool imports blocked.
            for name in ['devtools.reference_validator.edge_tasks','devtools.reference_validator.parallel']:
                sys.modules[name]=None
            results=[]
            for entry in spec['configurations']:
                p=Path(entry['protocol']);assert sha(p)==entry['sha256'];job=read(p)
                folder=p.parent/'receiving';receipt=read(folder/'receipt.json')
                for n,h in receipt['files'].items():assert sha(folder/n)==h
                assert read(folder/'model.json')==model.to_record()
                assert read(folder/'certificate.json')==cert
                results.append(read(folder/'verification.json'))
            result=m.run('independent_serial_saved_read',lambda:verify(model,cert))
            assert all(scientific(result)==scientific(v)==scientific(reference) for v in results)
            write(output/'verification.json',result)
        assert result['precision_status']=='resolved'
        files={str(p.relative_to(output)):sha(p) for p in sorted(output.rglob('*')) if p.is_file()}
        receipt={'owner':'uibcdf/topomt#76','name':spec['name'],'stage':stage,'mode':spec['mode'],
            'protocol_sha256':sha(protocol),'model_sha256':model.digest,'niceness':os.getpriority(os.PRIO_PROCESS,0),'wall_seconds':time.monotonic()-started,
            'measurements':m.to_record(),'files':files,'precision_status':result['precision_status'],
            'all_mathematical_fields_equal_original':True,'n_components':result['n_components'],
            'face_piece_count':result['face_piece_count'],'source_files':spec['source_files'],
            'scope':'Cold complete independent verification of frozen Model/symbolic proof. Producer/scientific imports blocked. Full topology/frontier/checker arithmetic is executed; proposal generation and resumed construction are separate prior scopes.'}
        if stage=='read':receipt['checked_configurations']=len(results)
        write(output/'receipt.json',receipt)
        print(json.dumps({k:receipt[k] for k in ['name','stage','mode','wall_seconds','precision_status']}),flush=True)
    except Exception as exc:
        write(output/'failure.json',{'type':type(exc).__name__,'message':str(exc),'measurements':m.to_record(),'protocol_sha256':sha(protocol)})
        raise

if __name__=='__main__':main()
