import hashlib,json,os,zipfile
from pathlib import Path
old=Path('devguide/evidence/reference_validator_analytic_panel_v1');base=Path('devguide/evidence/reference_validator_four_worker_v1')
if base.exists():assert {p.name for p in base.iterdir()}=={'README.md'}
else:base.mkdir()
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
archive=old/'receiving.zip';manifest=read(old/'capsule_manifest.json');assert sha(archive)==manifest['archive_sha256'];oldplan=read(old/'plan.json')
source={str(p):sha(p) for p in sorted(Path('devtools/reference_validator').rglob('*.py'))};assert source==oldplan['source_files']
jobs=[];reads=[];order=[];selected=[('original/regular_tetrahedron/profile_1','pilot_small'),('original/closed_shell/profile_2','pilot_large'),('original/dumbbell/profile_0','conditional_multiregion')]
selected += [(r['name'],'controls') for r in oldplan['reads'] if r['category']=='controls']
with zipfile.ZipFile(archive) as z:
    for name,phase in selected:
        original=next(r for r in oldplan['jobs'] if r['name']==name);spec=read(original['protocol']);inputs={}
        for kind,v in spec['inputs'].items():
            data=z.read(v['path']);assert hashlib.sha256(data).hexdigest()==v['sha256']
            p=base/'inputs'/name/(kind+'.json');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);inputs[kind]={'path':str(p),'sha256':sha(p),'original_capsule_member':v['path']}
        group=[]
        for repeat in range(1 if phase=='controls' else 3):
            modes=['parallel4'] if phase=='controls' else [['serial','parallel2','parallel4'],['parallel2','parallel4','serial'],['parallel4','serial','parallel2']][repeat]
            for mode in modes:
                cpus={'serial':1,'parallel2':2,'parallel4':4}[mode];p=base/phase/name/mode/f'repeat_{repeat}'/'protocol.json'
                write(p,{'schema':'topomt.reference-validator.four-worker-pilot/1','owner':'uibcdf/topomt#76','name':name,'mode':mode,'cpus':cpus,'repeat':repeat,'phase':phase,'inputs':inputs,'model_sha256':spec['model_sha256'],'worker_sha256':sha('/tmp/topomt-four-worker-worker.py'),'source_files':source,'minimum_niceness':10,'piece_budget':512})
                row={'protocol':str(p),'sha256':sha(p),'name':name,'mode':mode,'repeat':repeat,'phase':phase};group.append(row);jobs.append(row);order.append(dict(row,stage='solve'))
        p=base/phase/name/'saved_read'/'protocol.json'
        write(p,{'schema':'topomt.reference-validator.four-worker-read/1','owner':'uibcdf/topomt#76','name':name,'mode':'shared_serial_saved_read','cpus':1,'phase':phase,'inputs':inputs,'model_sha256':spec['model_sha256'],'worker_sha256':sha('/tmp/topomt-four-worker-worker.py'),'source_files':source,'configurations':group,'minimum_niceness':10})
        row={'protocol':str(p),'sha256':sha(p),'name':name,'phase':phase};reads.append(row);order.append(dict(row,stage='read'))
assert len(jobs)==52 and len(reads)==28
write(base/'plan.json',{'owner':'uibcdf/topomt#76','date':'2026-11-16 UTC','base_revision':'293fc69e83ae06928eb88e597e433b2b79994954','source_files':source,'original_capsule_sha256':sha(archive),'jobs':jobs,'reads':reads,'execution_order':order,'conditional_expansion':{'owner':'uibcdf/topomt#76','gate_input':'pilot_large','destination':'conditional_multiregion','all_mathematical_fields_unchanged':True,'all_requested_precisions_met':True,'median_elapsed_reduction_4_vs_2_minimum':0.05,'range_separation':'max(T4) < min(T2)','host_reserve_and_operational_success_required':True,'actual_four_task_workers_on_large_batches_required':True,'otherwise':'Do not execute the conditional multiregion block; retain a negative/inconclusive result, finish controls and report the bounded scope. No full nineteen-profile expansion or new default.'},'resource_policy':{'at_most_one_command_at_a_time':True,'default_cpus':1,'explicit_max_cpus':4,'minimum_niceness':10,'parent_address_bytes':2*1024**3,'parent_cpu_soft_hard_seconds':[300,330],'external_wall_seconds':420,'worker_address_bytes':256*1024**2,'pool_total_cpu_seconds':120,'aggregate_virtual_envelope_at_four_workers_bytes':5*1024**3,'max_pending_tasks':4,'piece_budget':512,'minimum_available_ram_fraction':0.2,'minimum_available_ram_bytes':4*1024**3,'observed_free_ram_is_not_reserved':True},'scope':'Four-worker analytic saved-proof verification pilot. Unchanged exact inputs, requests and checker. Prior full 19-profile serial/two-worker and source-construction/resume scopes remain separate; no new geometry, protein, provider, native operator or public API.'})
write(base/'source.json',source)
print(json.dumps({'configured_solves':len(jobs),'configured_reads':len(reads),'conditional_multiregion_commands':10,'source_files':len(source)}))
