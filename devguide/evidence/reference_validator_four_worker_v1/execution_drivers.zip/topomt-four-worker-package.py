import hashlib,json,shutil,statistics,zipfile
from pathlib import Path
base=Path('devguide/evidence/reference_validator_four_worker_v1')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
    with Path(p).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def scientific(v):return {k:x for k,x in v.items() if k not in ['verifier_files_sha256','python_version']}
plan=read(base/'plan.json');assert read(base/'expansion_decision.json')['execute_conditional_multiregion']
assert all(sha(p)==h for p,h in plan['source_files'].items())
entries=[]
for row in plan['execution_order']:
    p=Path(row['protocol']);spec=read(p);folder=p.parent/'receiving';r=read(folder/'receipt.json');e=read(p.parent/'execution.json')
    assert sha(p)==row['sha256'] and e['exit_code']==0 and e['stop_reason'] is None and all(s['host']['safe'] for s in e['samples'])
    assert r['precision_status']=='resolved' and r['niceness']>=10
    result=read(folder/'verification.json');assert scientific(result)==scientific(read(spec['inputs']['reference']['path']))
    for v in spec['inputs'].values():assert sha(v['path'])==v['sha256']
    for n,h in r['files'].items():assert sha(folder/n)==h
    phases=r['measurements']['phases'];assert all(not v['failed'] for v in phases.values())
    entry={**row,'receiving_prefix':str(folder),'bounded_wall_seconds':e['wall_seconds'],'waited_cpu_seconds':e['waited_cpu_seconds'],'worker_wall_seconds':r['wall_seconds'],'sampled_group_rss_peak_kib':e['sampled_group_rss_peak_kib'],'peak_individual_rss_kib':e['peak_child_rss_kib'],'niceness':r['niceness'],'n_components':r['n_components'],'face_piece_count':r['face_piece_count'],'all_mathematical_fields_equal_original':True,'precision_status':'resolved'}
    if row['stage']=='solve':
        pools=read(folder/'pools.json');pids={str(v['pid']) for p in pools for v in p.get('worker_records',[])}
        nice=[n for s in e['samples'] for pid,n in s.get('process_niceness',{}).items() if pid in pids]
        assert all(n>=10 for n in nice)
        entry.update(numerical_task_wall_seconds=sum(v['wall_seconds'] for n,v in phases.items() if n.startswith('integrate_after_')),topology_and_frontier_wall_seconds=phases['admit_complete_topology_and_frontier']['wall_seconds'],largest_observed_task_worker_inventory=max([len(p.get('worker_records',[])) for p in pools]+[0]),sampled_task_worker_niceness_range=[min(nice),max(nice)] if nice else None)
    else:entry['checked_configurations']=r['checked_configurations']
    entries.append(entry)
assert len(entries)==80
summaries=[];table=[]
for phase in ['pilot_small','pilot_large','conditional_multiregion']:
    rows=[r for r in entries if r['phase']==phase and r['stage']=='solve'];sample={mode:[r['bounded_wall_seconds'] for r in rows if r['mode']==mode] for mode in ['serial','parallel2','parallel4']};assert all(len(v)==3 for v in sample.values())
    med={mode:statistics.median(values) for mode,values in sample.items()};cpu={mode:statistics.median(r['waited_cpu_seconds'] for r in rows if r['mode']==mode) for mode in sample};num={mode:statistics.median(r['numerical_task_wall_seconds'] for r in rows if r['mode']==mode) for mode in sample}
    checked=next(r for r in entries if r['phase']==phase and r['stage']=='read');assert checked['checked_configurations']==9
    result={'phase':phase,'name':rows[0]['name'],'n_components':rows[0]['n_components'],'times_seconds':sample,'median_seconds':med,'median_waited_cpu_seconds':cpu,'median_numerical_seconds':num,'shared_read_seconds':checked['bounded_wall_seconds'],'elapsed_reduction_four_vs_two':1-med['parallel4']/med['parallel2'],'elapsed_reduction_four_vs_serial':1-med['parallel4']/med['serial'],'range_separation_four_vs_two':max(sample['parallel4'])<min(sample['parallel2']),'scope':'Three fresh observations per mode; rotating order at niceness >=10. Shared serial read executed once. Per-case observations, no general scaling or zero-impact guarantee.'}
    summaries.append(result)
    cells=[f"{med[m]:.3f} ({min(sample[m]):.3f}–{max(sample[m]):.3f})" for m in sample]
    table.append(f"| `{rows[0]['name'].split('/')[1]}` | {rows[0]['n_components']} | "+' | '.join(cells)+f" | {100*result['elapsed_reduction_four_vs_two']:.2f}% | {checked['bounded_wall_seconds']:.3f} |")
index={'owner':'uibcdf/topomt#76','date':'2026-11-16 UTC','source_files':plan['source_files'],'original_profiles':3,'analytic_controls':25,'solve_configurations':52,'shared_reads':28,'scientific_commands':80,'conditional_multiregion_executed':True,'default_mode':'serial','general_scaling_claim':False,'zero_impact_guarantee':False,'source_generation_reexecuted':False,'summaries':summaries,'entries':entries,'all_bounded_wall_seconds':sum(r['bounded_wall_seconds'] for r in entries),'all_waited_cpu_seconds':sum(r['waited_cpu_seconds'] for r in entries),'peak_sampled_group_rss_kib':max(r['sampled_group_rss_peak_kib'] for r in entries),'peak_individual_rss_kib':max(r['peak_individual_rss_kib'] for r in entries),'resource_scope':'Group RSS sampled every five seconds; can miss peaks/double-count pages. Excludes outer monitoring launcher. Short cases cannot resolve all worker lifetimes. Science totals exclude bootstrap failure, freeze/package/test/build and scheduling gaps.'}
write(base/'receiving_index.json',index)
(base/'table.md').write_text('| Original 1.4 Å profile | Regions | Serial median s (range) | Two-worker median s (range) | Four-worker median s (range) | Four vs two elapsed reduction | Shared further serial read s |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: |\n'+'\n'.join(table)+'\n\nTimes include the same cold checked solve/saving workflow and bounded launcher overhead. Each mode has three fresh observations in rotated order at lower scheduling priority. Shared reading is executed once per profile and checks all nine configurations; it is outside these solve medians and charged once in the total. These are scoped shared-host observations, not population statistics or general/causal scaling. Tiny inputs can use fewer task workers than requested. Serial remains the default.\n')
files={p.as_posix():p for p in sorted(base.rglob('*.json')) if p.name not in ['receiving_index.json','capsule_manifest.json','plan.json','source.json']}
members={};archive=base/'receiving.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,p in {**{n:Path(n) for n in plan['source_files']},**files}.items():
        data=p.read_bytes();z.writestr(n,data);members[n]=hashlib.sha256(data).hexdigest()
    data=Path('/tmp/topomt-four-worker-worker.py').read_bytes();z.writestr('drivers/worker.py',data);members['drivers/worker.py']=hashlib.sha256(data).hexdigest()
    z.writestr('devtools/__init__.py',b'');members['devtools/__init__.py']=hashlib.sha256(b'').hexdigest()
    data=(json.dumps({'members':members,'manifest_excludes_itself':True},indent=2)+'\n').encode();z.writestr('MANIFEST.json',data);members['MANIFEST.json']=hashlib.sha256(data).hexdigest()
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(members)
    assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in members.items())
write(base/'capsule_manifest.json',{'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':members})
for p in [base/'inputs']+[Path(r['protocol']).parent/'receiving' for r in plan['execution_order']]:
    assert p.is_dir() and p.is_relative_to(base)
    assert all(f.as_posix() in members and sha(f)==members[f.as_posix()] for f in p.rglob('*') if f.is_file())
    shutil.rmtree(p)
print(json.dumps({'scientific_commands':len(entries),'summary':summaries,'archive_bytes':archive.stat().st_size,'peak_group_mib':index['peak_sampled_group_rss_kib']/1024}))
