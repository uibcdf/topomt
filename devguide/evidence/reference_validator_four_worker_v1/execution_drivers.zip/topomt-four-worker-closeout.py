import hashlib,json,re,subprocess,sys,zipfile
from pathlib import Path
from urllib.parse import unquote
base=Path('devguide/evidence/reference_validator_four_worker_v1')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(n,v):
    with (base/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
plan=read(base/'plan.json');source=read(base/'source.json');assert len(source)==51 and source==plan['source_files'] and all(sha(p)==h for p,h in source.items())
frozen=read('docs/content/benchlab/synthetic/artifacts/six_case_review_v1/protocol.json')['frozen_files'];assert len(frozen)==355 and all(sha(p)==h for p,h in frozen.items())
human='d76f39e77bb54929c2d4a02f55ec04d61534ec09df776d2fe89ef731626a88b5';assert sha('topomt/_version.py')==human
previous={}
for name in ['reference_validator_parallel_resume_v1','reference_validator_parallel_edge_v1','reference_validator_storage_v1','reference_validator_analytic_panel_v1']:
    folder=base.parent/name;m=read(folder/'MANIFEST.json');assert all(sha(folder/p)==h for p,h in m['files'].items());previous[name+'/MANIFEST.json']=sha(folder/'MANIFEST.json')
reuse=read(base.parent/'reference_validator_storage_v1/source_qualification.json');assert reuse['source_files']==source and reuse['selected_tests']['total_distinct']==259
for name in ['guards','final_guards','package','docs','capsule_replay']:
    e=read(base/(name+'_execution.json'));assert e['exit_code']==0 and e['stop_reason'] is None and all(s['host']['safe'] for s in e['samples'])
assert '23 passed' in (base/'final_guards.log').read_text()
replay=read(base/'capsule_replay_receipt.json');assert replay['niceness']>=10 and replay['precision_status']=='resolved'
assert any(v['worker_count']==4 for v in read(base/'capsule_replay_pools.json'))
bootstrap=base/'pilot_large/original/closed_shell/profile_2/serial/repeat_0/bootstrap_attempt1_execution.json';assert read(bootstrap)['exit_code']==1
assert 'ModuleNotFoundError' in bootstrap.with_name('bootstrap_attempt1_execution.log').read_text()
caps=read(base/'capsule_manifest.json');assert sha(base/'receiving.zip')==caps['archive_sha256']
with zipfile.ZipFile(base/'receiving.zip') as z:
    assert set(z.namelist())==set(caps['members']) and all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in caps['members'].items())
    assert z.read('drivers/worker.py')==Path('/tmp/topomt-four-worker-worker.py').read_bytes()
html=Path('/tmp/topomt-four-worker-docs-html/content')
assert 'id="reference-validator-four-worker-pilot"' in (html/'benchlab/synthetic/reference_validator_report.html').read_text()
assert 'reference_validator_report.html#reference-validator-four-worker-pilot' in (html/'dfnd/validation_and_scope.html').read_text()
links=0
files=[Path(p) for p in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines() if p.endswith('.md')]+[base/'README.md',base/'table.md']
for p in files:
    for target in re.findall(r'\]\(([^)\s]+)\)',p.read_text()):
        if target.startswith(('#','http:','https:','mailto:','plugin:','app:')):continue
        target=unquote(target.split('#',1)[0].strip('<>'))
        if target:assert (p.parent/target).exists(),(p,target);links+=1
drivers=sorted(Path('/tmp').glob('topomt-four-worker-*.py'));assert len(drivers)==9
with zipfile.ZipFile(base/'execution_drivers.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in drivers:z.writestr(p.name,p.read_bytes())
with zipfile.ZipFile(base/'execution_drivers.zip') as z:assert all(z.read(p.name)==p.read_bytes() for p in drivers)
index=read(base/'receiving_index.json');assert index['scientific_commands']==80
write('source_qualification.json',{
    'owner':'uibcdf/topomt#76','date':'2026-11-16 UTC','source_revision':'293fc69e83ae06928eb88e597e433b2b79994954','executable_validator_changes':False,'source_files':source,'worker_sha256':sha('/tmp/topomt-four-worker-worker.py'),
    'scientific_receiving':{'original_1_4_angstrom_profiles':3,'fresh_repeats_per_original_mode':3,'original_modes':['serial','parallel2','parallel4'],'controls_at_four_workers':25,'solve_configurations':52,'shared_serial_reads':28,'successful_panel_commands':80,'all_mathematical_fields_equal_original':True,'all_total_and_region_requests_met':True,'source_generation_reexecuted':False,'four_worker_failure_resume_reexecuted':False},
    'expansion_gate':{'record':'expansion_decision.json','sha256':sha(base/'expansion_decision.json'),'executed_conditional_multiregion':True,'scope':'Frozen >=5% median reduction, separated observed two/four-worker ranges, actual four task workers, lower priority and unchanged scientific/resource checks on one pilot. Practical expansion decision, not a statistical significance/general scaling claim.'},
    'selected_tests':{'distinct':23,'new_four_worker_guards':4,'initial':'guards_execution.json','final':'final_guards_execution.json','scope':'Actual data/gate/resources, all mathematical/precision fields, fresh extracted capsule reading, previous receiving/reporting/DFND example.'},
    'reused_code_tests':{'distinct':259,'source_qualification':'devguide/evidence/reference_validator_storage_v1/source_qualification.json','sha256':sha(base.parent/'reference_validator_storage_v1/source_qualification.json'),'basis':'All 51 executable source hashes unchanged; not a newly executed 259-test run or full-suite claim.'},
    'checks':{'ruff_check_and_format_files':742,'mypy_local_modules':51,'report_index':'pass','comparative_findings':'pass; offline only','strict_one_cpu_sphinx':'pass; notebook execution disabled; local rendering only','rendered_anchor_and_method_link':True,'local_markdown_links':links,'fresh_extracted_four_worker_solve':'pass under Python -S; independent producer/scientific import denial policy; explicit four-CPU affinity/resources; outside 80 panel-command totals','fresh_extracted_producer_free_serial_read':'pass; no pool required'},
    'resources':{'minimum_niceness':10,'explicit_max_cpus':4,'parent_address_bytes':2*1024**3,'parent_cpu_soft_hard_seconds':[300,330],'external_wall_seconds':420,'worker_address_bytes':256*1024**2,'pool_cpu_total_seconds':120,'pool_cpu_per_worker_at_four_seconds':30,'aggregate_virtual_envelope_at_four_bytes':5*1024**3,'science_elapsed_seconds':index['all_bounded_wall_seconds'],'science_waited_cpu_seconds':index['all_waited_cpu_seconds'],'sampled_group_rss_peak_kib':index['peak_sampled_group_rss_kib'],'scope':'One command at a time. Five-second group RSS/priority samples can miss short workers or double-count pages. External monitor excluded; observed free RAM not reserved. No zero-impact guarantee for others; four-worker option remains explicit and host-dependent.'},
    'operational_bootstrap_failure':{'record':str(bootstrap.relative_to(base)),'scope':'Initial direct launch omitted explicit source path, failed before Model import; raw record/log preserved. Corrected PYTHONPATH startup; excluded from successful scientific durations and never a comparison denominator.'},
    'preserved':{'original_frozen_files':frozen,'earlier_evidence_manifests':previous,'human_version_sha256':human},
    'remaining':{'uibcdf/topomt#76':'S1/S3/S5, full nineteen-profile four-worker panel, source construction, four-worker failure/resume, broader S8/P6/P7. Measured serial geometric work remains a priority; no new algorithm/physical interpretation/default change.','uibcdf/topomt#60':'Canonical native receiving with #76','uibcdf/topomt#16':'Full suite, remote CI, installed/public/platform/Python-minor qualification; authorized direct development commit carries [skip ci].','unchanged_native':['#181','#180','#184','#188']},
    'not_selected':'No new geometry/protein/original provider, public API/attribution boundary, dependency, Slurm/GPU/distributed run, increased RAM/time ceilings or hosted deployment.',
    'execution_drivers':{p.name:sha(p) for p in drivers},'python_version':sys.version,
})
write('MANIFEST.json',{'schema':'topomt.reference-validator.four-worker-evidence/1','manifest_excludes_itself':True,'files':{str(p.relative_to(base)):sha(p) for p in sorted(base.rglob('*')) if p.is_file() and p.name!='MANIFEST.json'}})
print(json.dumps({'source_modules':51,'original_frozen_files_unchanged':355,'panel_commands':80,'selected_tests':23,'evidence_payloads':len(read(base/'MANIFEST.json')['files'])}))
