import argparse,json,os,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--phase',choices=['pilot_small','pilot_large','conditional_multiregion','controls'],required=True);a=p.parse_args()
base=Path('devguide/evidence/reference_validator_four_worker_v1');plan=json.loads((base/'plan.json').read_text())
if a.phase=='conditional_multiregion':assert json.loads((base/'expansion_decision.json').read_text())['execute_conditional_multiregion']
for row in plan['execution_order']:
    if row['phase']!=a.phase:continue
    protocol=Path(row['protocol']);spec=json.loads(protocol.read_text());folder=protocol.parent
    assert not (folder/'execution.json').exists() and not (folder/'receiving').exists()
    cmd=[sys.executable,'/tmp/topomt-four-worker-safe.py','--cpus',str(spec['cpus']),'--record',str(folder/'execution.json'),'--log',str(folder/'execution.log'),'--',sys.executable,'-S','/tmp/topomt-four-worker-worker.py',row['stage'],str(protocol),str(folder/'receiving')]
    print('START',spec['name'],spec['mode'],spec.get('repeat'),row['stage'],flush=True)
    p=subprocess.run(cmd,env={**os.environ,'PYTHONPATH':str(Path.cwd())},timeout=440)
    if p.returncode:raise SystemExit(p.returncode)
    e=json.loads((folder/'execution.json').read_text());r=json.loads((folder/'receiving/receipt.json').read_text());assert e['stop_reason'] is None and r['niceness']>=10
    print(json.dumps({'name':spec['name'],'mode':spec['mode'],'repeat':spec.get('repeat'),'stage':row['stage'],'wall_seconds':e['wall_seconds'],'precision_status':r['precision_status'],'niceness':r['niceness']}),flush=True)
