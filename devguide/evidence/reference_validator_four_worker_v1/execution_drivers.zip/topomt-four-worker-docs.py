from pathlib import Path
import json
base=Path('devguide/evidence/reference_validator_four_worker_v1');index=json.loads((base/'receiving_index.json').read_text());assert index['scientific_commands']==80
edits={}
def get(p):
    p=Path(p);return edits.get(p,p.read_text())
def put(p,s):edits[Path(p)]=s
def replace(p,old,new):
    s=get(p);assert old in s,(p,old[:80]);put(p,s.replace(old,new,1))
summary='''## Four-worker analytic assessment — 2026-11-16 UTC

The [bounded pilot](../evidence/reference_validator_four_worker_v1/README.md)
compares three fresh repetitions per mode on the original tetrahedron,
closed-shell and dumbbell 1.4 Å Models, in rotated serial/two/four-worker order.
Twenty-five existing controls also pass with four workers. All 80 scientific
commands preserve every mathematical field and total/per-region precision
request, including fresh shared serial reading. Actual large-case task workers
and sampled niceness 10 are retained; earlier inputs/evidence are unchanged.

The preregistered closed-shell expansion gate passes: four-worker median
82.919 s vs two-worker 87.453 s (5.18% less elapsed), with separated observed
ranges. The selected dumbbell extension gives 107.771 vs 119.029 s (9.46%).
The small tetrahedron is fastest in direct serial. These are three repetitions
on two larger fixed inputs at lower scheduling priority, not universal scaling
or proof of zero impact on other users. Serial remains the default; four
workers are an explicit option at this tested analytic scope after host checks.

This qualifies selected analytic verification, not a full nineteen-profile
four-worker run, source construction, four-worker failure/resume, native
#181/#180/#184/#188 correction or broader S8/P6/P7/public/installed admission.
S1/S3/S5, canonical #76/#60 and full-suite/platform #16 retain their gates.

'''
for name in ['reference_validator_checkpoint.md','notebook_laboratory_checkpoint.md']:
    p='devguide/DFND/'+name;s=get(p);pos=s.index('\n## ')+1;put(p,s[:pos]+summary+s[pos:])
p='devguide/DFND/reference_validator_performance_plan.md';s=get(p);pos=s.index('### Expanded original verification panel');put(p,s[:pos]+summary.replace('## Four-worker','### Four-worker')+s[pos:])
replace(p,'This extends analytic verification, not proposal generation or nineteen-profile\nsource-construction/resume admission. S6/S7 pause/recovery retain their earlier\nthree-Model source scopes. Four workers, remaining S1/S3/S5, broader S8/P6/P7,','This extends analytic verification, not proposal generation or nineteen-profile\nsource-construction/resume admission. S6/S7 pause/recovery retain their earlier\nthree-Model source scopes. The later four-worker pilot above keeps its selected\nanalytic scope; full four-worker receiving, remaining S1/S3/S5, broader S8/P6/P7,')
replace(p,'No four-worker run is qualified by this record. Runtime safety controls retain','At that checkpoint no four-worker run was qualified. The later bounded analytic\npilot above now qualifies its selected inputs, leaving construction/resume and\nfull nineteen-profile four-worker receiving separate. Runtime controls retain')
replace(p,'Partial: all 19 original saved proofs/25 controls in serial/two-worker modes, fresh shared reading and storage reliability delivered; broader construction/resume, repeatability and public gates open','Partial: 19 original saved proofs in serial/two-worker modes; selected repeated four-worker analytic pilot/controls, fresh reading and storage reliability delivered; broader construction/resume/panel and public gates open')
p='devguide/DFND/reference_validator_improvement_workplan.md';replace(p,'### Next executable work under #76',summary+'### Next executable work under #76')
replace(p,'   receiving; broader source-construction/resume and four workers remain open.','   receiving and selected repeated four-worker analytic controls; broader\n   construction/resume and full four-worker panel remain open.')
p='devguide/pending_proposals/dfnd_reference_validation_panel.md';s=get(p);pos=s.index('## Expanded original verification panel');put(p,s[:pos]+summary+s[pos:])
p='devguide/DFND/reference_validator_parallel_edge.md';replace(p,'Source-construction/resume over all nineteen, four workers, broader S8/P6/P7\nand remaining S1/S3/S5 work retain their gates.','''The [subsequent four-worker assessment](../evidence/reference_validator_four_worker_v1/README.md)
adds three fresh serial/two/four-worker repetitions on tetrahedron, closed-shell
and dumbbell 1.4 Å Models, plus four-worker receiving of 25 existing controls.
The pilot launcher uses niceness at least 10, unchanged memory/time ceilings
and explicit host reserve checks. The repeated larger-case observations support
only a scoped optional four-worker route; tiny inputs remain faster in serial.
Full nineteen-profile four-worker receiving, source construction, four-worker
failure/resume, broader S8/P6/P7 and remaining S1/S3/S5 retain their gates.''')
p='devguide/DFND/documentation_checkpoint.md';put(p,get(p)+'''
## Four-worker pilot review — 2026-11-16 UTC

The [bounded analytic assessment](../evidence/reference_validator_four_worker_v1/README.md)
adds actual repeated serial/two/four-worker observations and lower-priority
resource receiving. The validation chapter/report distinguish optional measured
benefit on two larger profiles from tiny-case overhead, general scaling and
full construction/resume/public admission. DFND operators, physical units,
derivations and interpretation are unchanged; the worked-example regression
remains in the selected tests. Rendering is checked locally, separately from
hosted publication.
''')
p='docs/content/dfnd/validation_and_scope.md';marker='## Source deliveries and remaining scientific/public boundaries';replace(p,marker,'''A later {ref}`four-worker pilot <reference-validator-four-worker-pilot>` repeats
three original 1.4 Å profiles in serial/two/four-worker modes and receives
25 existing controls with four workers. All intervals and requests are
unchanged. The larger profiles show a modest measured benefit; the tiny
tetrahedron remains faster in serial. This is an explicit bounded developer
option after host checks, not a new default, physical interpretation or full
four-worker molecular/public qualification.

'''+marker)
p='docs/content/benchlab/synthetic/reference_validator_report.md';table=(base/'table.md').read_text().split('\n\n')[0]
section='''(reference-validator-four-worker-pilot)=

## Four-worker assessment at unchanged precision — 2026-11-16 UTC

The original tetrahedron, closed shell and dumbbell at 1.4 Å each receive three
fresh serial/two/four-worker runs, rotating the mode order. Twenty-five existing
analytic controls also pass with four workers. All **80 scientific commands**
preserve every mathematical field and original total/per-region request,
including a further independent serial read per numerical profile.

'''+table+'''

The fixed expansion criterion is decided before the runs: at least 5% less
median solve time with four than two workers, separated observed ranges and
unchanged scientific/resource checks on the closed-shell pilot. It passes,
justifying the selected three-region dumbbell extension. This is an operating
decision from three repetitions per mode, not a statistical significance test
or general scaling claim. In the tiny tetrahedron direct serial is faster.
The further serial read is shared once per profile and is outside solve medians.

All commands run one at a time at lower scheduling priority (niceness at least
10), with the same 2 GiB parent AS, 300/330 CPU-second and 420 wall-second
ceilings. Four workers retain 256 MiB each and divide the same 120 CPU-second
pool budget. Actual large-case four-task-worker execution and sampled niceness
10 are retained. The 80 commands take **2122.669 bounded wall / 2431.147 waited
CPU seconds**; peak sampled group RSS is **160.33 MiB**. Five-second samples can
miss peaks/double-count pages and cannot resolve all tiny-case worker lifetimes.
Observed headroom is not a reservation or a zero-impact guarantee for others.

The [exact source, gate, observations and capsule](https://github.com/uibcdf/topomt/blob/main/devguide/evidence/reference_validator_four_worker_v1/README.md)
support an **explicit four-worker option at this tested analytic scope**.
Serial remains the default. Full nineteen-profile four-worker verification,
source construction, four-worker failure/resume, broader S8/P6/P7 and native
DFND/public qualification keep their gates. No input, request, earlier artifact
or native scientific behavior changes.

'''
replace(p,'## Earlier range-based face-integration feasibility — 2026-11-15',section+'## Earlier range-based face-integration feasibility — 2026-11-15')
p='devtools/reference_validator/README.md';replace(p,'The [resumable process route]','''The [four-worker pilot](../../devguide/evidence/reference_validator_four_worker_v1/README.md)
now qualifies selected repeated analytic verification on three original 1.4 Å
Models and 25 existing controls. Its launcher uses lower scheduling priority,
explicit one/two/four CPU limits and unchanged memory/time ceilings. Scientific
results and requests are identical. Four workers remain opt-in at this tested
scope; tiny inputs are faster in serial. Full construction/resume and the
nineteen-profile four-worker panel remain separate.

The [resumable process route]''')
p=base/'README.md';s=get(p);s=s.replace('Status: frozen protocol; qualification follows actual receiving.','''Status: **completed at the selected scope — 2026-11-16 UTC**.
All 52 solve configurations and 28 shared serial reads pass (80 scientific
commands). Every mathematical field and total/per-region request equals its
frozen original. `expansion_decision.json` retains the executed closed-shell
gate: 5.18% median elapsed reduction with four versus two workers, separated
ranges, actual four task workers and sampled niceness 10. It authorizes the
selected dumbbell extension, whose corresponding reduction is 9.46%.

The [matched median/range table](table.md) shows all three fresh repetitions
per mode. Direct serial remains fastest for the tiny tetrahedron. Per-phase
timing and CPU receipts show that geometry/checking limit the total gain; no
linear/general scaling or zero-impact claim is made. The 80 science commands
sum to 2122.669 bounded elapsed / 2431.147 waited CPU seconds, counting each
shared read once. Peak sampled group RSS is 160.33 MiB. Scheduling gaps,
bootstrap, packaging, tests and building are outside those scientific totals.

The initial large-case launch omitted the declared source path and exits before
Model import with `ModuleNotFoundError`; `bootstrap_attempt1_execution.json`
and its raw log are retained beside that protocol. Setting the explicit source
path corrects startup. This 0.117-second pre-calculation failure is excluded
from the successful scientific durations, not used as a comparison baseline.

`receiving.zip` preserves all exact inputs, protocols/working JSON at their
repository-relative paths, the 51-module source and independent reader. Every
byte is verified before removing duplicate working trees. Protocols/resource
records/raw logs remain visible; `receiving_index.json` maps accepted scope and
resources. Source/test/preservation checks are recorded in
`source_qualification.json`; `MANIFEST.json` binds this evidence tree. Exact
drivers are retained before temporary cleanup. The original 355 frozen files
and all prior evidence remain unchanged.

The broader eight-stage plan remains partial. This receives four-worker
analytic verification on selected inputs, without expanding source-construction,
four-worker failure/resume, the full nineteen-profile four-worker panel or
native/public/installed scientific admission. The next source work remains
cost accounting and exact geometric invariant reuse under #76/S1/S3/S5.''');put(p,s)
for p,s in edits.items():p.write_text(s)
print('Reconciled',len(edits),'current records and documentation pages.')
