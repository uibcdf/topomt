import hashlib,json,statistics
from pathlib import Path
base=Path('devguide/evidence/reference_validator_four_worker_v1')
def read(p):return json.loads(Path(p).read_text())
plan=read(base/'plan.json');rows=[r for r in plan['jobs'] if r['phase']=='pilot_large'];times={m:[] for m in ['serial','parallel2','parallel4']};success=True;four_counts=[];observed_priorities=[];input_receipts={}
for row in rows:
    folder=Path(row['protocol']).parent;r=read(folder/'receiving/receipt.json');e=read(folder/'execution.json')
    success=success and e['exit_code']==0 and e['stop_reason'] is None and all(s['host']['safe'] for s in e['samples']) and r['niceness']>=10 and r['precision_status']=='resolved' and r['all_mathematical_fields_equal_original']
    times[row['mode']].append(e['wall_seconds']);pools=read(folder/'receiving/pools.json')
    if row['mode']=='parallel4':
        four_counts.append(max(len(p['worker_records']) for p in pools))
        pids={str(v['pid']) for p in pools for v in p['worker_records']}
        observed_priorities.extend(nice for s in e['samples'] for pid,nice in s.get('process_niceness',{}).items() if pid in pids)
    input_receipts[str(folder/'receiving/receipt.json')]=hashlib.sha256((folder/'receiving/receipt.json').read_bytes()).hexdigest()
row=next(r for r in plan['reads'] if r['phase']=='pilot_large');folder=Path(row['protocol']).parent;r=read(folder/'receiving/receipt.json');e=read(folder/'execution.json');success=success and e['exit_code']==0 and e['stop_reason'] is None and r['all_mathematical_fields_equal_original'] and r['checked_configurations']==9
assert all(len(v)==3 for v in times.values())
medians={m:statistics.median(v) for m,v in times.items()};gain=1-medians['parallel4']/medians['parallel2'];separate=max(times['parallel4'])<min(times['parallel2'])
actual_four=bool(four_counts) and all(v==4 for v in four_counts)
priority_ok=bool(observed_priorities) and min(observed_priorities)>=10
execute=success and actual_four and priority_ok and gain>=plan['conditional_expansion']['median_elapsed_reduction_4_vs_2_minimum'] and separate
out={'owner':'uibcdf/topomt#76','phase':'pilot_large','frozen_criterion':plan['conditional_expansion'],'all_completed_scientific_resource_checks_pass':success,'actual_worker_counts_at_largest_pools':four_counts,'sampled_task_worker_niceness_range':[min(observed_priorities),max(observed_priorities)] if observed_priorities else None,'niceness_gate_pass':priority_ok,'bounded_elapsed_seconds':times,'medians_seconds':medians,'elapsed_reduction_4_vs_2':gain,'max_four_less_than_min_two':separate,'execute_conditional_multiregion':bool(execute),'input_receipts_sha256':input_receipts,'scope':'Three repetitions per mode on one fixed Model, rotating order at lower scheduling priority. Practical expansion gate, not a statistical significance/general scaling claim. A pre-calculation source-path bootstrap failure is retained separately, excluded from successful scientific durations.'}
with (base/'expansion_decision.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps(out))
