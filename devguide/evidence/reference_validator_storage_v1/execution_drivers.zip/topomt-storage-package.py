import ast,hashlib,json,os,subprocess,sys,zipfile
from pathlib import Path
base=Path('devguide/evidence/reference_validator_storage_v1')
source=json.loads((base/'source.json').read_text())
assert len(source)==51 and all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in source.items())
tree=ast.parse(Path('tests/test_reference_validator_storage.py').read_text())
test=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='test_fresh_independent_reader_accepts_each_written_bundle_without_producers')
script=next(n.value.value for n in test.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='script' for t in n.targets))
members={p:Path(p).read_bytes() for p in source};members['devtools/__init__.py']=b'';members['_replay.py']=script.encode()
cases=[]
root=Path('/tmp/topomt-storage-primary-20261115')
for index,name in enumerate(['raw','power','parallel','partition','region','edge']):
    folder=root/f'test_fresh_independent_reader_{index}'
    assert folder.is_dir() and not folder.is_symlink()
    paths=[p for p in folder.rglob('*.json') if p.is_file()]
    assert len(paths) in [3,4]
    for p in paths:members[f'cases/{name}/'+str(p.relative_to(folder))]=p.read_bytes()
    record_names={str(p.relative_to(folder)):len(p.read_bytes()) for p in paths}
    assert max(record_names.values())<=16*1024**2
    cases.append({'name':name,'prefix':f'cases/{name}','record_bytes':record_names})
spec={'schema':'topomt.reference-validator.storage-receiving/1','owner':'uibcdf/topomt#76','source_runtime':sys.version,'record_ceiling_bytes':16*1024**2,'cases':cases,'scientific_scope':'Existing one-ball control with exact Model; raw is storage-only. No original nineteen-profile rerun or new native/public qualification.'}
members['cases.json']=(json.dumps(spec,indent=2)+'\n').encode()
inside={'members':{n:hashlib.sha256(v).hexdigest() for n,v in members.items()},'manifest_excludes_itself':True}
members['MANIFEST.json']=(json.dumps(inside,indent=2)+'\n').encode()
archive=base/'receiving.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert all(z.read(n)==v for n,v in members.items())
    target=Path('/tmp/topomt-storage-capsule-replay-20261115');assert not target.exists();target.mkdir();z.extractall(target)
readers=[]
for row in cases:
    cmd=[sys.executable,'-S',str(target/'_replay.py'),row['name']]
    p=subprocess.run(cmd,cwd=target/row['prefix'],env={**os.environ,'PYTHONPATH':str(target)},capture_output=True,text=True,timeout=15)
    assert p.returncode==0,p.stdout+p.stderr
    readers.append({'name':row['name'],'exit_code':p.returncode,'output':p.stdout,'site_packages':False,'producer_scientific_imports':'blocked'})
out={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'members':{n:hashlib.sha256(v).hexdigest() for n,v in members.items()}}
(base/'capsule_manifest.json').write_text(json.dumps(out,indent=2)+'\n')
(base/'fresh_readers.json').write_text(json.dumps({'source_runtime':sys.version,'readers':readers},indent=2)+'\n')
print(json.dumps({'cases':len(cases),'members':len(members),'fresh_independent_readers':len(readers),'archive_bytes':archive.stat().st_size}))
