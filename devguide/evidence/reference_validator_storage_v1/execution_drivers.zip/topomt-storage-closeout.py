import hashlib,json,re,subprocess,zipfile
from pathlib import Path
from urllib.parse import unquote
base=Path('devguide/evidence/reference_validator_storage_v1')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,v):(base/name).write_text(json.dumps(v,indent=2)+'\n')
source=read(base/'source.json');assert len(source)==51 and all(sha(p)==h for p,h in source.items())
frozen=read('docs/content/benchlab/synthetic/artifacts/six_case_review_v1/protocol.json')['frozen_files']
assert len(frozen)==355 and all(sha(p)==h for p,h in frozen.items())
human='d76f39e77bb54929c2d4a02f55ec04d61534ec09df776d2fe89ef731626a88b5'
assert sha('topomt/_version.py')==human
records={n:read(base/(n+'_execution.json')) for n in ['primary','integration','guards','capsule','docs']}
assert all(e['exit_code']==0 and e['stop_reason'] is None for e in records.values())
assert all(s['host']['safe'] for e in records.values() for s in e['samples'])
for name,count in [('primary',179),('integration',78),('guards',2)]:
    assert str(count)+' passed' in (base/(name+'.log')).read_text()
previous={}
for name in ['reference_validator_parallel_edge_v1','reference_validator_parallel_resume_v1']:
    folder=base.parent/name;m=read(folder/'MANIFEST.json')
    files=m.get('files',m.get('members'))
    assert isinstance(files,dict)
    assert all(sha(folder/p)==h for p,h in files.items())
    previous[name+'/MANIFEST.json']=sha(folder/'MANIFEST.json')
capsule=read(base/'capsule_manifest.json')
assert sha(base/'receiving.zip')==capsule['archive_sha256']
with zipfile.ZipFile(base/'receiving.zip') as z:
    assert set(z.namelist())==set(capsule['members'])
    assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in capsule['members'].items())
    assert all(capsule['members'][p]==h for p,h in source.items())
html=Path('/tmp/topomt-storage-docs-html-20261115/content/benchlab/synthetic/reference_validator_report.html').read_text()
assert 'id="checkpoint-storage-reliability-2026-11-15"' in html
markdown=[Path(p) for p in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines() if p.endswith('.md')]
markdown += [Path('devguide/DFND/reference_validator_storage.md'),base/'README.md']
links=0
for p in markdown:
    for target in re.findall(r'\]\(([^)\s]+)\)',p.read_text()):
        if target.startswith(('#','http:','https:','mailto:','plugin:','app:')):continue
        target=unquote(target.split('#',1)[0].strip('<>'))
        if target:assert (p.parent/target).exists(),(p,target);links+=1
drivers=[Path('/tmp')/('topomt-storage-'+n+'.py') for n in ['safe','package','closeout']]
assert all(p.is_file() for p in drivers)
with zipfile.ZipFile(base/'execution_drivers.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in drivers:z.writestr(p.name,p.read_bytes())
implementation=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert implementation=='7e2b078f3bea1cdefdd0e1d6606c52bb890e688f'
save('source_qualification.json',{
    'owner':'uibcdf/topomt#76','date':'2026-11-15','base_revision':'0ecfd7a268d1d1c0b53e185615ede8f95b5e5f2c','implementation_revision':implementation,
    'source_files':source,'selected_tests':{'total_distinct':259,'disjoint_groups':{'primary':179,'integration':78,'capsule_guards':2},'new_storage_tests':21},
    'checks':{'ruff_check_and_format_python_files':740,'mypy_local_modules':51,'strict_one_cpu_sphinx':'pass; notebook execution disabled; local rendering only','rendered_storage_section':True,'checked_local_markdown_links':links,'report_index':'pass','comparative_findings':'pass; offline only'},
    'receiving':{'routes':['raw','power','parallel','partition','region','edge'],'fresh_capsule_readers':6,'site_packages':False,'producer_scientific_imports':'blocked','actual_limit_bytes':16*1024**2,'one_byte_excess':'reject before destination creation','previous_checkpoint':'unchanged and independently readable'},
    'baseline_failures':{'record':'before.json','expected_exit_code':1,'failed_tests':2,'scope':'Unpaired parallel record size and oversized generic commit manifest'},
    'precise_fix_scope':'Only the parallel writer had 128 MiB vs reader 16 MiB. Serial power/region data already capped but now preflight before creating directories. Subdivision data and all manifests are bounded. No larger/chunked format added.',
    'execution_records':{n:{'path':n+'_execution.json','sha256':sha(base/(n+'_execution.json'))} for n in records},
    'resource_scope':'Successful monitored runs sequential at one allowed logical CPU, 2 GiB per-process AS, finite per-process CPU and external elapsed ceilings; aggregate waited CPU can exceed a per-process ceiling. Five-second group RSS can miss peaks/double-count pages. No memory reservation or speedup claim.',
    'preserved':{'original_frozen_files':frozen,'previous_evidence_manifests':previous,'human_version_sha256':human},
    'resume':'Source-bound work requires its recorded executable/runtime; old capsules preserved. Final mathematical certificates retain their ordinary independent-reader meaning.',
    'deferred':{'uibcdf/topomt#76':'S1/S3/S5, broader S8/P6/P7, full nineteen-profile parallel/four-worker panel; no new native/promoted operators','uibcdf/topomt#60':'Canonical native receiving with #76','uibcdf/topomt#16':'Full suite, remote CI, installed/public/platform/Python-minor qualification and exact-candidate recovery; authorized direct commits use [skip ci]','unchanged_native':['#181','#180','#184','#188']},
    'not_selected':'No new geometry/protein/original external engine, public API, attribution boundary, dependency, Slurm/GPU/multi-machine run or hosted deployment.',
    'execution_drivers':{p.name:sha(p) for p in drivers},
})
save('MANIFEST.json',{'schema':'topomt.reference-validator.storage-evidence/1','manifest_excludes_itself':True,'files':{str(p.relative_to(base)):sha(p) for p in sorted(base.rglob('*')) if p.is_file() and p.name!='MANIFEST.json'}})
print(json.dumps({'source_files':len(source),'original_files_unchanged':len(frozen),'previous_evidence_trees_unchanged':len(previous),'tests':259,'evidence_payloads':len(read(base/'MANIFEST.json')['files'])}))
