
import importlib.abc,json,sys
from pathlib import Path
class Block(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        names=('topomt','numpy','scipy','molsysmt','pyunitwizard','ackredit',
            'devtools.reference_validator.producer',
            'devtools.reference_validator.runs',
            'devtools.reference_validator.power_cells',
            'devtools.reference_validator.power_runs',
            'devtools.reference_validator.parallel_runs',
            'devtools.reference_validator.edge_volume',
            'devtools.reference_validator.edge_tasks',
            'devtools.reference_validator.region_volume',
            'devtools.reference_validator.parallel')
        if any(fullname==n or fullname.startswith(n+'.') for n in names):
            raise ImportError('Producer/scientific import: '+fullname)
sys.meta_path.insert(0,Block())
from devtools.reference_validator import storage
from devtools.reference_validator.model import Model
model=Model.from_record(storage.read_record(Path('model.json')))
folder=Path('saved');kind=sys.argv[1]
if kind=='partition':
    cp,run=storage.load_bundle(folder,model)
    assert cp['performed_splits']==0
elif kind=='region':
    from devtools.reference_validator.verify.region_volume import check_region_volume
    proof=storage.read_record(folder/'certificate.json')
    assert check_region_volume(model,proof)['topology_complete']
else:
    schema={'raw':'test/1','power':'topomt.reference-validator.power-bundle/1',
        'parallel':'topomt.reference-validator.parallel-power-bundle/1',
        'edge':'topomt.reference-validator.edge-work-bundle/1'}[kind]
    proof=storage.read_progress_bundle(folder,schema=schema)
    if kind=='raw':assert proof['integer']==3
    else:
        name={'power':'power_progress','parallel':'parallel_progress',
            'edge':'edge_progress'}[kind]
        mod=__import__('devtools.reference_validator.verify.'+name,fromlist=['check_progress'])
        mod.check_progress(model,proof)
print(kind+' independently checked')
