"""Append-only proof bundles with a checksum manifest published last.

An interrupted/partial directory is rejected. Previous step directories are
never replaced. This is a verified commit-marker protocol, not a guarantee of
filesystem durability against every operating-system or storage failure.
"""

import hashlib
import json
import os
from pathlib import Path
from typing import Any

from .model import Model, _record
from .verify.records import verify_run

_MAX_RECORD_BYTES = 16 * 1024**2


def _encode_record(value: object) -> bytes:
    """Bound encoded JSON, including escapes, indentation and final newline.

    Incremental encoding avoids first materializing the complete output text.
    This is a serialized-record ceiling, not a bound on the caller's input or
    every individual encoder chunk. The external process memory limit remains
    necessary. Preflight all data/manifest records before creating a directory.
    """
    payload = bytearray()
    encoder = json.JSONEncoder(sort_keys=True, indent=2, allow_nan=False)
    for chunk in encoder.iterencode(value):
        encoded = chunk.encode()
        if len(payload) + len(encoded) + 1 > _MAX_RECORD_BYTES:
            raise ValueError('Record exceeds the bounded 16 MiB reader envelope')
        payload.extend(encoded)
    payload.extend(b'\n')
    return bytes(payload)


def _unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f'Duplicate JSON field: {key}')
        result[key] = value
    return result


def _payload(path: Path) -> bytes:
    with path.open('rb') as stream:
        data = stream.read(_MAX_RECORD_BYTES + 1)
    if len(data) > _MAX_RECORD_BYTES:
        raise ValueError('Pilot input exceeds 16 MiB limit')
    return data


def read_record(path: Path) -> Any:
    """Read bounded JSON, rejecting duplicate fields before interpreting it."""
    return read_record_with_digest(path)[0]


def read_record_with_digest(path: Path) -> tuple[Any, str]:
    """Bind the parsed record to the exact bytes that were read once."""
    data = _payload(path)
    return json.loads(data, object_pairs_hook=_unique), hashlib.sha256(data).hexdigest()


def write_progress_bundle(directory: Path, progress: object, *, schema: str) -> None:
    """Exclusively store untrusted proof data with its commit manifest last.

    Parameters
    ----------
    directory : Path
        New destination; existing directories are never replaced.
    progress : object
        JSON proof data. This storage operation makes no geometric claim.
    schema : str
        Consumer-owned bundle schema to bind explicitly.

    Raises
    ------
    ValueError, FileExistsError
        Non-JSON/excessive input or an occupied destination.
    """
    payload = _encode_record(progress)
    manifest = _encode_record(
        {'schema': schema, 'progress_sha256': hashlib.sha256(payload).hexdigest()}
    )
    directory.mkdir(parents=True, exist_ok=False)
    with (directory / 'progress.json').open('xb') as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    with (directory / 'MANIFEST.json').open('xb') as stream:
        stream.write(manifest)
        stream.flush()
        os.fsync(stream.fileno())


def read_progress_bundle(directory: Path, *, schema: str) -> Any:
    """Read the exact checksum-bound bytes without accepting geometric claims.

    Parameters
    ----------
    directory : Path
        Complete manifest-last bundle.
    schema : str
        Exact consumer-owned schema expected by the caller.

    Returns
    -------
    object
        Untrusted JSON proof data; the scientific consumer must check it.

    Raises
    ------
    ValueError
        Missing/changed data, wrong schema or malformed/duplicate JSON fields.
    """
    try:
        manifest = _record(
            read_record(directory / 'MANIFEST.json'), {'schema', 'progress_sha256'}
        )
        record, digest = read_record_with_digest(directory / 'progress.json')
        if manifest['schema'] != schema or manifest['progress_sha256'] != digest:
            raise ValueError('Progress bundle schema or digest differs')
        return record
    except OSError as exc:
        raise ValueError('Incomplete progress bundle') from exc


def save_bundle(directory: Path, model: Model, checkpoint: object, run: object) -> None:
    """Verify and exclusively create a new checkpoint/run bundle.

    The manifest is written after all data files are flushed. Interrupted
    directories stay visible but cannot be loaded as successful checkpoints.
    Existing directories, even empty ones, are not overwritten.
    """
    verify_run(model, run, checkpoint)
    payloads = {
        name: _encode_record(value)
        for name, value in (('checkpoint.json', checkpoint), ('run.json', run))
    }
    files = {n: hashlib.sha256(p).hexdigest() for n, p in payloads.items()}
    manifest = _encode_record(
        {'schema': 'topomt.reference-validator.bundle/1', 'files': files}
    )
    directory.mkdir(parents=True, exist_ok=False)
    for name, payload in payloads.items():
        with (directory / name).open('xb') as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
    with (directory / 'MANIFEST.json').open('xb') as stream:
        stream.write(manifest)
        stream.flush()
        os.fsync(stream.fileno())


def load_bundle(directory: Path, model: Model) -> tuple[dict[str, Any], dict[str, Any]]:
    """Require complete storage integrity and independent proof verification."""
    try:
        manifest = _record(
            read_record(directory / 'MANIFEST.json'), {'schema', 'files'}
        )
        if manifest['schema'] != 'topomt.reference-validator.bundle/1':
            raise ValueError('Unsupported bundle schema')
        files = _record(manifest['files'], {'checkpoint.json', 'run.json'})
        records = {}
        for name, expected in files.items():
            payload = _payload(directory / name)
            if hashlib.sha256(payload).hexdigest() != expected:
                raise ValueError('Incomplete or changed checkpoint bundle')
            # Interpret precisely the bytes whose digest was checked, even if
            # another process later replaces the file in this directory.
            records[name] = json.loads(payload, object_pairs_hook=_unique)
        checkpoint, run = records['checkpoint.json'], records['run.json']
        verify_run(model, run, checkpoint)
        return checkpoint, run
    except OSError as exc:
        raise ValueError('Incomplete checkpoint bundle') from exc
