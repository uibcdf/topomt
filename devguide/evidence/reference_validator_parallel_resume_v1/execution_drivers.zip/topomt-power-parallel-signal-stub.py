import json,os,signal,subprocess,sys,time
from pathlib import Path
child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)'])
requested=[]
def stop(sig,frame):
 requested.append(sig)
signal.signal(signal.SIGTERM,stop)
Path('/tmp/topomt-power-parallel-signal-ready.json').write_text(json.dumps({'parent':os.getpid(),'child':child.pid}))
while child.poll() is None:time.sleep(.02)
child.wait()
raise SystemExit(0 if requested else 1)
