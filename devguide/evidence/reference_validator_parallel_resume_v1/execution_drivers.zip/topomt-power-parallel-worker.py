import hashlib,json,os,resource,sys,time
from pathlib import Path
mode,protocol_path,output= sys.argv[1],Path(sys.argv[2]),Path(sys.argv[3])
if mode=='verify':
 import importlib.abc
 class Block(importlib.abc.MetaPathFinder):
  def find_spec(self,fullname,path=None,target=None):
   names=('topomt','numpy','scipy','molsysmt','devtools.reference_validator.parallel','devtools.reference_validator.parallel_runs','devtools.reference_validator.power_cells')
   if any(fullname==n or fullname.startswith(n+'.') for n in names):raise ImportError('Producer/scientific import: '+fullname)
 sys.meta_path.insert(0,Block())
from devtools.reference_validator.model import Model,record_digest
from devtools.reference_validator.performance import Measurements
from devtools.reference_validator.verify import verify

def write(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if __name__=='__main__':
 spec=json.loads(protocol_path.read_text());root=Path.cwd()
 for name,digest in spec['source_files'].items():assert sha(root/name)==digest,name
 assert len(os.sched_getaffinity(0))==spec['workers']
 output.mkdir(parents=True,exist_ok=True)
 started=time.monotonic();measure=Measurements();parent_cpu=time.process_time()
 model=measure.run('read_and_check_model',lambda:Model.from_record(spec['model']))
 assert model.digest==spec['model_sha256']
 if mode=='verify':
  proof=json.loads((output/'complete_certificate.json').read_text())
  result=measure.run('fresh_independent_serial_read',lambda:verify(model,proof))
  write(output/'fresh_verification.json',result)
 else:
  from devtools.reference_validator.parallel import LocalPolicy
  from devtools.reference_validator.parallel_runs import ParallelPowerSession,load_parallel_power_bundle
  policy=LocalPolicy(workers=spec['workers'],worker_cpu_seconds=120)
  if mode=='partial':
   session=measure.run('initialize_session',lambda:ParallelPowerSession(model))
   partial=measure.run('bounded_partial_work_and_checkpoints',lambda:session.advance(cell_budget=128,policy=policy,stop=lambda:len(session.snapshot['cells'])>=2,checkpoint_root=output/'checkpoints'))
   assert partial['stop_reason']=='cancelled' and len(partial['cells'])==2
   measure.run('save_cancelled_work',lambda:session.save(output/'partial_cancelled'))
   write(output/'partial_model.json',model.to_record())
  elif mode=='resume':
   partial=measure.run('load_and_check_partial',lambda:load_parallel_power_bundle(output/'partial_cancelled',model))
   session=measure.run('initialize_resumed_session',lambda:ParallelPowerSession(model,progress=partial))
   remaining_steps=[]
   while len(session.snapshot['cells']) < max(1,len(model.atoms)):
    before=len(session.snapshot['cells'])
    try:
     resumed=measure.run(f'remaining_source_work_{before:04d}',lambda:session.advance(cell_budget=4,policy=policy))
    except Exception:
     session.save(output/f'failed_cells_{len(session.snapshot["cells"]):04d}')
     raise
    measure.run(f'save_progress_{before:04d}',lambda:session.save(output/'chunks'/f'cells_{len(resumed["cells"]):04d}'))
    remaining_steps.append(session.execution)
   write(output/'chunk_pools.json',remaining_steps)
   assert resumed['stop_reason']=='cells_complete'
   measure.run('save_complete_cells',lambda:session.save(output/'complete_cells'))
   proof=measure.run('canonical_assembly_and_final_serial_check',session.finish)
   expected=json.loads((root/spec['expected_certificate']).read_text())
   assert sha(root/spec['expected_certificate'])==spec['expected_certificate_sha256']
   assert proof==expected
   measure.run('save_complete_certificate',lambda:write(output/'complete_certificate.json',proof))
  else:raise ValueError('Unknown phase')
  execution=session.execution
  write(output/(mode+'_pool.json'),execution)
 receipt={'mode':mode,'protocol_sha256':sha(protocol_path),'model_sha256':model.digest,'workers':spec['workers'],'phase_measurements':measure.to_record(),'wall_seconds':time.monotonic()-started,'parent_cpu_seconds':time.process_time()-parent_cpu,'waited_children_cpu_seconds':sum((resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime,resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime)),'peak_parent_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'peak_child_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'canonical_proof_matches_original':mode in ['resume','verify'],'source_files':spec['source_files']}
 if mode=='verify':receipt.update(n_components=result['n_components'],n_boundary_patches=result['n_boundary_patches'])
 write(output/(mode+'_receipt.json'),receipt)
 print(json.dumps({k:receipt[k] for k in ['mode','workers','wall_seconds','parent_cpu_seconds','waited_children_cpu_seconds']}),flush=True)
