import hashlib,json,shutil,zipfile
from pathlib import Path
base=Path('devguide/evidence/reference_validator_parallel_resume_v1')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
active=read(base/'plan_final.json')['jobs']
source=read(base/'source.json');assert all(sha(n)==h for n,h in source.items())
rows=[];members={};table=[]
for name in source:members[name]=Path(name).read_bytes()
members['devtools/__init__.py']=b''
for job in active:
 p=Path(job['protocol']);spec=read(p);folder=p.parent;rec=folder/'receiving';prefix=str(rec.relative_to(base))
 assert sha(p)==job['protocol_sha256']
 receipts={mode:read(rec/(mode+'_receipt.json')) for mode in ['partial','resume','verify']}
 executions={mode:read(folder/(mode+'_execution.json')) for mode in receipts}
 assert all(r['exit_code']==0 and r['stop_reason'] is None for r in executions.values())
 assert all(s['host']['safe'] for r in executions.values() for s in r['samples'])
 assert all(r['protocol_sha256']==sha(p) for r in receipts.values())
 phases=[phase for r in receipts.values() for phase in r['phase_measurements']['phases'].values()]
 childsum=sum(v['waited_children_cpu_seconds'] for v in phases)
 waited=sum(v['waited_children_cpu_seconds'] for v in receipts.values())
 assert abs(childsum-waited)<1e-7
 assert read(rec/'complete_certificate.json')==read(spec['expected_certificate'])
 row={'case':spec['case'],'workers':spec['workers'],'protocol':str(p),'protocol_sha256':sha(p),'receiving_prefix':prefix,'model_sha256':spec['model_sha256'],'n_components':receipts['verify']['n_components'],'n_boundary_patches':receipts['verify']['n_boundary_patches'],'worker_wall_seconds':sum(r['wall_seconds'] for r in receipts.values()),'bounded_wall_seconds':sum(r['wall_seconds'] for r in executions.values()),'parent_cpu_seconds':sum(r['parent_cpu_seconds'] for r in receipts.values()),'waited_children_cpu_seconds':waited,'fresh_read_wall_seconds':receipts['verify']['wall_seconds'],'resume_phase_wall_seconds':receipts['resume']['wall_seconds'],'sampled_group_rss_peak_kib':max(r['sampled_group_rss_peak_kib'] for r in executions.values()),'peak_individual_rss_kib':max(r['peak_child_rss_kib'] for r in executions.values()),'phase_cpu_reconciles':True,'single_observation':True}
 rows.append(row)
 members['models/'+spec['case']+'.json']=(json.dumps(spec['model'],indent=2)+'\n').encode()
 table.append(f"| `{spec['case']}` | {spec['workers']} | {row['worker_wall_seconds']:.3f} | {row['bounded_wall_seconds']:.3f} | {row['parent_cpu_seconds']:.3f} | {waited:.3f} | {row['sampled_group_rss_peak_kib']/1024:.2f} |")
# Retain all working JSON bytes, including each intermediate checkpoint and the failed pilot.
working=[]
for p in sorted(base.rglob('*')):
 if p.is_file() and 'receiving' in p.relative_to(base).parts:
  assert p.suffix=='.json',str(p)
  name=str(p.relative_to(base));members[name]=p.read_bytes();working.append((p,name))
inside={'schema':'topomt.reference-validator.parallel-capsule/1','manifest_excludes_itself':True,'members':{n:hashlib.sha256(d).hexdigest() for n,d in members.items()}}
members['MANIFEST.json']=(json.dumps(inside,indent=2)+'\n').encode()
archive=base/'receiving.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,data in sorted(members.items()):z.writestr(n,data)
manifest={'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':{n:hashlib.sha256(d).hexdigest() for n,d in members.items()}}
(base/'capsule_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 for p,name in working:assert hashlib.sha256(z.read(name)).hexdigest()==sha(p)
index={'owner':'uibcdf/topomt#76','source_files':source,'archive':'receiving.zip','archive_sha256':sha(archive),'member_paths_relative_to':'receiving.zip','jobs':rows,'retention':'Every working receiving JSON, including intermediate checkpoints and failed-pilot partials, is retained byte-for-byte at its original evidence-relative path in receiving.zip. No working data is discarded before archive verification. Inputs and earlier evidence are unchanged.'}
(base/'receiving_index.json').write_text(json.dumps(index,indent=2)+'\n')
(base/'table.md').write_text('| Original 1.4 A Model | Workers | Worker wall s | Bounded elapsed s | Parent CPU s | Waited child CPU s | Sampled group RSS MiB |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: |\n'+'\n'.join(table)+'\n')
comparisons=[]
for case in sorted({r['case'] for r in rows}):
 a,b=sorted([r for r in rows if r['case']==case],key=lambda r:r['workers']);ratio=a['bounded_wall_seconds']/b['bounded_wall_seconds'];comparisons.append({'case':case,'bounded_elapsed_ratio_T1_over_T2':ratio,'capacity_efficiency_T1_over_2T2':ratio/2,'scope':'Same checkpoint/resume/final-check/fresh-read workflow; one observation per configuration. One worker uses a spawned pool, not the direct serial constructor. No repeatable/general scaling claim.'})
(base/'comparisons.json').write_text(json.dumps(comparisons,indent=2)+'\n')
for rec in sorted({p.parent for p,name in working if p.name=='partial_model.json'},key=str):
 assert rec.name=='receiving' and str(rec).startswith(str(base)+'/')
 shutil.rmtree(rec)
print(json.dumps({'jobs':len(rows),'retained_working_files':len(working),'archive_bytes':manifest['archive_bytes'],'comparisons':comparisons}))
