import hashlib,json,re,subprocess,zipfile
from pathlib import Path
from urllib.parse import unquote
base=Path('devguide/evidence/reference_validator_parallel_resume_v1')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
source=read(base/'source.json');assert len(source)==49 and all(sha(p)==h for p,h in source.items())
frozen=read('docs/content/benchlab/synthetic/artifacts/six_case_review_v1/protocol.json')['frozen_files'];assert len(frozen)==355 and all(sha(p)==h for p,h in frozen.items())
assert sha('topomt/_version.py')=='d76f39e77bb54929c2d4a02f55ec04d61534ec09df776d2fe89ef731626a88b5'
for n in ['final_tests','docs','package','cost']:
 r=read(base/(n+'_execution.json'));assert r['exit_code']==0 and r['stop_reason'] is None
assert read(base/'launcher_signal_check.json')['child_and_descendant_ceased']
html=Path('/tmp/topomt-power-parallel-docs-html/content/benchlab/synthetic/reference_validator_report.html').read_text();assert 'id="reference-validator-resume"' in html
links=0
paths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+[str(base/'README.md'),'devguide/DFND/reference_validator_parallel_resume.md']
for name in paths:
 p=Path(name)
 if p.suffix!='.md':continue
 for target in re.findall(r'\]\(([^)\s]+)',p.read_text()):
  if re.match(r'^[a-z]+:',target) or target.startswith(('#','<')):continue
  assert (p.parent/unquote(target.split('#')[0])).exists(),(name,target)
  links+=1
with zipfile.ZipFile(base/'execution_drivers.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name in ['safe','case-safe','worker','panel','docs','package','cost','signal-check','signal-stub','closeout']:
  p=Path('/tmp/topomt-power-parallel-'+name+'.py')
  if p.exists():z.write(p,p.name)
qualification={'schema':'topomt.reference-validator.parallel-qualification/1','owner':'uibcdf/topomt#76','base_revision':'cd070465dda593635475935572432ae6eaa8f2c2','implementation_revision':'b2e67ba5e3df945a3ec7e8771c62f268b80d19a4','source_files':source,'original_frozen_files_unchanged':355,'human_version_edit_unchanged':True,'actual_models':['regular_tetrahedron','closed_shell','dumbbell'],'probe_angstrom':1.4,'worker_configurations':[1,2],'actual_complete_configurations':6,'all_final_certificates_equal_originals':True,'all_new_fresh_serial_reads_accepted':True,'selected_tests':115,'pytest_receiving_without_site_packages_or_producers':True,'ruff_check':True,'ruff_format_check':True,'mypy_modules':49,'devguide_index_check':True,'comparative_findings_offline_check':True,'strict_one_cpu_sphinx':True,'rendered_resume_anchor_checked':True,'local_markdown_targets_checked':links,'source_files_unchanged_since_receiving':49,'capsule_sha256':sha(base/'receiving.zip'),'capsule_bytes':(base/'receiving.zip').stat().st_size,'source_workflows':'Full atom constraints, independent local cell checking, source-bound non-prefix progress, manifest-last storage, fresh-process resume, final canonical assembly/full serial checker, then producer-free saved read.','launcher_signal_forwarding_test':read(base/'launcher_signal_check.json'),'operational_history':'Retain initial import-path failure, unchunked BrokenProcessPool and interrupted/overlapping launcher attempts. Old overlapping event-to-record attribution is partial: an unlinked log tail and an overwritten record are unavailable. These timings are excluded. Isolated completed workflows are fully bound; subsequent launches propagate signals to their owned groups.','support_boundary':'Standard-library independent developer bootstrap. No original external scientific engine executed; no new production attribution/quantity/dependency API admitted.','deferred':'Full suite and remote CI, Python 3.11-3.13 runtime/platform/installed #16, full parallel 19-profile/four-worker panel, S7 analytic integration, remaining S1/S3/S5 and broader S8/P6/P7 remain open. Authorized direct commits carry [skip ci]. #76/#60 native canonical receiving and native #181/#180/#184/#188 retain their scopes.','scope':'S6 controlled failure/recovery and selected three-Model source qualification; no native DFND correction, universal exactness, general scaling or public detector claim.'}
(base/'source_qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
manifest={'schema':'topomt.reference-validator.parallel-evidence-manifest/1','manifest_excludes_itself':True,'files':{str(p.relative_to(base)):sha(p) for p in sorted(base.rglob('*')) if p.is_file() and p!=base/'MANIFEST.json'}}
(base/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'source_files':49,'original_files':355,'link_targets':links,'evidence_files':len(manifest['files']),'capsule_bytes':qualification['capsule_bytes']}))
