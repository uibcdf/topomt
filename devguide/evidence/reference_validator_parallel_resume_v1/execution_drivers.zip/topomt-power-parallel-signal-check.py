import json,os,signal,subprocess,sys,time
from pathlib import Path
base=Path('devguide/evidence/reference_validator_parallel_resume_v1')
stub=Path('/tmp/topomt-power-parallel-signal-stub.py');ready=Path('/tmp/topomt-power-parallel-signal-ready.json')
stub.write_text('''import json,os,signal,subprocess,sys,time
from pathlib import Path
child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)'])
requested=[]
def stop(sig,frame):
 requested.append(sig)
signal.signal(signal.SIGTERM,stop)
Path('/tmp/topomt-power-parallel-signal-ready.json').write_text(json.dumps({'parent':os.getpid(),'child':child.pid}))
while child.poll() is None:time.sleep(.02)
child.wait()
raise SystemExit(0 if requested else 1)
''')
manager=subprocess.Popen([sys.executable,'/tmp/topomt-power-parallel-safe.py','--record',str(base/'launcher_signal_execution.json'),'--log',str(base/'launcher_signal_execution.log'),'--',sys.executable,str(stub)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
started=time.monotonic()
while not ready.exists():
 assert time.monotonic()-started<5
 time.sleep(.02)
pids=json.loads(ready.read_text());os.kill(manager.pid,signal.SIGTERM)
output=manager.communicate(timeout=8)[0];assert manager.returncode==143,(manager.returncode,output)
for pid in pids.values():
 p=Path(f'/proc/{pid}/stat')
 assert not p.exists() or p.read_text().rsplit(')',1)[1].split()[0]=='Z',pid
record=json.loads((base/'launcher_signal_execution.json').read_text());assert record['stop_reason']=='caller_signal_15'
(base/'launcher_signal_check.json').write_text(json.dumps({'caller_returncode':manager.returncode,'child_and_descendant_ceased':True,'stop_reason':record['stop_reason'],'scope':'Task launcher only: SIGTERM forwarded to the owned command process group, including its descendant. No unrelated processes addressed.'},indent=2)+'\n')
print(output,flush=True)
