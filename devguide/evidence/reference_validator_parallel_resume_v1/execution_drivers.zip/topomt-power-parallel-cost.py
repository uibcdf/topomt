import json,time
from pathlib import Path
from devtools.reference_validator.model import Model
from devtools.reference_validator.performance import Measurements
from devtools.reference_validator.power_cells import propose_cell
from devtools.reference_validator.verify.power_cells import checked_cells
from devtools.reference_validator.power_contracts import PowerLimits
base=Path('devguide/evidence/reference_validator_parallel_resume_v1')
spec=json.loads((base/'closed_shell/workers_1_retry/protocol.json').read_text())
plain=Measurements();model=plain.run('model',lambda:Model.from_record(spec['model']))
owner=min(model.atoms,key=lambda a:a.source_id)
profiled=Measurements(profile=True);row=profiled.run('one_cold_source_proposal',lambda:propose_cell(model,owner))
plain.run('independent_local_check',lambda:checked_cells(model,[row],limits=PowerLimits(),complete=False,offset=0))
assert row==json.loads(Path(spec['expected_certificate']).read_text())['cells'][0]
record={'owner':'uibcdf/topomt#76','model_sha256':model.digest,'source_files':spec['source_files'],'source_index':0,'unprofiled':plain.to_record(),'profiled':profiled.to_record(),'scope':'Separate one-cell cost isolation with profiler overhead, not a timing denominator or full-analysis speedup. Original full Model/constraints; local checked proposal equals original saved source cell.'}
(base/'one_cell_cost_profile.json').write_text(json.dumps(record,indent=2)+'\n')
calls=record['profiled']['phases']['one_cold_source_proposal']['calls']
print(json.dumps(sorted(calls,key=lambda r:r['exclusive_seconds'],reverse=True)[:10],indent=2))
