from pathlib import Path

def replace(path,old,new):
 p=Path(path);s=p.read_text();assert old in s,(path,old[:60]);p.write_text(s.replace(old,new,1))
def before(path,marker,insert):replace(path,marker,insert+'\n'+marker)

before('devtools/reference_validator/README.md','The opt-in developer `parallel` module', '''The [resumable process route](../../devguide/DFND/reference_validator_parallel_resume.md)
adds `parallel_runs.ParallelPowerSession`. It retains independently checked
source tasks in any completion order, saves exclusive manifest-last bundles and
rechecks every saved task on loading. A partial inventory has no global count;
`finish()` assembles all cells canonically and runs the full serial checker.
Pool failure preserves accepted work and propagates the error. Use small
explicit cell budgets and durable checkpoints for longer inputs: child CPU
ceilings apply over a pool's lifetime. One worker remains the default.
''')
replace('devtools/reference_validator/README.md', '''Durable partial
parallel resume, full failure/panel qualification and four workers remain open.''', '''The newer resumable route qualifies retained partial work, failure controls
and selected original one/two-worker receiving. Four workers and the full
parallel panel remain open. The older boundary-range route does not acquire
these capabilities or qualify S7 analytic parallel integration.''')
before('devguide/DFND/reference_validator_performance_plan.md','### Current serial precision receiving', '''### Resumable source-cell receiving — 2026-11-15

The [local source-work route](reference_validator_parallel_resume.md) adds exact
per-task binding, bounded completion-order collection, cooperative stopping,
manifest-last checkpoints and independent reconstruction on resume. The
[versioned receiving](../evidence/reference_validator_parallel_resume_v1/README.md)
compares one/two-worker checkpoint/resume workflows on original tetrahedron,
closed-shell and dumbbell 1.4 Å Models. Final canonical proofs match the original
certificates and receive a further producer-free serial read. Unit controls
inject child failure, malformed/duplicate tasks, storage corruption and nesting.

An initial unchunked shell pool fails near its worker CPU ceiling; its observed
`BrokenProcessPool` and raw resource evidence remain retained without inventing
an exit signal. Longer receiving uses four-cell pools and checkpoints between
them. Worker CPU ceilings are retained; the external phase deadline is finite.
These are scoped observations, not full nineteen-profile or four-worker admission.
S1 retains fuller cost/repeatability work; S7 analytic parallel integration and
broader S8 remain open. Source allocation, completion, precision and operational
failure remain separate outcomes.
''')
replace('devguide/DFND/reference_validator_performance_plan.md', 'Prototype; full fault/resume/panel qualification pending', 'Delivered for controlled failures/resume and three original one/two-worker Models; full parallel panel/four workers separate')
replace('devguide/DFND/reference_validator_performance_plan.md', '| S6 | `power_runs.py`, `capture_power_cells.py`; bounded orchestration | `test_reference_validator_power_resume.py`, `test_reference_validator_power_capture.py`; add focused process/failure tests |', '| S6 | `parallel.py`, `parallel_runs.py`, `verify/parallel_progress.py`; retain serial power runs | `test_reference_validator_parallel_resume.py`, `test_reference_validator_parallel_receiving.py` and original power controls |')
before('devguide/DFND/reference_validator_checkpoint.md','## Original total and region precision completed', '''## Resumable local source work — 2026-11-15

The [S6 source route](reference_validator_parallel_resume.md) now preserves
independently checked, source-bound cells across completion-order differences,
cooperative stop, child failure and durable resume. No partial inventory claims
global topology. Final exhaustive serial checking remains mandatory; the
ordinary saved reader is unchanged. Default execution uses one worker.

The [new receiving](../evidence/reference_validator_parallel_resume_v1/README.md)
retains one/two-worker interrupted workflows on the original tetrahedron,
closed-shell and dumbbell 1.4 Å Models. All final mathematical proofs match their
original certificates and pass a new producer-free saved read. An earlier pool
failure and the finite-resource/chunking correction are preserved. Source/kernel
identity, all constraints and original evidence stay explicit. This S6 scope
is separate from full parallel nineteen-profile admission, S7 analytic integration,
S1/S3/S5 follow-up and broader P6/P7. Original serial volume precision remains
qualified by the separate receiving below. Native #181/#180/#184/#188 and
canonical native receiving #76/#60 retain their own gates.
''')
before('devguide/pending_proposals/dfnd_reference_validation_panel.md','## Current disposition: original precision completed', '''## Current continuation: resumable local source work — 2026-11-15

The [S6 route](../DFND/reference_validator_parallel_resume.md) and
[receiving](../evidence/reference_validator_parallel_resume_v1/README.md) add
stable checked source tasks, durable out-of-order progress, failure/cancellation
controls and fresh-process resume. One/two-worker workflows on three original
1.4 Å Models preserve the exact canonical topology certificates and pass an
additional producer-free saved read. An initial pool failure and its finite
four-cell continuation are retained; no failed task implies an empty cell.

S6 is qualified at that controlled/three-Model scope. #76 remains partial/open
for the full parallel panel, S7 analytic integration, other performance gates,
canonical native receiving #60 and broader public/installed admission. The
nineteen-profile serial precision result below is unchanged. Native
#181/#180/#184/#188 are not resolved by this operational delivery.
''')
before('devguide/DFND/notebook_laboratory_checkpoint.md','## Original topology and requested volume precision', '''## Resumable reference construction — 2026-11-15 UTC

The [source-work receiving](../evidence/reference_validator_parallel_resume_v1/README.md)
adds bounded one/two-worker interruption, checked task persistence and independent
fresh-process resume on three existing original 1.4 Å Models. Complete final
proofs match the original topology certificates and pass the separate saved
reader. Partial work has no global region count. Four workers, the complete
parallel panel and S7 analytic integration remain unqualified. This changes
execution/recovery, not the original geometry, nineteen-profile serial volume
results or native DFND/public policy. Use the
[performance plan](reference_validator_performance_plan.md) and active validator
checkpoint for current scope; #76/#60/#181 retain their scientific owners.
''')
before('devguide/DFND/reference_validator_improvement_workplan.md','### Next executable work under #76', '''The subsequent [resumable source route](reference_validator_parallel_resume.md)
qualifies S6's controlled task/failure/recovery contract on three original
one/two-worker Models. It preserves original canonical topology proofs and serial
volume results. Full parallel panel and S7/S8 admission remain separate.
''')
