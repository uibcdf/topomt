import hashlib,json,os,subprocess,sys
from pathlib import Path
base=Path('devguide/evidence/reference_validator_parallel_resume_v1');plan=json.loads((base/'plan.json').read_text());rows=[]
for job in plan['jobs']:
 protocol=Path(job['protocol']);spec=json.loads(protocol.read_text());output=protocol.parent/'receiving'
 assert hashlib.sha256(protocol.read_bytes()).hexdigest()==job['protocol_sha256']
 assert hashlib.sha256(Path('/tmp/topomt-power-parallel-worker.py').read_bytes()).hexdigest()==spec['worker_script_sha256']
 for mode in ['partial','resume','verify']:
  print('START',spec['case'],spec['workers'],mode,flush=True)
  command=[sys.executable,'/tmp/topomt-power-parallel-case-safe.py','--cpus',str(spec['workers']),'--record',str(protocol.parent/(mode+'_execution.json')),'--log',str(protocol.parent/(mode+'_execution.log')),'--',sys.executable,'/tmp/topomt-power-parallel-worker.py',mode,str(protocol),str(output)]
  run=subprocess.run(command,timeout=450,env={**os.environ,'PYTHONPATH':str(Path.cwd())})
  row={'case':spec['case'],'workers':spec['workers'],'mode':mode,'exit_code':run.returncode,'execution':str(protocol.parent/(mode+'_execution.json'))};rows.append(row)
  (base/'panel_execution.json').write_text(json.dumps(rows,indent=2)+'\n')
  if run.returncode:
   print('STOP',row,flush=True);raise SystemExit(run.returncode)
  print('PASS',spec['case'],spec['workers'],mode,flush=True)
