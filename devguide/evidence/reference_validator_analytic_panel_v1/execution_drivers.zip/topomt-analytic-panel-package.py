import hashlib,json,shutil,statistics,zipfile
from pathlib import Path
from devtools.reference_validator.model import decode_scalar
base=Path('devguide/evidence/reference_validator_analytic_panel_v1')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
    with Path(p).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
plan=read(base/'plan.json');assert len(plan['jobs'])==92 and len(plan['reads'])==44
assert all(sha(p)==h for p,h in plan['source_files'].items())
def result(row):return read(Path(row['protocol']).parent/'receiving/verification.json')
def scientific(v):return {k:x for k,x in v.items() if k not in ['verifier_files_sha256','python_version']}
configs=[];reads=[];all_executions=[]
for row in plan['jobs']+plan['reads']:
    p=Path(row['protocol']);assert sha(p)==row['sha256'];spec=read(p)
    for v in spec['inputs'].values():assert sha(v['path'])==v['sha256']
    folder=p.parent/'receiving';r=read(folder/'receipt.json');e=read(p.parent/'execution.json')
    assert e['exit_code']==0 and e['stop_reason'] is None and all(s['host']['safe'] for s in e['samples'])
    assert r['precision_status']=='resolved' and scientific(result(row))==scientific(read(spec['inputs']['reference']['path']))
    for n,h in r['files'].items():assert sha(folder/n)==h
    phases=r['measurements']['phases'];assert all(not v['failed'] for v in phases.values())
    entry={**row,'receiving_prefix':str(folder),'model_sha256':r['model_sha256'],'n_components':r['n_components'],'face_piece_count':r['face_piece_count'],'precision_status':r['precision_status'],'bounded_wall_seconds':e['wall_seconds'],'worker_wall_seconds':r['wall_seconds'],'waited_cpu_seconds':e['waited_cpu_seconds'],'parent_phase_cpu_seconds':sum(v['cpu_seconds'] for v in phases.values()),'waited_children_phase_cpu_seconds':sum(v['waited_children_cpu_seconds'] for v in phases.values()),'sampled_group_rss_peak_kib':e['sampled_group_rss_peak_kib'],'peak_individual_rss_kib':e['peak_child_rss_kib'],'all_mathematical_fields_equal_original':True}
    if 'mode' in row:
        entry['numerical_task_wall_seconds']=sum(v['wall_seconds'] for n,v in phases.items() if n.startswith('integrate_after_'))
        entry['topology_and_frontier_wall_seconds']=phases['admit_complete_topology_and_frontier']['wall_seconds']
        pools=read(folder/'pools.json');entry['actual_numerical_worker_counts']=sorted({v['worker_count'] for v in pools if 'worker_count' in v})
        if row['mode']=='parallel2' and entry['face_piece_count']>0:assert entry['actual_numerical_worker_counts']==[2]
        if entry['face_piece_count']==0:assert pools==[]
        configs.append(entry)
    else:
        assert r['checked_configurations']==len(spec['configurations']);reads.append(entry)
    all_executions.append(e)
originals=[];tables=[];repeat_rows=[]
for row in [v for v in reads if v['category']=='original']:
    name=row['name'];rr=[v for v in configs if v['name']==name]
    serial=[v for v in rr if v['mode']=='serial'];parallel=[v for v in rr if v['mode']=='parallel2']
    spec=read(row['protocol']);probe=decode_scalar(read(spec['inputs']['model']['path'])['probe'])
    rec={'name':name,'probe_angstrom_approx':float(probe*10),'n_components':row['n_components'],'precision_status':row['precision_status'],'serial_repeats':len(serial),'parallel_repeats':len(parallel),'serial_bounded_wall_median_seconds':statistics.median(v['bounded_wall_seconds'] for v in serial),'parallel_bounded_wall_median_seconds':statistics.median(v['bounded_wall_seconds'] for v in parallel),'shared_serial_read_bounded_wall_seconds':row['bounded_wall_seconds'],'serial_numerical_wall_median_seconds':statistics.median(v['numerical_task_wall_seconds'] for v in serial),'parallel_numerical_wall_median_seconds':statistics.median(v['numerical_task_wall_seconds'] for v in parallel),'same_work_solve_elapsed_ratio':statistics.median(v['bounded_wall_seconds'] for v in serial)/statistics.median(v['bounded_wall_seconds'] for v in parallel),'scope':'Matched cold solve/saving workflow; shared independent reading reported once, separately. Larger profiles one observation per mode; no general/repeatable scaling claim.'}
    originals.append(rec)
    tables.append(f"| `{name.split('/')[1]}` | {float(probe*10):g} | {row['n_components']} | {rec['serial_bounded_wall_median_seconds']:.3f} | {rec['parallel_bounded_wall_median_seconds']:.3f} | {row['bounded_wall_seconds']:.3f} |")
    if len(serial)>1:
        repeat_rows.append({'name':name,'serial_solve_bounded_seconds':[v['bounded_wall_seconds'] for v in serial],'parallel_solve_bounded_seconds':[v['bounded_wall_seconds'] for v in parallel],'scope':'Three fresh tiny-profile observations per mode; representative of process overhead, not broader scaling.'})
assert len(originals)==19 and sum(r['n_components']>0 for r in originals)==13 and sum(r['n_components'] for r in originals)==16
write(base/'receiving_index.json',{'owner':'uibcdf/topomt#76','date':'2026-11-16 UTC','original_profiles':19,'analytic_controls':25,'solve_configurations':92,'shared_saved_reads':44,'source_generation_reexecuted':False,'general_scaling_claim':False,'default_mode':'serial','source_files':plan['source_files'],'originals':originals,'configurations':configs,'reads':reads,'tiny_repeated_profile':repeat_rows,'all_commands_bounded_wall_seconds':sum(e['wall_seconds'] for e in all_executions),'all_commands_waited_cpu_seconds':sum(e['waited_cpu_seconds'] for e in all_executions),'peak_sampled_group_rss_kib':max(e['sampled_group_rss_peak_kib'] for e in all_executions),'peak_individual_rss_kib':max(e['peak_child_rss_kib'] for e in all_executions),'resource_scope':'Aggregate bounded command wall/CPU includes controls and all shared reads once, excludes queue gaps/source freeze/packaging/tests. RSS samples can miss peaks/double-count shared pages; tiny runs do not resolve pool memory.'})
(base/'table.md').write_text('| Original case | Probe Å | Regions | Serial cold solve s | Two-worker cold solve s | Shared further serial read s |\n| --- | ---: | ---: | ---: | ---: | ---: |\n'+'\n'.join(tables)+'\n\nSolve times include exact reading, independent complete geometry/frontier, all certified arithmetic, saving and bounded launcher overhead. Shared reading is executed once per profile and checks every configuration; it is not duplicated in the aggregate. Only tetrahedron 1.4 Å has three fresh repetitions per mode (table shows medians); all larger entries are single shared-host observations. Exact exclusions do not launch numerical workers. Probe labels are rounded Å display values of unchanged exact nm Models. Serial remains the default.\n')
files={p.as_posix():p for p in sorted(base.rglob('*.json')) if p.name not in ['capsule_manifest.json','receiving_index.json'] and p.name!='source.json' and p.name!='plan.json'}
members={}
archive=base/'receiving.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in {**{p:Path(p) for p in plan['source_files']},**files}.items():
        data=path.read_bytes();z.writestr(name,data);members[name]=hashlib.sha256(data).hexdigest()
    for name,path in [('drivers/worker.py',Path('/tmp/topomt-analytic-panel-worker.py'))]:
        data=path.read_bytes();z.writestr(name,data);members[name]=hashlib.sha256(data).hexdigest()
    z.writestr('devtools/__init__.py',b'');members['devtools/__init__.py']=hashlib.sha256(b'').hexdigest()
    inside=(json.dumps({'members':members,'manifest_excludes_itself':True},indent=2)+'\n').encode();z.writestr('MANIFEST.json',inside);members['MANIFEST.json']=hashlib.sha256(inside).hexdigest()
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(members)
    for n,h in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
write(base/'capsule_manifest.json',{'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':members})
# Remove only verified duplicate working JSON; protocols/execution records stay visible.
for p in [base/'inputs']+[Path(v['protocol']).parent/'receiving' for v in plan['jobs']+plan['reads']]:
    assert p.is_dir() and p.is_relative_to(base)
    for f in p.rglob('*'):
        if f.is_file():assert f.as_posix() in members and sha(f)==members[f.as_posix()]
    shutil.rmtree(p)
print(json.dumps({'original_profiles':len(originals),'solve_configurations':len(configs),'shared_reads':len(reads),'archive_members':len(members),'archive_bytes':archive.stat().st_size}))
