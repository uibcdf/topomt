import argparse,json,os,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--name');p.add_argument('--mode',choices=['serial','parallel2']);p.add_argument('--stage',choices=['solve','read'],default='solve');p.add_argument('--repeat',type=int,default=0);p.add_argument('--pilot',action='store_true');a=p.parse_args()
plan=json.loads(Path('devguide/evidence/reference_validator_analytic_panel_v1/plan.json').read_text())
def run(row,stage):
    protocol=Path(row['protocol']);spec=json.loads(protocol.read_text())
    cmd=[sys.executable,'/tmp/topomt-analytic-panel-safe.py','--cpus',str(spec['cpus']),'--record',str(protocol.parent/'execution.json'),'--log',str(protocol.parent/'execution.log'),'--',sys.executable,'-S','/tmp/topomt-analytic-panel-worker.py',stage,str(protocol),str(protocol.parent/'receiving')]
    print('START',spec['name'],spec['mode'],stage,flush=True)
    r=subprocess.run(cmd,env={**os.environ,'PYTHONPATH':str(Path.cwd())},timeout=440)
    if r.returncode:raise SystemExit(r.returncode)
    rec=json.loads((protocol.parent/'receiving/receipt.json').read_text());e=json.loads((protocol.parent/'execution.json').read_text());assert e['stop_reason'] is None
    print(json.dumps({'name':spec['name'],'stage':stage,'mode':spec['mode'],'repeat':spec.get('repeat'),'wall':rec['wall_seconds'],'precision':rec['precision_status']}),flush=True)
if a.pilot:
    for name in ['original/regular_tetrahedron/profile_'+str(i) for i in range(3)]:
        for row in plan['jobs']:
            if row['name']==name:run(row,'solve')
        run(next(r for r in plan['reads'] if r['name']==name),'read')
else:
    rows=[r for r in (plan['reads'] if a.stage=='read' else plan['jobs']) if r['name']==a.name and (a.stage=='read' or (r['mode']==a.mode and r['repeat']==a.repeat))]
    assert len(rows)==1,rows
    run(rows[0],a.stage)
