import hashlib,json,zipfile
from pathlib import Path
base=Path('devguide/evidence/reference_validator_analytic_panel_v1')
assert not base.exists();base.mkdir()
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
source={str(p):sha(p) for p in sorted(Path('devtools/reference_validator').rglob('*.py'))}
assert len(source)==51
worker='/tmp/topomt-analytic-panel-worker.py'
source_index=read('devguide/evidence/reference_validator_edge_volume_v1/receiving_index.json')
archive=Path(source_index['artifact']);assert sha(archive)==source_index['archive_sha256']
families=['regular_tetrahedron','closed_shell','shell_with_opening','straight_tube_narrow_dense','straight_tube_wide_sparse','dumbbell']
originals=sorted(source_index['originals'],key=lambda r:(families.index(r['name'].split('/')[1]),r['name']))
all_jobs=[];all_reads=[]
def jobs(name,inputs,model_sha,category):
    rows=[]
    for mode in ['serial','parallel2']:
        # Three fresh repetitions of the small positive pilot; larger profiles have one observation.
        repeats=3 if name=='original/regular_tetrahedron/profile_1' else 1
        for repeat in range(repeats):
            folder=base/category/name.removeprefix(category+'/')/mode/f'repeat_{repeat}'
            protocol=folder/'protocol.json'
            spec={'schema':'topomt.reference-validator.analytic-panel/1','owner':'uibcdf/topomt#76','name':name,
                'mode':mode,'cpus':1 if mode=='serial' else 2,'repeat':repeat,'inputs':inputs,'model_sha256':model_sha,
                'worker_sha256':sha(worker),'source_files':source,'piece_budget':512}
            write(protocol,spec);row={'protocol':str(protocol),'sha256':sha(protocol),'name':name,'mode':mode,'repeat':repeat,'category':category}
            rows.append(row);all_jobs.append(row)
    folder=base/category/name.removeprefix(category+'/')/'saved_read'
    protocol=folder/'protocol.json'
    spec={'schema':'topomt.reference-validator.analytic-panel-read/1','owner':'uibcdf/topomt#76','name':name,'mode':'shared_serial_saved_read','cpus':1,'inputs':inputs,'model_sha256':model_sha,'worker_sha256':sha(worker),'source_files':source,'configurations':rows}
    write(protocol,spec);all_reads.append({'protocol':str(protocol),'sha256':sha(protocol),'name':name,'category':category})
with zipfile.ZipFile(archive) as z:
    for row in originals:
        inputs={}
        for kind,key in [('model','model_member'),('certificate','certificate_member'),('reference','verification_member')]:
            p=base/'inputs'/row['name']/(kind+'.json');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(row[key]))
            inputs[kind]={'path':str(p),'sha256':sha(p),'original_capsule_member':row[key]}
        jobs(row['name'],inputs,row['model_sha256'],'original')
s7=read('devguide/evidence/reference_validator_parallel_edge_v1/plan.json');seen=set()
for row in s7['controls']:
    v=read(row['protocol'])
    if v['name'] in seen:continue
    seen.add(v['name']);inputs={}
    for kind,old in v['inputs'].items():
        p=base/'inputs'/v['name']/(kind+'.json');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(Path(old['path']).read_bytes())
        assert sha(p)==old['sha256'];inputs[kind]={'path':str(p),'sha256':sha(p),'original_capsule_member':old['original_capsule_member']}
    jobs(v['name'],inputs,v['model_sha256'],'controls')
assert len(originals)==19 and len(seen)==25 and len(all_jobs)==92 and len(all_reads)==44
write(base/'plan.json',{'owner':'uibcdf/topomt#76','base_revision':'e7a3052d949f207241e602bea3728d43427aca20','source_files':source,'original_capsule_sha256':sha(archive),'jobs':all_jobs,'reads':all_reads,'resource_policy':{'default_cpus':1,'explicit_max_cpus':2,'parent_address_bytes':2*1024**3,'parent_cpu_soft_hard_seconds':[300,330],'external_wall_seconds':420,'worker_address_bytes':256*1024**2,'pool_total_cpu_seconds':120,'max_pending_tasks':2,'piece_budget':512,'minimum_available_ram_fraction':0.2,'minimum_available_ram_bytes':4*1024**3,'observed_free_ram_is_not_reserved':True},'scope':'Complete saved-proof verification panel, same exact original models/proofs/requests and fixed arithmetic. All configurations fresh processes; pair has one shared further serial read, checked against every configuration. Source construction and broader full resume/public admission remain separate; no new native/geometry/provider/protein phase.'})
write(base/'source.json',source)
print(json.dumps({'original_profiles':19,'controls':25,'solve_configurations':len(all_jobs),'shared_reads':len(all_reads),'source_files':len(source)}))
