from pathlib import Path
import json
base=Path('devguide/evidence/reference_validator_analytic_panel_v1')
index=json.loads((base/'receiving_index.json').read_text());assert index['original_profiles']==19
edits={}
def get(path):
    p=Path(path)
    return edits.get(p,p.read_text())
def put(path,text):edits[Path(path)]=text
def replace(path,old,new):
    text=get(path);assert old in text,(path,old[:80]);put(path,text.replace(old,new,1))
summary='''## Expanded original verification panel — 2026-11-16 UTC

The [new receiving](../evidence/reference_validator_analytic_panel_v1/README.md)
qualifies complete saved-proof verification for all nineteen original numerical
profiles and twenty-five analytic controls in direct serial/two-worker modes.
Every mathematical field and original total/per-region precision request is
preserved. Each profile receives a further fresh producer-free serial read
shared by all its configurations; all 136 commands pass. The small tetrahedron
1.4 Å profile has three fresh repetitions per mode; larger profiles have one
observation per mode and acquire no general/repeatable scaling claim.

This extends analytic verification, not proposal generation or nineteen-profile
source-construction/resume admission. S6/S7 pause/recovery retain their earlier
three-Model source scopes. Four workers, remaining S1/S3/S5, broader S8/P6/P7,
canonical native #76/#60 and installed/platform #16 keep their gates. Native
#181/#180/#184/#188 and all older evidence are unchanged. Serial is the default.

'''
for name in ['reference_validator_checkpoint.md','notebook_laboratory_checkpoint.md']:
    path='devguide/DFND/'+name;text=get(path);pos=text.index('\n## ')+1;put(path,text[:pos]+summary+text[pos:])
path='devguide/DFND/reference_validator_performance_plan.md';text=get(path);pos=text.index('### Certified analytic task execution');put(path,text[:pos]+summary.replace('## Expanded','### Expanded')+text[pos:])
replace(path,'S7 is delivered at this fixed-\nfrontier scope; full parallel nineteen-profile/four-worker and broader S8 remain\nopen.','S7 is delivered at this fixed-\nfrontier scope. The later S8 record above expands saved-proof verification to\nall nineteen; source-construction/resume, four workers and broader S8 stay open.')
replace(path,'Delivered: canonical analytic frontier, failure/resume controls, 25 analytic controls and three original serial/two-worker profiles; broader panel separate','Delivered: canonical analytic frontier and selected failure/resume controls; later saved-proof verification covers 19 originals/25 controls in serial/two-worker modes; wider construction/resume separate')
replace(path,'Partial: original serial precision and six-route storage reliability delivered; broader optimized/parallel/public receiving open','Partial: all 19 original saved proofs/25 controls in serial/two-worker modes, fresh shared reading and storage reliability delivered; broader construction/resume, repeatability and public gates open')
path='devguide/DFND/reference_validator_improvement_workplan.md';replace(path,'### Next executable work under #76',summary+'### Next executable work under #76')
replace(path,'The analytic edge checker now has selected fixed-frontier serial/two-worker\n   qualification; the full parallel panel remains open.','The analytic checker now has full original saved-proof serial/two-worker\n   receiving; broader source-construction/resume and four workers remain open.')
path='devguide/pending_proposals/dfnd_reference_validation_panel.md';replace(path,'## Current continuation: checkpoint-size reliability',summary+'## Current continuation: checkpoint-size reliability')
path='devguide/DFND/reference_validator_parallel_edge.md';replace(path,'Four workers, the full parallel nineteen-profile panel, broader S8/P6/P7 and\nremaining S1/S3/S5 work retain their gates.','''The [later S8 receiving](../evidence/reference_validator_analytic_panel_v1/README.md)
now covers complete saved-proof verification for all nineteen originals and
25 controls in serial/two-worker modes, with fresh shared serial reading.
Source-construction/resume over all nineteen, four workers, broader S8/P6/P7
and remaining S1/S3/S5 work retain their gates.''')
path='devguide/DFND/documentation_checkpoint.md';put(path,get(path)+'''
## Expanded analytic verification review — 2026-11-16 UTC

The [complete original saved-proof panel](../evidence/reference_validator_analytic_panel_v1/README.md)
checks all nineteen numerical profiles and 25 controls in serial/two-worker
modes, with fresh producer-free reading. The validation chapter/report separate
that scope from source construction, paused recovery, larger-case repeatability
and public/installed qualification. DFND operators, units, interpretation and
derivations are unchanged; the worked-example regression remains applicable.
Local strict rendering is separate from hosted publication.
''')
path='docs/content/dfnd/validation_and_scope.md';replace(path,'''The same reference arithmetic now has
{ref}`bounded two-worker receiving <reference-validator-parallel-analytic>`
on the three original 1.4 Å Models and
25 analytic controls. Mathematical intervals and requests are unchanged; saved
work is independently reconstructed on recovery. This qualifies an execution
route, without adding a physical interpretation or fixing native DFND policy.
Direct serial remains the default and broader parallel admission stays separate.''','''The same reference arithmetic now has
{ref}`expanded serial/two-worker verification <reference-validator-expanded-analytic>`
on all nineteen original numerical profiles and 25 analytic controls. Complete
independent reconstruction, integration and fresh saved reading preserve every
mathematical field and request. The earlier
{ref}`pause/recovery receiving <reference-validator-parallel-analytic>` retains
its three-Model scope. These qualify execution routes without changing physical
interpretation or native DFND policy. Direct serial remains the default; broader
source-construction/resume and public admission stay separate.''')
path='docs/content/benchlab/synthetic/reference_validator_report.md';replace(path,'''retain the executed scope. The full parallel nineteen-profile/four-worker panel
and broader admission remain under #76.''','''retain that executed scope. The later expanded verification below covers all
nineteen saved original proofs; broader source-construction/resume, four-worker
and public admission remain under #76.''')
table=(base/'table.md').read_text().split('\n\n')[0]
section='''(reference-validator-expanded-analytic)=

## Complete original verification panel — 2026-11-16 UTC

All **nineteen original numerical profiles** and **25 analytic controls** pass
complete independent saved-proof verification in direct serial and explicit
two-worker modes. Exact Model/proof reading, full topology/frontier
reconstruction, certified integration and saving preserve **every mathematical
field and every original total/per-region precision request**. A further fresh
serial read independently recomputes each profile and checks both configurations.
Thirteen original profiles contain sixteen positive regions; six are exact zeros.

'''+table+'''

Times cover the complete checked solve and saving, including bounded launcher
overhead. The further independent read is shared and executed **once per
profile**, not counted twice. Tetrahedron 1.4 Å has three fresh runs per mode
(table: medians); all larger entries are single shared-host observations.
They establish neither repeatable nor general scaling. Small positive runs are
slower with processes; exact exclusions need no numerical workers even when
configured for two. **Direct serial remains the default.**

The 92 solve configurations and 44 shared reads take **3700.203 bounded wall /
3870.938 waited CPU seconds** in total, including controls. Peak sampled group
RSS is **106.79 MiB**; peak individual-process RSS is **53.66 MiB**. Five-second
group samples can miss peaks/double-count shared pages and cannot resolve the
short tetrahedron pool lifetime. Per-process limits, child/parent accounting,
host samples and phase times remain in the
[versioned evidence](https://github.com/uibcdf/topomt/blob/main/devguide/evidence/reference_validator_analytic_panel_v1/README.md).

This qualifies the saved-proof verification panel. Proposal generation and
paused source construction retain their earlier source scopes; the full
construction/resume panel, four workers, larger-case repeatability, native DFND
qualification and public/installed admission keep their gates. Original Models,
requests, earlier artifacts and native behavior are unchanged.

'''
replace(path,'## Earlier range-based face-integration feasibility — 2026-11-15',section+'## Earlier range-based face-integration feasibility — 2026-11-15')
path='devtools/reference_validator/README.md';replace(path,'The [resumable process route]','''The later [expanded verification panel](../../devguide/evidence/reference_validator_analytic_panel_v1/README.md)
receives all nineteen original numerical profiles and 25 analytic controls in
fresh serial/two-worker processes, plus one shared further serial read per
profile. All mathematical fields/requests are unchanged. This extends saved-proof
verification; generation/resume, four-worker, repeatability and public admission
retain their separate scopes. Use its exact source/capsule/drivers; repository
code need not match an older source-bound checkpoint.

The [resumable process route]''')
for p,text in edits.items():p.write_text(text)
print('Reconciled',len(edits),'current source/evidence/documentation records.')
