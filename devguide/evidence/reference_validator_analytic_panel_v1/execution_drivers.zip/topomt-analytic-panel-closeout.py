import hashlib,json,re,signal,sys,zipfile
from pathlib import Path
from urllib.parse import unquote
base=Path('devguide/evidence/reference_validator_analytic_panel_v1')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,v):
    with (base/name).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
source=read(base/'source.json');assert len(source)==51 and all(sha(p)==h for p,h in source.items())
frozen=read('docs/content/benchlab/synthetic/artifacts/six_case_review_v1/protocol.json')['frozen_files']
assert len(frozen)==355 and all(sha(p)==h for p,h in frozen.items())
human='d76f39e77bb54929c2d4a02f55ec04d61534ec09df776d2fe89ef731626a88b5';assert sha('topomt/_version.py')==human
previous={}
for name in ['reference_validator_parallel_resume_v1','reference_validator_parallel_edge_v1','reference_validator_storage_v1']:
    folder=base.parent/name;m=read(folder/'MANIFEST.json');assert all(sha(folder/p)==h for p,h in m['files'].items());previous[name+'/MANIFEST.json']=sha(folder/'MANIFEST.json')
reuse=read(base.parent/'reference_validator_storage_v1/source_qualification.json');assert reuse['source_files']==source and reuse['selected_tests']['total_distinct']==259
for n in ['guards','final_guards','package','docs']:
    e=read(base/(n+'_execution.json'));assert e['exit_code']==0 and e['stop_reason'] is None and all(v['host']['safe'] for v in e['samples'])
assert '19 passed' in (base/'final_guards.log').read_text()
failed=read(base/'package_attempt1_execution.json');assert failed['exit_code']==-signal.SIGXCPU
assert failed['cpu_soft_seconds']==45 and 44<failed['waited_cpu_seconds']<46
manifest=read(base/'capsule_manifest.json');archive=base/'receiving.zip';assert sha(archive)==manifest['archive_sha256']
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(manifest['members'])
    assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in manifest['members'].items())
    assert z.read('drivers/worker.py')==Path('/tmp/topomt-analytic-panel-worker.py').read_bytes()
html=Path('/tmp/topomt-analytic-panel-docs-html/content')
assert 'id="reference-validator-expanded-analytic"' in (html/'benchlab/synthetic/reference_validator_report.html').read_text()
assert 'reference_validator_report.html#reference-validator-expanded-analytic' in (html/'dfnd/validation_and_scope.html').read_text()
import subprocess
markdown=[Path(p) for p in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines() if p.endswith('.md')]+[base/'README.md',base/'table.md']
links=0
for p in markdown:
    for target in re.findall(r'\]\(([^)\s]+)\)',p.read_text()):
        if target.startswith(('#','http:','https:','mailto:','plugin:','app:')):continue
        target=unquote(target.split('#',1)[0].strip('<>'))
        if target:assert (p.parent/target).exists(),(p,target);links+=1
drivers=sorted(Path('/tmp').glob('topomt-analytic-panel-*.py'));assert len(drivers)==9
with zipfile.ZipFile(base/'execution_drivers.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in drivers:z.writestr(p.name,p.read_bytes())
with zipfile.ZipFile(base/'execution_drivers.zip') as z:assert all(z.read(p.name)==p.read_bytes() for p in drivers)
index=read(base/'receiving_index.json');assert index['solve_configurations']==92 and index['shared_saved_reads']==44
write('source_qualification.json',{
    'owner':'uibcdf/topomt#76','date':'2026-11-16 UTC','source_revision':'e7a3052d949f207241e602bea3728d43427aca20','source_files':source,'executable_validator_changes':False,'receiving_driver_sha256':sha('/tmp/topomt-analytic-panel-worker.py'),
    'actual_receiving':{'original_profiles':19,'controls':25,'solve_configurations':92,'shared_fresh_serial_reads':44,'original_positive_profiles':13,'original_positive_regions':16,'original_exact_zero_profiles':6,'all_mathematical_fields_equal_original':True,'all_original_total_and_region_absolute_and_relative_requests_met':True,'source_generation_reexecuted':False,'prior_pause_resume_scope':'Three original Models in S6/S7, at their recorded sources; not extended by saved-proof verification.'},
    'new_selected_tests':{'distinct':19,'new_panel_guards':3,'initial_record':'guards_execution.json','final_record':'final_guards_execution.json','scope':'Frozen panel/capsule/resources, fresh producer-free archive reading, old receiving, report governance and executable DFND example'},
    'reused_code_qualification':{'path':'devguide/evidence/reference_validator_storage_v1/source_qualification.json','sha256':sha(base.parent/'reference_validator_storage_v1/source_qualification.json'),'distinct_tests':259,'basis':'Every executable validator source hash is unchanged; selected receiving/doc guards executed again. Not a newly executed 259-test run or full-suite claim.'},
    'checks':{'ruff_check_and_format_files':741,'mypy_local_modules':51,'report_index':'pass','comparative_findings':'pass; offline only','strict_one_cpu_sphinx':'pass; notebook execution disabled; local rendering only','new_rendered_anchor_and_method_link':True,'local_markdown_links':links,'fresh_extracted_capsule_python_S':'pass; producer/scientific imports blocked; independent serial reader needs no pool'},
    'resource_scope':{'default_cpus':1,'explicit_max_cpus':2,'parallel_worker_address_bytes':256*1024**2,'parent_address_bytes':2*1024**3,'parent_cpu_soft_hard_seconds':[300,330],'external_wall_seconds':420,'max_pending_tasks':2,'piece_budget':512,'all_commands_bounded_wall_seconds':index['all_commands_bounded_wall_seconds'],'all_commands_waited_cpu_seconds':index['all_commands_waited_cpu_seconds'],'peak_sampled_group_rss_kib':index['peak_sampled_group_rss_kib'],'peak_individual_rss_kib':index['peak_individual_rss_kib'],'limits':'Per-process ceilings and explicit finite concurrency; observed free RAM not reserved. Five-second group RSS can miss peaks/double-count pages; short cases cannot resolve pool memory. Zero shortcuts launch no numerical workers. Packaging/tests/builds excluded from scientific totals.'},
    'operational_failure':{'record':'package_attempt1_execution.json','observed_exit_code':failed['exit_code'],'observed_signal':'SIGXCPU','declared_cpu_soft_seconds':45,'scope':'Packaging only; first driver revalidated Models to extract display probes. Revised packaging reads already-qualified rational fields; mathematical outputs unchanged. Both scripts/records retained, no timing speedup claim.'},
    'preserved':{'original_frozen_files':frozen,'earlier_evidence_manifests':previous,'human_version_sha256':human},
    'remaining':{'uibcdf/topomt#76':'S1/S3/S5, full source-construction/resume panel, four workers, larger-case repeatability, broader S8/P6/P7; no new algorithm/physical interpretation/native fix','uibcdf/topomt#60':'Canonical native receiving with #76','uibcdf/topomt#16':'Full suite, remote CI, installed/public/platform/Python-minor gates; authorized development commits carry [skip ci]','unchanged_native':['#181','#180','#184','#188']},
    'resource_question':'Headroom may justify a bounded four-worker pilot after a fresh check, one task at a time, measured benefit and preserved reserve. No four-worker run or resource-limit change in this frozen panel; executor contracts must also admit any changed external ceiling.',
    'no_new_boundary':'No new geometry/protein/original provider, public API/attribution boundary, dependency, Slurm/GPU/distributed run or hosted deployment.',
    'execution_drivers':{p.name:sha(p) for p in drivers},'python_version':sys.version,
})
write('MANIFEST.json',{'schema':'topomt.reference-validator.analytic-panel-evidence/1','manifest_excludes_itself':True,'files':{str(p.relative_to(base)):sha(p) for p in sorted(base.rglob('*')) if p.is_file() and p.name!='MANIFEST.json'}})
print(json.dumps({'source_files':51,'original_files_unchanged':355,'original_profiles':19,'controls':25,'successful_scientific_commands':136,'focused_tests':19,'reused_source_tests':259,'evidence_payloads':len(read(base/'MANIFEST.json')['files'])}))
