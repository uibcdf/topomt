import hashlib,json,re,subprocess,zipfile
from pathlib import Path
from urllib.parse import unquote
base=Path('devguide/evidence/reference_validator_edge_volume_v1')
artifact=Path('docs/content/benchlab/synthetic/artifacts/reference_validator_edge_v1')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
source=read(base/'source_retry.json')
assert all(sha(p)==h for p,h in source.items())
frozen=read('docs/content/benchlab/synthetic/artifacts/six_case_review_v1/protocol.json')['frozen_files']
assert len(frozen)==355 and all(sha(p)==h for p,h in frozen.items())
assert sha('topomt/_version.py')=='d76f39e77bb54929c2d4a02f55ec04d61534ec09df776d2fe89ef731626a88b5'
html=Path('/tmp/topomt-edge-docs-html')
report=(html/'content/benchlab/synthetic/reference_validator_report.html').read_text()
book=(html/'content/dfnd/validation_and_scope.html').read_text()
assert 'id="reference-validator-edge-volumes"' in report
assert 'reference_validator_report.html#reference-validator-edge-volumes' in book
archive_hash=sha(artifact/'receiving.zip')
copies=[p for p in (html/'_downloads').rglob('receiving.zip') if sha(p)==archive_hash]
assert len(copies)==1
links=0
paths=list(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines())
paths+=['devguide/DFND/reference_validator_edge_integration.md',str(base/'README.md'),str(artifact/'README.md')]
for name in paths:
 p=Path(name)
 if p.suffix!='.md':continue
 for target in re.findall(r'\]\(([^)\s]+)',p.read_text()):
  if re.match(r'^[a-z]+:',target) or target.startswith('#') or target.startswith('<'):continue
  dest=unquote(target.split('#')[0])
  assert (p.parent/dest).exists(),(name,target)
  links+=1
r={'schema':'topomt.reference-validator.edge-closeout/1','owner':'uibcdf/topomt#76','source_files_unchanged_since_original_receiving':len(source),'original_frozen_files_unchanged':len(frozen),'human_version_change_preserved':True,'strict_sphinx_success':read(base/'docs_execution.json')['exit_code']==0,'rendered_report_anchor_and_method_book_link':True,'rendered_download_sha256':archive_hash,'local_markdown_link_targets_checked':links,'hosted_site_deployment_qualified':False}
(base/'closeout_checks.json').write_text(json.dumps(r,indent=2)+'\n')
old=base/'drivers_in_progress.zip';new=base/'execution_drivers.zip'
with zipfile.ZipFile(old if old.exists() else new) as z:drivers={n:z.read(n) for n in z.namelist()}
for name in ['check','bounded','case-bounded','pilot','controls','controls-final','original-worker','original-panel','cost','matched-cost','extra-controls','package','finalize-data','docs-update','reconcile-docs','closeout']:
 p=Path('/tmp/topomt-edge-'+name+'.py')
 if p.exists():drivers['final_'+name.replace('-','_')+'.py']=p.read_bytes()
with zipfile.ZipFile(new,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(drivers.items()):z.writestr(name,data)
if old.exists():old.unlink()
checks={n:read(base/(n+'.json')) for n in ['affected_tests_execution','receiving_regressions_execution','final_receiving_tests_execution','docs_execution']}
assert all(d['exit_code']==0 and d['stop_reason'] is None for d in checks.values())
assert all(s['host']['safe'] for d in checks.values() for s in d['samples'])
qualification={'schema':'topomt.reference-validator.edge-qualification/1','owner':'uibcdf/topomt#76','base_revision':'688aa6ea15d5aa34f2f277034630bcfaa9944b1e','implementation_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_files':source,'tested_python':'3.14.10','original_profiles':19,'positive_profiles':13,'positive_regions':16,'exact_zero_profiles':6,'requested_k':24,'all_original_precision_resolved':True,'boundary_controls':16,'region_controls':9,'affected_tests':155,'receiving_performance_documentation_reporting_tests':45,'final_enriched_receiving_guards_rerun':3,'distinct_selected_tests':200,'ruff_check':True,'ruff_format_check':True,'mypy_modules':47,'devguide_index_check':True,'comparative_findings_offline_check':True,'strict_sphinx_build':True,'fresh_capsule_check_without_site_packages_or_producers':True,'portable_archive_sha256':archive_hash,'closeout':r,'support_boundary':'Standard-library exact independent developer bootstrap; no scientific external engine executed. Production quantities, arguments, diagnostics, dependencies and attribution admission remain P6.','deferred':'Eight-stage plan remains partial. Common canonical native receiver #76/#60 and native #181/#180/#184/#188 retain their scopes. Full suite/remote CI, Python 3.11-3.13, installed/platform/public #16 and broader P6/P7 remain unqualified. Authorized source-only direct commit carries [skip ci]; recover those gates through their owned checkpoint before public/release claims.','failed_attempts':['original/ (180 CPU-second exhaustion, no complete certificate)','region_controls_execution.json (null topology-path harness error, before scientific evaluation)'],'scope':'Complete topology and requested total/per-region volume precision for selected six-case original numerical Models and named independent controls; no native DFND correction or universal exactness/speed claim.'}
(base/'source_qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
manifest={'schema':'topomt.reference-validator.edge-evidence-manifest/1','manifest_excludes_itself':True,'files':{str(p.relative_to(base)):sha(p) for p in sorted(base.rglob('*')) if p.is_file() and p.name!='MANIFEST.json'}}
(base/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'source_files':len(source),'frozen_files':len(frozen),'markdown_targets':links,'archive_sha256':archive_hash,'evidence_files':len(manifest['files'])}))
