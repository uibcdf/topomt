import os,resource,subprocess,sys,time
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));resource.setrlimit(resource.RLIMIT_CPU,(50,60))
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[key]='1'
t=time.monotonic();r=subprocess.run([sys.executable,*sys.argv[1:]],timeout=70)
print('elapsed',time.monotonic()-t,'peak_child_rss_kib',resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
raise SystemExit(r.returncode)
