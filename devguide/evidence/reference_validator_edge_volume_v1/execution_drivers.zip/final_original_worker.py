import hashlib,json,sys,time
from pathlib import Path
from fractions import Fraction
from devtools.reference_validator.model import Model,decode_scalar
from devtools.reference_validator.edge_volume import edge_volume_proposal
from devtools.reference_validator.verify import verify
from devtools.reference_validator.verify.geometry import volume
from devtools.reference_validator.volume_request import VolumeRequest
protocol=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=False)
spec=json.loads(protocol.read_text());start,cpu=time.monotonic(),time.process_time()
m=Model.from_record(spec['model']);topology=json.loads(Path(spec['topology_path']).read_text());request=VolumeRequest(volume(m.domain)/2**24,Fraction(1,2**24))
(out/'model.json').write_text(json.dumps(m.to_record(),indent=2)+'\n')
saved_model=Model.from_record(json.loads((out/'model.json').read_text()))
for bits in (128,256,512):
 cert=edge_volume_proposal(m,topology,request,bits=bits)
 cp=out/f'certificate_{bits}.json';cp.write_text(json.dumps(cert,indent=2)+'\n')
 saved_proof=json.loads(cp.read_text())
 result=verify(saved_model,saved_proof)
 (out/f'verification_{bits}.json').write_text(json.dumps(result,indent=2)+'\n')
 if result['precision_status']=='resolved':break
(out/'certificate.json').write_text(json.dumps(cert,indent=2)+'\n')
(out/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
old=json.loads((protocol.parent/'receiving/leaves_512/verification.json').read_text()) if (protocol.parent/'receiving/leaves_512/verification.json').exists() else None
if old is not None:
 assert old['n_components']==result['n_components']
 assert max(decode_scalar(old['volume_lower']),decode_scalar(result['volume_lower']))<=min(decode_scalar(old['volume_upper']),decode_scalar(result['volume_upper']))
row={'original_protocol':str(protocol),'original_protocol_sha256':hashlib.sha256(protocol.read_bytes()).hexdigest(),'model_sha256':m.digest,'bits':cert['bits'],'n_components':result['n_components'],'face_piece_count':result['face_piece_count'],'precision_status':result['precision_status'],'wall_seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-cpu,'old_bounds_overlap':old is not None}
(out/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
if result['precision_status']!='resolved':raise SystemExit(3)
