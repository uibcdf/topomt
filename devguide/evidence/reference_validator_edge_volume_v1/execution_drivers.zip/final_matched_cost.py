import json,time,types,zipfile
from pathlib import Path
from devtools.reference_validator.model import Model
from devtools.reference_validator.verify import edge_volume as new
base=Path('devguide/evidence/reference_validator_edge_volume_v1')
spec=json.loads(Path('devguide/evidence/reference_validator_region_volume_v1/original/dumbbell/profile_0/protocol.json').read_text())
m=Model.from_record(spec['model']);p=Path(spec['topology_path']);proof=json.loads(p.read_text());old_checked=json.loads(p.with_name('verification.json').read_text())
pieces=new.assigned_faces(m,proof,old_checked)[:32]
old=types.ModuleType('devtools.reference_validator.verify.edge_reference');old.__package__='devtools.reference_validator.verify'
with zipfile.ZipFile(base/'source_attempt_1.zip') as z:exec(z.read('devtools/reference_validator/verify/edge_volume.py'),old.__dict__)
rows=[]
for repeat in range(3):
 bounds={}
 for label,module in [('fraction_reference',old),('integer_dyadic',new)]:
  module._atan_endpoint.cache_clear();t,c=time.monotonic(),time.process_time()
  result=[module.triangle_flux(center,radius,tri,64) for center,radius,tri,_ in pieces]
  bounds[label]=result
  rows.append({'repeat':repeat,'route':label,'piece_count':len(pieces),'wall_seconds':time.monotonic()-t,'cpu_seconds':time.process_time()-c})
 for a,b in zip(bounds['fraction_reference'],bounds['integer_dyadic']):assert max(a.lower,b.lower)<=min(a.upper,b.upper)
(base/'matched_primitive_cost.json').write_text(json.dumps({'model_sha256':m.digest,'scope':'32 identical original dumbbell face integrals; metrics only; full topology admission excluded','endpoint_caches_reset_each_repeat':True,'constant_pi_cache_may_persist':True,'results_enclosures_compatible':True,'runs':rows},indent=2)+'\n')
print(json.dumps(rows),flush=True)
