from pathlib import Path
base=Path('devguide/evidence/reference_validator_edge_volume_v1')
table=(base/'table.md').read_text()
readme='''# Certified analytic edge-volume receiving, version 1

Owner [TopoMT #76](https://github.com/uibcdf/topomt/issues/76).
[Mathematical construction](../../DFND/reference_validator_edge_integration.md).
[Portable capsule](../../../docs/content/benchlab/synthetic/artifacts/reference_validator_edge_v1/README.md).

## Qualified original numerical scope

All **19 original profiles** of the six synthetic cases now pass their original
k=24 requests: absolute `V(domain)*2^-24` AND relative `2^-24`, for the total
and every region. Thirteen positive profiles contain sixteen positive regions;
six excluded profiles have exact zero volume. Complete original topology and
boundary incidence are retained. Every new interval lies inside its previous
conservative total/per-region enclosure. Inputs, radii, probes, units, frames,
source identities and the 355 frozen files are unchanged.

The reader reconstructs the original power cells, proves complete regional
face assignment and evaluates the exact-cut analytic edge formula with outward
numerical error. Proposals contain no trusted totals or region assignments.
This supplies precision receiving for these fixed numerical Models, not a
native DFND correction or universal public/molecular/platform admission.

## Results and resources

'''+table+'''

Displayed volumes are rounded midpoints and relative widths are approximate;
the exact rational endpoints and original requests are in the capsule. These
are arithmetic enclosures for fixed exact inputs, not experimental uncertainty.
The total and every region pass independently, including the small extra
boundary regions of dumbbell. Region counts are not morphological catalog names.

All original workers run sequentially with one CPU/thread and 2 GiB address
space. The original receiving takes **1354.837 worker wall / 1353.655 CPU
seconds**; bounded process elapsed sums to 1357.359 seconds. Peak worker RSS is
44,784 KiB (43.73 MiB). All five-second host samples preserve the reserve. Each
worker has finite 300/330 CPU-second and 420 wall-second ceilings; these are
safety ceilings, not reserved machine resources or runtime goals.
The worker times include input/Model reading, proposal saving, a new Model read
and full independent topology/volume verification. They do not hide verification
behind a producer-only timing. Originals use a declared 128-bit proposal;
only an unmet request could select a new stronger arithmetic proposal.

## Controls and arithmetic cost

`controls_final/receipt.json` qualifies all sixteen original clipped-cube
k=8/16/24/32 controls, including eight extremely tiny regions. Each region lies
within the independent polynomial sandwich; near-rational cancellation needs
512 bits. `region_controls_final/receipt.json` qualifies all nine earlier
region controls, including the asymmetric three-region Model. Independent
unit controls also cover signed-owner faces, exact 3-4-5 contacts, rational
covariance, literal-zero cases, bad units/topology and maximum 2048-bit atan.

The first original dumbbell attempt reaches its 180 CPU-second budget without
producing a complete certificate; `original/` and `source_attempt_1.zip` retain
it. `cost/` isolates face preparation and the first 32 face integrals using
historical checked labels only for profiling, not for a new physical result.
The Fraction atan implementation dominates that sampled integral cost.
`matched_primitive_cost.json` measures the same 32 pieces unprofiled: median
2.912799 seconds for Fraction arithmetic and 0.299421 for integer dyadic
arithmetic, with compatible certified enclosures. This is a primitive-cost
comparison, not a full-analysis speedup against an unfinished baseline.

A declarative proposal also avoids evaluating the integral in order to prepare
a record which the saved reader must evaluate again. The actual final execution
still checks the complete topology and every numerical contribution. Final
receiving lives under `original_retry/`; all earlier source-scoped attempts,
including the 0.117-second extra-control harness error for a null topology path,
remain retained. That error preceded scientific evaluation and is corrected
by reading the original embedded topology, not by changing geometry.

## Retention and remaining gates

`receiving_index.json` maps original records to checksum-bound capsule members.
Large original certificates are stored once in the ZIP. The working
`certificate_128.json` is byte-identical to the final certificate; the duplicate
alias rule is recorded. Models, verification receipts and resource logs remain
in the evidence tree. `source_retry.json` binds all executable inputs used for
the complete receiving, and source snapshots/drivers preserve reproducibility.
Old notebooks, artifacts, downloads and historical coarse outcomes are retained.

The eight-stage performance plan stays partial. S4's original serial precision
gate is now delivered; S1/S3 instrumentation/invariant follow-up, conditional
compiled work, full parallel fault/resume qualification and public/installed/
platform admission retain their gates. #76 remains open for that work and common
native receiving under #60. Native #181/#180/#184/#188 are not resolved by a
stronger reference. No new BenchLab family, protein or original provider run is
selected. The checker executes no original external engine or scientific
floating backend; optional production attribution/API adoption remains at P6.
'''
(base/'README.md').write_text(readme)
p=Path('docs/content/benchlab/synthetic/reference_validator_report.md');s=p.read_text();heading='## Performance continuation and face-integration feasibility — 2026-11-15'
new='''(reference-validator-edge-volumes)=
## Certified volume precision for all six original systems — 2026-11-15

The independent validator now meets the original **k=24 absolute and relative
volume requirements for all nineteen profiles**, for the total and every region.
This resolves the requested precision of the thirteen positive profiles and
their sixteen regions. Six excluded profiles retain exact zero volume.

The new construction integrates signed flux over the exact power-cell faces,
then reduces each face to analytic edge integrals with exact sphere-cut decisions
and outward numerical bounds. Region assignment is reconstructed from the
complete checked topology. The original Models, probes, radii, inputs and native
DFND observations are unchanged. This certifies probe-center volume in each
finite domain; native public qualification remains a separate task.

'''+table+'''

Volumes are rounded midpoints; relative widths are approximate summaries of
exact rational intervals. They describe numerical error for the fixed input
Model, not biological or experimental uncertainty. Every individual region
also passes the original absolute AND relative requirements.

The nineteen analyses run sequentially on one CPU with a 2 GiB address-space
limit: 1354.837 worker elapsed / 1353.655 CPU seconds in total, peak worker RSS
43.73 MiB. This includes independent saved checking. All monitored host samples
preserve the shared-machine reserve. Sixteen boundary precision controls and
nine earlier region-volume controls also pass; the tiny-region and asymmetric
assignments are retained.

[Download the standalone receiving capsule](artifacts/reference_validator_edge_v1/README.md).
It contains the exact Models, certificates, checker source and mathematical
derivation. Fresh reading needs no producer, DFND, scientific floating package,
process pool or cached accepted state. Full records, attempted budgets and
remaining gates live in the [versioned evidence](https://github.com/uibcdf/topomt/blob/main/devguide/evidence/reference_validator_edge_volume_v1/README.md).
The performance plan and public/molecular admission remain open under
[#76](https://github.com/uibcdf/topomt/issues/76) and
[#16](https://github.com/uibcdf/topomt/issues/16). This reference delivery does
not fix native #181/#180/#184/#188.

The sections below preserve earlier methods and source-scoped outcomes. Their
unmet positive-volume targets describe those earlier receiving records, rather
than the current analytic edge route.

'''
assert heading in s;s=s.replace(heading,new+'## Earlier range-based face-integration feasibility — 2026-11-15',1);p.write_text(s)
