import hashlib,json,time
from pathlib import Path
from fractions import Fraction as F
from devtools.reference_validator.model import Model,decode_scalar
from devtools.reference_validator.edge_volume import edge_volume_certificate
from devtools.reference_validator.verify import verify
from devtools.reference_validator.verify.geometry import volume
from devtools.reference_validator.volume_request import VolumeRequest
base=Path('devguide/evidence/reference_validator_edge_volume_v1/region_controls');base.mkdir(exist_ok=False)
plan=json.loads(Path('devguide/evidence/reference_validator_region_volume_v1/plan.json').read_text());rows=[]
for job in plan['jobs']:
 if job['category']!='control':continue
 path=Path(job['protocol']);assert hashlib.sha256(path.read_bytes()).hexdigest()==job['sha256'];spec=json.loads(path.read_text());model=Model.from_record(spec['model']);topology=json.loads(Path(spec['topology_path']).read_text())
 request=VolumeRequest(volume(model.domain)/2**spec['k'],F(1,2**spec['k']))
 t,c=time.monotonic(),time.process_time();cert=edge_volume_certificate(model,topology,request);result=verify(model,cert);assert result['precision_status']=='resolved'
 out=base/job['name'].removeprefix('controls/');out.mkdir(parents=True)
 for name,obj in [('model',model.to_record()),('certificate',cert),('verification',result)]: (out/(name+'.json')).write_text(json.dumps(obj,indent=2)+'\n')
 row={'name':job['name'],'original_protocol':str(path),'original_protocol_sha256':job['sha256'],'model_sha256':model.digest,'bits':cert['bits'],'regions':len(result['regions']),'precision_status':result['precision_status'],'wall_seconds':time.monotonic()-t,'cpu_seconds':time.process_time()-c};rows.append(row);print(json.dumps(row),flush=True)
(base/'receipt.json').write_text(json.dumps(rows,indent=2)+'\n')
