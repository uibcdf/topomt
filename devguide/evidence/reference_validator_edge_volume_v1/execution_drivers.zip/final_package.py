import hashlib,json,zipfile
from pathlib import Path
base=Path('devguide/evidence/reference_validator_edge_volume_v1')
artifact=Path('docs/content/benchlab/synthetic/artifacts/reference_validator_edge_v1')
members={};records=[]
def add(name,path):
 members[name]=path.read_bytes()
rows=json.loads((base/'original_retry_summary.json').read_text())
for row in rows:
 key=row['name'].removeprefix('original/');folder=base/'original_retry'/key
 model=f'models/{key}.json';certificate=f'volumes/{key}.json';verification=f'verification/{key}.json'
 for name,path in [(model,folder/'model.json'),(certificate,folder/'certificate.json'),(verification,folder/'verification.json')]:add(name,path)
 assert (folder/'certificate_128.json').read_bytes()==(folder/'certificate.json').read_bytes()
 assert (folder/'verification_128.json').read_bytes()==(folder/'verification.json').read_bytes()
 records.append({**row,'model_member':model,'certificate_member':certificate,'verification_member':verification,'member_paths_relative_to':'receiving.zip'})
for source,prefix in [('controls_final','boundary'),('region_controls_final','region')]:
 for row in json.loads((base/source/'receipt.json').read_text()):
  key=row['name'].removeprefix('controls/');folder=base/source/key
  for name in ['model.json','certificate.json','verification.json']:add(f'controls/{prefix}/{key}/{name}',folder/name)
source=json.loads((base/'source_retry.json').read_text())
for name,digest in source.items():
 assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
 add(name,Path(name))
members['devtools/__init__.py']=b''
add('DERIVATION.md',Path('devguide/DFND/reference_validator_edge_integration.md'))
inside={'schema':'topomt.reference-validator.edge-capsule/1','manifest_excludes_itself':True,'members':{k:hashlib.sha256(v).hexdigest() for k,v in members.items()}}
members['MANIFEST.json']=(json.dumps(inside,indent=2)+'\n').encode()
archive=artifact/'receiving.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for name,body in members.items():z.writestr(name,body)
external={'schema':'topomt.reference-validator.edge-capsule-manifest/1','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'members':{k:hashlib.sha256(v).hexdigest() for k,v in members.items()}}
(artifact/'bundle_manifest.json').write_text(json.dumps(external,indent=2)+'\n')
index={'owner':'uibcdf/topomt#76','artifact':str(archive),'archive_sha256':external['archive_sha256'],'originals':records,'controls_boundary':16,'controls_region':9,'source_files':source,'duplicate_intermediate_rule':'certificate_128.json and verification_128.json are byte-identical to final records; certificates are retained once in the archive'}
(base/'receiving_index.json').write_text(json.dumps(index,indent=2)+'\n')
print(archive.stat().st_size,'archive bytes;',len(members),'members')
# Only remove byte-identical task-created working copies after checksum-bound
# retention in the ZIP. Frozen original inputs and historical artifacts stay.
with zipfile.ZipFile(archive) as z:
 for row in records:
  key=row['name'].removeprefix('original/');folder=base/'original_retry'/key
  assert z.read(row['certificate_member'])==(folder/'certificate.json').read_bytes()
  (folder/'certificate.json').unlink();(folder/'certificate_128.json').unlink()
