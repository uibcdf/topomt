import hashlib,json,statistics,zipfile
from pathlib import Path
from fractions import Fraction
from devtools.reference_validator.model import decode_scalar
base=Path('devguide/evidence/reference_validator_edge_volume_v1')
rows=json.loads((base/'original_retry_summary.json').read_text());assert len(rows)==19
records=json.loads((base/'receiving_index.json').read_text())['originals']
executions=[json.loads(p.read_text()) for p in (base/'original_retry').rglob('*_execution.json')]
summary={'owner':'uibcdf/topomt#76','original_profiles':19,'positive_profiles':sum(r['n_components']>0 for r in rows),'positive_regions':sum(r['n_components'] for r in rows),'exact_zero_profiles':sum(r['n_components']==0 for r in rows),'all_original_precision_resolved':all(r['precision_status']=='resolved' for r in rows),'requested_k':24,'request_policy':'V(domain)*2^-24 absolute AND 2^-24 relative; total and every region','original_worker_wall_seconds':sum(r['wall_seconds'] for r in rows),'original_worker_cpu_seconds':sum(r['cpu_seconds'] for r in rows),'original_bounded_wall_seconds':sum(r['wall_seconds'] for r in executions),'peak_worker_rss_kib':max(r['peak_child_rss_kib'] for r in executions),'all_host_samples_safe':all(s['host']['safe'] for r in executions for s in r['samples']),'boundary_controls':16,'region_controls':9,'source_files':json.loads((base/'source_retry.json').read_text()),'scope':'selected six-case original numerical Models only; no native policy, public/installed/platform or broader P7 admission'}
assert summary['all_host_samples_safe'];(base/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with zipfile.ZipFile('docs/content/benchlab/synthetic/artifacts/reference_validator_edge_v1/receiving.zip') as z:
 lines=['| Original case | Probe (Å) | Regions | Volume (nm³, approx.) | Relative width (approx.) | Worker seconds | Peak RSS (MiB) |','| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
 for row in sorted(records,key=lambda r:r['name']):
  key=row['name'].removeprefix('original/');model=json.loads(z.read(row['model_member']));result=json.loads(z.read(row['verification_member']));lo,hi=map(decode_scalar,[result['volume_lower'],result['volume_upper']]);probe=10*decode_scalar(model['probe']);ex=json.loads((base/'original_retry'/key).with_name((base/'original_retry'/key).name+'_execution.json').read_text())
  relative='exact zero' if hi==0 else f'{float((hi-lo)/lo):.2e}'
  lines.append(f"| `{key.rsplit('/',1)[0]}` | {float(probe):g} | {row['n_components']} | {float((lo+hi)/2):.9g} | {relative} | {row['wall_seconds']:.3f} | {ex['peak_child_rss_kib']/1024:.2f} |")
(base/'table.md').write_text('\n'.join(lines)+'\n')
with zipfile.ZipFile(base/'drivers_in_progress.zip','a',compression=zipfile.ZIP_DEFLATED) as z:
 for name in ['topomt-edge-extra-controls.py','topomt-edge-controls-final.py','topomt-edge-package.py','topomt-edge-finalize-data.py']:
  p=Path('/tmp')/name;z.write(p,name)
print(json.dumps(summary,indent=2)[:1100])
