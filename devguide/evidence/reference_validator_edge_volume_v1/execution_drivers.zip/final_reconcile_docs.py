from pathlib import Path

def replace(path, old, new):
    p=Path(path); s=p.read_text()
    assert old in s, (path, old[:70])
    p.write_text(s.replace(old,new,1))

def before(path, marker, text):
    replace(path,marker,text+'\n'+marker)

before('devguide/DFND/reference_validator_checkpoint.md','## Selected improvement workplan — 2026-11-14', '''## Original total and region precision completed — 2026-11-15

The [analytic edge construction](reference_validator_edge_integration.md)
reduces signed power-cell face flux to exact-cut edge primitives. The independent
reader reconstructs source facets, all region assignments and outward rational
sqrt/atan intervals. It imports no producer or scientific library; a declarative
proposal supplies no accepted result. The exact model/contact/domain contracts
and original requests are unchanged.

The [new receiving](../evidence/reference_validator_edge_volume_v1/README.md)
qualifies **19/19 original k=24 profiles**: thirteen positive profiles and their
sixteen regions meet both absolute and relative requests; six excluded profiles
have exact zero volume. All new intervals are inside their previous conservative
bounds. All sixteen original clipped-boundary k=8/16/24/32 controls and nine
earlier region controls pass, including tiny eight-region and asymmetric
three-region Models. The capsule retains all 47 source files and exact receipts;
no previously frozen input or evidence file is changed.

Sequential execution uses one CPU/thread, 2 GiB address-space ceilings and finite
CPU/wall deadlines. Summed original worker wall/CPU is 1354.837/1353.655 seconds,
peak RSS 43.73 MiB. A failed earlier 180 CPU-second dumbbell attempt is retained.
Matched primitive timings justify integer dyadic atan; they do not establish a
full-analysis speedup over that incomplete attempt.

S4 and the original precision portion of D/E are delivered for this selected
synthetic scope. The eight-stage plan and #76 remain partial: common canonical-
unit native receiving (#76/#60), broader P6/public/installed admission and
qualified parallel/scaling work remain. #181/#180/#184/#188 retain their native
scopes; no DFND behavior or finding is fixed. The
[BenchLab report](../../docs/content/benchlab/synthetic/reference_validator_report.md#reference-validator-edge-volumes)
provides the per-system table and portable download. Earlier unmet-precision
statements below describe their retained methods/sources, not this current result.
''')
replace('devguide/DFND/reference_validator_checkpoint.md', '''These are bounded implemented P0/P1 tranches of the
[implementation plan](physical_reference_validator_implementation.md), not a
complete topology-plus-precision validator or a supported public TopoMT detector.''', '''These identify early P0/P1 tranches of the
[implementation plan](physical_reference_validator_implementation.md). The latest
section below records nineteen topology-plus-precision synthetic profiles;
broader admission and a supported public TopoMT detector remain separate.''')
p='devguide/DFND/notebook_laboratory_checkpoint.md'
s=Path(p).read_text();start=s.index('## Complete original topology panel');end=s.index('## Next validator work')
Path(p).write_text(s[:start]+'''## Original topology and requested volume precision — 2026-11-15 UTC

The [active validator checkpoint](reference_validator_checkpoint.md) records
**19/19 original profiles with complete topology and satisfied k=24 volume
requests**: thirteen positive profiles/sixteen regions and six exact-zero
profiles. Total and every region meet the unchanged absolute AND relative
requirements. Exact-cut analytic edge integration replaces the unresolved
precision disposition of the earlier box/range constructions, whose raw
certificates and results remain historical evidence.

The [receiving](../evidence/reference_validator_edge_volume_v1/README.md)
retains independent checking, a portable capsule, sixteen boundary controls
through k=32, nine region controls and one-CPU resource measurements. Dumbbell
still has 3/2/0 regions: its small boundary regions are counted and integrated.
All original named references, inputs and 355 frozen files remain intact.

Next under #76/#60: qualify common canonical-unit native receiving and hand
whole-carrier evidence to #181's physical qualification/public decision.
Two additional actual-vdW Models already exclude four submitted native carriers;
that receiving does not assert exact equality for all original/native inputs.
The eight-stage performance plan, broader P6/P7 and public/installed #16 remain
partial. Native #181/#180/#184/#188 are unchanged. No new geometry, protein or
provider phase is selected. Older counts and next steps below are historical;
use this section and the active checkpoint for the current gate.

'''+s[end:])
p='devguide/DFND/reference_validator_improvement_workplan.md';s=Path(p).read_text();start=s.index('**Status:');end=s.index('This document gives the next implementation order')
Path(p).write_text(s[:start]+'''**Status: A/B/C delivered; D/E delivered for complete topology and original
k=24 total/per-region precision on the selected nineteen-profile synthetic
panel; F delivered for two explicitly mapped native-input Models. Broader
native receiving and public qualification remain open.** Correctness,
exhaustive justified topology and certified volume error take priority over
runtime. The serial exact construction and independent reader remain the baseline.

The [analytic edge receiving](../evidence/reference_validator_edge_volume_v1/README.md)
passes all nineteen unchanged requests: thirteen positive profiles/sixteen
regions and six exact zeros. All sixteen clipped-boundary ladder controls and
nine earlier region controls pass. Historical box/range bounds remain valid at
their original, sometimes unresolved, precision. No native behavior changes.

| Package | Current disposition |
| --- | --- |
| A | Bounded proof/trust review and falsification controls delivered. |
| B | Checked source-cell progress, same-kernel resume and final exhaustive assembly delivered. |
| C | Original topology coverage is 19/19. |
| D | Complete conservative accounting and exact-cut analytic edge integration delivered, including signed faces, tiny/asymmetric regions and independently checked region assignment. |
| E | All original k=24 total AND per-region requests pass; selected serial precision receiving delivered. Full public/native P5/P6 admission remains separate. |
| F | Four whole-carrier exclusions checked on two fresh exactly matched actual-vdW Models. Common canonical-unit receiving across the original panel remains #76/#60. |

### Next executable work under #76

1. Qualify common native receiving in canonical units under #76/#60 before
   asserting equality across all nineteen native/reference inputs. Actual
   assigned radii need a distinct captured Model and full proof when their
   bits differ from supplied-radius records. Preserve original public results.
2. Hand retained whole-carrier supports to #181's physical qualification/public
   reporting decision. Point checks and whole-carrier exclusions do not prove
   a positive carrier/path. Wider support and morphology retain #60/#180/#184/#188.
3. Continue the [performance stages](reference_validator_performance_plan.md)
   from the qualified serial baseline: complete cost accounting/invariant
   review, then explicit bounded process failure/resume/equivalence admission.
   The analytic edge route has no qualified parallel backend yet. Rust is
   optional and requires a measured justified hotspot; no speed target replaces
   correctness. Keep the prior conservative routes as independently readable
   fallback evidence. No new geometry, protein or provider phase is selected.

'''+s[end:])
p='devguide/DFND/reference_validator_performance_plan.md'
before(p,'### Implementation receiving — 2026-11-15', '''### Current serial precision receiving — 2026-11-15

S4 is **delivered for the selected nineteen original profiles and controls**.
The [analytic edge route](reference_validator_edge_integration.md) and
[receiving](../evidence/reference_validator_edge_volume_v1/README.md) meet every
unchanged k=24 total/per-region request, including sixteen positive regions.
The sixteen clipped-boundary ladder and nine region controls also pass. Original
workers run sequentially on one CPU (1354.837 wall seconds; 43.73 MiB peak RSS).
Fresh checking needs no producer or scientific dependency.

A measured Fraction-atan hotspot led to certified integer dyadic arithmetic;
matched 32-piece primitive medians are 2.912799 versus 0.299421 seconds. This is
not a full-analysis speedup over the retained incomplete dumbbell attempt.
Declarative proposals avoid evaluating the full integral twice while earning
no completion credit. Optional Rust remains deferred pending an additional
justified hotspot and its independent qualification. S1/S3/S5/S6/S7/S8 retain
unexecuted parts. The former unmet-precision statements below describe the
earlier range-based method; parallel prototypes do not qualify this analytic
route. The current scientific continuation is common canonical native receiving
under #76/#60 and #181, with broader public/installed gates separate.
''')
replace(p,'### Implementation receiving — 2026-11-15','### Earlier range-based implementation receiving — 2026-11-15')
replace(p,'## Starting evidence and scope','## Historical starting evidence and preserved scope')
replace(p,'the current scientific continuation is S4.','S4 was the scientific continuation selected at that baseline.')
replace(p,'Partial: conservative face flux; original precision still unmet','Delivered: all 19 original total/per-region requests and selected controls; wider admission separate')
replace(p,'Outward denominator control delivered; optional Rust deferred','Partial: denominator control and measured integer dyadic atan; optional Rust deferred')
replace(p,'Prototype; same partition checked; precision/panel gate open','Earlier range prototype only; analytic-route parallel/failure/resume qualification open')
replace(p,'Partial: selected receiving, not full optimized original panel','Partial: original serial precision panel delivered; broader optimized/parallel/public receiving open')
replace('devguide/DFND/physical_reference_validator_plan.md', '''profiles**. Conservative total/per-region volume construction is implemented;
requested precision for nonempty original regions retains its own open gate.
The proposed complete-validator acceptance below retains those requirements.''', '''profiles**. The later [analytic edge route](reference_validator_edge_integration.md)
meets the unchanged k=24 absolute AND relative volume request for the total and
every region in all nineteen originals. The selected serial scientific gate is
delivered; common native receiving and broader public/installed/parallel
admission remain open. Earlier unmet-precision evidence retains its own source.
The complete-validator acceptance below retains its broader requirements.''')
replace('devguide/DFND/physical_reference_validator_plan.md','**Status: proposed implementation and acceptance plan, not a delivered validator.**','**Historical design baseline:** the proposal below predates the bounded source\ndeliveries summarized above. It does not qualify the complete public validator.')
p='devguide/DFND/physical_reference_validator_implementation.md'
before(p,'Planning baseline:', '''## Current selected scientific receiving — 2026-11-15

The [analytic edge construction](reference_validator_edge_integration.md) now
qualifies complete original topology plus k=24 total AND per-region volume
precision on all nineteen profiles: thirteen positive profiles/sixteen regions
and six exact zeros. The [receiving](../evidence/reference_validator_edge_volume_v1/README.md)
retains independent saved checking, exact requests, sixteen boundary and nine
region controls, source snapshots and bounded one-CPU resources. This completes
the selected serial precision gate. Common canonical native receiving (#76/#60),
#181's native policy and broader P6/P7/public/installed admission remain open.
No specification, native behavior or frozen evidence is weakened or replaced.

## Historical implementation tranches

The following dated/source-bound outcomes preserve their original limitations;
the current section above supersedes their outstanding original precision gate.
''')
replace(p,'''source route. Nonempty original requested precision remains open: use the
measured integration pilot and clipped-boundary controls before increasing
grid work or claiming the P5 target. Small analytic controls qualify their
specific admission, not general original-hull precision.

Complete the required original-source receiving and P1/P4 region-assigned
integration before expanding a native engine.''', '''source route. The later analytic edge construction meets every original
k=24 total/per-region request; its exact-cut derivation, independent controls
and nineteen-profile receiving qualify that selected synthetic scope.

Next qualify common canonical native receiving under #76/#60 before broader
native-input equivalence claims or changing #181's public policy.''')
p='devguide/pending_proposals/dfnd_reference_validation_panel.md'
before(p,'## Partial performance implementation — 2026-11-15', '''## Current disposition: original precision completed — 2026-11-15

The [analytic edge derivation](../DFND/reference_validator_edge_integration.md)
and [new evidence](../evidence/reference_validator_edge_volume_v1/README.md)
qualify **19/19 original k=24 requests**, total and every region, at unchanged
absolute AND relative thresholds. Thirteen positive profiles contain sixteen
positive regions; six excluded profiles are exactly zero. Complete topology and
all original inputs are preserved. Sixteen clipped-boundary k=8/16/24/32 controls
and nine region controls pass, including tiny and asymmetric region inventories.

All original workers execute sequentially on one CPU, with finite deadlines and
2 GiB address-space ceilings; summed worker wall/CPU is 1354.837/1353.655 seconds,
peak RSS 43.73 MiB. A portable capsule retains exact Models, requests, proofs,
reader source and receipts. Earlier failed/resource-limited attempts are retained.
S4 and original precision D/E are delivered for this selected synthetic scope.

**#76 remains partial/open.** Next qualify common canonical-unit native receiving
under #76/#60 and hand retained supports to #181. Broader P6/public/installed #16,
P7 and performance-plan admission remain unqualified. Native #181/#180/#184/#188
are unchanged. No new family, protein or provider run is selected. Earlier
unmet-precision statements below retain their historical method/source scope
and must not be reused as the current disposition of the analytic edge route.
''')
replace(p,'## Partial performance implementation — 2026-11-15','## Earlier range-based performance implementation — 2026-11-15')
replace(p,'## Current A--F disposition — 2026-11-15 UTC','## Earlier A--F volume-bound disposition — 2026-11-15 UTC')
replace(p,'## Current three-case acceptance — 2026-11-10','## Historical three-case acceptance — 2026-11-10')
p='devguide/DFND/reference_validator_face_flux.md'
replace(p,'# Certified face flux: construction and remaining precision gate','# Certified face flux: original range-based construction')
replace(p,'''partition. The original k=24 request remains unmet. It is not public API or a
qualification of native DFND, general molecular performance or the entire plan.''', '''partition. Its range-based original k=24 pilot remains unmet at its recorded
budget. The later [analytic edge reduction](reference_validator_edge_integration.md)
uses the same field and complete power partition and passes all nineteen original
requests, total and per region. Keep these method-specific receipts distinct.
Neither route is public API or qualification of native DFND, general molecular
performance or the entire plan.''')
p='devguide/DFND/reference_validator_region_volume_construction.md'
replace(p,'''The later [face-flux prototype](reference_validator_face_flux.md) supplies a
second conservative construction within the actual power cells. Its original
tetrahedron pilot still misses k=24; the box-cover results below retain their
original definitions and scope.''', '''The [face-flux prototype](reference_validator_face_flux.md) supplies a second
conservative construction within the actual power cells; its range-based
original tetrahedron pilot misses k=24. The later
[analytic edge construction](reference_validator_edge_integration.md) qualifies
all nineteen original total/per-region requests and selected tiny/asymmetric
controls. The box-cover results below retain their original definitions and
precision scope; they are a conservative baseline, not the latest precision
limit of the validator.''')
p='devtools/reference_validator/README.md'
replace(p,'''precision and hull-proof routes. It is not a supported public detector or a
complete per-region precision implementation.''', '''precision and hull-proof routes. The selected nineteen original profiles now
have complete topology and satisfied k=24 total/per-region requests. This is
not a supported public detector or universal per-region admission.''')
before(p,'`boundary_volume.boundary_volume_certificate`', '''`edge_volume.edge_volume_proposal` prepares a detached unverified symbolic
job, with no result or precision credit. The independent saved `verify` command
reconstructs every face, region assignment and exact-cut analytic integral for
its `power_edge_volume` kind. `edge_volume_certificate` offers adaptive arithmetic
selection when desired. Both preserve the same request and all geometric
constraints. See the [derivation](../../devguide/DFND/reference_validator_edge_integration.md)
and [original receiving](../../devguide/evidence/reference_validator_edge_volume_v1/README.md):
all nineteen originals plus sixteen boundary and nine region controls pass.
The exact reader needs no producer/scientific dependency. Serial is the default;
parallel admission of the analytic route is pending.

''')
replace(p,'''Clipped/per-region
high precision and production attribution/API admission remain pending.''', '''The analytic edge route supplies original clipped/per-region precision;
production attribution/API and broader admission remain pending.''')
replace(p,'''they do not add production exports or qualify all original precision targets.''', '''they do not add production exports. The separate analytic edge receiving
qualifies all original precision targets at its stated synthetic scope.''')
p='docs/content/dfnd/validation_and_scope.md'
replace(p,'''profile has exact zero finite-hull probe-center volume; certified nonempty
region volumes remain pending. These are independent physical references,
with native/public candidate qualification still under #181.''', '''profile has exact zero finite-hull probe-center volume. The later analytic
edge receiving described below also certifies the requested nonempty region
volumes. These are independent physical references, with native/public
candidate qualification still under #181.''')
before(p,'## Source deliveries and remaining scientific/public boundaries', '''The later {ref}`analytic edge receiving <reference-validator-edge-volumes>`
meets **all nineteen original volume requests**, for the total and every region.
Both the absolute requirement `V(domain) × 2⁻²⁴` and relative requirement `2⁻²⁴`
are satisfied, including sixteen positive regions and six exact-zero profiles.
Analytic integration uses certified outward rational error bounds rather than
sampling uncertainty. These bounds concern the fixed numerical atom/probe/domain
model; they do not quantify uncertainty in atomic radii or coordinates. Native
DFND measurements and public feature qualification are unchanged. Broader
molecular validation and public-validator admission remain separate work.

''')
p='devguide/DFND/documentation_checkpoint.md'
before(p,'## Later runtime deliveries — 2026-11-10', '''## Independent original-volume precision — 2026-11-15

The validation chapter now links the [new validator receiving](../../docs/content/benchlab/synthetic/reference_validator_report.md#reference-validator-edge-volumes):
all nineteen original k=24 total/per-region requests pass, including sixteen
positive regions and six exact zeros. The text distinguishes numerical error
bounds on the frozen Model from input/model uncertainty. Earlier failed range/
box integrals retain their own method/source scope. No native DFND operator,
query, promotion, measurement or worked-example input changes. #181/#180/#184/
#188, broader native receiving and public/installed admission remain separate.

''')
