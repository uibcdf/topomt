import json,time,cProfile,pstats
from pathlib import Path
from devtools.reference_validator.model import Model
from devtools.reference_validator.verify.edge_volume import assigned_faces,triangle_flux
base=Path('devguide/evidence/reference_validator_edge_volume_v1/cost');base.mkdir(exist_ok=False)
spec=json.loads(Path('devguide/evidence/reference_validator_region_volume_v1/original/dumbbell/profile_0/protocol.json').read_text())
t=time.monotonic();m=Model.from_record(spec['model']);print('model_seconds',time.monotonic()-t,flush=True)
p=Path(spec['topology_path']);proof=json.loads(p.read_text());old=json.loads(p.with_name('verification.json').read_text())
t=time.monotonic();pieces=assigned_faces(m,proof,old);print('face_seconds',time.monotonic()-t,'pieces',len(pieces),flush=True)
prof=cProfile.Profile();prof.enable();t=time.monotonic()
for i,(center,radius,triangle,region) in enumerate(pieces):
 triangle_flux(center,radius,triangle,64)
 if i==31:break
prof.disable();print('32_triangles_seconds',time.monotonic()-t,flush=True)
prof.dump_stats(str(base/'primitive.prof'))
with (base/'profile.txt').open('w') as f:pstats.Stats(prof,stream=f).sort_stats('cumtime').print_stats(30)
