import hashlib,json,os,subprocess,sys
from pathlib import Path
base=Path('devguide/evidence/reference_validator_edge_volume_v1')
plan=json.loads(Path('devguide/evidence/reference_validator_region_volume_v1/plan.json').read_text())
jobs=[j for j in plan['jobs'] if j['category']=='original'];assert len(jobs)==19
frozen={'owner':'uibcdf/topomt#76','jobs':jobs,'requested_k':24,'scope':'same nineteen original numerical Models; sequential one-CPU independent saved checking','resources':{'cpu_soft_seconds':300,'cpu_hard_seconds':330,'wall_seconds':420,'address_space_bytes':2*1024**3}}
(base/'original_retry_plan.json').write_text(json.dumps(frozen,indent=2)+'\n')
rows=[]
# Challenge the ambiguous multi-region geometry first, then follow the frozen order.
jobs.sort(key=lambda j:(not j['name'].startswith('original/dumbbell'),j['name']))
for job in jobs:
 spec=Path(job['protocol']);assert hashlib.sha256(spec.read_bytes()).hexdigest()==job['sha256']
 folder=base/'original_retry'/job['name'].removeprefix('original/');folder.parent.mkdir(parents=True,exist_ok=True)
 execution=folder.with_name(folder.name+'_execution')
 cmd=[sys.executable,'/tmp/topomt-edge-case-bounded.py','--record',str(execution.with_suffix('.json')),'--log',str(execution.with_suffix('.log')),'--',sys.executable,'/tmp/topomt-edge-original-worker.py',str(spec),str(folder)]
 result=subprocess.run(cmd,env=dict(os.environ,PYTHONPATH=str(Path.cwd())));record={'name':job['name'],'exit_code':result.returncode}
 if (folder/'receipt.json').exists():record.update(json.loads((folder/'receipt.json').read_text()))
 rows.append(record);(base/'original_retry_summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(record),flush=True)
 if result.returncode:break
