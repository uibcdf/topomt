import json,time
from pathlib import Path
from fractions import Fraction
from devtools.reference_validator.model import Model
from devtools.reference_validator.verify import verify
from devtools.reference_validator.verify.geometry import volume
from devtools.reference_validator.edge_volume import edge_volume_certificate
from devtools.reference_validator.volume_request import VolumeRequest
out=Path('devguide/evidence/reference_validator_edge_volume_v1/tetrahedron')
out.mkdir(parents=True,exist_ok=False)
rows=[]
for profile in range(3):
 original=Path(f'devguide/evidence/reference_validator_region_volume_v1/original/regular_tetrahedron/profile_{profile}/protocol.json')
 spec=json.loads(original.read_text());m=Model.from_record(spec['model']);proof=json.loads(Path(spec['topology_path']).read_text())
 req=VolumeRequest(volume(m.domain)/2**24,Fraction(1,2**24))
 t,c=time.monotonic(),time.process_time()
 cert=edge_volume_certificate(m,proof,req)
 result=verify(m,cert)
 row={'profile':profile,'model_sha256':m.digest,'wall_seconds':time.monotonic()-t,'cpu_seconds':time.process_time()-c,'bits':cert['bits'],'precision_status':result['precision_status'],'face_piece_count':result['face_piece_count'],'volume_lower':result['volume_lower'],'volume_upper':result['volume_upper']}
 rows.append(row)
 for name,obj in [('model',m.to_record()),('certificate',cert),('verification',result)]:
  (out/f'{name}_{profile}.json').write_text(json.dumps(obj,indent=2)+'\n')
 print(json.dumps(row),flush=True)
(out/'receipt.json').write_text(json.dumps(rows,indent=2)+'\n')
