"""Verify recorded child file paths and loaded original source bytes."""

import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

WORK = Path(__file__).resolve().parent.parent
TASK = Path('/tmp/topomt-pycasta-handoff-bshtk36l')
PREFIX = TASK / 'receiver'
rows = []
bundles = [
    *TASK.glob('installed-flow-1/flow-output/*/handoff/original.zip'),
    *TASK.glob('source-independent-flow/*/handoff/original.zip'),
    *TASK.glob('installed-suite-1/pytest-temp/**/*.zip'),
]
with ZipFile(next((WORK / 'inputs').glob('pycasta-1.0.8-*.whl'))) as upstream:
    for path in sorted(bundles):
        if path.is_symlink():
            continue
        with ZipFile(path) as saved:
            if 'manifest.json' not in saved.namelist():
                continue
            manifest = json.loads(saved.read('manifest.json'))
            meta = manifest.get('metadata', {})
            if (manifest.get('provider') != 'pycasta'
                    or meta.get('distribution_version') != '1.0.8'):
                continue
            trace = json.loads(saved.read(meta['worker_origin_artifact']))
            source = Path(trace['source_root']).resolve()
            assert source == PREFIX / 'lib/python3.14/site-packages/pycasta'
            assert Path(trace['executable']).resolve().is_relative_to(PREFIX)
            assert trace['distribution_version'] == '1.0.8'
            regular = 0
            fileless = []
            for name, entry in trace['modules'].items():
                if entry['file']:
                    module_file = Path(entry['file']).resolve()
                    assert module_file.is_relative_to(PREFIX) and module_file.is_file()
                    regular += 1
                else:
                    fileless.append({'module': name, 'spec_origin': entry['spec_origin']})
                # Schema 1 records str(spec.origin), including the literal 'None'
                # for namespace modules. Preserve that observation without
                # treating the sentinel as a filesystem path or proving ownership.
                origin = entry['spec_origin']
                if origin not in (None, 'None', 'built-in', 'frozen'):
                    assert Path(origin).resolve().is_relative_to(PREFIX)
            for entry in trace['sys_path']:
                assert entry and Path(entry).resolve().is_relative_to(PREFIX)
            for name, info in trace['source_files'].items():
                payload = saved.read(name)
                relative = Path(info['path']).resolve().relative_to(source)
                assert len(payload) == info['bytes']
                assert hashlib.sha256(payload).hexdigest() == info['sha256']
                assert payload == upstream.read('pycasta/' + relative.as_posix())
            assert meta['source_sha256'] == hashlib.sha256(
                upstream.read('pycasta/run_analysis.py')).hexdigest()
            rows.append({
                'bundle': str(path), 'worker_module_count': len(trace['modules']),
                'normal_file_modules_verified': regular,
                'original_sources_matched_to_published_wheel': len(trace['source_files']),
                'fileless_raw_observations': fileless,
            })
assert len(rows) >= 6
result = {
    'passed': True, 'rows': rows,
    'limits': [
        'Child normal module paths and exact loaded original source bytes are checked.',
        'Fileless child objects remain raw observations, including schema-1 None sentinels; no complete typed ownership attestation is claimed.',
        'The parent uses the separate full OriginProbe and prefix integrity checks.',
    ],
}
(WORK / 'evidence/worker-origin-file-verification.json').write_text(
    json.dumps(result, indent=2) + '\n')
print(json.dumps({'verified_bundles': len(rows),
    'module_counts': sorted({r['worker_module_count'] for r in rows}),
    'original_source_counts': sorted({r['original_sources_matched_to_published_wheel'] for r in rows})}))
