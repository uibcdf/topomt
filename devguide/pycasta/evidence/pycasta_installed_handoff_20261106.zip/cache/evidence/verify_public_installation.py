"""Independently compare public wheel bytes and unchanged receiving inventories."""

import base64
import csv
import hashlib
import io
import json
import os
import re
from importlib.metadata import PathDistribution
from pathlib import Path, PurePosixPath
from urllib.parse import unquote, urlsplit
from zipfile import ZipFile

BASE = Path(__file__).resolve().parents[1]
PREFIX = Path('/tmp/topomt-pycasta-handoff-bshtk36l/receiver')
SITE = PREFIX / 'lib/python3.14/site-packages'


def digest(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def normalize(name: str) -> str:
    return re.sub('[-_.]+', '-', name).lower()


def main() -> int:
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
    os.nice(10)
    inputs = json.loads((BASE / 'inputs/dependency-acquisition.json').read_text())
    before = json.loads((BASE / 'receiving-prefix-dependencies.json').read_text())
    baseline = json.loads((BASE.parent / 'alphaspace2-installed-receiving/evidence/engine-free-environment/profile.json').read_text())
    distributions = {}
    duplicates = []
    for path in sorted([*SITE.glob('*.dist-info'), *SITE.glob('*.egg-info')]):
        dist = PathDistribution(path)
        name = normalize(dist.metadata['Name'])
        if name in distributions:
            duplicates.append(name)
        distributions[name] = dist
    if duplicates:
        raise ValueError(f'Duplicate distributions: {duplicates}')
    baseline_versions = before['all_installed_versions']
    added = sorted(set(distributions) - set(baseline_versions))
    removed = sorted(set(baseline_versions) - set(distributions))
    expected_added = sorted(row['name'] for row in inputs['selected_artifacts'])
    changed = {name: [version, distributions[name].version] for name, version in baseline_versions.items() if name in distributions and distributions[name].version != version}
    if removed or changed or added != expected_added:
        raise ValueError(f'Distribution inventory differs: removed={removed}, changed={changed}, additions={added}')
    fields = ('name', 'version', 'build', 'fn', 'sha256')
    expected_conda = {row['name']: {key: row.get(key) for key in fields} for row in baseline['conda_packages']}
    actual_conda = {}
    for path in sorted((PREFIX / 'conda-meta').glob('*.json')):
        row = json.loads(path.read_text())
        actual_conda[row['name']] = {key: row.get(key) for key in fields}
    if actual_conda != expected_conda or len(actual_conda) != 398:
        raise ValueError('Conda package name/version/build/filename/hash inventory differs from engine-free baseline')
    artifacts = []
    for row in inputs['selected_artifacts']:
        wheel = BASE / 'inputs' / row['filename']
        if wheel.stat().st_size != row['bytes'] or digest(wheel) != row['sha256']:
            raise ValueError(f'Input wheel differs: {row["name"]}')
        dist = distributions[row['name']]
        if dist.version != row['version']:
            raise ValueError('Installed wheel version differs')
        direct = json.loads(dist.read_text('direct_url.json'))
        location = urlsplit(direct['url'])
        if direct.get('dir_info', {}).get('editable') or direct['archive_info']['hashes']['sha256'] != row['sha256']:
            raise ValueError('Installed direct-input identity differs')
        if location.scheme != 'file' or Path(unquote(location.path)).resolve() != wheel.resolve():
            raise ValueError('Installed direct-input wheel path differs')
        payload = []
        skipped = []
        with ZipFile(wheel) as archive:
            for item in archive.infolist():
                if item.is_dir():
                    continue
                parts = PurePosixPath(item.filename)
                if parts.is_absolute() or '..' in parts.parts or '\\' in item.filename:
                    raise ValueError('Unsafe wheel member')
                if item.filename.endswith('.dist-info/RECORD'):
                    skipped.append({'member': item.filename, 'reason': 'pip regenerates RECORD; installed manifest independently checked below'})
                    continue
                if '.data' in parts.parts[0]:
                    kind, *tail = parts.parts[1:]
                    if kind in {'purelib', 'platlib'}:
                        destination = SITE.joinpath(*tail)
                    elif kind == 'data':
                        destination = PREFIX.joinpath(*tail)
                    else:
                        raise ValueError(f'Wheel scheme needs explicit review: {item.filename}')
                else:
                    destination = SITE / item.filename
                if not destination.resolve().is_relative_to(PREFIX):
                    raise ValueError('Installed payload escapes receiving prefix')
                raw = archive.read(item)
                if destination.read_bytes() != raw:
                    raise ValueError(f'Installed payload bytes differ: {item.filename}')
                payload.append({'member': item.filename, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
        record_count = 0
        for filename, expected, size in csv.reader(io.StringIO(dist.read_text('RECORD'))):
            if filename.endswith(('.pyc', '.pyo')):
                continue
            path = Path(dist.locate_file(filename)).resolve()
            if not path.is_relative_to(PREFIX):
                raise ValueError('Installed RECORD escapes receiving prefix')
            if size and path.stat().st_size != int(size):
                raise ValueError('Installed RECORD size differs')
            if expected:
                algorithm, value = expected.split('=', 1)
                actual = base64.urlsafe_b64encode(hashlib.new(algorithm, path.read_bytes()).digest()).rstrip(b'=').decode()
                if actual != value:
                    raise ValueError('Installed RECORD hash differs')
                record_count += 1
        artifacts.append({**row, 'payload_members_verified': len(payload), 'payload': payload, 'generated_manifest_exceptions': skipped, 'installed_record_hashes_verified': record_count, 'installed_metadata_path': str(dist._path), 'direct_url': direct, 'entry_points': [{'name': ep.name, 'group': ep.group, 'value': ep.value} for ep in dist.entry_points]})
    report = {'profile': 'pycasta-public-installed-wheel-content-verification-1', 'passed': True, 'prefix': str(PREFIX), 'artifacts': artifacts, 'artifact_count': len(artifacts), 'payload_members_verified': sum(row['payload_members_verified'] for row in artifacts), 'installed_record_hashes_verified': sum(row['installed_record_hashes_verified'] for row in artifacts), 'baseline_distribution_count': len(baseline_versions), 'actual_distribution_count': len(distributions), 'exact_added_distributions': added, 'removed_distributions': removed, 'baseline_version_changes': changed, 'conda_count': len(actual_conda), 'conda_inventory_identical': True, 'conda_inventory': list(actual_conda.values()), 'package_imports_executed': False, 'limits': ['Wheel contents including modules/data/METADATA/WHEEL/entry-points compare exactly; RECORD is installed-generated and independently verified.', 'Generated console launchers have no direct wheel byte equivalent; native integrity helper inventories their installed hashes separately.', 'No imports, calculations, installed-package mutations or compatibility claims follow from file identity alone.']}
    output = BASE / 'evidence/public-installation-byte-verification.json'
    with output.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({key: report[key] for key in ('passed', 'artifact_count', 'payload_members_verified', 'installed_record_hashes_verified', 'baseline_distribution_count', 'actual_distribution_count', 'exact_added_distributions', 'conda_count', 'conda_inventory_identical')}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
