"""Observe the installed original's script imports without executing analysis."""

import hashlib
import importlib
import importlib.metadata
import importlib.util
import json
import os
import sys
from pathlib import Path

os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
os.nice(10)
prefix = Path(sys.prefix).resolve()
optional = {}
for name in ('pymol', 'pymol2', 'freesasa'):
    spec = importlib.util.find_spec(name)
    optional[name] = None if spec is None else spec.origin
if optional['pymol'] is not None or optional['pymol2'] is not None:
    raise ValueError('This import-only profile declares the optional PyMOL routes absent')
dist = importlib.metadata.distribution('pycasta')
source = Path(dist.locate_file('pycasta')).resolve()
if not source.is_relative_to(prefix):
    raise ValueError('The original script root is outside the receiving prefix')
sys.path.insert(0, str(source))
module = importlib.import_module('run_analysis')
names = (
    'run_analysis', 'config', 'pocket_detection', 'alpha_shape',
    'cgal_wdelaunay', 'ranking', 'utils.preprocessing_utils',
    'utils.geometry_utils', 'utils.sasa_utils', 'numpy', 'scipy',
    'pandas', 'Bio', 'biopandas', 'sklearn', 'trimesh', 'tabulate',
)
origins = {}
for name in names:
    loaded = sys.modules[name]
    path = Path(vars(loaded)['__file__']).resolve()
    if not path.is_relative_to(prefix):
        raise ValueError(f'Loaded original/import dependency is outside prefix: {name}')
    origins[name] = str(path)
if not callable(vars(module).get('process_pdb')):
    raise ValueError('Published run_analysis does not expose process_pdb')
report = {
    'profile': 'pycasta-installed-original-import-only-1',
    'passed': True,
    'python': sys.version,
    'prefix': str(prefix),
    'cwd': str(Path.cwd()),
    'source_root': str(source),
    'distribution_version': dist.version,
    'run_analysis_sha256': hashlib.sha256((source / 'run_analysis.py').read_bytes()).hexdigest(),
    'loaded_origins': origins,
    'optional_specs': optional,
    'process_pdb_present': True,
    'process_pdb_called': False,
    'pharmacophoremt_loaded': 'pharmacophoremt' in sys.modules,
    'limits': ['Imports only; no detector, molecular input, chemistry, mesh/SASA or recognition execution.'],
}
with Path(sys.argv[1]).open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print('PYCASTA_ORIGINAL_IMPORT_ONLY_PASS')
