"""Build and inspect a development wheel from the preserved isolated source."""

import ast
import base64
import contextlib
import csv
import hashlib
import importlib.metadata
import io
import json
import os
import subprocess
import sys
import tomllib
from email.parser import BytesParser
from pathlib import Path
from zipfile import ZipFile

import setuptools.build_meta
import versioningit
from packaging.utils import parse_wheel_filename

root = Path(__file__).resolve().parents[4]
base = root / '.cache/pycasta-handoff'
source = base / 'source-final'
evidence = base / 'evidence/final-build'
artifacts = base / 'final-artifacts'
metadata_dir = evidence / 'stable-metadata'
metadata_dir.mkdir(exist_ok=False)
os.chdir(source)
before = json.loads((evidence / 'source-before-clone.json').read_text())
if hashlib.sha256((root / 'topomt/_version.py').read_bytes()).hexdigest() != before[
    'root_version_sha256'
]:
    raise ValueError('The principal checkout version file changed')
generated = versioningit.get_version(source, write=True, fallback=False)
with (evidence / 'stable-metadata.log').open('w') as log:
    with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        metadata_folder = setuptools.build_meta.prepare_metadata_for_build_wheel(
            str(metadata_dir)
        )
metadata = BytesParser().parsebytes(
    (metadata_dir / metadata_folder / 'METADATA').read_bytes()
)
embedded = ast.literal_eval(ast.parse((source / 'topomt/_version.py').read_bytes()).body[0].value)
after = versioningit.get_version(source, write=False, fallback=False)
stable = {
    'generated_version': generated,
    'metadata_version': metadata['Version'],
    'embedded_version': embedded,
    'calculated_version_after_metadata': after,
    'guard_passed': generated == metadata['Version'] == embedded == after,
    'source_status': subprocess.check_output(
        ['git', 'status', '--porcelain'], text=True
    ).strip(),
}
(evidence / 'stable-version-preflight.json').write_text(
    json.dumps(stable, indent=2) + '\n'
)
if not stable['guard_passed'] or stable['source_status'] != 'M topomt/_version.py':
    raise ValueError('The development version did not stabilize safely')
command = [
    sys.executable,
    '-m',
    'pip',
    'wheel',
    '--no-deps',
    '--no-build-isolation',
    '--no-cache-dir',
    '--no-index',
    '--wheel-dir',
    str(artifacts),
    str(source),
]
(evidence / 'wheel-command.json').write_text(
    json.dumps({'argv': command, 'cwd': str(source)}, indent=2) + '\n'
)
with (evidence / 'wheel-build.log').open('w') as log:
    result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=False)
if result.returncode:
    (evidence / 'wheel-build-failure.json').write_text(
        json.dumps({'exit_code': result.returncode, 'command': command}, indent=2) + '\n'
    )
    raise SystemExit(result.returncode)
wheels = list(artifacts.glob('topomt-*.whl'))
if len(wheels) != 1:
    raise ValueError('Expected exactly one retained TopoMT candidate wheel')
wheel = wheels[0]
wheel_bytes = wheel.read_bytes()
wheel_name, filename_version, _, filename_tags = parse_wheel_filename(wheel.name)
tracked = subprocess.check_output(
    ['git', 'ls-files', '-z', '--', 'topomt', 'molsysviewer_topomt']
).decode().rstrip('\0').split('\0')
resources = tomllib.loads((source / 'devtools/conda-build/resources.toml').read_text())
required = [name.removeprefix('site-packages/') for name in resources['required_paths']]
with ZipFile(wheel) as archive:
    if archive.testzip() is not None:
        raise ValueError('Candidate wheel CRC validation failed')
    names = archive.namelist()
    if len(names) != len(set(names)):
        raise ValueError('Candidate wheel has duplicate members')
    metadata_name = next(name for name in names if name.endswith('.dist-info/METADATA'))
    wheel_metadata = BytesParser().parsebytes(archive.read(metadata_name))
    wheel_embedded = ast.literal_eval(
        ast.parse(archive.read('topomt/_version.py')).body[0].value
    )
    if str(filename_version) != wheel_metadata['Version'] or wheel_embedded != str(
        filename_version
    ):
        raise ValueError('Wheel filename, metadata and embedded versions disagree')
    missing = sorted(set(required) - set(names))
    changed = [name for name in tracked if archive.read(name) != (source / name).read_bytes()]
    if missing or changed:
        raise ValueError(f'Candidate resource/source mismatch: {missing}, {changed}')
    payload = sorted(
        name
        for name in names
        if name.startswith(('topomt/', 'molsysviewer_topomt/'))
    )
    unexpected = sorted(set(payload) - set(tracked))
    if unexpected:
        raise ValueError(f'Unexpected package payload: {unexpected}')
    record_name = next(name for name in names if name.endswith('.dist-info/RECORD'))
    hashed = 0
    for name, digest, declared_size in csv.reader(io.StringIO(archive.read(record_name).decode())):
        data = archive.read(name)
        if declared_size and int(declared_size) != len(data):
            raise ValueError(f'Wheel RECORD size mismatch: {name}')
        if digest:
            algorithm, encoded = digest.split('=', 1)
            actual = base64.urlsafe_b64encode(hashlib.new(algorithm, data).digest()).rstrip(b'=')
            if actual.decode() != encoded:
                raise ValueError(f'Wheel RECORD digest mismatch: {name}')
            hashed += 1
source_status = subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
if source_status != 'M topomt/_version.py':
    raise ValueError('Build modified tracked source beyond the generated version')
human_version_after = hashlib.sha256((root / 'topomt/_version.py').read_bytes()).hexdigest()
if human_version_after != before['root_version_sha256']:
    raise ValueError('The principal version file changed during isolated build')
report = {
    'schema': 'topomt.local-development-wheel-build@1',
    'source_sha': before['root_head'],
    'source_snapshot': str(source),
    'source_status_before_build': stable['source_status'],
    'source_status_after_build': source_status,
    'tracked_source_difference': ['topomt/_version.py'],
    'candidate': {
        'path': str(wheel),
        'filename': wheel.name,
        'bytes': len(wheel_bytes),
        'sha256': hashlib.sha256(wheel_bytes).hexdigest(),
        'metadata_name': wheel_metadata['Name'],
        'metadata_version': wheel_metadata['Version'],
        'embedded_version': wheel_embedded,
        'filename_version': str(filename_version),
        'tags': sorted(str(tag) for tag in filename_tags),
        'requires_python': wheel_metadata['Requires-Python'],
        'requires_dist': wheel_metadata.get_all('Requires-Dist'),
    },
    'python': sys.version,
    'executable': sys.executable,
    'build_tools': {
        name: importlib.metadata.version(name)
        for name in ('versioningit', 'setuptools', 'pip')
    },
    'bdist_wheel_provider': 'setuptools.command.bdist_wheel',
    'wheel_distribution_installed': False,
    'build_command': command,
    'resource_inventory_paths_verified': len(required),
    'tracked_runtime_paths_compared': len(tracked),
    'package_payload_paths': len(payload),
    'record_hashes_verified': hashed,
    'human_version_sha256_before': before['root_version_sha256'],
    'human_version_sha256_after': human_version_after,
    'known_build_followup': 'uibcdf/topomt#78',
    'limits': [
        'Development candidate only; the existing clean-build version transition remains open.',
        'No installed execution, scientific, platform matrix or public delivery claim.',
        'Only the generated version file differs from the original committed source.',
    ],
}
(evidence / 'wheel-build-receipt.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
