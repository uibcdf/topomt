"""Record the existing generated-version transition in an isolated clone."""

import ast
import contextlib
import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys
from email.parser import BytesParser
from pathlib import Path

import setuptools.build_meta
import versioningit

root = Path(__file__).resolve().parents[4]
base = root / '.cache/pycasta-handoff'
source = base / 'source-final'
evidence = base / 'evidence/final-build'
metadata_dir = evidence / 'initial-metadata'
metadata_dir.mkdir(exist_ok=False)
os.chdir(source)
source_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
source_status = subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
if source_head != json.loads((evidence / 'source-before-clone.json').read_text())['root_head'] or source_status:
    raise ValueError('The initial isolated source is not the clean intended commit')
alternates = source / '.git/objects/info/alternates'
object_files = [item for item in (source / '.git/objects').rglob('*') if item.is_file()]
if alternates.exists() or any(item.stat().st_nlink != 1 for item in object_files):
    raise ValueError('The isolated source has shared Git object storage')
before = versioningit.get_version(source, write=False, fallback=False)
with (evidence / 'initial-metadata.log').open('w') as log:
    with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        folder = setuptools.build_meta.prepare_metadata_for_build_wheel(str(metadata_dir))
metadata = BytesParser().parsebytes((metadata_dir / folder / 'METADATA').read_bytes())
embedded_bytes = (source / 'topomt/_version.py').read_bytes()
embedded_tree = ast.parse(embedded_bytes)
embedded = ast.literal_eval(embedded_tree.body[0].value)
after = versioningit.get_version(source, write=False, fallback=False)
report = {
    'source_head': source_head,
    'source_status_before': source_status,
    'source_status_after': subprocess.check_output(
        ['git', 'status', '--porcelain'], text=True
    ).strip(),
    'git_alternates_present': alternates.exists(),
    'git_object_files_with_multiple_links': 0,
    'python': sys.version,
    'python_executable': sys.executable,
    'build_tools': {
        name: importlib.metadata.version(name)
        for name in ('pip', 'setuptools', 'versioningit')
    },
    'clean_calculated_version': before,
    'metadata_version': metadata['Version'],
    'embedded_version': embedded,
    'subsequent_calculated_version': after,
    'initial_version_guard_passed': metadata['Version'] == embedded == after,
    'embedded_version_sha256': hashlib.sha256(embedded_bytes).hexdigest(),
    'metadata_directory': str(metadata_dir / folder),
    'known_followup': 'uibcdf/topomt#78',
    'limits': 'Metadata preflight only; no wheel built or scientific package imported.',
}
(evidence / 'version-preflight.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
