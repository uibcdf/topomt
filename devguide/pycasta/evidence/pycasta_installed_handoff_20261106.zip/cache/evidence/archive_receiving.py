"""Archive this task's declared evidence without prefixes or build caches."""

import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

WORK = Path(__file__).resolve().parent.parent
TASK = Path('/tmp/topomt-pycasta-handoff-bshtk36l')
ROOT = WORK.parents[1]
output = WORK / 'archives'
output.mkdir(exist_ok=True)
files = {}
omitted_links = []


def include(path: Path, name: str) -> None:
    if path.is_symlink():
        omitted_links.append(str(path))
    elif path.is_file():
        if name in files:
            raise ValueError('Duplicate archive target: ' + name)
        if name.startswith('/') or '..' in Path(name).parts:
            raise ValueError('Unsafe archive target: ' + name)
        files[name] = path


def tree(path: Path, prefix: str) -> None:
    if not path.is_dir():
        return
    for item in sorted(path.rglob('*')):
        if '__pycache__' not in item.parts:
            include(item, prefix + '/' + item.relative_to(path).as_posix())


tree(WORK / 'evidence', 'cache/evidence')
tree(WORK / 'public-sources', 'cache/public-sources')
for path in sorted(WORK.iterdir()):
    if path.is_file() and path.suffix in {'.json', '.log', '.py'}:
        include(path, 'cache/' + path.name)
for path in sorted((WORK / 'inputs').iterdir()):
    if path.suffix in {'.txt', '.json', '.h5msm'}:
        include(path, 'inputs/' + path.name)
for name in (
    'drivers', 'checker-support', 'harness', 'source-independent-flow',
    'installed-suite-1', 'installed-flow-1', 'installed-recovery-1',
    'installed-recovery-2',
):
    tree(TASK / name, 'task/' + name)
for path in sorted((ROOT / '.cache').iterdir()):
    if path.name.startswith('pycasta') and path != WORK and (path / 'evidence').is_dir():
        tree(path / 'evidence', 'tdd/' + path.name)
summary = json.loads((WORK / 'scientific-summary.json').read_text())
manifest = {
    'profile': 'pycasta-installed-handoff-evidence-1',
    'producer': summary['producer_commit'],
    'candidate_sha256': summary['candidate']['sha256'],
    'omitted_task_links': omitted_links,
    'limits': [
        'Prefixes, build clones/caches and wheel/sdist bytes are excluded; actual installation artifacts are retained separately.',
        'Failed attempts and deliberate invalid test fixtures are preserved as evidence, not accepted scientific records.',
        'TDD logs are development history; the three acceptance receipts own installed qualification.',
    ],
    'files': {},
}
for name, path in sorted(files.items()):
    data = path.read_bytes()
    manifest['files'][name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
encoded = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
archive = output / 'pycasta_installed_handoff_20261106.zip'
with ZipFile(archive, 'x', ZIP_DEFLATED) as saved:
    for name, path in sorted(files.items()):
        saved.write(path, name)
    saved.writestr('MANIFEST.json', encoded)
with ZipFile(archive) as saved:
    assert saved.testzip() is None
    assert set(saved.namelist()) == set(files) | {'MANIFEST.json'}
    for name, row in manifest['files'].items():
        data = saved.read(name)
        assert len(data) == row['bytes']
        assert hashlib.sha256(data).hexdigest() == row['sha256']
result = {
    'archive': archive.name, 'bytes': archive.stat().st_size,
    'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'members': len(files) + 1, 'manifest_sha256': hashlib.sha256(encoded).hexdigest(),
    'manifest': manifest,
}
(output / (archive.stem + '.json')).write_text(json.dumps(result, indent=2) + '\n')
(output / (archive.name + '.sha256')).write_text(result['sha256'] + '  ' + archive.name + '\n')
small = {key: value for key, value in result.items() if key != 'manifest'}
(WORK / 'archive-result.json').write_text(json.dumps(small, indent=2) + '\n')
print(json.dumps(small, indent=2))
