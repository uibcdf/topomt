"""Freeze missing public wheels while preserving all receiving baseline versions."""

import datetime
import hashlib
import io
import json
import sys
import urllib.error
from email.parser import BytesParser
from pathlib import Path
from zipfile import ZipFile

from packaging.markers import default_environment
from packaging.requirements import Requirement
from packaging.specifiers import SpecifierSet
from packaging.tags import sys_tags
from packaging.utils import canonicalize_name, parse_wheel_filename
from packaging.version import InvalidVersion, Version

sys.path.insert(0, str(Path(__file__).resolve().parent))
from acquire_public_inputs import acquire, preserve

BASE = Path(__file__).resolve().parent
INPUTS = BASE / 'inputs'
BASELINE = json.loads((BASE / 'receiving-prefix-dependencies.json').read_text())
VERSIONS = BASELINE['all_installed_versions']
ENVIRONMENT = {**default_environment(), 'extra': ''}
TAGS = {tag: index for index, tag in enumerate(sys_tags())}
PYTHON = ENVIRONMENT['python_full_version']


def active(value: str) -> Requirement | None:
    requirement = Requirement(value)
    if requirement.url:
        raise ValueError('Only public-index dependency names are admitted')
    if requirement.marker and not requirement.marker.evaluate(ENVIRONMENT):
        return None
    if requirement.extras:
        raise ValueError('Explicit extras require a separate reviewed profile')
    return requirement


def metadata(name: str, version: str | None = None) -> dict:
    suffix = f'/{version}' if version else ''
    raw = acquire(f'https://pypi.org/pypi/{name}{suffix}/json', 25_000_000)
    data = json.loads(raw)
    selected = version or data['info']['version']
    preserve(INPUTS / f'pypi-dependency-{name}-{selected}.json', raw)
    return data


def select(requirement: Requirement, rejected: list[dict]) -> dict:
    name = canonicalize_name(requirement.name)
    project = metadata(name)
    versions = []
    for text in project['releases']:
        try:
            candidate = Version(text)
        except InvalidVersion:
            continue
        if not candidate.is_prerelease and requirement.specifier.contains(candidate):
            versions.append(candidate)
    for candidate in sorted(versions, reverse=True)[:25]:
        data = project if str(candidate) == project['info']['version'] else metadata(name, str(candidate))
        python_requirement = data['info'].get('requires_python') or ''
        if python_requirement and not SpecifierSet(python_requirement).contains(PYTHON):
            continue
        wheels = []
        for item in data['urls']:
            if item['packagetype'] != 'bdist_wheel' or item.get('yanked'):
                continue
            _, version, _, tags = parse_wheel_filename(item['filename'])
            compatible = [TAGS[tag] for tag in tags if tag in TAGS]
            if version == candidate and compatible:
                wheels.append((min(compatible), item))
        for _, artifact in sorted(wheels, key=lambda row: row[0]):
            if not 0 < artifact['size'] <= 100_000_000:
                raise ValueError('Dependency artifact size requires explicit review')
            raw = acquire(artifact['url'], artifact['size'])
            digest = hashlib.sha256(raw).hexdigest()
            if len(raw) != artifact['size'] or digest != artifact['digests']['sha256']:
                raise ValueError('Dependency wheel hash/size differs from PyPI')
            with ZipFile(io.BytesIO(raw)) as archive:
                path = next(name for name in archive.namelist() if name.endswith('.dist-info/METADATA'))
                wheel = BytesParser().parsebytes(archive.read(path))
            if canonicalize_name(wheel['Name']) != name or Version(wheel['Version']) != candidate:
                raise ValueError('Wheel metadata identity differs from selected public version')
            dependencies = wheel.get_all('Requires-Dist', [])
            conflicts = []
            for text in dependencies:
                dependency = active(text)
                if dependency is None:
                    continue
                existing = VERSIONS.get(canonicalize_name(dependency.name))
                if existing is not None and not dependency.specifier.contains(existing):
                    conflicts.append({'requirement': str(dependency), 'baseline_version': existing})
            if conflicts:
                rejected.append({'name': name, 'version': str(candidate), 'conflicts': conflicts})
                continue
            destination = INPUTS / artifact['filename']
            preserve(destination, raw)
            return {'name': name, 'version': str(candidate), 'filename': artifact['filename'], 'bytes': len(raw), 'sha256': digest, 'url': artifact['url'], 'requires_python': wheel['Requires-Python'], 'requires_dist': dependencies}
    raise ValueError(f'No reviewed baseline-compatible public wheel found for {requirement}')


def main() -> int:
    attempt = sys.argv[1]
    try:
        acquisition = json.loads((INPUTS / 'acquisition.json').read_text())
        pycasta = next(row for row in acquisition['artifacts'] if row['packagetype'] == 'bdist_wheel')
        with ZipFile(INPUTS / pycasta['filename']) as archive:
            path = next(name for name in archive.namelist() if name.endswith('.dist-info/METADATA'))
            metadata = BytesParser().parsebytes(archive.read(path))
        pending = [*metadata.get_all('Requires-Dist', []), 'biopandas', 'colorama']
        selected, retained, rejected = {}, {}, []
        while pending:
            requirement = active(pending.pop(0))
            if requirement is None:
                continue
            name = canonicalize_name(requirement.name)
            if name in VERSIONS:
                if not requirement.specifier.contains(VERSIONS[name]):
                    raise ValueError(f'Baseline provider does not satisfy {requirement}; no automatic upgrade')
                retained[name] = VERSIONS[name]
                continue
            if name in selected:
                if not requirement.specifier.contains(selected[name]['version']):
                    raise ValueError('Dependency constraints conflict; no implicit replacement')
                continue
            selected[name] = select(requirement, rejected)
            pending.extend(selected[name]['requires_dist'])
        artifacts = [{'name': 'pycasta', 'version': '1.0.8', **pycasta}, *selected.values()]
        lock = ''.join(f'{row["name"]} @ {(INPUTS / row["filename"]).as_uri()} --hash=sha256:{row["sha256"]}\n' for row in artifacts)
        preserve(INPUTS / 'dependency-wheel-inputs.txt', lock.encode())
        report = {'profile': 'pycasta-public-missing-wheel-closure-1', 'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'receiver_prefix': BASELINE['prefix'], 'baseline_distribution_count': BASELINE['installed_distribution_count'], 'baseline_versions_retained': retained, 'selected_artifacts': artifacts, 'rejected_baseline_conflicting_candidates': rejected, 'wheel_tag_python': PYTHON, 'installed_packages': False, 'executed_package_code': False, 'limits': ['Wheel tag/metadata compatibility only, not imports or scientific qualification.', 'All initially installed versions are preserved; only missing wheels selected.', 'No PyMOL, FreeSASA, Rtree, CGAL or other optional-extra route is added.', 'PyCASTA missing metadata dependencies biopandas/colorama are explicit reviewed additions.']}
        preserve(INPUTS / 'dependency-acquisition.json', (json.dumps(report, indent=2) + '\n').encode())
        print(json.dumps({'receipt': str(INPUTS / 'dependency-acquisition.json'), 'lock': str(INPUTS / 'dependency-wheel-inputs.txt'), 'selected': [{'name': row['name'], 'version': row['version'], 'filename': row['filename']} for row in artifacts], 'baseline_retained': retained}))
        return 0
    except urllib.error.URLError as error:
        category = f'http-{error.code}' if isinstance(error, urllib.error.HTTPError) else 'network-dns-or-connect'
        preserve(INPUTS / f'dependency-attempt-{attempt}.json', (json.dumps({'attempt': attempt, 'error_category': category}) + '\n').encode())
        print(json.dumps({'attempt': attempt, 'error_category': category}))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
