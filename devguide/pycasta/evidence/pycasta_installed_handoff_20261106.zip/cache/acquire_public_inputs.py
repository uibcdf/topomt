"""Download PyPI metadata and exact public pyCASTA artifacts without installing."""

import datetime
import hashlib
import json
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent / 'inputs'


def acquire(url: str, limit: int) -> bytes:
    parsed = urlsplit(url)
    if parsed.scheme != 'https' or parsed.hostname not in {'pypi.org', 'files.pythonhosted.org'}:
        raise ValueError('Only public PyPI HTTPS inputs are permitted')
    request = urllib.request.Request(url, headers={'User-Agent': 'TopoMT-public-artifact-review'})
    with urllib.request.urlopen(request, timeout=60) as response:
        final = urlsplit(response.url)
        if final.scheme != 'https' or final.hostname not in {'pypi.org', 'files.pythonhosted.org'}:
            raise ValueError('Unexpected artifact redirect')
        data = response.read(limit + 1)
    if len(data) > limit:
        raise ValueError('Public input exceeds the declared size bound')
    return data


def preserve(path: Path, raw: bytes) -> None:
    if path.exists():
        if path.read_bytes() != raw:
            raise ValueError('Existing public input has different bytes; preserve it')
    else:
        with path.open('xb') as stream:
            stream.write(raw)


def main() -> int:
    ROOT.mkdir(parents=True, exist_ok=True)
    attempt = sys.argv[1]
    try:
        current_url = 'https://pypi.org/pypi/pycasta/json'
        release_url = 'https://pypi.org/pypi/pycasta/1.0.8/json'
        current_raw = acquire(current_url, 20_000_000)
        release_raw = acquire(release_url, 20_000_000)
        current, release = json.loads(current_raw), json.loads(release_raw)
        if release['info']['version'] != '1.0.8':
            raise ValueError('Unexpected release identity')
        preserve(ROOT / 'pypi-project.json', current_raw)
        preserve(ROOT / 'pypi-1.0.8.json', release_raw)
        files = []
        for item in release['urls']:
            if item['packagetype'] not in {'bdist_wheel', 'sdist'}:
                continue
            name, size = item['filename'], item['size']
            expected = item['digests']['sha256']
            if Path(name).name != name or not re.fullmatch(r'[A-Za-z0-9_.+-]+', name):
                raise ValueError('Unexpected artifact name')
            if not isinstance(size, int) or not 0 < size <= 100_000_000:
                raise ValueError('Unexpected artifact size')
            if not re.fullmatch(r'[0-9a-f]{64}', expected):
                raise ValueError('Unexpected public artifact digest')
            data = acquire(item['url'], size)
            digest = hashlib.sha256(data).hexdigest()
            if len(data) != size or digest != expected:
                raise ValueError('Public artifact hash or size differs from PyPI metadata')
            preserve(ROOT / name, data)
            files.append({'filename': name, 'bytes': size, 'sha256': digest, 'url': item['url'], 'packagetype': item['packagetype'], 'uploaded_utc': item.get('upload_time_iso_8601'), 'yanked': item.get('yanked')})
        report = {'profile': 'pycasta-public-artifact-acquisition-1', 'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'attempt': attempt, 'project_metadata_url': current_url, 'release_metadata_url': release_url, 'current_public_version': current['info']['version'], 'selected_version': '1.0.8', 'metadata_requires_python': release['info'].get('requires_python'), 'metadata_requires_dist': release['info'].get('requires_dist'), 'artifacts': files, 'metadata': {'pypi-project.json': hashlib.sha256(current_raw).hexdigest(), 'pypi-1.0.8.json': hashlib.sha256(release_raw).hexdigest()}, 'executed_package_code': False, 'installed_packages': False, 'limits': ['PyPI metadata and artifact byte identity only; no import, scientific execution or Python 3.14 compatibility qualification.']}
        preserve(ROOT / 'acquisition.json', (json.dumps(report, indent=2) + '\n').encode())
        print(json.dumps({'current_public_version': report['current_public_version'], 'artifacts': files, 'receipt': str(ROOT / 'acquisition.json')}))
        return 0
    except urllib.error.URLError as error:
        category = 'network-dns-or-connect'
        if isinstance(error, urllib.error.HTTPError):
            category = f'http-{error.code}'
        failure = {'profile': 'pycasta-public-acquisition-failed-attempt-1', 'attempt': attempt, 'error_category': category, 'package_code_executed': False}
        preserve(ROOT / f'attempt-{attempt}.json', (json.dumps(failure, indent=2) + '\n').encode())
        print(json.dumps(failure))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
