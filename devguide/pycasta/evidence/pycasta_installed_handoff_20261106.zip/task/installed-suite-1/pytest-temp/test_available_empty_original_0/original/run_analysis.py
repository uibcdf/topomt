# Synthetic worker; never executed.
