VERSION_TAG="synthetic"
def process_pdb(path):
    return {"ranked_pockets": []}
