"""Run two independent prepared original pyCASTA consumer flows."""

import argparse
import hashlib
import importlib.metadata as metadata
import json
import sys
from pathlib import Path
from typing import Any

SEED_SHA256 = 'a42ef9868578ba16c62d52a1267d24160b973dca0d50dbc804ca46b6b2fe316a'
RECIPE = {
    'pocket_id': 'pycasta:0',
    'projection_direction': (1.0, 0.0, 0.0),
    'distance': '0.30 nm',
    'radius': '0.15 nm',
}


def run_control(args: argparse.Namespace) -> dict[str, Any]:
    """Persist both unit-policy flows with explicit input and import ownership."""
    harness = args.harness.resolve(strict=True)
    seed = args.seed.resolve(strict=True)
    output = args.output.resolve()
    prefix = args.expected_prefix.resolve(strict=True)
    if (
        args.phase not in {'source', 'installed'}
        or Path(sys.prefix).resolve() != prefix
    ):
        raise ValueError(
            'An explicit phase and its receiving interpreter are required.'
        )
    if output.exists():
        raise FileExistsError(output)
    if hashlib.sha256(seed.read_bytes()).hexdigest() != SEED_SHA256:
        raise ValueError('The prepared input changed.')
    sys.path.insert(0, str(harness))

    import molsysmt as msm
    import numpy as np

    import topomt
    from devtools.provider_handoff import pocket_outputs_agree, pocket_signature
    from devtools.qualify_pharmacophore_handoff import _same_sites, consume
    from devtools.qualify_pycasta_handoff import qualify
    from topomt import pyunitwizard as puw
    from topomt.provider_output import ProviderRun

    if args.phase == 'installed':
        dist = metadata.distribution('topomt')
        origin = Path(topomt.__file__).resolve()
        if (
            not origin.is_relative_to(prefix)
            or origin != Path(dist.locate_file('topomt/__init__.py')).resolve()
        ):
            raise ValueError('Installed TopoMT is shadowed or outside its receiver.')
        if topomt.__version__ != dist.version:
            raise ValueError('Installed TopoMT metadata and embedded version disagree.')
    for function, name in (
        (qualify, 'qualify_pycasta_handoff.py'),
        (consume, 'qualify_pharmacophore_handoff.py'),
        (_same_sites, 'qualify_pharmacophore_handoff.py'),
    ):
        if Path(function.__code__.co_filename).resolve() != harness / 'devtools' / name:
            raise ValueError('The declared developer support was shadowed.')
    if metadata.version('pycasta') != '1.0.8':
        raise ValueError('The fixed original distribution is pyCASTA 1.0.8.')
    if any(
        name == 'pharmacophoremt' or name.startswith('pharmacophoremt.')
        for name in sys.modules
    ):
        raise ValueError('The consumer was imported before application policy.')

    output.mkdir(parents=True)
    rows, models, originals, sources = [], [], [], []
    for tag, units in (
        ('pm_fs', ['pm', 'fs', 'radians']),
        ('nm_ps', ['nm', 'ps', 'radians']),
    ):
        with puw.context(standard_units=units):
            policy = puw.configure.get_standard_units()
            folder = output / tag
            handoff = qualify(seed, folder / 'handoff')
            consumer = consume(folder / 'handoff', folder / 'consumer', **RECIPE)
            from pharmacophoremt.io import load_json

            model = load_json(folder / 'consumer/query.json')
            if not all(handoff['checks'].values()) or not all(
                consumer['checks'].values()
            ):
                raise ValueError('A receiving control failed.')
            if handoff['pocket_count'] <= 0 or consumer['site_count'] <= 0:
                raise ValueError('The declared composition has no pockets or sites.')
            if policy != puw.configure.get_standard_units():
                raise ValueError('The consumer changed application policy.')
            run = ProviderRun.load(folder / 'handoff/original.zip')
            source = msm.convert(
                folder / 'handoff/source.h5msm', to_form='molsysmt.MolSys'
            )
            original = topomt.get_provider_output(
                source,
                method='pycasta',
                backend='files',
                bundle_file=folder / 'handoff/original.zip',
            )
            if (
                original.run != run
                or consumer['context']['original_run_id'] != run.run_id
            ):
                raise ValueError('The original run identity changed during receiving.')
            xyz = puw.get_value(
                msm.get(source, coordinates=True, structure_indices=1), to_unit='nm'
            )[0]
            for site in model.interaction_sites:
                indices = site.metadata['atom_indices']
                assert (
                    len(indices) == 1 and indices[0] in consumer['pocket_atom_indices']
                )
                np.testing.assert_allclose(
                    puw.get_value(site.center, to_unit='nm'),
                    xyz[indices[0]] + [0.30, 0.0, 0.0],
                    rtol=0,
                    atol=1e-12,
                )
                assert site.features == ['hydrophobicity']
                assert (
                    abs(float(puw.get_value(site.shape.radius, to_unit='nm')) - 0.15)
                    < 1e-12
                )
                assert site.essential is True and site.weight == 1
            assert model.ref_struct == 1
            assert model.metadata['source_inventory']['chemical_state'] == 0
            rows.append({'units': units, 'handoff': handoff, 'consumer': consumer})
            originals.append(original)
            models.append(model)
            sources.append(
                puw.get_value(msm.get(source, coordinates=True), to_unit='nm')
            )
            (folder / 'scientific-signature.json').write_text(
                json.dumps(pocket_signature(original), indent=2) + '\n'
            )
    checks = {
        'both_full_flows_passed': True,
        'application_policy_preserved': True,
        'original_physical_records_agree': pocket_outputs_agree(*originals),
        'physical_sites_agree': _same_sites(*models),
        'source_frames_physically_agree': bool(
            np.allclose(*sources, rtol=0, atol=1e-12)
        ),
        'original_source_and_query_context_preserved': True,
    }
    if not all(checks.values()):
        raise ValueError(f'Independent receiving controls disagree: {checks}')
    receipt = {
        'schema_version': 1,
        'profile': 'original-pycasta-prepared-installed-consumer-1'
        if args.phase == 'installed'
        else 'original-pycasta-prepared-source-consumer-1',
        'phase': args.phase,
        'expected_prefix': str(prefix),
        'topomt_origin': str(Path(topomt.__file__).resolve()),
        'input_sha256': SEED_SHA256,
        'rows': rows,
        'checks': checks,
        'limits': [
            'One prepared receptor, reference state 0 and translated nonperiodic frame 1.',
            'Original default configuration and first-ranked pocket; no native parity claim.',
            'Explicit hydrophobic projection hypothesis; no affinity or biological validation.',
            'Enclosing acceptance owns installed candidate, dependency origins and file integrity.',
        ],
    }
    (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(
        json.dumps(
            {
                'phase': args.phase,
                'checks': checks,
                'pockets': [r['handoff']['pocket_count'] for r in rows],
                'sites': [r['consumer']['site_count'] for r in rows],
            }
        ),
        flush=True,
    )
    return receipt


def main() -> None:
    """Parse declared detached-support, input and receiver paths."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--harness', type=Path, required=True)
    parser.add_argument('--seed', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--phase', choices=['source', 'installed'], required=True)
    parser.add_argument('--expected-prefix', type=Path, required=True)
    run_control(parser.parse_args())


if __name__ == '__main__':
    main()
