"""Run one bounded installed pyCASTA gate with same-process origin evidence."""

import argparse
import ast
import hashlib
import importlib
import importlib.metadata
import json
import os
import re
import runpy
import subprocess
import sys
import traceback
from collections import Counter
from email.parser import BytesParser
from pathlib import Path, PurePosixPath
from urllib.parse import urlparse
from zipfile import ZipFile

WORKSPACE = Path('/fast_data/home/liliana/repos@uibcdf/topomt')
EVIDENCE = WORKSPACE / '.cache/pycasta-handoff/evidence'
BASE_PYTHON = Path('/fast_data/home/liliana/miniconda3/bin/python')
INTEGRITY_HELPER = EVIDENCE / 'integrity/check_prefix_integrity.py'
INTEGRITY_SHA256 = 'fc931ce83cadaa6c7ae2dd4aab686be1e440a9f157544c447ff3f925fab2aaf6'
BYTECODE_WORKER_SHA256 = (
    'f9882ef7891b886ac285064757a6a3af3ae22743052bd943fca07d1752406a12'
)
ORIGIN_PROBE_SHA256 = '64e864058771e1a1de36503e2488cbf1fd253c575727b7e6e860840991cbe136'
FLOW_DRIVER_SHA256 = '399dd4a53721de880055e7fcb2f33916a2537addb011deb4415cf7eee15fe22d'


def _sha256(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def _write(path: Path, value: dict) -> None:
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def _manifest(path: Path, harness: Path, task: Path) -> tuple[dict, Path]:
    data = json.loads(path.read_text())
    checker = Path(data['checker_support_root']).resolve(strict=True)
    if (
        Path(data['harness_root']).resolve() != harness
        or harness != task / 'harness'
        or checker != task / 'checker-support'
    ):
        raise ValueError(
            'Detached harness/checker roots differ from the exact task directories'
        )
    seen = set()
    for row in data['files']:
        name = row['target']
        parts = PurePosixPath(name)
        if (
            not re.fullmatch(r'(?:harness|checker-support)/[A-Za-z0-9_./-]+', name)
            or '..' in parts.parts
            or parts.as_posix() != name
            or name in seen
        ):
            raise ValueError('Unsafe or duplicate detached-support target')
        seen.add(name)
        target = (task / name).resolve(strict=True)
        if (
            not target.is_relative_to(task)
            or target.stat().st_size != row['bytes']
            or _sha256(target) != row['sha256']
        ):
            raise ValueError(f'Detached-support bytes differ: {name}')
    for runtime in ('topomt', 'molsysmt', 'pharmacophoremt', 'pycasta'):
        if (harness / runtime).exists():
            raise ValueError('Detached harness contains a runtime source package')
    return data, checker


def _integrity(prefix: Path, output: Path, baseline: Path | None = None) -> dict:
    if (
        _sha256(INTEGRITY_HELPER) != INTEGRITY_SHA256
        or _sha256(INTEGRITY_HELPER.with_name('verify_regenerated_bytecode.py'))
        != BYTECODE_WORKER_SHA256
    ):
        raise ValueError('Reviewed integrity helper or derivative worker changed')
    command = [str(BASE_PYTHON), str(INTEGRITY_HELPER), str(prefix), str(output)]
    if baseline is not None:
        command += ['--baseline', str(baseline)]
    environment = dict(os.environ)
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    process = subprocess.run(
        command, text=True, capture_output=True, env=environment, check=False
    )
    output.with_suffix('.command.json').write_text(
        json.dumps({'argv': command, 'exit_code': process.returncode}, indent=2) + '\n'
    )
    output.with_suffix('.log').write_text(process.stdout + process.stderr)
    if not output.is_file():
        raise ValueError(
            f'Integrity helper did not retain its report; exit={process.returncode}'
        )
    report = json.loads(output.read_text())
    result = {
        'path': str(output),
        'sha256': _sha256(output),
        'exit_code': process.returncode,
        'passed': report['passed'],
        'baseline_equal': report['baseline_equal'],
        'raw_native_doctor_has_findings': report['raw_native_doctor_has_findings'],
        'verified_regenerated_bytecode': len(
            report['regenerated_bytecode_interpretation']['verified']
        ),
    }
    if process.returncode or not report['passed']:
        raise ValueError(f'Independent prefix integrity failed; see {output}')
    return result


def _candidate(prefix: Path, wheel: Path, expected_hash: str) -> dict:
    if _sha256(wheel) != expected_hash:
        raise ValueError('The retained candidate wheel bytes changed')
    dist = importlib.metadata.distribution('topomt')
    metadata_path = Path(dist._path).resolve()
    direct = json.loads(dist.read_text('direct_url.json') or '{}')
    if (
        not metadata_path.is_relative_to(prefix)
        or direct.get('dir_info', {}).get('editable')
        or direct.get('archive_info', {}).get('hashes', {}).get('sha256')
        != expected_hash
    ):
        raise ValueError(
            'TopoMT is editable, outside the prefix or not installed from the exact candidate archive hash'
        )
    location = urlparse(direct.get('url', ''))
    if location.scheme != 'file' or location.netloc not in ('', 'localhost'):
        raise ValueError('This candidate must retain a local wheel installation URL')
    with ZipFile(wheel) as archive:
        metadata_name = next(
            name for name in archive.namelist() if name.endswith('.dist-info/METADATA')
        )
        wheel_metadata = BytesParser().parsebytes(archive.read(metadata_name))
        embedded = ast.literal_eval(
            ast.parse(archive.read('topomt/_version.py')).body[0].value
        )
    module = importlib.import_module('topomt')
    origin = Path(module.__file__).resolve()
    installed_init = Path(dist.locate_file('topomt/__init__.py')).resolve()
    if (
        origin != installed_init
        or not origin.is_relative_to(prefix)
        or module.__version__ != dist.version
        or dist.version != wheel_metadata['Version']
        or embedded != dist.version
    ):
        raise ValueError(
            'Installed TopoMT origin, metadata and embedded candidate version disagree'
        )
    return {
        'wheel': str(wheel),
        'sha256': expected_hash,
        'version': dist.version,
        'metadata_path': str(metadata_path),
        'origin': str(origin),
        'direct_url': direct,
    }


class Outcomes:
    """Retain collection and every native pytest execution stage."""

    def __init__(self) -> None:
        self.collected = []
        self.deselected = []
        self.collection_failures = []
        self.reports = []

    def pytest_collection_finish(self, session) -> None:
        self.collected = [item.nodeid for item in session.items]

    def pytest_deselected(self, items) -> None:
        self.deselected.extend(item.nodeid for item in items)

    def pytest_collectreport(self, report) -> None:
        if report.failed:
            self.collection_failures.append(
                {'nodeid': report.nodeid, 'message': str(report.longrepr)[:12000]}
            )

    def pytest_runtest_logreport(self, report) -> None:
        self.reports.append(
            {
                'nodeid': report.nodeid,
                'stage': report.when,
                'outcome': report.outcome,
                'wasxfail': getattr(report, 'wasxfail', None),
                'duration': report.duration,
                'failure': str(report.longrepr)[:12000] if report.failed else None,
            }
        )

    def receipt(self, exit_code: int) -> dict:
        stages = {name: Counter() for name in self.collected}
        failures = []
        if (
            exit_code
            or not self.collected
            or len(self.collected) != len(set(self.collected))
            or self.deselected
            or self.collection_failures
        ):
            failures.append(
                'Nonzero exit, empty/duplicate collection, deselection or collection failure'
            )
        for row in self.reports:
            if (
                row['nodeid'] not in stages
                or row['outcome'] != 'passed'
                or row['wasxfail'] is not None
            ):
                failures.append(
                    f'Unaccepted execution stage: {row["nodeid"]} {row["stage"]} {row["outcome"]}'
                )
            else:
                stages[row['nodeid']][row['stage']] += 1
        for name, actual in stages.items():
            if actual != Counter({'setup': 1, 'call': 1, 'teardown': 1}):
                failures.append(f'Missing or repeated execution stages: {name}')
        return {
            'exit_code': exit_code,
            'passed': not failures,
            'collected_nodeids': self.collected,
            'deselected_nodeids': self.deselected,
            'collection_failures': self.collection_failures,
            'stage_reports': self.reports,
            'collected': len(self.collected),
            'fully_executed': sum(
                value == Counter({'setup': 1, 'call': 1, 'teardown': 1})
                for value in stages.values()
            ),
            'failures': failures,
        }


def main() -> int:
    """Execute the selected gate only under the exact installed interpreter."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('suite', 'flow', 'recovery'), required=True)
    parser.add_argument('--prefix', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--harness', type=Path, required=True)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--forbidden-source', type=Path, action='append', required=True)
    parser.add_argument('--expected-wheel', type=Path, required=True)
    parser.add_argument(
        '--expected-wheel-hash',
        '--expected-wheel-sha256',
        dest='expected_wheel_hash',
        required=True,
    )
    parser.add_argument('--native-attestations', type=Path)
    parser.add_argument('--handoff-root', type=Path)
    parser.add_argument('--recovery-driver-sha256')
    args = parser.parse_args()
    prefix = args.prefix.resolve(strict=True)
    output = args.output.resolve()
    if output.is_relative_to(prefix) or output.exists():
        parser.error('Use a new output directory outside the receiving prefix')
    output.mkdir(parents=True)
    receipt = {
        'profile': 'pycasta-installed-acceptance-1',
        'mode': args.mode,
        'passed': False,
        'python': sys.version,
        'executable': sys.executable,
        'prefix': str(prefix),
        'wrapper': {
            'path': str(Path(__file__).resolve()),
            'sha256': _sha256(Path(__file__)),
        },
        'failures': [],
    }
    probe = None
    wheel = None
    completed = False
    baseline = output / 'integrity-before.json'
    try:
        if (
            sys.flags.isolated != 1
            or sys.version_info[:2] != (3, 14)
            or Path(sys.prefix).resolve() != prefix
        ):
            raise ValueError('Use the receiving Python 3.14 interpreter with -I')
        sys.dont_write_bytecode = True
        task = Path(__file__).resolve().parent.parent
        if Path(__file__).resolve() != task / 'drivers/acceptance.py':
            raise ValueError('Execute the declared detached acceptance.py copy')
        harness = args.harness.resolve(strict=True)
        manifest_path = args.manifest.resolve(strict=True)
        manifest, checker = _manifest(manifest_path, harness, task)
        forbidden = tuple(path.resolve() for path in args.forbidden_source)
        if WORKSPACE not in forbidden:
            raise ValueError('The original TopoMT checkout must be forbidden')
        if not re.fullmatch(r'[0-9a-f]{64}', args.expected_wheel_hash):
            raise ValueError('The expected wheel digest must be an exact SHA-256')
        wheel = args.expected_wheel.resolve(strict=True)
        build_path = EVIDENCE / 'final-build/wheel-build-receipt.json'
        build = json.loads(build_path.read_text())
        if (
            build['candidate']['sha256'] != args.expected_wheel_hash
            or build['candidate']['filename'] != wheel.name
            or build['source_sha'] != manifest['producer']
        ):
            raise ValueError(
                'Candidate arguments do not match the retained build producer/receipt'
            )
        selectors_path = harness / 'selectors.json'
        selectors = json.loads(selectors_path.read_text())
        if (
            selectors != manifest['selectors']
            or not selectors
            or len(selectors) != len(set(selectors))
            or any(
                not re.fullmatch(
                    r'tests/(?:[A-Za-z0-9_]+/)*test_[A-Za-z0-9_]+\.py(?:::[A-Za-z_][A-Za-z0-9_]*){0,2}',
                    selector,
                )
                for selector in selectors
            )
        ):
            raise ValueError('Use the exact safe producer-hashed selector inventory')
        seed = harness / 'inputs/prepared.h5msm'
        attestations = {}
        if args.native_attestations:
            attestations = json.loads(args.native_attestations.read_text())
            if not isinstance(attestations, dict) or any(
                not re.fullmatch(
                    r'[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*', name
                )
                for name in attestations
            ):
                raise ValueError(
                    'Native attestations require exact module names, never patterns'
                )
            receipt['native_attestations'] = {
                'path': str(args.native_attestations.resolve()),
                'sha256': _sha256(args.native_attestations),
                'module_names': sorted(attestations),
            }
        receipt['inputs'] = {
            'manifest': str(manifest_path),
            'manifest_sha256': _sha256(manifest_path),
            'harness': str(harness),
            'selectors': selectors,
            'selectors_sha256': _sha256(selectors_path),
            'build_receipt': str(build_path),
            'build_receipt_sha256': _sha256(build_path),
            'forbidden_sources': [str(path) for path in forbidden],
            'prepared_seed': str(seed),
            'prepared_seed_sha256': _sha256(seed),
        }
        receipt['integrity_before'] = _integrity(prefix, baseline)
        if _sha256(checker / 'origin_probe.py') != ORIGIN_PROBE_SHA256:
            raise ValueError('The reviewed detached OriginProbe helper changed')
        sys.path[:0] = [str(checker), str(harness)]
        origin_module = importlib.import_module('origin_probe')
        if Path(origin_module.__file__).resolve() != checker / 'origin_probe.py':
            raise ValueError('OriginProbe was imported from another location')
        drivers = (Path(__file__).resolve(),)
        control_driver = task / 'drivers/run_control.py'
        if args.mode in ('flow', 'recovery'):
            expected_driver_hash = FLOW_DRIVER_SHA256
            if args.mode == 'recovery':
                control_driver = task / 'drivers/engine_free_control.py'
                expected_driver_hash = args.recovery_driver_sha256
                if (
                    not args.handoff_root
                    or not expected_driver_hash
                    or not re.fullmatch(r'[0-9a-f]{64}', expected_driver_hash)
                ):
                    raise ValueError(
                        'Recovery requires a handoff root and exact driver SHA-256'
                    )
            if _sha256(control_driver) != expected_driver_hash:
                raise ValueError('The reviewed independent flow driver changed')
            drivers += (control_driver,)
            receipt['control_driver'] = {
                'path': str(control_driver),
                'sha256': expected_driver_hash,
            }
        probe = origin_module.OriginProbe(
            prefix=prefix,
            harness_manifest=manifest_path,
            forbidden_roots=forbidden,
            driver_files=drivers,
            native_generated=attestations,
        )
        receipt['candidate_before'] = _candidate(
            prefix, wheel, args.expected_wheel_hash
        )
        if args.mode == 'suite':
            os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
            pytest = importlib.import_module('pytest')
            receptor = importlib.import_module('pytest_receptor.plugin')
        before = probe.audit(required_roots=('topomt',))
        probe.write_report(output / 'origins-before.json', before)
        receipt['origins_before'] = {
            'path': str(output / 'origins-before.json'),
            'passed': before['passed'],
            'module_count': before['module_count'],
            'pharmacophoremt_loaded': before['pharmacophoremt_loaded'],
        }
        if not before['passed']:
            raise ValueError('Before-execution runtime origin evidence failed')
        if args.mode in ('flow', 'recovery'):
            if before['pharmacophoremt_loaded']:
                raise ValueError(
                    'Independent flow requires PharmacophoreMT absent before policy selection'
                )
            namespace = runpy.run_path(
                str(control_driver), run_name='declared_pycasta_control'
            )
            if args.mode == 'flow':
                result = namespace['run_control'](
                    argparse.Namespace(
                        harness=harness,
                        seed=seed,
                        output=output / 'flow-output',
                        phase='installed',
                        expected_prefix=prefix,
                    )
                )
                if (
                    result['phase'] != 'installed'
                    or not result['checks']['both_full_flows_passed']
                ):
                    raise ValueError(
                        'The independent control did not complete both installed flows'
                    )
                science_receipt = output / 'flow-output/receipt.json'
            else:
                handoff_root = args.handoff_root.resolve(strict=True)
                result = namespace['run_control'](
                    argparse.Namespace(
                        harness=harness,
                        handoff_root=handoff_root,
                        output=output / 'recovery-output',
                        expected_prefix=prefix,
                    )
                )
                if (
                    not isinstance(result.get('checks'), dict)
                    or not result['checks']
                    or any(value is not True for value in result['checks'].values())
                ):
                    raise ValueError(
                        'The engine-free recovery driver did not retain complete passing checks'
                    )
                science_receipt = output / 'recovery-output/receipt.json'
                receipt['handoff_root'] = str(handoff_root)
            if not science_receipt.is_file():
                raise ValueError('The scientific control did not retain its receipt')
            receipt['science'] = {
                'passed': True,
                'receipt': str(science_receipt),
                'receipt_sha256': _sha256(science_receipt),
                'checks': result['checks'],
            }
        else:
            os.environ['TOPOMT_PREPARED_RECEPTOR'] = str(seed)
            outcomes = Outcomes()
            pytest_args = [
                '--noconftest',
                '--basetemp=' + str(output / 'pytest-temp'),
                '-c',
                str(harness / 'pytest.ini'),
                '--receptor=llm',
                '--junitxml=' + str(output / 'tests.xml'),
                '-p',
                'no:cacheprovider',
                *selectors,
            ]
            os.chdir(harness)
            code = -1
            try:
                code = int(pytest.main(pytest_args, plugins=[receptor, outcomes]))
            finally:
                result = outcomes.receipt(code)
                _write(output / 'pytest-outcomes.json', result)
                receipt['science'] = {
                    'passed': result['passed'],
                    'outcomes': str(output / 'pytest-outcomes.json'),
                    'junit': str(output / 'tests.xml'),
                    'collected': result['collected'],
                    'fully_executed': result['fully_executed'],
                    'command': pytest_args,
                    'reporter_version': importlib.metadata.version('pytest-receptor'),
                }
            if not result['passed']:
                raise ValueError(
                    'Pytest must execute every collected case successfully with zero skips/xfails'
                )
        completed = True
    except BaseException as error:
        receipt['failures'].append(
            {
                'stage': 'before_or_scientific_execution',
                'type': type(error).__name__,
                'message': str(error),
                'traceback': traceback.format_exc(),
            }
        )
    finally:
        if probe is not None:
            try:
                after = probe.audit(
                    required_roots=('topomt', 'molsysmt') if completed else ('topomt',)
                )
                probe.write_report(output / 'origins-after.json', after)
                receipt['origins_after'] = {
                    'path': str(output / 'origins-after.json'),
                    'passed': after['passed'],
                    'module_count': after['module_count'],
                    'pharmacophoremt_loaded': after['pharmacophoremt_loaded'],
                }
                if not after['passed']:
                    raise ValueError('After-execution runtime origin evidence failed')
                if wheel is not None:
                    receipt['candidate_after'] = _candidate(
                        prefix, wheel, args.expected_wheel_hash
                    )
            except BaseException as error:
                receipt['failures'].append(
                    {
                        'stage': 'after_runtime_origins',
                        'type': type(error).__name__,
                        'message': str(error),
                        'traceback': traceback.format_exc(),
                    }
                )
        if baseline.is_file():
            try:
                receipt['integrity_after'] = _integrity(
                    prefix, output / 'integrity-after.json', baseline
                )
            except BaseException as error:
                receipt['failures'].append(
                    {
                        'stage': 'after_prefix_integrity',
                        'type': type(error).__name__,
                        'message': str(error),
                        'traceback': traceback.format_exc(),
                    }
                )
        if 'native_attestations' in receipt:
            try:
                witness = receipt['native_attestations']
                if _sha256(Path(witness['path'])) != witness['sha256']:
                    raise ValueError('Native attestations changed during execution')
            except (OSError, ValueError) as error:
                receipt['failures'].append(
                    {'stage': 'configuration_integrity', 'message': str(error)}
                )
        receipt['passed'] = completed and not receipt['failures']
        receipt['limits'] = [
            'Bounded Linux/Python 3.14 installed candidate control; not the full scientific suite, another platform/minor or public delivery.',
            'Native Conda Doctor raw findings and verified regenerated bytecode remain separate from the interpreted declared-file integrity acceptance.',
            'Runtime origin observations and native-generated-module attestations are retained explicitly; no origins or sys.modules entries are rewritten.',
        ]
        _write(output / 'acceptance-receipt.json', receipt)
    print(
        json.dumps(
            {
                'passed': receipt['passed'],
                'mode': args.mode,
                'receipt': str(output / 'acceptance-receipt.json'),
                'failures': len(receipt['failures']),
            },
            sort_keys=True,
        ),
        flush=True,
    )
    return 0 if receipt['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
