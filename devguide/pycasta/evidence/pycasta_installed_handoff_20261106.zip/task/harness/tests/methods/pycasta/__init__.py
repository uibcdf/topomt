"""PyCASTA method tests."""
