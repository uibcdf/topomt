import hashlib,json,shutil,socket
from pathlib import Path
from collections import Counter
from urllib import request
import molsysmt as msm
import topomt as tmt
from topomt.third_party.castp.servers.castpfold import CastpFoldClient
from devtools.qualify_castpfold_handoff import collect
root=Path('.cache/castp-prepared-receiving')
original=root/'qualified';recovery=root/'recovered-qualified'
before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in original.iterdir() if p.is_file()}
shutil.copytree(original,recovery,ignore=shutil.ignore_patterns('receipt.json','collection-observations.jsonl'))
def forbidden(*args,**kwargs):raise AssertionError('Offline recovery attempted network')
socket.create_connection=forbidden;socket.socket.connect=forbidden;request.urlopen=forbidden
CastpFoldClient.submit=forbidden;CastpFoldClient.download_result_zip_bytes=forbidden
r=collect(recovery)
assert r['run_id']=='e121c3d691e29a1474355735cf6c5ad30b9a87fa92aa3a689c246e83d065d877'
assert all(x is True for x in r['checks'].values())
source=msm.convert(recovery/'source.h5msm',to_form='molsysmt.MolSys')
output=tmt.get_provider_output(source,method='castpfold',backend='files',bundle_file=recovery/'original.zip')
counts=dict(Counter(p.record_kind for p in output.records))
assert counts=={'pocket':42,'mouth_aggregate':22}
assert before=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in original.iterdir() if p.is_file()}
report={'checks':r['checks'],'record_counts':counts,'original_directory_unchanged':True,'run_id':r['run_id'],'source_sha256':r['source_sha256'],'network_blocked':True}
(root/'offline-recovery.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
