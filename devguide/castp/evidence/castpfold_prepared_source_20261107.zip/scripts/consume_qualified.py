import base64,hashlib,json,sys,socket
from pathlib import Path
from urllib import request
import molsysmt as msm
import topomt
from topomt import pyunitwizard as puw
from topomt.third_party.castp.servers.castpfold import CastpFoldClient
from devtools.qualify_pharmacophore_handoff import consume
root=Path('.cache/castp-prepared-receiving/qualified')
r=json.loads((root/'submission.json').read_text())
raw=base64.b64decode(r['http']['response_base64'],validate=True)
assert hashlib.sha256(raw).hexdigest()==r['http']['response_sha256']
assert json.loads(raw)==r['acknowledgement']
assert r['acknowledgement']=={'success':True,'jobid':'j_6aee831b083dc','filename':'input.pdb','probe':'1.4','email':'N/A'}
assert r['parameters']=={'probe_radius':{'value':1.4,'unit':'angstroms'},'email':'N/A'}
assert hashlib.sha256((root/'input.pdb').read_bytes()).hexdigest()==r['input_pdb']['sha256']
def forbidden(*args,**kwargs):raise AssertionError('Saved consumer attempted network access')
socket.create_connection=forbidden
socket.socket.connect=forbidden
socket.socket.connect_ex=forbidden
request.urlopen=forbidden
CastpFoldClient.submit=forbidden
CastpFoldClient.download_result_zip_bytes=forbidden
assert 'pharmacophoremt' not in sys.modules
unit=sys.argv[1]
with puw.context(standard_units=[unit,'fs' if unit=='pm' else 'ps','radians']):
    source=msm.convert(root/'source.h5msm',to_form='molsysmt.MolSys')
    output=topomt.get_provider_output(source,method='castpfold',backend='files',bundle_file=root/'original.zip')
    categories={}
    for p in output.pockets:
        key=p.source_id.split()[0];categories[key]=categories.get(key,0)+1
    receipt=consume(root,Path(f'.cache/castp-prepared-receiving/consumer-{unit}'),pocket_id='Pocket 1',feature='hydrophobicity',projection_direction=(1.,0.,0.),distance='0.30 nm',radius='0.15 nm')
    print(json.dumps({'unit':unit,'categories':categories,'site_count':receipt['site_count'],'checks':receipt['checks'],'source_indices':[s['atom_indices'] for s in receipt['sites']]},indent=2))
