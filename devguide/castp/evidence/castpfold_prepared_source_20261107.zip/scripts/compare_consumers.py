import json,hashlib
from pathlib import Path
from devtools.qualify_pharmacophore_handoff import _same_sites
from pharmacophoremt.io import load_json
root=Path('.cache/castp-prepared-receiving')
a=json.loads((root/'consumer-nm/receipt.json').read_text());b=json.loads((root/'consumer-pm/receipt.json').read_text())
checks={'same_context':a['context']==b['context'],'same_recipe':a['recipe']==b['recipe'],'same_source_indices':[x['atom_indices'] for x in a['sites']]==[x['atom_indices'] for x in b['sites']],'same_physical_sites':_same_sites(load_json(root/'consumer-nm/query.json'),load_json(root/'consumer-pm/query.json')),'sixteen_declared_sites':a['site_count']==b['site_count']==16,'same_bundle':a['original_bundle_sha256']==b['original_bundle_sha256'],'source_unchanged':hashlib.sha256((root/'qualified/source.h5msm').read_bytes()).hexdigest()=='c967e3f15cdb5a5401ab016588aa1cf886675083ab750ea8fbd0008eabff8580'}
assert all(x is True for x in checks.values())
(root/'consumer-comparison.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks))
