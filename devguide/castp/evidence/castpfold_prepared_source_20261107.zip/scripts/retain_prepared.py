import hashlib,json,subprocess,zipfile
from pathlib import Path
from datetime import UTC,datetime
repo=Path.cwd();root=repo/'.cache/castp-prepared-receiving';dest=repo/'devguide/castp/evidence'
name='castpfold_prepared_source_20261107'
files={}
def add(path,archive_name):
    if not path.is_file() or path.is_symlink():raise ValueError(path)
    if archive_name in files:raise ValueError(archive_name)
    files[archive_name]=path.read_bytes()
add(repo/'.cache/pycasta-handoff/inputs/prepared.h5msm','inputs/prepared.h5msm')
for path in sorted((root/'qualified').iterdir()):add(path,'qualified/'+path.name)
add(root/'recovered-qualified/receipt.json','recovered-qualified/receipt.json')
for unit in ['nm','pm']:
    for path in sorted((root/f'consumer-{unit}').iterdir()):add(path,f'consumer-{unit}/'+path.name)
    add(root/f'consumer-{unit}-initial/receipt.json',f'initial-consumers/{unit}/receipt.json')
for dirname in ['preflight','preflight-heavy']:
    names=['input.pdb','manifest.json','preflight.json','pdb-row-identity-mismatches.json','pdb-row-map.json','preflight.py']
    if dirname=='preflight-heavy':names+=['diagnostic-interpretation.json','selection-declaration.json','phmt-recognition-preflight.json','phmt-recognition-preflight.log']
    for filename in names:add(root/dirname/filename,dirname+'/'+filename)
for filename in ['declared-recipe.json','consumer-comparison.json','offline-recovery.json','source-origins.json','development-notes.json']:
    add(root/filename,'observations/'+filename)
for filename in ['consume_qualified.py','compare_consumers.py','recover_qualified.py','retain_prepared.py']:
    add(root/filename,'scripts/'+filename)
for filename in ['final-source-tests.log','source-contract-tests-explicit.log','distribution-reporting-tests.log','ruff-check-final.log','ruff-format-final.log','mypy-final.log','docs-html.log','prepare-qualified.log','submit-qualified.log','collect-qualified-1.log','offline-recovery.log','consumer-nm-final.log','consumer-pm-final.log','consumer-comparison-final.log','prepared-consumer-regression.log','source-origins.log']:
    add(root/filename,'validation/'+filename)
logroot=repo/'.cache/castp-handoff/evidence/source-tests'
for path in sorted(logroot.iterdir()):
    if path.name.startswith(('castpfold-submission-','pharmacophore-admission-')):add(path,'development-tests/'+path.name)
extra=root/'lifecycle-log-paths.json'
if extra.exists():
    for label,path in json.loads(extra.read_text()).items():add(Path(path),'development-tests/'+label)
sourcefiles=['topomt/third_party/castp/servers/castpfold.py','devtools/qualify_castpfold_handoff.py','devtools/qualify_pharmacophore_handoff.py','tests/methods/castp/test_castpfold_submission.py','tests/methods/castp/test_prepared_pharmacophore_handoff.py','tests/test_castp_pharmacophore_handoff.py','tests/test_castpfold_handoff.py']
for path in sourcefiles:add(repo/path,'source/'+path)
receipt={'schema_version':1,'owner':'uibcdf/topomt#101','class':'bounded source integration, not exact installed qualification','producer_commit':'00f6a9a04d6f511303dc82da326754322d0523f4','created_utc':datetime.now(UTC).isoformat(),'jobid':'j_6aee831b083dc','profile':'original-castpfold-source-handoff-1','run_id':'e121c3d691e29a1474355735cf6c5ad30b9a87fa92aa3a689c246e83d065d877','source_sha256':'c967e3f15cdb5a5401ab016588aa1cf886675083ab750ea8fbd0008eabff8580','counts':{'source_atoms':4047,'submitted_atoms':1975,'pockets':42,'mouth_aggregates':22,'openings':23,'query_sites':16},'validation':{'new_and_prepared_tests':{'passed':97,'skipped':0},'adapter_and_recovery_tests':{'passed':200,'skipped':3,'skip_scope':'separate original pyCASTA prepared input absent'},'distribution_reporting_tests':{'passed':20,'skipped':0},'overlap':'Selections overlap and are not additive coverage.','ruff':'484 files formatted; check passed','mypy':'3 changed executable modules; follow-imports skip, missing optional imports ignored','documentation':'HTML build succeeded; 12 existing warnings including unavailable PlantUML'},'temporary_resources':{'owner':'TopoMT#101 prepared CASTpFold receiving','retained':['.cache/castp-prepared-receiving','/tmp/topomt-pycasta-handoff-bshtk36l/engine-free'],'reason':'Continuation to exact new installed candidate; durable source/result evidence is in this archive. Shared/previous receivers were not modified.','review_by':'2026-11-13','cleanup_condition':'Installed receiving accepted and required candidate/evidence bytes durably retained; preserve human/shared resources.'},'limits':['One declared prepared reference and selected frame; Cartesian projections without periodic imaging.','Original CASTpFold only; CASTp3 upload failure remains separate.','No binding relevance, chemical preparation certification, full-service uptime, native parity, full suite or platform/matrix claim.','Historical initial consumer receipts retain corrected wording history.','Preflight manifests describe their original directories; shared identical source bytes are retained at qualified/source.h5msm.'],'payloads':{key:{'bytes':len(value),'sha256':hashlib.sha256(value).hexdigest()} for key,value in sorted(files.items())}}
manifest=(json.dumps(receipt,indent=2,sort_keys=True)+'\n').encode()
path=dest/(name+'.zip')
with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for filename,data in sorted(files.items()):
        info=zipfile.ZipInfo(filename,date_time=(2026,11,7,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,data,compresslevel=9)
    z.writestr('manifest.json',manifest)
with zipfile.ZipFile(path) as z:
    assert z.testzip() is None
    for filename,data in files.items():assert z.read(filename)==data
summary={k:v for k,v in receipt.items() if k!='payloads'}
summary['archive']={'path':path.name,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'payload_count':len(files)}
(dest/(name+'.json')).write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
(dest/(name+'.zip.sha256')).write_text(summary['archive']['sha256']+'  '+path.name+'\n')
print(json.dumps(summary['archive']))
