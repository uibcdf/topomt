"""Declare and export protein-heavy atoms from an unchanged prepared source."""

from collections import Counter
import hashlib
from importlib.metadata import version
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
CHECKOUT = ROOT.parents[2]
SEED = CHECKOUT / '.cache/pycasta-handoff/inputs/prepared.h5msm'
ALL_H_PREFLIGHT = ROOT.with_name('preflight')
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ['NUMBA_CACHE_DIR'] = str(ROOT / 'numba-cache')
os.environ['MPLCONFIGDIR'] = str(ROOT / 'matplotlib-cache')
os.environ['XDG_CACHE_HOME'] = str(ROOT / 'xdg-cache')
sys.path.insert(0, str(CHECKOUT))

import molsysmt as msm

from devtools.provider_handoff import prepare_reference_source
from topomt import pyunitwizard as puw
from topomt.third_party._common import prepare_wrapper_input_pdb
from topomt.third_party.pdb_context import (
    reference_chemical_context,
    source_input_context,
    validate_submitted_pdb,
)


def encode(value):
    if isinstance(value, dict):
        return {str(key): encode(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [encode(item) for item in value]
    if hasattr(value, 'tolist'):
        return encode(value.tolist())
    if hasattr(value, 'item'):
        return encode(value.item())
    return value


def dump(name, value):
    (ROOT / name).write_text(json.dumps(encode(value), indent=2, allow_nan=False) + '\n')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_fingerprint(source):
    content = {
        'atoms': source_input_context(source, 0),
        'chemistry': reference_chemical_context(source, 0, provider='CASTp preflight'),
        'frames': msm.get(source, n_structures=True),
    }
    return hashlib.sha256(json.dumps(encode(content), sort_keys=True).encode()).hexdigest()


def facts(source):
    types = msm.get(source, element='atom', atom_type=True)
    return {
        'n_atoms': msm.get(source, n_atoms=True),
        'n_bonds': msm.get(source, n_bonds=True),
        'n_structures': msm.get(source, n_structures=True),
        'n_chemical_states': msm.get(source, n_chemical_states=True),
        'reference_chemical_state_index': msm.get(source, reference_chemical_state_index=True),
        'chemical_state_ids': msm.get(source, chemical_state_id=True),
        'structure_chemical_state_indices': msm.get(source, structure_chemical_state_index=True),
        'connectivity_completeness': msm.get(source, connectivity_completeness=True, chemical_state=0),
        'atom_element_counts': dict(Counter(str(value) for value in types)),
        'molecule_types': msm.get(source, element='molecule', molecule_type=True),
    }


def readiness_summary(report):
    detached = encode(report)
    return {
        key: detached.get(key) for key in (
            'schema', 'method', 'rule_version', 'n_atoms', 'structure_index',
            'chemical_state_index', 'chemical_state_status', 'unassessed_checks',
        )
    } | {
        'n_selected_atoms': len(detached.get('atom_indices', [])),
        'n_examined_bonds': len(detached.get('bond_indices', [])),
        'fields': {
            name: {'status': field.get('status')} | {
                key: len(field.get(key, [])) for key in (
                    'present_indices', 'missing_indices', 'unsupported_indices', 'conflict_indices'
                )
            }
            for name, field in detached.get('fields', {}).items()
        },
        'connectivity': {
            key: {'n_entries': len(value)} if isinstance(value, (list, dict)) else value
            for key, value in detached.get('connectivity', {}).items()
        },
        'n_explicit_hydrogens': len(detached.get('explicit_hydrogen_atom_indices', [])),
    }


assert version('molsysmt') == '0.23.0+368.g00abb958f'
assert version('pharmacophoremt') == '0.4.0+98.gb934471'
old_manifest = json.loads((ALL_H_PREFLIGHT / 'manifest.json').read_text())
old_manifest_sha = digest(ALL_H_PREFLIGHT / 'manifest.json')
for name, expected in old_manifest['artifacts'].items():
    assert digest(ALL_H_PREFLIGHT / name) == expected['sha256'], name
dump('selection-declaration.json', {
    'schema': 'topomt.castp_prepared_selection_declaration@1',
    'profile': 'protein-heavy geometry submission from the unchanged full prepared source',
    'selection': "protein selection intersect public msm.select(source, selection=\"atom_type != 'H'\")",
    'protein_selection': "molecule_type in ['protein', 'peptide']",
    'excluded_from_submission': 'All hydrogen atoms and all nonprotein atoms; retained in the full source.',
    'structure_indices': 1, 'chemical_state': 0,
    'reason': 'The all-H export truncated five-character source H atom names and failed exact PDB row identity. No names are changed here.',
    'declared_before_heavy_output_or_server_results': True,
    'network_submission_authorized_or_executed': False,
    'previous_all_h_preflight_manifest_sha256': old_manifest_sha,
    'no_claim': 'Neither this choice nor prior bounded PharmacophoreMT receiving certifies universal chemical readiness.',
})
seed_sha = digest(SEED)
assert seed_sha == 'a42ef9868578ba16c62d52a1267d24160b973dca0d50dbc804ca46b6b2fe316a'
version_file = CHECKOUT / 'topomt/_version.py'
version_before = digest(version_file)
seed = msm.convert(SEED, to_form='molsysmt.MolSys')
seed_facts = facts(seed)
assert [seed_facts[key] for key in ('n_atoms', 'n_bonds', 'n_structures', 'n_chemical_states', 'reference_chemical_state_index')] == [4047, 4088, 1, 1, 0]
before = source_fingerprint(seed)
seed_readiness = msm.physchem.get_chemical_readiness(seed, structure_indices=0, chemical_state=0)
dump('seed-readiness.json', seed_readiness)
source, protein_selection = prepare_reference_source(seed)
heavy_indices = set(int(index) for index in msm.select(source, selection="atom_type != 'H'"))
selection = [int(index) for index in protein_selection if int(index) in heavy_indices]
assert source_fingerprint(seed) == before
source_facts = facts(source)
assert source_facts['n_atoms'] == 4047 and source_facts['n_bonds'] == 4088
assert source_facts['n_structures'] == 2
assert source_facts['n_chemical_states'] == 1
assert source_facts['reference_chemical_state_index'] == 0
assert source_facts['structure_chemical_state_indices'] == [0, 0]
assert len(protein_selection) == 4003 and len(selection) == 1975
assert any(right - left > 1 for left, right in zip(selection, selection[1:]))
protein_readiness = msm.physchem.get_chemical_readiness(
    source, selection=selection, structure_indices=1, chemical_state=0
)
dump('selected-heavy-protein-readiness.json', protein_readiness)
atom_ids = [str(value) for value in msm.get(source, element='atom', atom_id=True)]
counts = Counter(atom_ids)
duplicate_labels = {
    value: [index for index, atom_id in enumerate(atom_ids) if atom_id == value]
    for value, count in counts.items() if count > 1
}
selected_ids = [atom_ids[index] for index in selection]
missing_orders = [int(index) for index in protein_readiness['fields']['bond_order']['missing_indices']]
bonds = source.chemical_states.get_bonds(chemical_state=0)
missing_order_records = json.loads(
    bonds.iloc[missing_orders][['atom1_index', 'atom2_index', 'bond_order', 'is_aromatic', 'bond_type']].to_json(orient='records')
)
diagnostic_interpretation = {
    'atom_id_definition': 'The public readiness provider marks stored atom_id labels duplicated anywhere in the full source (keep=False), then restricts the mask to the selected indices. Atom IDs are labels, not atom indices or PDB export serials.',
    'full_source_duplicate_label_groups': duplicate_labels,
    'n_full_source_duplicate_label_groups': len(duplicate_labels),
    'n_full_source_atoms_with_duplicated_labels': sum(len(values) for values in duplicate_labels.values()),
    'selected_heavy_atom_ids_unique_within_selection': len(set(selected_ids)) == len(selected_ids),
    'n_selected_heavy_atoms_marked_conflicting_by_public_readiness': len(protein_readiness['fields']['atom_id']['conflict_indices']),
    'missing_bond_order_definition': 'The public readiness provider classifies a stored bond_order as missing when pandas.isna(value) is true. This does not remove the bond or by itself establish unknown effective aromatic multiplicity.',
    'n_incident_bonds_with_missing_stored_order': len(missing_orders),
    'all_missing_order_records_explicitly_marked_aromatic': all(record['is_aromatic'] is True for record in missing_order_records),
    'all_missing_order_records_declared_covalent': all(record['bond_type'] == 'covalent' for record in missing_order_records),
    'covalent_multiplicity_status': protein_readiness['fields']['covalent_multiplicity']['status'],
    'effective_aromatic_multiplicity_rule': 'The owning readiness provider substitutes the token aromatic for effective multiplicity when stored is_aromatic is true; no missing numeric bond_order is filled here.',
    'missing_order_records': missing_order_records,
    'readiness_owner': 'MolSysMT public msm.physchem.get_chemical_readiness; source diagnostics only, no independent certifier.',
    'prior_pharmacophore_receiving_scope': 'Prior receiving was bounded to its declared consumers and cases; it is not a universal certificate for this source or submission profile.',
}
dump('diagnostic-interpretation.json', diagnostic_interpretation)
before_export = {
    'atoms': source_input_context(source, 1),
    'chemistry': reference_chemical_context(source, 0, provider='CASTp preflight'),
}
pdb, rows_to_source = prepare_wrapper_input_pdb(
    source, tmpdir=ROOT, selection=selection, structure_indices=1, syntax='MolSysMT'
)
serial_map = validate_submitted_pdb(
    source, pdb, rows_to_source,
    selection=selection, structure_indices=1, syntax='MolSysMT',
)
rows = [line for line in pdb.read_text().splitlines() if line.startswith(('ATOM  ', 'HETATM'))]
attributes = msm.get(
    source, element='atom', selection=rows_to_source, output_type='dictionary',
    get_missing_bonds=False, atom_id=True, atom_name=True, atom_type=True,
    group_id=True, group_name=True, chain_id=True,
)
mismatches = []
for index, row in enumerate(rows):
    expected = {
        'atom_name': row[12:16].strip(), 'group_name': row[17:20].strip(),
        'group_id': row[22:26].strip(), 'chain_id': row[21:22].strip(),
    }
    for name, value in expected.items():
        if attributes[name] is None or str(attributes[name][index]) != value:
            mismatches.append({'row': index, 'attribute': name, 'pdb': value, 'source': str(attributes[name][index])})
    if row[76:78].strip().upper() != str(attributes['atom_type'][index]).upper():
        mismatches.append({'row': index, 'attribute': 'atom_type'})
identity_compatible = not mismatches
dump('pdb-row-identity-mismatches.json', {
    'status': 'passed' if identity_compatible else 'failed',
    'mismatches': mismatches,
    'n_mismatches': len(mismatches),
})
assert len(rows) == len(serial_map) == len(selection) == 1975
assert not any(row[76:78].strip().upper() == 'H' for row in rows)
assert not any(row[16:17].strip() or row[26:27].strip() for row in rows)
coordinates = puw.get_value(
    msm.get(source, selection=rows_to_source, structure_indices=1, coordinates=True),
    to_unit='angstroms',
).tolist()[0]
max_error = max(
    abs(float(row[start:start + 8]) - value)
    for row, xyz in zip(rows, coordinates)
    for start, value in zip((30, 38, 46), xyz)
)
assert max_error <= 0.00051
after_export = {
    'atoms': source_input_context(source, 1),
    'chemistry': reference_chemical_context(source, 0, provider='CASTp preflight'),
}
assert encode(before_export) == encode(after_export)
msm.convert(source, to_form='file:h5msm', output_filename=ROOT / 'source.h5msm')
assert digest(SEED) == seed_sha and digest(version_file) == version_before
assert digest(ALL_H_PREFLIGHT / 'manifest.json') == old_manifest_sha
for name, expected in old_manifest['artifacts'].items():
    assert digest(ALL_H_PREFLIGHT / name) == expected['sha256'], name
dump('source-input-context.json', before_export)
dump('pdb-row-map.json', {
    'selection': selection, 'pdb_row_to_source_atom_indices': rows_to_source,
    'pdb_serial_to_source_atom_indices': serial_map,
    'structure_indices': 1, 'chemical_state': 0,
    'n_source_atoms': source_facts['n_atoms'],
    'n_selected_atoms': len(selection),
    'excluded_source_atom_indices': sorted(set(range(4047)) - set(selection)),
})
dump('preflight.json', {
    'status': 'passed' if identity_compatible else 'blocked_pdb_row_identity',
    'profile': 'declared protein-heavy export from the unchanged full prepared source; diagnostics only',
    'seed_sha256': seed_sha, 'seed_facts': seed_facts, 'source_facts': source_facts,
    'seed_readiness_summary': readiness_summary(seed_readiness),
    'selected_heavy_protein_readiness_summary': readiness_summary(protein_readiness),
    'diagnostic_interpretation': {key: value for key, value in diagnostic_interpretation.items() if key not in ('full_source_duplicate_label_groups', 'missing_order_records')},
    'selection_declaration_sha256': digest(ROOT / 'selection-declaration.json'),
    'previous_all_h_preflight_manifest_sha256': old_manifest_sha,
    'previous_all_h_preflight_unchanged': True,
    'n_protein_atoms_in_full_source': len(protein_selection),
    'n_selected_atoms': len(selection), 'selection_nonconsecutive': True,
    'n_excluded_atoms': 4047 - len(selection),
    'pdb': {'path': pdb.name, 'bytes': pdb.stat().st_size, 'sha256': digest(pdb),
            'atom_rows': len(rows), 'n_hydrogen_rows': sum(row[76:78].strip().upper() == 'H' for row in rows),
            'n_model_records': sum(line.startswith('MODEL ') for line in pdb.read_text().splitlines()),
            'known_row_identities_agree': identity_compatible,
            'n_row_identity_mismatches': len(mismatches),
            'unique_serial_map_passed': True,
            'maximum_coordinate_error_angstroms': max_error},
    'source_h5msm': {'sha256': digest(ROOT / 'source.h5msm'), 'bytes': (ROOT / 'source.h5msm').stat().st_size},
    'versions': {name: version(name) for name in ('molsysmt', 'pharmacophoremt', 'pyunitwizard')},
    'seed_unchanged': True, 'source_export_unchanged': True, 'human_version_file_unchanged': True,
    'pharmacophoremt_imported': 'pharmacophoremt' in sys.modules,
    'network_submission_executed': False, 'scientific_detection_executed': False,
    'source_helpers_sha256': {name: digest(CHECKOUT / name) for name in (
        'devtools/provider_handoff.py', 'topomt/third_party/_common.py', 'topomt/third_party/pdb_context.py')},
    'limitations': [
        'Readiness reports describe stored coverage and limited diagnostics, not a universal ready flag or independent validation of preparation.',
        'Prepared seed provenance is retained separately; no chemistry is prepared, repaired or reassigned here.',
        'A failed PDB row-identity check remains blocking; saved diagnostic artifacts do not qualify the source for the CASTp source-binding route.',
        'Server acceptance, atom preprocessing and original CASTp output remain untested by this preflight.',
    ],
})
print(json.dumps({
    'status': 'passed' if identity_compatible else 'blocked_pdb_row_identity',
    'seed': seed_facts, 'source': source_facts,
    'n_selected': len(selection), 'n_excluded': 4047 - len(selection),
    'pdb_bytes': pdb.stat().st_size, 'pdb_sha256': digest(pdb),
    'maximum_coordinate_error_angstroms': max_error,
    'pdb_hydrogen_rows': sum(row[76:78].strip().upper() == 'H' for row in rows),
    'n_row_identity_mismatches': len(mismatches),
    'mismatch_examples': mismatches[:4],
    'readiness_field_statuses': {name: field.get('status') for name, field in protein_readiness.get('fields', {}).items()},
}, default=encode))
