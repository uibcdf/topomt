"""Record four original archive/source controls; no receptor preparation."""

import hashlib
import json
import zipfile
from pathlib import Path

import molsysmt as msm

import topomt as tmt
from topomt import pyunitwizard as puw


def main():
    work = Path('.cache/castp-handoff/source-bound-receiving')
    work.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile('tests/data/castp_source_binding.zip') as archive:
        source_file = work / 'source.h5msm'
        source_file.write_bytes(archive.read('source.h5msm'))
        mapping = json.loads(archive.read('mapping.json'))['original_pdb_row_to_source_atom_indices']
    results = []
    for family, provider in [('CASTp_3.0_server', 'castp3'), ('CASTpFold_server', 'castpfold')]:
        for units in (['nm', 'ps', 'radians'], ['pm', 'fs', 'radians']):
            with puw.context(standard_units=units):
                source = msm.convert(source_file, to_form='molsysmt.MolSys')
                output = tmt.get_provider_output(source, method=provider, backend='files', zip_file=Path('topomt/data') / family / '2pk4.zip', source_atom_indices=mapping, selection=mapping, structure_indices=1)
                path = work / (provider + '-' + units[0] + '.zip')
                output.run.save(path)
                recovered = tmt.get_provider_output(source, method=provider, backend='files', bundle_file=path)
                assert recovered.run == output.run
                assert [(p.source_id, p.atom_indices) for p in output.records] == [(p.source_id, p.atom_indices) for p in recovered.records]
                results.append({'provider': provider, 'units': units, 'pockets': len(output.pockets), 'records': len(output.records), 'run_id': output.run.run_id, 'bundle': path.name, 'bundle_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    receipt = {'scope': 'source-bound original archive recovery only; no prepared chemistry, service execution or installed qualification', 'source_sha256': hashlib.sha256(source_file.read_bytes()).hexdigest(), 'reader_sha256': hashlib.sha256(Path('topomt/third_party/castp/_source.py').read_bytes()).hexdigest(), 'results': results}
    (work / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
