"""Observe public GET endpoints without uploading inputs or creating jobs."""

import concurrent.futures
import hashlib
import json
import time
from datetime import UTC, datetime
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = Path('.cache/castp-handoff/server-observation')
URLS = {
    'castpfold_compute': 'https://cfold.bme.uic.edu/castpfold/compute',
    'castp3_http_calculation': 'http://sts.bioe.uic.edu/castp/calculation.html',
    'castp3_https_calculation': 'https://sts.bioe.uic.edu/castp/calculation.html',
    'existing_fold_tetrahedron': 'https://cfold.bme.uic.edu/castpfold/data/tmppdb/j_6abe78a311665/processed/j_6abe78a311665.zip',
    'existing_fold_shell': 'https://cfold.bme.uic.edu/castpfold/data/tmppdb/j_6abe78a074161/processed/j_6abe78a074161.zip',
}


def observe(item):
    name, url = item
    start = time.perf_counter()
    result = {'name': name, 'method': 'GET', 'url': url, 'observed_utc': datetime.now(UTC).isoformat()}
    try:
        request = Request(url, headers={'User-Agent': 'TopoMT original-provider diagnostics'})
        try:
            response = urlopen(request, timeout=15)
        except HTTPError as error:
            response = error
        with response:
            payload = response.read(32 * 1024 * 1024 + 1)
            result.update({'http_status': response.code, 'final_url': response.url, 'headers': {k: response.headers[k] for k in ('Content-Type', 'Content-Length', 'Server', 'Date', 'X-Mitmproxy-Blocked-Reason') if k in response.headers}, 'bytes_read': len(payload), 'truncated': len(payload) > 32 * 1024 * 1024, 'sha256': hashlib.sha256(payload).hexdigest()})
        (ROOT / (name + '.body')).write_bytes(payload)
    except (URLError, OSError) as error:
        result.update({'transport_error_type': type(error).__name__, 'transport_error': str(error)})
    result['elapsed_seconds'] = time.perf_counter() - start
    return result


def main():
    ROOT.mkdir(parents=True, exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        results = list(executor.map(observe, URLS.items()))
    receipt = {'scope': 'GET-only reachability; no new submission and no computation-success claim', 'results': results}
    (ROOT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
