"""Exercise existing original server APIs with one public historical PDB."""

import hashlib
import importlib
import io
import json
import re
import time
import zipfile
from datetime import UTC, datetime
from pathlib import Path

import topomt as tmt

ROOT = Path('.cache/castp-handoff/live-2pk4')


def now():
    return datetime.now(UTC).isoformat()


def run(provider, class_name):
    folder = ROOT / provider
    folder.mkdir(parents=True, exist_ok=True)
    receipt_file = folder / 'receipt.json'
    if receipt_file.exists():
        print(json.dumps({'provider': provider, 'state': 'existing_receipt_no_resubmission'}), flush=True)
        return
    module = importlib.import_module('topomt.third_party.castp.servers.' + provider)
    client_class = getattr(module, class_name)
    real_open, real_submit = module.urlopen, client_class.submit
    receipt = {'provider': provider, 'source': 'unchanged historical 2pk4.pdb from tracked CASTp3 export; not a prepared receptor', 'input_sha256': hashlib.sha256((ROOT / '2pk4.pdb').read_bytes()).hexdigest(), 'probe_radius': {'value': 1.4, 'unit': 'angstroms'}, 'email': 'N/A' if provider == 'castpfold' else 'null', 'state': 'submission_started', 'started_utc': now(), 'requests': []}

    def save():
        receipt_file.write_text(json.dumps(receipt, indent=2) + '\n')

    def capture(request, timeout=10):
        index = len(receipt['requests'])
        entry = {'method': request.get_method(), 'url': request.full_url, 'started_utc': now()}
        receipt['requests'].append(entry)
        if request.data is not None:
            entry['request_bytes'] = len(request.data)
            entry['request_sha256'] = hashlib.sha256(request.data).hexdigest()
            (folder / f'{index:02d}.request').write_bytes(request.data)
        save()
        start = time.perf_counter()
        try:
            with real_open(request, timeout=timeout) as response:
                data = response.read(32 * 1024 * 1024 + 1)
                entry.update({'http_status': response.status, 'final_url': response.url, 'content_type': response.headers.get('Content-Type'), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'payload': f'{index:02d}.response'})
            if len(data) > 32 * 1024 * 1024:
                raise ValueError('Diagnostic response exceeds its 32 MB bound.')
            (folder / entry['payload']).write_bytes(data)
            entry['zip_signature'] = zipfile.is_zipfile(io.BytesIO(data))
            if entry['method'] == 'POST':
                receipt['acknowledgement_artifact'] = entry['payload']
            return io.BytesIO(data)
        except Exception as error:
            entry.update({'error_type': type(error).__name__, 'error': str(error)})
            raise
        finally:
            entry['elapsed_seconds'] = time.perf_counter() - start
            save()

    def submit(self, pdb_path, **options):
        jobid = real_submit(self, pdb_path, **options)
        receipt['jobid'] = jobid
        if provider == 'castpfold':
            raw = (folder / receipt['acknowledgement_artifact']).read_bytes()
            acknowledgement = json.loads(raw)
            receipt['acknowledgement'] = acknowledgement
            if acknowledgement.get('success') is not True:
                receipt['state'] = 'acknowledgement_not_success'
                save()
                raise ValueError('CASTpFold acknowledgement does not report success.')
        if not re.fullmatch(r'j_[A-Za-z0-9_]+', jobid):
            raise ValueError('Unexpected job identifier; preserved without polling.')
        receipt['state'] = 'submitted_pending'
        receipt['submitted_utc'] = now()
        save()
        print(json.dumps({'provider': provider, 'state': receipt['state'], 'jobid': jobid}), flush=True)
        return jobid

    module.urlopen = capture
    client_class.submit = submit
    save()
    try:
        output = tmt.get_provider_output(ROOT / '2pk4.pdb', method=provider, probe_radius=1.4, wait=0, extra_wait=0, retries=0, timeout=10, output_zip_file=folder / 'original_server.zip')
        output.run.save(folder / 'provider_run.zip')
        receipt.update({'state': 'completed_imported', 'pockets': len(output.pockets), 'records': len(output.records), 'run_id': output.run.run_id})
    except Exception as error:
        receipt.update({'adapter_error_type': type(error).__name__, 'adapter_error': str(error)})
        if (folder / 'original_server.zip').exists():
            receipt['state'] = 'zip_received_import_failed'
        elif receipt.get('jobid') and receipt['state'] != 'acknowledgement_not_success':
            receipt['state'] = 'submitted_result_unavailable'
        elif receipt['state'] == 'submission_started':
            receipt['state'] = 'submission_not_accepted_or_unparsed'
    finally:
        module.urlopen, client_class.submit = real_open, real_submit
        receipt['finished_observation_utc'] = now()
        save()
    print(json.dumps({k: receipt[k] for k in ('provider', 'state', 'jobid', 'pockets', 'adapter_error') if k in receipt}), flush=True)


def main():
    ROOT.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile('topomt/data/CASTp_3.0_server/2pk4.zip') as archive:
        pdb = archive.read('2pk4.pdb')
    assert hashlib.sha256(pdb).hexdigest() == '491d6fc18883b7b3f82c8b9c85023129a7390c7120ba94eb16b199801f2ee1c1'
    (ROOT / '2pk4.pdb').write_bytes(pdb)
    run('castp3', 'Castp3Client')
    run('castpfold', 'CastpFoldClient')


if __name__ == '__main__':
    main()
