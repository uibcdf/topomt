"""Bound source-reader checks against unchanged, already tracked server ZIPs."""

import hashlib
import json
import time
import zipfile
from pathlib import Path

import topomt as tmt


def main():
    evidence = Path('.cache/castp-handoff/evidence')
    audit = json.loads((evidence / 'corpus-audit.json').read_text())
    results = []
    started = time.perf_counter()
    for case in audit['archives']:
        path = Path(case['path'])
        assert hashlib.sha256(path.read_bytes()).hexdigest() == case['sha256']
        result = tmt.get_provider_output(method='castp', backend='files', zip_file=path)
        assert len(result.pockets) == case['pockets'], path
        mouths = [r for r in result.records if r.record_kind == 'mouth_aggregate']
        assert len(mouths) == case['positive_mouth_aggregates'], path
        assert result.run.get_artifact(f'input/{path.name}') == path.read_bytes()
        with zipfile.ZipFile(path) as archive:
            for name in archive.namelist():
                assert result.run.get_artifact(f'output/{name}') == archive.read(name)
        for record in result.records:
            for field in ('provider_atom_source_artifact', 'provider_result_source_artifact'):
                if field in record.fields:
                    result.run.get_artifact(record.fields[field])
            for measurement in record.measurements.values():
                result.run.get_artifact(measurement.source_artifact)
                assert measurement.run_id == result.run.run_id
        results.append({'path': case['path'], 'sha256': case['sha256'], 'pockets': len(result.pockets), 'mouth_aggregates': len(mouths), 'run_id': result.run.run_id})
        if len(results) % 20 == 0:
            print(f'Checked {len(results)}/{len(audit["archives"])} archives', flush=True)
    receipt = {'schema_version': 1, 'scope': 'source files reader only; no service execution, prepared-receptor binding or installed qualification', 'archives': results, 'elapsed_seconds': time.perf_counter() - started, 'reader_sha256': hashlib.sha256(Path('topomt/io/load_CASTp.py').read_bytes()).hexdigest()}
    (evidence / 'corpus-reader-results.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'archives': len(results), 'pockets': sum(r['pockets'] for r in results), 'mouth_aggregates': sum(r['mouth_aggregates'] for r in results), 'elapsed_seconds': receipt['elapsed_seconds']}), flush=True)


if __name__ == '__main__':
    main()
