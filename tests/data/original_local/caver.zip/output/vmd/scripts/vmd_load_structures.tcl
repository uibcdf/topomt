set dir "/tmp/topomt_caver_srkllh5r/structures"

mol load pdb ${dir}/input.pdb

after idle { 
  mol representation NewCartoon 
  mol delrep 0 top
  mol addrep top
  mol modcolor 0 top "ColorID" 8
} 

