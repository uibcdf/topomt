"""Generate an analytical CASTp source-binding fixture through public MolSysMT."""

import hashlib
import json
import os
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
os.environ['NUMBA_CACHE_DIR'] = str(ROOT / 'numba-cache')
os.environ['MPLCONFIGDIR'] = str(ROOT / 'matplotlib-cache')
os.environ['XDG_CACHE_HOME'] = str(ROOT / 'xdg-cache')

import molsysmt as msm

puw = msm.pyunitwizard


def encode(value):
    if isinstance(value, dict):
        return {key: encode(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [encode(item) for item in value]
    if hasattr(value, 'tolist'):
        return encode(value.tolist())
    if hasattr(value, 'item'):
        return encode(value.item())
    return value


def write_json(name, value):
    (ROOT / name).write_text(json.dumps(encode(value), indent=2, allow_nan=False) + '\n')


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot(system):
    return encode({
        'n_atoms': msm.get(system, n_atoms=True),
        'n_structures': msm.get(system, n_structures=True),
        'n_chemical_states': msm.get(system, n_chemical_states=True),
        'reference_chemical_state_index': msm.get(
            system, reference_chemical_state_index=True
        ),
        'chemical_state_ids': msm.get(system, chemical_state_id=True),
        'structure_chemical_state_indices': msm.get(
            system, structure_chemical_state_index=True
        ),
        'atom_attributes': msm.get(
            system,
            element='atom',
            output_type='dictionary',
            get_missing_bonds=False,
            atom_id=True,
            atom_name=True,
            atom_type=True,
            group_id=True,
            group_name=True,
            chain_id=True,
        ),
        'coordinates': {
            'value': puw.get_value(msm.get(system, coordinates=True), to_unit='nm'),
            'unit': 'nm',
        },
        'reference_formal_charges': msm.get(
            system, element='atom', formal_charge=True, chemical_state=0
        ),
        'reference_bonds': json.loads(
            system.chemical_states.get_bonds(chemical_state=0).to_json(orient='split')
        ),
        'connectivity_completeness': msm.get(
            system, connectivity_completeness=True, chemical_state=0
        ),
    })


def assert_same(expected, actual):
    for key in expected:
        if key != 'coordinates':
            assert actual[key] == expected[key], key
    first = expected['coordinates']['value']
    second = actual['coordinates']['value']
    assert actual['coordinates']['unit'] == 'nm'
    assert len(first) == len(second)
    for left_frame, right_frame in zip(first, second):
        assert len(left_frame) == len(right_frame)
        for left, right in zip(left_frame, right_frame):
            assert all(abs(a - b) <= 1e-12 for a, b in zip(left, right))


def generate(archive_path):
    assert msm.__version__ == '0.23.0+368.g00abb958f', msm.__version__
    input_dir = ROOT / 'input'
    input_dir.mkdir(exist_ok=True)
    pdb_path = input_dir / '2pk4.pdb'
    with zipfile.ZipFile(archive_path) as archive:
        pdb_path.write_bytes(archive.read('2pk4.pdb'))
    assert sha256(pdb_path) == '491d6fc18883b7b3f82c8b9c85023129a7390c7120ba94eb16b199801f2ee1c1'
    seed = msm.convert(pdb_path, to_form='molsysmt.MolSys', get_missing_bonds=False)
    seed_before = snapshot(seed)
    n_original = seed_before['n_atoms']
    assert n_original == 745 and seed_before['n_structures'] == 1
    assert seed_before['n_chemical_states'] == 1
    assert seed_before['reference_chemical_state_index'] == 0
    auxiliary_mode = 'two copied atoms appended with public msm.merge'
    try:
        auxiliary = msm.extract(seed, selection=[0, 1])
        auxiliary = msm.structure.translate(
            auxiliary, translation=puw.quantity([[[10.0, 20.0, 30.0]]], 'nm')
        )
        combined = msm.merge([seed, auxiliary], keep_ids=True, to_form='molsysmt.MolSys')
        combined_before = snapshot(combined)
        assert combined_before['n_atoms'] == n_original + 2
        assert combined_before['n_chemical_states'] == 1
        assert combined_before['reference_chemical_state_index'] == 0
        for key, values in seed_before['atom_attributes'].items():
            assert combined_before['atom_attributes'][key][:n_original] == values, key
        assert combined_before['coordinates']['value'][0][:n_original] == seed_before['coordinates']['value'][0]
        original_order = list(range(n_original - 1, -1, -1))
        order = [
            original_order[0], n_original,
            original_order[1], n_original + 1,
            *original_order[2:],
        ]
    except Exception as error:
        write_json('auxiliary-attempt-failure.json', {
            'error_type': type(error).__name__, 'error': str(error)
        })
        auxiliary_mode = 'fallback: original 745 atoms only; auxiliary composition unsupported'
        combined = msm.copy(seed)
        order = list(range(n_original - 1, -1, -1))
    result = msm.permute_atoms(combined, order, return_report=True)
    permuted, report = result['molecular_system'], result['report']
    original_row_to_source = encode(report['source_to_output_atom_indices'][:n_original])
    assert len(set(original_row_to_source)) == n_original
    assert original_row_to_source != sorted(original_row_to_source)
    source = msm.structure.translate(
        permuted, translation=puw.quantity([[[0.3, -0.2, 0.1]]], 'nm')
    )
    msm.append_structures(source, msm.convert(permuted, to_form='molsysmt.Structures'))
    expected = snapshot(source)
    assert expected['n_structures'] == 2
    assert expected['n_chemical_states'] == 1
    assert expected['reference_chemical_state_index'] == 0
    assert expected['structure_chemical_state_indices'] == [0, 0]
    for index, source_index in enumerate(original_row_to_source):
        assert expected['coordinates']['value'][1][source_index] == seed_before['coordinates']['value'][0][index]
        for key, values in seed_before['atom_attributes'].items():
            assert expected['atom_attributes'][key][source_index] == values[index], key
    assert_same(seed_before, snapshot(seed))
    mapping = {
        'schema': 'topomt.castp_source_binding_test_fixture@1',
        'profile': 'analytical correspondence fixture; no chemical preparation claim',
        'n_original_pdb_rows': n_original,
        'source_n_atoms': expected['n_atoms'],
        'original_pdb_row_to_source_atom_indices': original_row_to_source,
        'selection': original_row_to_source,
        'excluded_source_atom_indices': sorted(set(range(expected['n_atoms'])) - set(original_row_to_source)),
        'structure_indices': 1,
        'chemical_state': 0,
        'auxiliary_mode': auxiliary_mode,
        'original_atom_order': 'reverse original PDB row order, with auxiliary atoms interleaved',
        'auxiliary_input_atom_indices': [0, 1] if expected['n_atoms'] == 747 else [],
        'auxiliary_translation_nm': [10.0, 20.0, 30.0] if expected['n_atoms'] == 747 else None,
        'frame_zero_translation_nm': [0.3, -0.2, 0.1],
        'frame_one': 'original archive PDB coordinates in the declared permuted source axis',
    }
    write_json('atom-map-report.json', report)
    write_json('mapping.json', mapping)
    write_json('expected-source.json', expected)
    source_path = ROOT / 'source.h5msm'
    msm.convert(source, to_form='file:h5msm', output_filename=source_path)
    assert_same(expected, snapshot(msm.convert(source_path, to_form='molsysmt.MolSys')))
    write_json('generation-receipt.json', {
        'status': 'passed',
        'molsysmt_version': msm.__version__,
        'molsysmt_origin': msm.__file__,
        'python': sys.version.split()[0],
        'openmm_loaded': 'openmm' in sys.modules,
        'topomt_loaded': 'topomt' in sys.modules,
        'input_archive': {'path': str(archive_path), 'sha256': sha256(archive_path)},
        'input_pdb': {'path': str(pdb_path.relative_to(ROOT)), 'sha256': sha256(pdb_path)},
        'recipe': 'get_missing_bonds=False; copied auxiliary atoms; merge; reverse original atom order with auxiliary atoms interleaved; declared permutation; translated decoy frame 0; original frame 1',
        'source_n_atoms': expected['n_atoms'],
        'n_selected_atoms': len(original_row_to_source),
        'original_pdb_row_map_is_nonmonotonic': True,
        'excluded_source_atom_indices': mapping['excluded_source_atom_indices'],
        'source_unchanged': True,
        'controlled_readback_passed': True,
        'artifacts': {
            name: {'sha256': sha256(ROOT / name), 'bytes': (ROOT / name).stat().st_size}
            for name in ['generate.py', 'input/2pk4.pdb', 'source.h5msm', 'atom-map-report.json', 'mapping.json', 'expected-source.json']
        },
        'limitations': [
            'Auxiliary atom IDs intentionally copy the seed labels; correspondence is from the declared operation report, not label matching.',
            'Explicit PDB connectivity only; no chemical preparation, completed chemistry, scientific detection, server submission or algorithm parity is claimed.',
            'The source was constructed with the controlled public-API MolSysMT source pin, not public MolSysMT 0.23.0.',
        ],
    })
    print(json.dumps({'status': 'passed', 'source_n_atoms': expected['n_atoms'], 'n_selected': n_original, 'excluded': mapping['excluded_source_atom_indices'], 'root': str(ROOT)}))


def public_readback():
    expected = json.loads((ROOT / 'expected-source.json').read_text())
    actual = snapshot(msm.convert(ROOT / 'source.h5msm', to_form='molsysmt.MolSys'))
    assert_same(expected, actual)
    mapping = json.loads((ROOT / 'mapping.json').read_text())
    selected = mapping['original_pdb_row_to_source_atom_indices']
    labels = msm.get_label(
        ROOT / 'source.h5msm',
        selection=selected,
        string='{atom_id}-{atom_name}/{group_name}/{chain_id}',
    )
    raw_labels = [
        f'{line[6:11].strip()}-{line[12:16].strip()}/{line[17:20].strip()}/{line[21].strip()}'
        for line in (ROOT / 'input/2pk4.pdb').read_text().splitlines()
        if line.startswith(('ATOM  ', 'HETATM'))
    ]
    assert list(labels) == raw_labels
    raw_coordinates = [
        [float(line[start:start + 8]) / 10 for start in (30, 38, 46)]
        for line in (ROOT / 'input/2pk4.pdb').read_text().splitlines()
        if line.startswith(('ATOM  ', 'HETATM'))
    ]
    public_coordinates = puw.get_value(
        msm.get(
            ROOT / 'source.h5msm', selection=selected, structure_indices=1,
            coordinates=True
        ), to_unit='nm'
    ).tolist()[0]
    assert len(raw_coordinates) == len(public_coordinates) == 745
    for original, current in zip(raw_coordinates, public_coordinates):
        assert all(abs(a - b) <= 1e-12 for a, b in zip(original, current))
    write_json('public-readback-receipt.json', {
        'status': 'passed', 'molsysmt_version': msm.__version__,
        'molsysmt_origin': msm.__file__, 'python': sys.version.split()[0],
        'source_h5msm_sha256': sha256(ROOT / 'source.h5msm'),
        'full_attributes_coordinates_and_reference_state_agree': True,
        'original_pdb_labels_and_coordinates_agree_in_declared_map_order': True,
        'n_source_atoms': actual['n_atoms'], 'n_selected_atoms': len(selected),
        'structure_indices': 1, 'reference_chemical_state_index': 0,
        'structure_chemical_state_indices': actual['structure_chemical_state_indices'],
        'topomt_loaded': 'topomt' in sys.modules,
        'openmm_loaded': 'openmm' in sys.modules,
        'scientific_detection_executed': False,
    })
    print(json.dumps({'status': 'passed', 'molsysmt_version': msm.__version__, 'n_atoms': actual['n_atoms'], 'n_selected': len(selected), 'public_readback': True}))


if __name__ == '__main__':
    if sys.argv[1] == 'generate':
        generate(Path(sys.argv[2]).resolve())
    elif sys.argv[1] == 'public-readback':
        public_readback()
    else:
        raise ValueError('Expected generate or public-readback mode.')
