"""Check the generated H5MSM with public MolSysMT 0.23.0, without TopoMT."""

import hashlib
import json
from pathlib import Path
import runpy
import sys

ROOT = Path(__file__).resolve().parent
helpers = runpy.run_path(str(ROOT / 'generate.py'))
msm = helpers['msm']
puw = msm.pyunitwizard
assert msm.__version__ == '0.23.0', msm.__version__

expected = json.loads((ROOT / 'expected-source.json').read_text())
source = msm.convert(ROOT / 'source.h5msm', to_form='molsysmt.MolSys')
actual = helpers['snapshot'](source)
differences = {
    key: {'controlled': expected[key], 'public': actual[key]}
    for key in expected
    if key != 'coordinates' and expected[key] != actual[key]
}
# The old public getter exposes this sole-state field as a one-element list.
# Retain that raw API difference; compare the explicitly declared state value.
assert differences == {
    'connectivity_completeness': {'controlled': 'partial', 'public': ['partial']}
}, differences
state_value_comparison = dict(actual)
state_value_comparison['connectivity_completeness'] = actual[
    'connectivity_completeness'
][0]
helpers['assert_same'](expected, state_value_comparison)

mapping = json.loads((ROOT / 'mapping.json').read_text())
indices = mapping['original_pdb_row_to_source_atom_indices']
assert indices != sorted(indices)
assert list(msm.select(source, selection=indices)) == indices
lines = [
    line
    for line in (ROOT / 'input/2pk4.pdb').read_text().splitlines()
    if line.startswith(('ATOM  ', 'HETATM'))
]
expected_labels = [
    f'{line[6:11].strip()}-{line[12:16].strip()}/{line[17:20].strip()}/{line[21].strip()}'
    for line in lines
]
labels = msm.get_label(
    source, selection=indices,
    string='{atom_id}-{atom_name}/{group_name}/{chain_id}',
)
assert list(labels) == expected_labels
coordinates = puw.get_value(
    msm.get(source, selection=indices, structure_indices=1, coordinates=True),
    to_unit='angstroms',
).tolist()[0]
assert len(coordinates) == len(indices) == len(lines) == 745
max_abs_error = max(
    abs(value - float(line[start:start + 8]))
    for row, line in zip(coordinates, lines)
    for value, start in zip(row, (30, 38, 46))
)
assert max_abs_error <= 1e-10
assert actual['n_atoms'] == 747
assert actual['n_structures'] == 2
assert actual['reference_chemical_state_index'] == 0
assert actual['structure_chemical_state_indices'] == [0, 0]
assert mapping['excluded_source_atom_indices'] == [1, 3]
assert 'topomt' not in sys.modules
assert 'openmm' not in sys.modules

receipt = {
    'status': 'passed_with_recorded_getter_shape_difference',
    'molsysmt_version': msm.__version__,
    'molsysmt_origin': msm.__file__,
    'python': sys.version.split()[0],
    'source_h5msm_sha256': hashlib.sha256((ROOT / 'source.h5msm').read_bytes()).hexdigest(),
    'public_verifier_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'raw_api_differences': differences,
    'other_attributes_bonds_charges_and_state_inventory_equal': True,
    'all_full_source_coordinates_equal_with_tolerance_nm': 1e-12,
    'original_pdb_labels_agree_in_declared_map_order': True,
    'original_pdb_coordinates_max_abs_error_angstroms': max_abs_error,
    'n_source_atoms': actual['n_atoms'],
    'n_selected_atoms': len(indices),
    'original_pdb_row_map_is_nonmonotonic': True,
    'excluded_source_atom_indices': mapping['excluded_source_atom_indices'],
    'structure_indices': 1,
    'reference_chemical_state_index': 0,
    'structure_chemical_state_indices': actual['structure_chemical_state_indices'],
    'topomt_loaded': False,
    'openmm_loaded': False,
    'scientific_detection_executed': False,
    'limitations': [
        'The public connectivity_completeness getter returns a one-element list, while the controlled pin returns its scalar state value. The raw shape difference is retained above.',
        'This validates H5MSM readback and explicit correspondence only; no chemical preparation or readiness is asserted.',
    ],
}
(ROOT / 'public-readback-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
