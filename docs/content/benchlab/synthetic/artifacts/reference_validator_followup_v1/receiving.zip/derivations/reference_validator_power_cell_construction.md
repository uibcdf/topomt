# Exact multi-ball regions through clipped power cells

Owner [#76](https://github.com/uibcdf/topomt/issues/76); first native consumer
#181. This is the P1 topology construction implemented after the measured six-case
panel. Correctness/completeness outrank speed. No native DFND operator changes.
Implementation, retained receiving and qualification are recorded separately
below; this derivation alone is not executed qualification.

Current receiving, 2026-11-15 UTC: all nineteen original profiles have complete
checked topology. The [current checkpoint](reference_validator_checkpoint.md)
and [shell/dumbbell family summary](../evidence/reference_validator_remaining_topology_v1/family_summary.json)
supersede the smaller counts in dated delivery history below. Region-volume
precision is a separate construction and acceptance gate.

## Fixed-probe partition

For the frozen expanded radius `R_i=r_i+p`, write
`q_i(x)=||x-c_i||^2-R_i^2` and define the closed clipped power cell
`P_i=D intersect {q_i<=q_j for every j}`. Differences of the q functions are
affine, so each P_i is a bounded rational convex polytope. Their union is D;
empty and lower-dimensional cells are retained, not silently discarded.
On P_i the strict physical free set is exactly `P_i minus closed_ball(c_i,R_i)`.
Every source atom participates in deriving the inequalities, including distant
large-radius blockers and coincident centers. Equal coincident balls can have
identical cells; their shared geometry is glued rather than counted twice.

[Aurenhammer 1987](https://doi.org/10.1137/0216006) supplies the established power-
diagram definition and polyhedral context. The completeness argument below is
explicitly derived here from convexity and polyhedral linear programming; it is
not attributed as a theorem proved in that article. No external geometry engine
is executed. This is not a claim of method novelty.

Power is used only to partition the **fixed-probe** exclusion problem. Its sign
is equivalent to spherical exclusion; its magnitude/order is not additive
clearance or a bottleneck. Weights `(r_i+p)^2` depend on p. This does not replace
DFND's ordinary Delaunay carrier or additive local capacities with weighted ones.

## Local completeness lemma: a convex polytope outside one ball

Let P be any nonempty bounded convex polytope, including lower-dimensional ones,
and K a closed ball. Construct a graph of the vertices outside K and precisely
those polytope edges whose **entire** segments avoid K. The graph components
are in bijection with the connected/path-connected components of `P minus K`.
The graph is not claimed to recover higher homotopy or every Betti number.

The proof has four parts:

1. **Open convex caps cover the free set.** For any x outside a ball centered
   at c, put u=x-c. The cap `P intersect {u*(y-c)>R*||u||}` contains x and is
   wholly outside K by Cauchy--Schwarz. Every nonempty cap contains a vertex
   of P: a linear functional reaches its maximum at a vertex. Every free
   point thus connects to a free polytope vertex inside such a convex cap.
2. **A cap's vertex graph is connected.** From any non-maximal vertex, an
   increasing edge exists for its linear functional. Following increasing
   edges stays strictly inside the cap and reaches its maximizing face.
   That face has a connected vertex-edge graph. Flat maximizing faces and
   non-simple vertices do not require perturbation.
3. **Two intersecting caps have an edge/vertex bridge.** Write their strict
   affine inequalities as f>0 and g>0. Maximize t over
   `x in P, t<=f(x), t<=g(x)`. The optimum is positive. At an optimal vertex
   of this lifted polyhedron, at most two active inequalities are the new
   t bounds; the remaining active constraints put x on a face of P of
   dimension at most one. Thus the caps intersect a polytope vertex or edge.
   On that edge each cap occupies an interval adjacent to an endpoint.
   They either share a vertex or their overlapping intervals cover the
   whole edge and join free endpoints. That edge avoids K completely.
4. **These bridges prove completeness.** Associate a free point with the graph
   component of any cap containing it. Parts 2--3 make this independent of
   the chosen cap. Unions of caps associated with different graph components
   are disjoint relatively open sets partitioning the free set. Within each
   union, convex-cap paths and graph edges connect every point. No additional
   component can lack a free polytope vertex.

The irrational supporting thresholds above are existential proof tools, not
numerical inputs to the algorithm. All implemented decisions use rational
vertices and exact squared whole-segment distance comparisons. For a free
point x, maximizing `(x-c)*(v-c)` over the cell vertices gives a supporting-root
vertex v: its value is at least `||x-c||^2`. The segment x--v therefore has
nondecreasing squared distance and is independently checkable.

## Global completeness and free boundary patches

Two clipped power cells meet in a common exposed face (`q_i=q_j`), including
degenerate and identical-cell cases. Every component of the free subset of
that face contains a face vertex by the local lemma. Face vertices/edges are
vertices/edges of both cells. Consequently two local free pieces intersect
exactly when their graph components share a free geometric vertex.

Glue identical rational free vertices and all checked free edges. Local free
components form a **finite relatively closed cover** of the physical free set:
cells are closed and their finitely many components are relatively closed.
Intersection-graph gluing therefore proves all global components and their
separations. Omitting a source cell or a lower-dimensional incidence is invalid.

Apply the same argument to the finite cover by cell/domain-face intersections
to recover free patches of the declared domain boundary. Retain free vertices
on a domain face and free edges whose endpoints share that **same** domain
face. An edge connecting different boundary points through the interior must
not merge boundary patches. Each boundary patch has one incident global free
region; one region may meet several patches or none. No biological Mouth label,
area, optimal bottleneck or infinite-exterior interpretation follows by itself.

## Producer/checker separation

The producer clips an exact bounding box successively by the domain/power
halfspaces, retaining full vertex geometry and degeneracies. The box is only a
computational enclosure. It proposes a bounded supporting subset per cell.

The checker independently enumerates **all** feasible independent plane triples
for that subset. All six enclosing box planes must be included. Every resulting
vertex must satisfy **all** original domain and all-atom power inequalities.
Since the subset contains the true cell and is bounded, this proves reverse
containment as well: the subset polytope equals the true cell. An empty bounded
subset proves emptiness; a coincident dominating ball has a direct algebraic
infeasibility witness. Cell/atom coverage is exhaustive and source-bound.

The producer finds edges from shared vertex-active-plane ranks. The checker
instead enumerates independent plane pairs and their common verified vertices.
It recomputes free vertices/whole edges against the original atomic balls and
independently assembles components with disjoint sets, rather than trusting the
producer's graph search or proposed counts. The same independent checks apply
to boundary incidence. Arithmetic, convex/polyhedral lemmas above and the
declared exact enumeration are the trusted base, not a machine-checked proof
of Python or a second copy of an unchecked topology routine.

Region supports are recoverable through source cells, strict sphere exclusion
and vertex-component membership. A free anchor is assigned using the checked
supporting-root segment. Different complete region IDs prove separation;
equal IDs yield a continuous path through checked graph edges. IDs are scoped
to the model/certificate; no cross-probe ordinal identity is assumed.

## First implementation controls and remaining scope

Freeze analytic multi-ball controls before receiving: two transverse ball
barriers with three free regions, their exact-contact `1/3/3` transition,
unequal radii, coincident/identical/dominated cells, lower-dimensional gluing,
and eight corner balls enclosing a tiny central region followed by exact
complete union coverage. Preserve gaps of `2^-80` without float conversion.
Test missing cells/edges, false joins/separations, wrong weights/source units,
corrupt bounds and fresh saved reading without DFND, producer or NumPy.

The [20-profile protocol](../evidence/reference_validator_power_cells_v1/protocol.json)
contains seventeen analytic controls and three **reused saved** original
tetrahedron models from the previous panel archive. Analytic fixture definitions
and assertions were written test-first; the JSON protocol was frozen after
unit prototypes and before retained committed-source receiving. It is not
presented as a blind pre-prototype experiment. Positive original tetrahedron
counts are left unspecified in that protocol: complete counts must come from
the checked construction, not a label or assumed ideal answer.

The two-barrier controls use centers `(+/-8,0,0)`, atomic radii 4 and domain
`[-20,20] x [-3,3] x [-4,4]`. At expanded radius 5 each complete `x=+/-8`
section is covered. Every free point in each of the three open slabs can move
monotonically away from its nearest barrier toward an end section or `x=0`;
these sections are free and connected. This proves three regions. Just below
5, the corner line `(x,3,4)` also joins the slabs, giving one. The same argument
survives the `2^-80` positive/negative perturbations and the unequal 5/6-radius
control. The boundary surface connects around each excluded cross-section,
giving respectively one or three free boundary patches.

For eight centers `(+-1,+-2,+-2)` in their center hull, the nearest-center
squared distance is `(1-|x|)^2+(2-|y|)^2+(2-|z|)^2`, whose maximum is 9 at
the origin. Radius `3-2^-80` leaves a connected central free set: moving each
absolute coordinate toward zero increases every nearest-center distance.
The boundary has maximum nearest-center distance `sqrt(8)<3-2^-80` and is
covered. Radius 3 or larger covers the entire hull exactly. This independently
establishes the `1/0/0` region and `0/0/0` boundary transition.

For the rational regular tetrahedron with vertices `(1,1,1)`, `(1,-1,-1)`,
`(-1,1,-1)`, `(-1,-1,1)`, all centers have squared norm 3. Along a ray from
the origin inside the tetrahedron, the nearest-center squared distance is
`3-2*t*max_i(u*c_i)+t^2*||u||^2`; it decreases up to the hull boundary
because that boundary lies before the nearest-center radial minimum. Hence
the inequality `max_i(x*c_i)>=||x||^2`, obtained from a convex combination of
the vertices representing x, justifies that monotonicity. Thus
every free point connects toward the origin. Edge midpoint distance `sqrt(2)`,
face circumradius `sqrt(8/3)` and origin distance `sqrt(3)` independently give
`(regions,patches)=(1,4),(1,0),(0,0)` at radii `3/2,5/3,7/4`. These statements
refer to these rational controls; the original binary64 tetrahedron is received
and checked as its own exact numerical model.

Then measure small original inputs before expanding. Initial execution is local,
one CPU/thread, finite memory/time/work ceilings and conservative host reserves;
Slurm is not needed in this phase. A budget stop is unresolved, never empty.

This route initially qualifies topology/boundary incidence and anchor claims.
Nonempty per-region volumes still require certified integration (P4); tight
volume bounds are not substituted for topology. No native fix, general release,
protein phase or comparative-superiority claim is inferred from this design.

`docs/content/dfnd/geometry_and_probe.md`, `validation_and_scope.md` and the
worked tetrahedron were reviewed for interpretation. This independent reference
construction changes no native operator, public promotion, probe convention or
Topography classification; no method-book formula needs replacement. The
previous BenchLab panel remains historical source-scoped evidence.

## Retained committed-source receiving — 2026-11-14 UTC

Source `bb308baddc52098f73f1fe9e8b5a185dc7aa7c21` runs the frozen protocol,
saves every Model/certificate, reads both again and independently checks them.
The [receipt](../evidence/reference_validator_power_cells_v1/receiving/receipt.json)
binds all eighty supporting files and all thirty-two Python source files;
the [external execution record](../evidence/reference_validator_power_cells_v1/execution.json)
retains host resources, exact command, limits and receipt digest. The producer
tree is clean; the separate human `_version.py` edit is not part of this
developer computation. There is no fresh native/provider/quantity receiving.

| Original tetrahedron probe | Complete regions | Free hull patches | Disposition |
| --- | ---: | ---: | --- |
| 1.2 Å | 1 | 4 | All four boundary patches attach to the same complete free region. |
| 1.4 Å | 1 | 0 | One enclosed region; the origin is assigned to it. |
| 1.7 Å | 0 | 0 | Exact empty free set, consistent with the earlier tetrahedral cover. |

The seventeen analytic controls also meet their independent expectations,
including the `1/3/3` and `1/0/0` exact-contact transitions, lower-dimensional
power cells and separate boundary-patch count. The original tetrahedron's new
complete inventories strengthen its earlier local statements; they do not
rewrite the source-scoped earlier report or fix native carrier qualification.

The whole bounded process takes **1.764 s**, peak child RSS **23,800 KiB**,
one CPU/thread, a 2 GiB address-space ceiling and 50 CPU/60 wall-second limits.
Internal capture takes 1.651 wall / 1.641 CPU seconds. These tiny controls are
not competitive measurements. The receiving contains 81 JSON files / 477,164
bytes; protocol and execution are additional records. Requested nonempty-region
volume precision remains uncomputed. Source, schema and exact rational
decisions are preserved; no float approximation discards small features.

### First narrow-tube attempt is unresolved

After that receiving, the
[separately frozen narrow pilot](../evidence/reference_validator_power_cells_v1/narrow_pilot/protocol.json)
selects the **same exact saved** 81-atom model at 1.4 Å. Its earlier boundary
reference supplies two expected free patches; no global component count is
assumed. The first execution ends with signal 9 after **52.030 s**, peak RSS
**28,908 KiB**, under the same one-CPU/2 GiB/50 CPU/60 wall-second envelope.
This is consistent with the hard CPU ceiling, but the signal alone is not an
independent diagnosis. Neither a completed certificate nor a final receipt is
emitted. The [disposition](../evidence/reference_validator_power_cells_v1/narrow_pilot/disposition.json)
therefore retains unknown topology/boundary counts and no physical answer.

Next under #76: profile the exact construction, then justify a larger bounded
sequential budget or a mathematically equivalent clipping order. Retain every
all-atom inequality and the independent verification; do not tune geometry or
expected counts to fit execution time. This dated stop does not qualify the
tubes, diagnose DFND or establish a permanent limitation of the construction.

## Exact working-plane continuation — 2026-11-14

The first-cell profile identifies repeated rational evaluation in edge
reconstruction: 79,305 plane evaluations for original source atom 0. The
producer now retains active working planes and the fixed enclosing box when
finding edges. A plane strictly slack at all current vertices is strictly
slack on their convex hull and every later clipped subset. It cannot support
an edge or become active later. Equality is retained exactly, including
lower-dimensional incidences. Every original inequality is still processed,
included in the final active-support extraction and checked independently.
There is no cutoff, epsilon or selected-obstacle approximation.

All twenty frozen pilot certificates are reproduced **exactly**, including
every cell, vertex, edge and final partition. The independent checker is
unchanged. The same instrumented first cell uses 44,555 plane evaluations and
retains the same seventeen support planes/seventeen vertices. The
[diagnostic profile](../evidence/reference_validator_power_cells_v2/profiling.json)
binds the input, source bytes and raw cProfile output. Its one-run timings
include profiling overhead; they are not whole-engine or competitive evidence.

The receiving helper now saves the exact Model before construction, retaining
the input when a run stops. Completed profiles additionally record separate
model receiving, construction, saved reading, verification and anchor-query
wall/CPU costs. A partial directory is not a completed receiving or physical
absence result. The final receipt still binds every saved JSON record.

The [repeat protocol](../evidence/reference_validator_power_cells_v2/protocol.json)
preserves the previous exact 81-atom Model/probe/anchors and unspecified global
count. The measured stop/profile justify a first 180 CPU/240 wall-second
envelope, still one CPU/thread and 2 GiB, with host samples every five seconds.
The envelope is a finite ceiling, not a resource reservation. Actual committed-
source receiving is recorded separately; other original profiles, per-region
precision and native #181 keep their gates.

### The repeat constructs and verifies the complete narrow-tube topology

At source `fd3eeb7e6a5df99ad1781f63c090355fe497eaf1`, the repeat constructs all
81 original power cells and saves a complete certificate (1,833 cell vertices,
at most 31 supporting planes per cell). Its independently saved
[verification](../evidence/reference_validator_power_cells_v2/receiving/original_narrow_tube_1_4/verification.json)
establishes **one free region and two free hull patches** at 1.4 Å. Every
source sphere remains included. This is the first complete global inventory
for this original profile; the earlier point/path references keep their scope.

The broader capture subsequently stops during repeated anchor checks, after
190.237 wall / 179.713 CPU seconds under the hard 180 CPU-second ceiling,
peak child RSS 37,568 KiB. The
[execution record](../evidence/reference_validator_power_cells_v2/execution.json)
contains five-second host samples and the exact supervisor source. The
[disposition](../evidence/reference_validator_power_cells_v2/disposition.json)
separates a completed mathematical proof/verification from incomplete later
query/manifest receiving. No final capture receipt or phase summary was emitted.
An input/partial directory alone is insufficient; the retained complete
certificate can nevertheless be independently checked on its own.

### Detached query batches and explicit saved-certificate reading

`verify.power_cells.query_anchors` now detaches a complete proof, independently
checks it once for a bounded batch, then assigns the named anchors and answers
their pairs from that same checked result. Each positive continuous path is
still independently checked against every ball. No unchecked result is accepted
from the caller and no verification cache crosses calls. Unit/model/certificate
bindings stay in the detached output. Existing individual point/path operations
retain their checking semantics.

The receiving helper can explicitly reuse a saved certificate by its raw file
SHA-256 and original producer revision. It still reads the exact Model and
independently verifies the proof; the receipt distinguishes `saved_certificate`
from `constructed_here`, and the phase records saved reading rather than a new
construction. The [saved-reading protocol](../evidence/reference_validator_power_cells_v3/protocol.json)
freezes that route before actual receiving, preserving all physical inputs,
the original unspecified expected global count and the finite 180 CPU/240 wall-
second one-CPU/2 GiB envelope. This does not rerun or credit the constructor.

### Saved narrow receiving completes at source 92679fc

Source `92679fc2d97c3d72108f35c79fc1a0c06c3cd471` completes the v3 saved-reading
protocol and all named queries. The raw certificate is identical to the v2
producer's file (`21564404d3b16cf659202040982e9300d10e6b002d5aab157839f05d552311e2`).
The [receipt](../evidence/reference_validator_power_cells_v3/receiving/receipt.json)
records `saved_certificate` and original producer `fd3eeb7`, not a new geometry
construction. Six JSON receiving files total 1,579,275 bytes. The
[supervised execution](../evidence/reference_validator_power_cells_v3/execution.json)
binds every saved byte, exact command/source, fourteen host samples and the
supervisor source. The scientific source tree is clean.

The full saved-reading process takes **68.683 wall / 66.497 CPU seconds**, peak
RSS **34,144 KiB**, one CPU/thread and a 2 GiB ceiling. Complete verification
takes 34.878 wall / 32.833 CPU seconds; the detached anchor batch takes
32.577 wall / 32.478 CPU seconds, including its own complete check. This
separates one initial saved verification and one batch verification from the
earlier per-anchor repeats. It does not give a fresh-construction runtime or
change the proof assumptions. Available memory stays above 49.80 GiB, with
zero sampled memory pressure and no pressure stop.

The origin is blocked. Lower and upper interior anchors are strict free and
belong to the single complete region, which meets both free hull patches. A
recovered **28-point continuous path** is separately checked against every
source ball and the original hull. The complete count remains one region/two
patches. Nonempty per-region volumes remain uncomputed; no biological Mouth,
native Channel promotion or #181 correction follows from reference membership.

This supersedes the former missing complete topology/query receiving for the
**same original narrow 1.4 Å Model**. Both earlier interrupted runs and their
own scopes remain unchanged. Next under #76: qualify the other frozen
narrow-tube probes and the wider six-case topology panel, then complete certified
clipped/per-region integration. Native carrier/path qualification remains #181;
the complementary tetrahedral-grid route is still proposed, not implemented.

## Probe-family geometry reuse — 2026-11-14

For fixed atoms, changing p to p' changes `q_i-q_j` by
`-2*(p'-p)*(r_i-r_j)`. Common atomic radii therefore leave the complete power
partition unchanged. This is not generally true for unequal radii. The
`reprobe_certificate` producer admits only identical complete model records
apart from the probe **and exact equality of every canonical source power
inequality**. It detaches and independently checks the original source proof
before reusing its complete cell geometry. Changed atoms, domain, frame,
source identity, arithmetic convention or power inequalities are rejected.

For coincident centers, the power comparison is constant rather than a plane.
Its true/false/tie class is checked through the original coincident-radius
ordering, which is unchanged for fixed nonnegative radii/probes. The exact
plane-equality condition applies to every nonconstant canonical halfspace;
no constant infeasibility witness or duplicate cell is dropped.

For the target probe it recomputes every free vertex, every whole-edge
collision predicate and all global/boundary partitions. The source's topology
and node inventory are not copied. The proposed target proof still needs its
own independent target verification. Small test-first controls cover the exact
`1/3/3` transition with `2^-80` gaps, complete exclusion, corrupt source proofs,
changed nonprobe fields and rejected unequal-radius weight changes. The old
twenty pilot certificates keep their exact contents after the shared helper
refactoring. No monotone component-count rule is imposed.

The receiving protocol explicitly distinguishes `reprobed_geometry` from
fresh cell construction and unchanged saved-certificate reading. Its origin
retains source Model/certificate raw SHA-256 values and original geometry
producer revision; the current receipt revision identifies the new target
classification/proof proposal. A source proof is checked on every reprobe;
there is no persistent verification cache. Competing saved routes are rejected.

The [frozen remaining-narrow-profile panel](../evidence/reference_validator_power_cells_v4/protocol.json)
selects the original **saved** 1.2/2.5 Å Models from the nineteen-profile
archive, with no new quantity receiving. Positive global count is unspecified
before execution. Earlier independent boundary references and complete empty-
hull cover supply the respective boundary/negative expectations. Two separate
sequential workers each retain one CPU/thread, 2 GiB, 180 CPU/240 wall-second
limits and five-second host checks. Expected cost includes checking the source
proof, target reclassification, target proof verification and named queries;
these are not fresh cell-construction timings. Actual committed-source
receiving remains separate from the frozen protocol and source controls.

### The original narrow family is received completely

Source `d73477c534c9a23f89d57bced6757e06d73581bc` now receives the original
1.2/2.5 Å target Models through the declared geometry-reprobe route. The
source geometry remains the original `fd3eeb7` 1.4 Å construction; no fresh
cell clipping is claimed. Every source proof is independently rechecked,
every target availability/incidence is recomputed, and each target proof and
query batch is independently checked. The scientific source tree is clean.

| Probe | Complete regions | Free hull patches | Origin | Target result |
| --- | ---: | ---: | --- | --- |
| 1.2 Å | 1 | 2 | free | A separately checked 28-point path connects the earlier interior anchors. |
| 1.4 Å | 1 | 2 | blocked | Earlier `92679fc` saved receiving remains unchanged. |
| 2.5 Å | 0 | 0 | blocked | Complete empty free set and exact `[0,0] nm**3` total volume. |

The positive global count was not set by the new protocol. Earlier independent
boundary references and the negative conservative cover are met; the new
complete region count follows from the checked construction. This does not
qualify native candidates or impose monotone counts on other geometries.

For the 2.5 Å negative profile, each complete checked convex source cell has
all vertices within its owner's expanded ball. Ball convexity therefore covers
the entire cell, and the exhaustive cell partition covers the hull. This is a
whole-hull exclusion proof; the separate 31 native-center point checks do not
acquire that completeness argument. Strict contact remains excluded.

The [1.2 Å receiving](../evidence/reference_validator_power_cells_v4/probe_1_2/receiving/receipt.json)
takes **123.483 wall / 114.327 CPU seconds**, peak RSS **36,020 KiB**. Its
source-proof check/target reclassification takes 48.769 wall seconds, target
verification 38.245 and anchor queries 35.312. The
[2.5 Å receiving](../evidence/reference_validator_power_cells_v4/probe_2_5/receiving/receipt.json)
takes **79.879 wall / 79.782 CPU seconds**, peak RSS **34,668 KiB**; corresponding
phase costs are 33.899, 22.462 and 22.434 seconds. The latter query checks the
blocked origin; it does not invent a pair of free connection anchors.

The two sequential one-CPU/thread workers each use the frozen 2 GiB/180 CPU/
240 wall-second ceilings, with five-second host checks. Total new work is
203.362 wall / 194.109 CPU seconds. Forty-one host samples have no measured
memory pressure and preserve at least 49.62 GiB available RAM. These costs
include source and target checking, not fresh geometry construction. Earlier
construction, interrupted attempts and 1.4 Å saved-replay costs stay separate.

The [structured family summary](../evidence/reference_validator_power_cells_v4/family_summary.json)
binds the three exact Models, complete certificates, source/target producer
scopes, query results, phase/resource records and volume enclosures. Source
geometry, model/frame/input hashes and every original artifact remain unchanged.
At this narrow-family delivery, six of the nineteen original profiles have
complete topology; thirteen and certified nonempty region integration remain under #76.
The narrow reference family is complete; native #181/#180, wide #184 and dumbbell #188
retain their scopes, with no public morphological promotion or protein phase.

## Complete original wide family — 2026-11-14

The [frozen wide plan](../evidence/reference_validator_power_cells_wide_v1/plan.json)
selects the same saved 77-atom Models at 1.4/2.5/5 Å, without changing a
coordinate, radius, domain or frame. All balls have radius 1.88 Å, so the
probe-family equality criterion above applies. A three-cell feasibility
preflight precedes full construction; positive global counts are unspecified
before receiving. Earlier two-patch references and the negative sufficient
cover remain independent controls, rather than catalog labels as truth.

Source `38f5a86381db9cc83b79d82066cdaf4482eb9aaa` constructs and independently
checks the complete wide 1.4 Å geometry with an empty query set. Initialization
uses 183.539 wall / 178.553 CPU seconds, peak RSS 38,160 KiB. The later
[three-profile protocol](../evidence/reference_validator_power_cells_wide_v1/protocol.json)
binds its exact Model/certificate file hashes and original geometry producer.
Source `9c79ad797730428bb7ec69b6dc6ccaa33dbe911c` reads the unchanged 1.4 Å
proof and independently rechecks/reprobes that geometry at 2.5/5 Å. Every
target has its own complete topology verification and detached anchor batch.

| Probe | Complete free regions | Free hull patches | Origin | Additional checked result |
| --- | ---: | ---: | --- | --- |
| 1.4 Å | 1 | 2 | free | 26-point path between exact lower/upper hull-end anchors. |
| 2.5 Å | 1 | 2 | free | 26-point path between the same declared hull-end anchors. |
| 5 Å | 0 | 0 | blocked | Exact zero total probe-center volume in the finite hull. |

Both positive anchors belong to the same complete region and distinct boundary
patches. Their paths are independently checked against every original ball;
IDs remain scoped to each Model/certificate. At 5 Å every complete checked
convex cell has all vertices inside its owner's expanded ball. Ball convexity
therefore proves the full hull covered. Nonempty per-region precision is not
computed; these topology and path results do not provide aperture area or an
optimal bottleneck.

The new free boundary partitions match the previous independent certificates
**face by face**, using sorted source atom IDs. Each end patch has three free
faces at 1.4 Å and two at 2.5 Å, with none among the 68 wall faces. At 2.5 Å
the negative-end faces are `[2,4,8]`, `[2,8,10]`; the positive-end faces are
`[67,69,75]`, `[69,71,75]`. This recovers the reference pieces without equating
validator, old-reference and native face ordinals. Native #184's `face 12`
numerical ambiguity is not diagnosed or fixed by this matching alone.

| Later worker scope | Wall seconds | CPU seconds | Peak RSS KiB |
| --- | ---: | ---: | ---: |
| 1.4 Å saved proof/queries | 84.379 | 84.307 | 34,772 |
| 2.5 Å source check, reprobe, target verification/queries | 138.635 | 138.489 | 36,352 |
| 5 Å source check, reprobe, target verification/query | 100.525 | 97.615 | 35,228 |

Summed profile worker costs are 323.540 wall / 320.410 CPU seconds. Including
initialization gives 507.079 wall / 498.963 CPU seconds; interstage development
and protocol preparation are excluded. All four workers are sequential with
one CPU/thread and 2 GiB ceilings, initialization at 300 CPU/360 wall seconds
and profiles at 240 CPU/300 wall seconds. Across 103 host samples, available
RAM stays at least 49.68 GiB and measured memory pressure is zero. These are
execution records, not reserved resources or a competitive timing study.

The [family summary](../evidence/reference_validator_power_cells_wide_v1/family_summary.json)
binds receipts, Models, proofs, queries, phases, execution costs and the earlier
face references. All 32 validator Python files retain their previous qualified
bytes, recorded in the [source snapshot](../evidence/reference_validator_power_cells_wide_v1/source_qualification_reuse.json).
The new receiving guards additionally check saved positive/negative proofs in
fresh processes without the producer, DFND or scientific libraries.

At that wide-family delivery, nine of nineteen original profiles have complete
topology: tetrahedron and both tubes. The subsequent
[shell/dumbbell receiving](../evidence/reference_validator_remaining_topology_v1/family_summary.json)
completes all nineteen profiles; the [current checkpoint](reference_validator_checkpoint.md)
records it with separate resources. Certified requested nonempty per-region
precision remains under #76. Native #181 public qualification and #184 numerical handling
are unchanged; no comparative-finding resolution, new geometry/provider,
protein phase or public morphological promotion follows. The original frozen
case artifacts and all earlier source-scoped receiving remain unchanged.

## Proof/trust review — 2026-11-14, work package A

The post-tube review maps every completeness obligation to the implementation.
This is a review of the stated mathematical argument and bounded controls, not
a formal proof of Python or qualification of unexecuted input families.

| Obligation | Producer / independent checker | Shared trusted foundation |
| --- | --- | --- |
| Exact source partition | `proposed_planes` expands affine power differences; checker `_planes` expands separate polynomial coefficients and also checks direct all-source power inequalities. | Exact Model/scalar decoding, canonical halfspaces and domain planes. |
| Complete convex cells | Producer clips successively; checker enumerates every feasible supporting-plane triple, proves boundedness and checks all original inequalities. | Rational/integer arithmetic and elementary convex-polyhedral facts. |
| Whole-edge availability | Producer enumerates vertex-pair active ranks; checker reconstructs edges from independent plane-pair intersections and scans all atomic balls. | Exact squared whole-segment predicates; contact is excluded. |
| Complete global regions | Producer graph traversal; checker disjoint-set reconstruction and exact partition comparison. | Convex-cap/skeleton lemma, finite closed-cell cover and shared geometric incidences. |
| Boundary patches and incidence | Only edges sharing a declared domain face glue boundary nodes; checker reconstructs patch supports and region incidence. | Exact domain-face membership; finite-domain interpretation. |
| Anchor/path claims | Supporting-root association plus complete path checking. | Convex-cap path argument and all-atom segment predicates. |

The cap argument covers point, segment and polygonal cells as well as 3D ones.
Identical cells glue on identical rational vertices; dominated coincident
cells retain an algebraic infeasibility witness. Shared-face free components
contain shared face vertices by the same lemma, so those incidences cannot be
discarded. Boundary gluing deliberately excludes interior shortcuts. A finite
relatively closed cover justifies global separation once all local pieces and
their intersections are exhausted. No unresolved obligation was identified in
this bounded review; the declared trusted mathematical/arithmetic base remains.

`test_reference_validator_proof_review.py` adds source-order, exact boundary-
contact, coincident/redundant eight-corner and content-corruption controls.
Covered coordinate planes separate the eight orthants, while monotone motion
toward each corner proves each orthant's free part connected. Thus the expected
eight regions/patches do not come from either graph implementation. Removing
an edge/free vertex or forging region/boundary gluing is rejected geometrically,
without depending on a file digest. Existing tiny-gap, unequal-radius,
lower-dimensional and transformed-model controls remain in the selection.

## Checked power-cell progress — work package B

`power_runs.py` and the separately importable `verify/power_progress.py` add
source-bound prefix construction and manifest-last saved bundles. Every
retained cell is reconstructed independently before reuse. The progress record
binds exact model, source/runtime fingerprints and work policy; changed requests,
missing/boolean source IDs, corrupted cells and torn bundles are rejected.
The empty-obstacle inventory uses its explicit single domain-cell sentinel.

Cooperative stopping is checked inside clipping and supporting-plane triple
enumeration. An interrupted cell is discarded, while completed verified cells
can be saved. Global counts stay unavailable even for a locally complete
progress record until `finish_power_run` assembles and independently verifies
the exhaustive proof. The default certificate schema and earlier exact pilot
contents remain unchanged. Receiving can explicitly select `cell_batch` to
retain immutable progress bundles; old protocols keep their original route.
Saved-check/rechecking costs are part of the measured receiving, not free reuse.

## Complementary tetrahedral reference proposed by the maintainer

Any full-dimensional tetrahedron with vertices v0..v3 has coordinates
`x=v0+u*(v1-v0)+v*(v2-v0)+w*(v3-v0)`, with `u,v,w>=0` and `u+v+w<=1`.
Uniform steps in these barycentric coordinates give a reproducible sampling
inside each tetrahedron; they are not necessarily uniform physical distances
on skew/slender cells. Ordinary Delaunay is a convenient complete hull carrier,
not a requirement for the physical exclusion test.

Every sample must test the probe against **all** source atomic balls, not only
the tetrahedron's vertices. Every proposed link needs a complete all-atom
segment check. Shared-face coordinates must match between neighboring cells;
edge/vertex incidences and strict-contact closure remain explicit. For certified
coverage, classify complete subcells, retain unresolved portions and give valid
volume bounds. Point sampling alone cannot exclude a missed narrow passage or
small component. A complete negative/separation statement requires its own
cover/outer-representation proof, not failed finite exploration.

Reusing DFND's entire tetrahedral mesh can give a useful independent physical
checker while sharing a carrier. Verify that the mesh covers the exact hull
without gaps/overlaps and has matching incidences; do not consume only DFND-
selected features or treat shared triangulation as fully independent evidence.
This is a complementary route under #76, not a replacement of the exact
multi-ball construction or an already delivered second validator.
