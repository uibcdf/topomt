"""Local namespace for the bundled standalone checker."""
