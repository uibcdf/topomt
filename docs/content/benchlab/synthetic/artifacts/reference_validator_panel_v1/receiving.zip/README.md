# Six-case reference-validator panel

Producer: 2b21cb2ee63093734ff71f1f70bd4ede7a53ebbb. Read summary.json and protocol.json first.
All numerical models/proposed certificates/independent outcomes are retained.
MANIFEST.json binds every included file; check SHA-256 before interpreting data.
The exact developer checker source is included. From this archive's root:

python -m devtools.reference_validator verify receiving/cases/regular_tetrahedron/profile_2/tetrahedron_model.json receiving/cases/regular_tetrahedron/profile_2/queries/tetrahedron_partition.certificate.json

Saved checking uses only Python standard-library modules, without TopoMT, DFND,
NumPy or PyUnitWizard. A rejected path candidate is not a disconnection proof.
Re-running source receiving needs the exact committed checkout and the recorded
quantity dependencies. This archive is not an installed package/support matrix.
Case execution complete does not mean general topology/precision complete.
