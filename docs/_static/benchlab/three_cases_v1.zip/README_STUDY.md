# TopoMT three-case study

Use the qualified TopoMT Python 3.14 source-development environment. Environment inputs and exact suite source pins are included under devtools/. They describe the tested source route, not a newly qualified public installation.

Open docs/content/benchlab/synthetic/CASE/public_topography.ipynb in Jupyter; run from that notebook directory in a fresh kernel. Start with regular_tetrahedron, then closed_shell and shell_with_opening. Original providers and servers are not run. The closed parent is included for the opening subset. The older notebooks are frozen history: the new topography stage links their current dispositions.

MANIFEST.json identifies every included source byte. Source dependency acquisition may require network access when preparing an environment; Run All does not.
