# Wide, sparsely sampled straight-tube study

Start at `docs/content/benchlab/synthetic/straight_tube_wide_sparse/system.ipynb`,
then `dfnd.ipynb`. Run each from its own case directory in a fresh Python 3.14
kernel. All code is included; long inputs are expandable on the website.
Run All replays independent references and calls the actual public DFND API.
It neither rewrites retained evidence nor submits coordinates to providers.

Prepare TopoMT source **3ad9515019e722c0ccf4ade7a3024de4166e217e** separately,
using the development environment in `devtools/conda-envs/development_env.yaml`
and reviewed suite inputs in
`devtools/requirements/controlled_suite_dependencies_py314.txt`. Confirm the
printed imported module path and actual producer version. This archive contains
the study, independent checkers, shared receiving and reading context; it is
not a TopoMT installation or a fully locked environment. Source acquisition can
need network access. Source receiving does not qualify an installed release
or an interpreter/platform matrix.

The fixed system has 77 argon balls of radius 1.88 Å, ring radius 6 Å, nominal
sampling 3.5 Å and length 20 Å. Full-precision quantity-aware coordinates define
its geometry; the PDB supplies topology only. Probes are 1.4, 2.5 and 5 Å.
Both radius and sampling differ from the narrow companion. The shared 2.5 Å
probe passes this wider tube and is excluded from the narrow finite carrier;
this does not isolate a density effect.

The 1.4 Å global physical count and Channel contacts resolve; other associations
remain unknown. At 2.5 Å the physical count is numerically unresolved (#184),
while the selected interior path is clear. At 5 Å budget #180 and local/all-atom
qualification #181 remain open. Wider physical paths remain #76. No original
third-party comparison, optimal path, aperture area, exact physical volume or
biological superiority is established. Original observations/producer versions
are retained. The first attempted capture is preserved but is not accepted as
portable attribution (#185); the corrected new execution preserves bibliographic
strings and the same scientific outcomes. See the artifact README for chronology.

Verify every included byte from the extraction root:

```python
import hashlib, json
from pathlib import Path
root = Path.cwd()
manifest = json.loads((root / 'MANIFEST.json').read_text())
for name, expected in manifest['files'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
```

Other included studies retain their own dated scopes. Previous published ZIPs
are unchanged. Native JSON is development evidence, not a versioned public
Topography interchange format. Run All displays newly executed results alongside
original observations, with their source and version identities kept separate.
