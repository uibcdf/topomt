# Narrow, densely sampled straight-tube study

Current system identifier: `straight_tube_narrow_dense`. Start at
`docs/content/benchlab/synthetic/straight_tube_narrow_dense/system.ipynb`, then `dfnd.ipynb`.
Execute each from its case directory in a separate fresh Python 3.14 kernel.
Run All replays independent references and runs the actual public DFND API;
it makes no original-provider/server call and does not overwrite evidence.

Prepare TopoMT source **107c291cf8c6fa0663793fa32a96cd975e49589e** separately, using the development environment
in `devtools/conda-envs/development_env.yaml` and reviewed suite source inputs
in `devtools/requirements/controlled_suite_dependencies_py314.txt`. Confirm the
printed module origin. This archive contains the study/reference helpers and
reading context, rather than a TopoMT installation. Acquisition of the source
environment can need network access; notebook Run All does not submit inputs.

The new name describes the fixed input: nominal ring radius 3.5 Å, nominal
sampling 2.5 Å, length 20 Å and 81 argon balls. `identity.json` identifies the
unchanged frozen full-precision ball model. Original input/reference/native
records retain their original bytes and source identities; old spellings inside
that historical evidence are provenance, not supported current resource aliases.
The alternative catalog input is `straight_tube_wide_sparse`, with ring radius
6 Å and nominal sampling 3.5 Å. It has no new independent study in this delivery.

Original b07a20e native observations remain scientifically incomplete under
#180/#181, and general certified paths remain #76. Naming is not a scientific
fix or installed/platform qualification. Tables render in both Jupyter and
Sphinx; long code inputs are expandable on the web. The previous published
study archives remain unchanged historical evidence.

Verify every included byte from the extraction root:

```python
import hashlib, json
from pathlib import Path
root = Path.cwd()
manifest = json.loads((root / 'MANIFEST.json').read_text())
for name, expected in manifest['files'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
```

The source-bound route is not a fully locked environment or a release/support
matrix. Native JSON is development evidence, not a versioned public Topography
interchange format. Other included cases retain their own historical scopes.
