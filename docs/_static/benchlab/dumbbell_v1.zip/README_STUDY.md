# Dumbbell: two chambers and a neck

Start at `docs/content/benchlab/synthetic/dumbbell/system.ipynb`, then
`dfnd.ipynb`. Run each from its case directory in a separate fresh Python 3.14
kernel. Code is complete in the download and expandable on the website.
Run All replays independent references and executes the actual public DFND API;
it does not rewrite retained evidence, call original engines or submit inputs.

Prepare TopoMT source **17a4c9a521c89a64efb12ba339161e15c85d4ce0** separately,
using `devtools/conda-envs/development_env.yaml` and the reviewed suite inputs in
`devtools/requirements/controlled_suite_dependencies_py314.txt`. Confirm the
printed imported module path and actual producer version. This archive includes
the study/checkers/shared receiving/reading context, not a TopoMT installation
or a fully locked environment. Source acquisition can need network access;
source receiving does not qualify an installed release or platform matrix.

The input is 94 argon balls of radius 1.88 Å, nominal lobe radius 7 Å,
separation 12.5 Å, sampling 3.5 Å, jitter 0.1 Å and seed zero. Full-precision
quantity-aware coordinates define the geometry; the PDB supplies topology only.
Controls are 1.4, 2.2 and 6 Å. Independent complete wall/path/section certificates
prove connected enclosed named anchors and then distinct enclosed anchors;
this is not a count of every physical region. A separate whole native-hull
cover excludes every strict-free center at 6 Å. The nonconvex reference barrier
is not the native convex hull.

Actual native/public receiving gives one anchored Void with two provisional
chamber motifs/one throat at 1.4 Å, two anchored Voids at 2.2 Å and no wet/public
objects at 6 Å. The motifs retain supports and reach public `.motifs`, without
standalone Chamber-child promotion. Global physical hull availability remains
#184 at 1.4 Å and #180 at 2.2/6 Å. The physical zero-count target at 6 Å remains
strict expected failure. Prior tube #181 findings are not corrected by this
input's successful exclusion control. The later joint review is #187; the
historical component-count diagnosis is needs_review under #188. A count increase
alone need not be a defect, since shrinking free sets can fragment.

Reader revision2 fixes diagram-label escaping. `reader_attempt_v1/` retains
original source/protocol and the failed first full run; current entry notebooks
are separately executed and guarded. `reference_pilot_v1/` keeps earlier checker
bytes before formatting, with the same certificate. No scientific operator was
retuned. Actual producer versions and real detached attribution remain separate
from clean-source module identity. No original-comparator superiority, exact
physical volume/global count, optimal bottleneck or biological claim follows.

Verify every included byte from the extraction root:

```python
import hashlib, json
from pathlib import Path
root = Path.cwd()
manifest = json.loads((root / 'MANIFEST.json').read_text())
for name, expected in manifest['files'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
```

Other studies retain their dated scopes; previous published ZIPs and all five
prior case artifacts/notebooks are unchanged. Native JSON is development
evidence, not a versioned public Topography interchange format. The artifact
README explains original/protocol/reader/resource chronology and remaining work.
