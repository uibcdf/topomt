# TopoMT three-case study — reader v2

Start at docs/content/benchlab/synthetic/CASE/public_topography_v2.ipynb in a fresh Python 3.14 Jupyter kernel, working from its case directory. Use regular_tetrahedron, then closed_shell and shell_with_opening. Run All makes no server requests or original-provider executions. All inputs, parent correspondence and reference replay helpers are included.

Use the source-development environment described in devtools/conda-envs/development_env.yaml; exact suite acquisition inputs are in devtools/requirements/controlled_suite_dependencies_py314.txt. This reader is bound to TopoMT source d75d98363960f17135908b1b6af472827b4086c3. Prepare that checkout/environment separately; for example install its reviewed requirements with `python -m pip install --no-deps -r devtools/requirements/controlled_suite_dependencies_py314.txt`, then `python -m pip install --no-deps /path/to/that/topomt-checkout`. Source/environment acquisition can need network access; notebook Run All does not. Do not replace the pinned source with an unqualified released package.

This is source-bound receiving, not a fully locked environment, installed release qualification or a platform matrix. Actual receiving records retain the imported module path and dependency versions. The original system/native/comparison notebooks and public reader v1 remain dated history. The separately preserved three_cases_v1.zip is unchanged.

MANIFEST.json identifies every included source byte and the source revision. Verify its SHA-256 entries after extraction. Native support JSON is study evidence, not a versioned public Topography interchange format.
