# TopoMT straight-tube study v1

Start at `docs/content/benchlab/synthetic/cylinder_tube/system.ipynb`, then
`dfnd.ipynb`. Open each from its own case directory in a separate fresh Python
3.14 kernel; Run All needs no original provider/server call and does not overwrite
retained evidence. The system stage replays independent references without
importing TopoMT. The native stage runs the real public API.

This source-bound study uses TopoMT **b07a20ed0ee1533cc16a0b6e30ace73c2ab09ac4**. Prepare that exact source
checkout separately and use the development environment described in
`devtools/conda-envs/development_env.yaml`. Exact suite source acquisition inputs
are in `devtools/requirements/controlled_suite_dependencies_py314.txt`; review
them before installation in your chosen environment. Run the kernel with that
source installed or on PYTHONPATH and confirm the printed TopoMT origin.
The archive includes study/reference helpers and context, rather than a TopoMT
installation. Source/environment acquisition can need network access; notebook
Run All does not send molecular inputs to services. No new environment or
external executable is installed by these notebooks.

The 81-ball model, input/radius identities and three probes are fixed. Independent
references establish two-end passage at 1.2/1.4 Å and finite-hull exclusion at
2.5 Å. Initial native/public receiving is **incomplete** under #180/#181;
general certified paths remain #76. Strict expected-failure targets are pending
scientific work, not passing qualification. Read the case's artifact guide for
original failures and protocol refinements. This is not an installed release,
fully locked environment, support matrix, held-out benchmark or superiority claim.

MANIFEST.json contains the SHA-256 of every included source byte. From the
extraction root verify it with:

```python
import hashlib, json
from pathlib import Path
root = Path.cwd()
manifest = json.loads((root / 'MANIFEST.json').read_text())
for name, expected in manifest['files'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
```

The other BenchLab units and DFND book are included as linked reading context.
Their observations keep their own original software/source identities. Previously
published three-case archives are unchanged. Native evidence JSON is not a
versioned public Topography interchange format. Retained notebook outputs are
reviewed observations; rerun results are new observations for your actual kernel.
